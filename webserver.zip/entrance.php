<html>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<title>�_���ǰ|,�_���i,YongRan,��ONLINE,RAN ONLINE,yong-ran.com,enyong,yong-ran.com,yong-ran.com,yong-ran.com</title>
<style type="text/css"> 
 
 
<!--
body,td,th {
	color: #2F3448;
}
body {
	background-color: #2F3448;
}
-->
</style><script>__wm.rw(0);</script></head>
<body>
 <br>
<table id="__01" width="1024" height="768" cellspacing="0" cellpadding="0" border="0" align="center">
<!--<form form id="thisForm" method="post" action="secure.php">-->
	<tbody><tr>
		<td>
			<a href="http://yong-ran.com/main" name="django" onclick="document.getElementById('thisForm').submit();"><img src="images/en1.jpg" alt="" width="1024" height="294" border="0"></a></td>
	</tr>
	<tr>
		<td>
			<a href="http://yong-ran.com/main" onclick="document.getElementById('thisForm').submit();"><img src="images/en2.jpg" alt="" width="1024" height="51" border="0"></a></td>
	</tr>
	<tr>
		<td>
			<a href="http://yong-ran.com/main" onclick="document.getElementById('thisForm').submit();"><img src="images/en3.jpg" alt="" width="1024" height="48" border="0"></a></td>
	</tr>
	<tr>
		<td>
			<a href="http://yong-ran.com/main" onclick="document.getElementById('thisForm').submit();"><img src="images/en4.jpg" alt="" width="1024" height="51" border="0"></a></td>
	</tr>
	<tr>
		<td>
			<a href="http://yong-ran.com/main" onclick="document.getElementById('thisForm').submit();"><img src="images/cn.jpg" alt="" width="1024" height="324" border="0"></a></td>
	</tr>

</tbody></table>
</body></html>