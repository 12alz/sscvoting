<?php 
// if(ENTER != 'otep') die('Access Invalid');
	include_once('root.inc.php');
	include_once('lib/common/ItemPagination.php');
	
	include_once('lib/logic/itemcustomize.php');
	include_once('lib/logic/ChaReborn.php');
	include_once('lib/logic/character.php');
	
	include_once('control/ctl_itemcustomize.inc.php');
	include_once('control/ctl_character.inc.php');
	include_once('control/ctl_chareborn.inc.php');
	include_once('control/ctl_chareborn.inc.php');
	include_once('mixing/functions.php');
	include_once('mixing/format_items.php');
	include_once('mixing/html.php');
	
	/**
		//MIXING
		//GET MATERIALS
		//CHECK ITEM
	**/
	
	if(isset($_POST['codex'])){
		
		$itemid = clean_variable(trim(strtolower($_POST['MID'])));
		// $itemid = '136_02';
		$CID = clean_variable(trim(strtolower($_POST['CID'])));
		
		//get character info
		$character = new CharacterController;
		
		//user
		$user = new UserController();
		$CUser = $user->getUserInfo();
		
		$USER_ID = $CUser->userNum;
		//Check Char exist
		
		$html = '';
		$msg = '';
		$reset = false;
		if(isset($_SESSION['auth_user'])){	
				//get character inventory
			$reset = $character->resetPages($USER_ID);
		}else{
			$msg = 'User Must be login';
		}
		
		$data['msg'] = $msg;
		$data['reset'] = $reset;
		$data['func'] = 'resetPages_out';
		$data['html'] = $html;
		echo json_encode($data);exit();
	}else{
		$data['msg'] = 'No data found';
		$data['func'] = 'resetPages_out';
		$data['reset'] = false;
		$data['html'] = '';
		echo json_encode($data);exit();
	}
	
	
