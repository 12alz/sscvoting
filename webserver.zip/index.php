<?php
include_once('root.inc.php');
include_once('lib/logic/News.php');
include_once('control/ctl_news.inc.php');
include_once('control/ctl_rank.inc.php');
include_once('control/ctl_vote.inc.php');


$news = new NewsController;
$rank = new RankController;

// This file have to be very first included
//include "$_SERVER[DOCUMENT_ROOT]/ksantiddos.php";
//$ksa = new ksantiddos();
// Substitute your mysql_login, mysql_pass and database name below:
//$ksa->doit(10,20,'root','chrisjake102021','ksantiddos'); // allow 20 hits in 10 seconds
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title><?php echo PAGE_TITLE;?></title>
<meta http-equiv="Cache-control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<meta name="description" content="<?php echo PAGE_TITLE;?>" />
<meta name="keywords" content="<?php echo PAGE_TITLE;?>" />
<link rel="stylesheet" href="/common/css/Layout.css" />
<link rel="stylesheet" href="/common/css/MainPage.css" />
<link rel="icon"
	  href="/common/boss.ico" 
	  type="image/x-icon" />
<script type="text/javascript" src="/common/jquery-1.2.6.min.js"></script>
<script type="text/javascript" src="/common/main.js"></script>	
<script type="text/javascript" src="/common/menu.js"></script>
<script type="text/javascript" src="/common/screenshot.js"></script>
<?php include_once('js/commoncss.php'); ?>
<?php include_once('js/commonjs.php'); ?>


</head>
<body>
<div id="wrap">
<style>

#gameStart { width:153px; height:265px; top:<?php if(!$user_auth->haslogin) echo '185'; else echo '165';?>px; margin-left:17px; z-index:0; } 

</style>
    <div id="navigationMain"></div>
    

    <div id="contentsWrap">
        <div id="contentsNavi">
            <div id="loginBox" class="upstairs" style="margin-top:-20px">
<?php 
if($user_auth->haslogin){
$user = $user_auth->getUserInfo();
echo '	
<div style="background:url(\'/img/loginbg2.jpg.png\') no-repeat bottom left;width:190px;height:85px;padding-top:3px">
<div style="margin-left:20px;margin-top:-4px;color:#ffffff;text-align:left;line-height:16px;"><br>
	<strong>Hello, <span id="ctl00_UserID" style="color:#FFE32A;">',$user->userID,'</span></strong><br>

	<strong>Points: <span id="ctl00_GamePoint" style="color:#8FFAD0;">',$user->userPoint,'</span></strong> <a href=mart.php?do=itemorder><font color=#FFFFFF>[Use]</font></a> <a href=member.php?do=payorder><font color=#FFFFFF>[Get]</font></a>
		
	<!-- <strong>You\'re<font color=#FF9E04><span id="ctl00_UserType"></span></font></strong>  -->
	</div>
	</div>
	';
}else{
?>
<div id="loginIDNPW" style="margin:46px 0px 0px 0px;margin: 30px 0 0 1px!important; /* IE7+FF */">
	<iframe name="inner2" width="185" allowTransparency="true" height="80" src="member/ilogin.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no"></iframe>
</div>
<?php } ?>
    <!-- <img src="/img/common/btn_idpw.gif" style="padding-top:-4px;"/> -->
	
            <div id="subMenu">

	<div class="subMenuBox" style="margin-top:-1px;padding-left:0px;height:180px;">
	<!--<a href="/"><img src="/img/common/menu_sub1_title.png" style="padding-bottom:8px" height="31" onContextMenu="return false;" ></a>	-->
	<img src="/img/common/btn_idpw.gif" style="padding-top:-4px;">
	<table border="0" style="border-collapse: collapse;border-spacing:0;table-layout: fixed;white-space:nowrap;" >

		<tr>
        <?php 
		if($user_auth->haslogin){
		echo '	
		<td><a href="member/logout.php"><u>Logout</u></a></td>
		<td align="right"><a href="member.php?do=getbackpwd"><u>Find Password</u></a></td>
		';
		}else{
		?>
		<td><a href="javascript:menu(1001);"><u>Register</u></a></td>
			<td align="right"><a href="member.php?do=getbackpwd"><u>Find Password</u></a></td>
		</tr>
		<?php } ?>
		<tr>

<?php include_once('parts/SubMenuBox.php'); ?>		
		
		</table>

<tr>
<td><div align="left"><a href="javascript:menu(46);"><u><FONT color=#ffffff>Purchase VIP Reborn</u></a></div></td>
</tr>	


<tr>
<td><div align="left"><a href="javascript:menu(33);"><u><FONT>Reset PK Status</font></u></a></div></td>
</tr>

<tr>
<td><div align="left"><a href="javascript:menu(33);"><u><FONT>Reset Stat Points</font></u></a></div></td>
</tr>	

<tr>
<td><div align="left"><a href="javascript:menu(34);"><u>Distribution of Stat Points</u></a></div></td>
</tr>

<tr>
<td><div align="left" style="white-space:nowrap;"><a href="javascript:menu(47);"><u><FONT color=#ffa500>Exchange EPoints to Game Gold</u></a></div></td>
</tr>


<tr>		
<td><div align="left"><a href="javascript:menu(41);"><u><FONT>Exchange GameGold to EPoints</font></u></a></div></td>
</tr>	
<!--<tr>
<td><div align="left"><a href="extend.php?do=webr2p"><u><FONT color=#ffa500>Exchange Reborn to EPoints</u></a></div></td>
</tr>-->

<tr>
<td><div align="left"><a href="javascript:menu(38);"><u>Reset Second Password</u></a></div></td>
</tr>

<tr>
<td><div align="left" style="white-space:nowrap;"><a href="javascript:menu(37);"><u>Game Time Exchange to Epoints</u></a></div></td>
</tr>

<tr>
<td><div align="left"><a href="javascript:menu(22);"><u>Earn Epoints from Publicity</u></a></div></td>
</tr>

<tr>
<td><div align="left"><a href="javascript:menu(54);"><u><FONT>Recover Deleted Character</u></a></div></td>
</tr>

<tr>
	<td><div align="left"><a href="javascript:menu(65);"><u>Epoints Got Records</u></a></div></td>
</tr>
<tr>
	<td><div align="left"><a href="javascript:menu(39);"><u>Epoints Used Records</u></a></div></td>
</tr>

<tr>
<td><div align="left"><a href="javascript:menu(64);"><u><FONT color=#ffffff>Agent's Contact LiveChat</u></a></div></td>
<td><br></td>
</tr>
	</div>
        </div>
</div>
<center class="" style="padding-left:10px;height:180px"> <!-- class=boxesWShadow-->
<table border="0" style="border-collapse: collapse;border-spacing:0;table-layout: fixed;" >


		</table>
		</div>   
		</center>	   

  

        <div id="contentsBody" class="">

            <div id="noticeBox" class="upstairs">
                <h3>
                    <img src="/img/contents/tit_mainnotice.gif.png" />
                    <a href="/list.php"><img src="/img/contents/btn_more.gif.png" width="39" height="10" alt="more" /></a>
                </h3><br><br>
				
	

<ul>
	
<?php
$news->top12News();
?>	
	 
</ul>


            </div>
            <div id="issuetalkBox">
			    <img src="/img/contents/tit_hotissue.gif.png" />
        		<div style="width:350px;padding:10px 0 0 10px">
				
	<P><FONT color=#ffa500><STRONG>★ <?php echo EVENT_TITLE;?></STRONG></FONT></P>
	

				</div>
            </div>
         <br>
 <div id="noticeBox" class="upstairs" style="margin-top:-20px;">
				
	
	<li>
	   <a href="http://www.bossran.com/event/geardzp/?id=1">               
		<font color = white>Win 999, 555, 99 EP today!!!<br>

		<img border="0" src="http://bossran.com/images/win999.png" /></a>
	</li>
<ul>
	                                       
	
	<!--<li style="height:12px;padding-bottom:8px">
		<a href="/show.php?articleid=112" title="" style="height:12px;padding:3px 0 0px 13px;">
			<font color=yellow>How to Prevent Items Lost via Website Upgrade( Important)</font></a> 
		<span class="date" style="padding-top:0px;height:12px;">16-01-01</span>
	</li>-->
	<!--63972    .Trim()-->
	
	<!--<li style="height:12px;padding-bottom:8px">
		<a href="javascript:menu(23);" title="" style="height:12px;padding:3px 0 0px 13px;">
			<font color=green>How to Get Free 15,000 Epoints Register Now (Click Here)!</font></a> 
		<span class="date" style="padding-top:0px;height:12px;">11-11-17</span>
	</li>
	<li style="height:12px;padding-bottom:8px">
	
	<!--</li>-->

</ul>
<?php
$userVote = new VoteController;
//$userVote->voteSiteList();
?>


            </div>




           
        </div>
        <div id="contentsExt"  style="width:220px; float:left; margin:0; padding:0;"> <!--class="boxCusMarginLeft haveborderBot"-->

		<div id="eventBanner" style="width:208px;height:142px;background:url(/img/contents/ph.jpg.png) no-repeat 0px -3px;text-align:left;"><br><font color=#eeeeee>
		<span style="height:15px;float:right;width:180px;text-align:right;padding-right:20px;margin-top:-17px"><a href='javascript:menu(21);'><img src="/img/contents/btn_more.gif.png" width="39" height="10" alt="more" /></a></span>		

<ul style="margin-left:-1px;padding-top:3px;">
<?php
$rank->top5Character();
?>

</ul>

            </font></div>
<!--1-->
<div id="eventBanner" style="width:208px;height:121px;background:url(/img/contents/ds.jpg.png) no-repeat 0px -3px;text-align:left;"><br><font color=#eeeeee>
<ul style="margin-left:-1px;padding-top:3px;">

<?php
$rank->clubWarWinner();
?>


 

</ul>

            </font></div>
<!--1-->

<div id="movieBox"><a href="javascript:menu(391);">
<img src="http://bossran.com/img/common/main_movie_ready_090315.jpg"><br>
</a></div>

            <!--<a href="javascript:menu(23);" class="bannerButton"><img src="/img/banner/btn_bugreport.gif"></a>
            <a href="javascript:menu(40);" class="bannerButton"><img src="/img/banner/btn_download.gif"></a>-->
        </div>
        <div class="clear">
        </div>
    </div>	
</div>


</form>
<?php include_once('js/globaljs.php'); ?>
<?php include 'parts/global_script.php'; ?>
<?php
display_query_console($db);
$db->Close();
?>
</body>
</html>
