<?php
include_once('root.inc.php');
include_once('control/ctl_download.inc.php');
$download = new DownloadController;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title><?php echo PAGE_TITLE;?></title>
<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<meta name="description" content="<?php echo PAGE_TITLE;?>" />
<meta name="keywords" content="<?php echo PAGE_TITLE;?>" />
<meta http-equiv="imagetoolbar" content="no" />	
<link rel="icon"	  href="/common/boss.ico" 	  type="image/x-icon" />
<link rel="stylesheet" href="/common/css/Layout.css" />
<link rel="stylesheet" href="/common/css/main.css" />
<link rel="stylesheet" href="/common/css/SubPage.css" />
<link rel="stylesheet" href="/common/css/table.css" />
<link rel="stylesheet" href="/common/css/common.css" />

<script type="text/javascript" src="/common/main.js"></script>

<script type="text/javascript" src="/common/menu.js"></script>	

<?php include_once('js/commoncss.php'); ?>
<?php include_once('js/commonjs.php'); ?>
</head>

<body onload="">

<div id="wrap">
    <div id="navigation"></div>
    
<!--subbanner-->
	

    
    <div id="contentsWrap">
        <div id="contentsNavi">
            <div id="loginBox">

    <script type="text/javascript">
    
    function setBack(obj, showBg) {
        if (showBg == false) {
            obj.className = 'clearBg';
        }
        
        if (showBg == true && obj.value == '') {
            obj.className = '';
        }
    }
    </script>
<?php 
if($user_auth->haslogin){
$user = $user_auth->getUserInfo();
echo '	
    <div style="background:url(\'/img/loginbg2.jpg.png\') no-repeat bottom left;width:190px;height:85px;padding-top:3px">
	<div style="margin-left:20px;margin-top:-4px;color:#ffffff;text-align:left;line-height:16px;">
	<br>

	<strong>Hello, <span id="ctl00_UserID" style="color:#FFE32A;">',$user->userID,'</span></strong><br>
	<strong>Points: <span id="ctl00_GamePoint" style="color:#8FFAD0;">',$user->userPoint,'</span></strong> <a href=mart.php?do=itemorder><font color=#FFFFFF>[Use]</font></a> <a href=member.php?do=payorder><font color=#FFFFFF>[Get]</font></a>
		<br>
	<!-- <strong>You\'re<font color=#FF9E04><span id="ctl00_UserType"></span></font></strong>  -->
	</div>

	</div>
';
}else{
?>
<div id="loginIDNPW" style="margin:26px 2px 0px 0px;margin: 2px 0 0 1px!important; /* IE7+FF */">
	<iframe name="inner2" width="190" allowTransparency="true" height="85" src="member/ilogin.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no"></iframe>
</div>
<?php 
}
if(!$user_auth->haslogin){
	//cho '<img src="/img/common/btn_idpw2.png" usemap="#loginSecuritySettingMap" />';
	}else{
	//echo '<img src="/img/common/btn_idpw3.png" usemap="#loginSecuritySettingMap" style="margin-top:-6px"/>';	
	}
	?>	
		<map name="loginSecuritySettingMap" id="loginSecuritySettingMap">
		<?php 
		if($user_auth->haslogin){
		echo'
			<area shape="rect" coords="3,5,100,25" href="/member.php?do=editpwd" alt="" />
			<area shape="rect" coords="115,5,170,25" href="/member/logout.php" alt="" />
			';
		}else{
		echo'
			<area shape="rect" coords="3,5,100,25" href="javascript:menu(1001);" alt="" />
			<area shape="rect" coords="115,5,170,25" href="javascript:menu(1002);" alt="" />
			';
		}
		?>
    </map>
		


</div>
            <div id="subMenu">
<div id="subMenuRing"></div>
<!--leftmenn-->
	<div class="subMenuBox" style="margin-top:-38px;padding-left:0px;height:180px;">
	<img src="/img/common/menu_sub1_title.png" height="31" style="padding-bottom:8px"" >
		<table border="0" cellspacing="0" cellpadding="0">
		<tr>
<?php include_once('parts/SubMenuBox2.php'); ?>		
		
		</table>
	</div>
	
            </div>
            <!--div id="subBanner"><script>useSwf("/Common/Flash/sub_quick.swf","204","114",1)</script></div-->
        </div>
        <div id="contentsBody">
    <div id="subContents">

	
<!--title
	<div class="title">
	<table>
	<tr><img src="/img/Title/title_22.jpg" align="left" /></tr><d>
	<tr><img src="/img/Title/img_0101.jpg" align="left" /></tr>
	</table>
		
	</div>-->
	
	<div class="Contents">
	
<!--contents img-->

        <div id="board" >
		
<table width="100%" height="350" border="0" cellspacing="0" cellpadding="0">
  <tr>

    <td>
								<P><FONT size=2 face=Verdana></FONT></P>
<p>
	
	<div class="read_contents">
	<p>
    <font size="2" face="Verdana" color="#000000">
        <font style="background-color: #000000;">
		<font face="Verdana">
			<font color="#ffff00">
					<font size="2">
						<font style="background-color: #000000;" size="3"><strong>Please read before use</strong></font>
					</font>
				</font>
		</font>
			    <font face="Verdana" color="#ff0000">    
        <font size="2">
            <font face="Verdana" color="#ff0000">
                <br />               
                <font style="background-color: #000000;">

                    <font face="Verdana">
                        <font size="2">
                            <font color="#ffffff">
                                <strong>(1) </strong> To claim your reward you must enter your exact/correct <font color=red>[Character Name]</font>
								<br><strong>(2) </strong> You can only claim once in each account!
                                <br><strong>(3) </strong> Player(s) Character must reach 80 Rebirth to claim reward!
                            </font>
                        </font>
                    </font>
                </font>
            </font>
        </font>
    </font>
	<br>
    <font face="Verdana">
        <font color="#ff0000">
            <font size="1">
                <font style="background-color: #ffff00;" size="3"><strong>If any problem encounter please contact: moyranonline@gmail.com<br>or go to <a href="http://moyran.com/agent.php">Agent's Contact LiveChat<a/></strong></font>&nbsp;<br />
            </font>
        </font>
    </font>
        </font>
		<centeR>
        <font color="#ff0000">
            <font color="#000000">
			<iframe src="http://moyran.com/claimreward/" frameborder="0"></iframe>
            </font>            
        </font>
		</center>
        <br />
    </font> 



</p>

	</div>
		
        </div>
    </div>

    <div class="ContentsFooter"></div>
</div> 

        </div>
        <div class="clear">
		
        </div>
    </div>

</div>
<?php include_once('js/globaljs.php'); ?>
<?php include 'parts/global_script.php'; ?>
<?php
display_query_console($db);
$db->Close();  
?>
</body>
</html>
