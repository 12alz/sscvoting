<?php
include_once('root.inc.php');
include_once('lib/logic/News.php');
include_once('control/ctl_news.inc.php');
$news = new NewsController;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title><?php echo PAGE_TITLE;?></title>
<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<meta name="description" content="<?php echo PAGE_TITLE;?>" />
<meta name="keywords" content="<?php echo PAGE_TITLE;?>" />
<meta http-equiv="imagetoolbar" content="no" />	
<link rel="shortcut icon" href="/common/ran.ico" type="image/x-icon" />
<link rel="stylesheet" href="/common/css/Layout.css" />
<link rel="stylesheet" href="/common/css/main.css" />
<link rel="stylesheet" href="/common/css/SubPage.css" />
<link rel="stylesheet" href="/common/css/table.css" />
<link rel="stylesheet" href="/common/css/common.css" />
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-6388752191388588",
    enable_page_level_ads: true
  });
</script>
<script type="text/javascript" src="/common/main.js"></script>

<script type="text/javascript" src="/common/menu.js"></script>	
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>

</head>
<body onload="MM_preloadImages('img/Common/menu_sub_31s.jpg','img/Common/menu_sub_33s.jpg','img/Common/menu_sub_34s.jpg','img/Common/menu_sub_35s.jpg','img/Common/menu_sub_36s.jpg','img/Common/menu_sub_37s.jpg','img/Common/menu_sub_38s.jpg','img/Common/menu_sub_22s.jpg','img/Common/menu_sub_391s.jpg','img/Common/menu_sub_24s.jpg','img/Common/menu_sub_25s.jpg')">

<div id="wrap">
    <div id="navigation"></div>
    
<!--subbanner-->
 

    
    <div id="contentsWrap">
        <div id="contentsNavi">
            <div id="loginBox">

    <script type="text/javascript">
    
    function setBack(obj, showBg) {
        if (showBg == false) {
            obj.className = 'clearBg';
        }
        
        if (showBg == true && obj.value == '') {
            obj.className = '';
        }
    }
    </script>

<?php 
if($user_auth->haslogin){
$user = $user_auth->getUserInfo();
echo '	
	<div style="background:url(\'/img/loginbg2.jpg.png\') no-repeat bottom left;width:190px;height:85px;padding-top:3px">
	<div style="margin-left:20px;margin-top:-4px;color:#ffffff;text-align:left;line-height:16px;">
	<br>

	<strong>Hello, <span id="ctl00_UserID" style="color:#FFE32A;">',$user->userID,'</span></strong><br>
	<strong>Points: <span id="ctl00_GamePoint" style="color:#8FFAD0;">',$user->userPoint,'</span></strong> <a href=mart.php?do=itemorder><font color=#FFFFFF>[Use]</font></a> <a href=member.php?do=payorder><font color=#FFFFFF>[Get]</font></a>
		<br>
	<!-- <strong>You\'re<font color=#FF9E04><span id="ctl00_UserType"></span></font></strong>  -->
	</div>

	</div>
';
}else{
?>
<div id="loginIDNPW" style="margin:26px 2px 0px 0px;margin: 2px 0 0 1px!important; /* IE7+FF */">
	<iframe name="inner2" width="190" allowTransparency="true" height="85" src="member/ilogin.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no"></iframe>
</div>
<?php 
}
if(!$user_auth->haslogin){
//echo '<img src="/img/common/btn_idpw2.png" usemap="#loginSecuritySettingMap" />';
}else{
//echo '<img src="/img/common/btn_idpw3.png" usemap="#loginSecuritySettingMap" style="margin-top:-6px"/>';	
}
?>	
    <map name="loginSecuritySettingMap" id="loginSecuritySettingMap">
    <?php 
	if($user_auth->haslogin){
	echo'
        <area shape="rect" coords="3,5,100,25" href="/member.php?do=editpwd" alt="" />
        <area shape="rect" coords="115,5,170,25" href="/member/logout.php" alt="" />
		';
	}else{
	echo'
        <area shape="rect" coords="3,5,100,25" href="javascript:menu(1001);" alt="" />
        <area shape="rect" coords="115,5,170,25" href="javascript:menu(1002);" alt="" />
		';
	}
	?>
    </map>
		


</div>
            <div id="subMenuRing"></div>
            <div id="subMenu">
<!--leftmenn-->
	<div class="subMenuBox" style="margin-top:-38px;padding-left:0px;height:180px;">
	<img src="/img/common/menu_sub1_title.png" height="31" style="padding-bottom:8px"" >
		<table border="0" cellspacing="0" cellpadding="0">
		<tr>
<?php include_once('parts/SubMenuBox2.php'); ?>		
		
		</table>
	</div>
	
            </div>
            <!--div id="subBanner"><script>useSwf("/Common/Flash/sub_quick.swf","204","114",1)</script></div-->
        </div>
        <div id="contentsBody" >
    <div id="subContents">

	
<!--title-->
	

	<div class="Contents">	
<!--contents img-->	
<!--<img src="/img/Intro/line_h_bdot.gif" alt="" style="margin-top:-12px"/>-->

        <div id="board" >
		
<div style="line-height:23px;font-size:12px">

	
<div class="ClearList">
    <table cellpadding="0" cellspacing="0">
    <colgroup><col width="15"><col width="470"><col width="100"><col width="60"><col width="15"></colgroup>
    <!--<tr>
        <th class="left"></th>
        <th><img src="/img/Community/Img_board_title.jpg" alt=""></th>
        <th><img src="/img/Community/Img_board_name.jpg" alt=""></th>
        <th><img src="/img/Community/Img_board_date.jpg" alt=""></th>
        <th class="right"></th>
    </tr>-->

	
	    
<?php
$news->showNewsList();
?>		
		
		    </table>
		 
						
    </table>
    
    <div id="ctl00_ContentPlaceHolder1_TempRowPanel" style="height:0px;"></div>

    <!-- 페이지 -->
    <div class="paging">
<?php echo $news->newsListPaging();?>    
	</div>
</div>
</div>
<div style="height:25px"></div>

        </div>
    </div>

    <div class="ContentsFooter"></div>
</div> 

        </div>
        <div class="clear">
        </div>
    </div>

</div>
<?php
display_query_console($db);  
$db->Close();
?>
</body>
</html>