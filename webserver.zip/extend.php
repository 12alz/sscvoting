<?php
include_once('root.inc.php');
include_once('lib/common/ItemPagination.php');
include_once('lib/logic/itemcustomize.php');
include_once('lib/logic/ChaReborn.php');
include_once('lib/logic/character.php');
include_once('control/ctl_itemcustomize.inc.php');
include_once('control/ctl_character.inc.php');
include_once('control/ctl_chareborn.inc.php');
if(!isset($_GET['do'])){ 
jump_location('extend.php?do=webreborn'); 
}else
if($user_auth->haslogin){
$itemcustomize = new ItemCustomizeController;
$character = new CharacterController;
$reborn = new ChaRebornController;
$crafting = '';
$isTabSession = false;
$noError = false;

	function consoleLOGS($dt){
		echo '<pre>';
		var_dump($dt);
		exit();
	}

	function EMencrypt($str) {
		global $CRYPTPASS;
		
		if(!$str){return false;}
		$skey = substr($CRYPTPASS, 2, 4);
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$crypttext = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $skey, $str, MCRYPT_MODE_ECB, $iv);
		return trim(safe_encode($crypttext)); 
	}

	/**
	 * Returns decrypted original string
	 */
	function EMdecrypt($str) {
		global $CRYPTPASS;
		
		if(!$str){return false;}
		$skey = substr($CRYPTPASS, 2, 4);
		$crypttext = safe_decode($str);
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$decrypttext = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $skey, $crypttext, MCRYPT_MODE_ECB, $iv);
		return trim($decrypttext);
	}
	
	function safe_encode($string) {
		$data = base64_encode($string);
		$data = str_replace(array('+','/','='),array('ZZZ','DOL',''),$data);
		return $data;
	}

	function safe_decode($string) {
		$data = str_replace(array('ZZZ','DOL'),array('+','/'),$string);
		$mod4 = strlen($data) % 4;
		if ($mod4) {
			$data .= substr('====', $mod4);
		}
		return stripslashes(base64_decode($data));
	}

switch(clean_variable(trim(strtolower($_GET['do'])))){
	
	case "webreborn":
		$character->character_FunctionJump('webreborn_detail&cid='.(int)$_POST["ChaList"].'');
	    $imgTitle = "title_31";
		break;
		
	case "webreborn_detail":
		$reborn->rebornDetail();
	    $imgTitle = "title_31";
		break;
		
	case "webjd_todo":
	    $character->addStatsToDo();
		$imgTitle = "title_34";
		break;
		
	case "webupitem":
		$character->character_FunctionJump('webupitem_list&cid='.(int)$_POST["ChaList"].'');
		$imgTitle = "title_32";
		break;
	
	// case "crafting":
		// $character->character_FunctionJump('crafting_list&cid='.(int)$_POST["ChaList"].'');
		//$itemcustomize->itemUpgrade();
		// $imgTitle = "title_80";
		// $title = 'Crafting';
		// break;
	// case "crafting_list":
		
		// include_once('lib/logic/ItemPurchase.php');
		// include_once('lib/logic/ShopItemMap.php');
		// include_once('control/ctl_shopitemmap.inc.php');
		// include_once('control/ctl_itempurchase.inc.php');
		// $getItems = new ShopItemMapController;
		// echo '<pre>';
		// var_dump($getItems->getAllItemsFromProduct());
		// exit();
		
		// $imgTitle = "title_32";
		// $title = 'Crafting';
		// break;
	
	case "cap_reward":
		// $serial = strtotime(date('Y-m-d H:i:s'));
		
		// if(! isset($_COOKIE['serial'])){
			// $_COOKIE['serial'] = $serial;
		// }
		
		// if(isset($_POST["__EVENTTARGET"])){
			// var_dump($_POST["__EVENTARGUMENT2"]);EXIT();
		// }
		
		// $character->checkCharacterSinglePage('cap_reward','cap_reward_get&cid='.(int)$_POST["ChaList"].'');
		// $character->character_FunctionJump('cap_reward_get&cid='.(int)$_POST["ChaList"].'');
		$imgTitle = "title_61";
		$title = 'Reborn Reward';
	break;
	
	case "daily_reward":
	
		//submit form
		if(isset($_POST["__EVENTTARGET"])){
			if(isset($_POST["__EVENTARGUMENT2"]) && $_POST["__EVENTARGUMENT2"] != ''){
				
			}
		}
		
		
		
	break;
	
	case "cap_reward_get":
		$isTabSession = true;
		$hyperlink = true;
		
		//$currentSes = $character->checkCharacterSinglePage('cap_reward_get','cap_reward_get&cid='.(int)$_GET["cid"].'',$ses);
		
		if(isset($_POST["__EVENTTARGET"])){

				if(isset($_POST["__EVENTARGUMENT2"]) && $_POST["__EVENTARGUMENT2"] != ''){
					
					$currentSes = $character->checkCharacterSinglePage('cap_reward_get','cap_reward_get&cid='.(int)$_POST["ChaList"].'',$ses);
					if($currentSes){
						echo '<script type="text/javascript">alert("This tab is active. Use Reset Session to Unlock some pages");window.self.location=\'extend.php?do=cap_reward\';</script>';
					}else{
						jump_location("extend.php?do=cap_reward_get&cid=".(int)$_POST["ChaList"]."");
					}
				}

		}
		
		if(isset($_POST["__EVENTTARGET3"]) && isset($_POST["__EVENTARGUMENT4"])){
			// consoleLOGS($_POST["__EVENTARGUMENT4"]);
			$itemcustomize->cliamReward();
		}
		
		$getCurrentTabSession = $character->getCurrentTabSession('cap_reward_get','cap_reward');
		$getCurrentTabSession = base64_decode($getCurrentTabSession);
		
		$imgTitle = "title_61";
		$title = 'Reborn Reward';
		break;
		
	case "webupitem_list":
		$itemcustomize->itemUpgrade();
		$imgTitle = "title_32";
		break;
		
	case "webxd":
		$character->resetStatsPoint();
	    $imgTitle = "title_33";
		break;

	case "webjd":
	    $character->character_FunctionJump('webjd_todo&id='.(int)$_POST["ChaList"].'');
		$imgTitle = "title_34";
		break;
		
	case "webxb":
		$character->resetPK();
	    $imgTitle = "title_35";
		break;
		
	case "webchangesex":
		$character->changeSex();
	    $imgTitle = "title_36";
		break;

	case "webpd":
		$character->gameTimeEarnPoint();
	    $imgTitle = "title_37";
		break;
		
	case "editsafepwd":
		$character->editSafePassword();
	    $imgTitle = "title_38";
		break;
		
	case "webcc":
		$character->changeClass();
	    $imgTitle = "title_45";
		break;
		
	case "webdelitem":
		$character->character_FunctionJump('webdelitem_list&cid='.(int)$_POST["ChaList"].'');
	    $imgTitle = "title_46";
		break;

	case "webdelitem_list":
		$character->deleteItems();
	    $imgTitle = "title_46";
		break;
		
	//GOLD TO EP
	case "webp2g":
	    $character->character_FunctionJump('webp2g_todo&id='.(int)$_POST["ChaList"].'');
		$imgTitle = "title_66";
		break;

	case "webp2g_todo":
		$character->pointToGameGold();
		$imgTitle = "title_66";
		break;
	 
	//END GOLD TO EP
	
	//reborn to ep
	case "webr2p":
		$character->character_FunctionJump('webr2p_todo&id='.(int)$_POST["ChaList"].'');
		$title = 'Rebirth to EP';
		$imgTitle = "title_67";
		break;

	case "webr2p_todo":
		$character->resetRebornToEpoints();
		$imgTitle = "title_67";
		break;
	//end reborn to ep
	
	// case "webreborn2":
		// $character->character_FunctionJump('webreborn2_todo&cid='.(int)$_POST["ChaList"].'');
		// $imgTitle = "title_68";
		// break;

	case "webreborn2_todo":
		$reborn->purchaseReborn();
		$imgTitle = "title_68";
		break;

	case "recover_delcha":
		$character->recoverDeletedChar();
		$imgTitle = "title_71";
		break;

	case "recover_delchalist":
		$character->character_FunctionJump('recover_delchalist_do&cid='.(int)$_POST['ChaList'].'');
		$imgTitle = "title_71";
		break;

	case "recover_delchalist_do":
		$character->recoverDeletedCharDo();
		$imgTitle = "title_71";
		break;

	case "webg2p":
	    $character->character_FunctionJump('webg2p_todo&id='.(int)$_POST["ChaList"].'');
		$imgTitle = "title_72";
		break;

	case "webg2p_todo":
		$character->goldToEpoints();
		$imgTitle = "title_72";
		break;
		
	case "itemorder":
		$character->goldToEpoints();
		$imgTitle = "title_39";
		break;

		
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title><?php echo(PAGE_TITLE);?></title>
<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<meta name="description" content="<?php echo PAGE_TITLE;?>" />
<meta name="keywords" content="<?php echo PAGE_TITLE;?>" />
<meta http-equiv="imagetoolbar" content="no" />	
<link rel="shortcut icon" href="/common/ran.ico" type="image/x-icon" />
<link rel="stylesheet" href="/common/css/Layout.css" />
<link rel="stylesheet" href="/common/css/main.css" />
<link rel="stylesheet" href="/common/css/SubPage.css" />
<link rel="stylesheet" href="/common/css/table.css" />
<link rel="stylesheet" href="/common/css/common.css" />
<script type="text/javascript" src="/common/main.js"></script>

<script type="text/javascript" src="/common/menu.js"></script>	
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<?php include_once('js/commoncss.php'); ?>
<?php include_once('js/commonjs.php'); ?>
</head>
<body onload="MM_preloadImages('img/Common/menu_sub_31s.jpg','img/Common/menu_sub_33s.jpg','img/Common/menu_sub_34s.jpg','img/Common/menu_sub_35s.jpg','img/Common/menu_sub_36s.jpg','img/Common/menu_sub_37s.jpg','img/Common/menu_sub_38s.jpg','img/Common/menu_sub_22s.jpg','img/Common/menu_sub_391s.jpg','img/Common/menu_sub_24s.jpg','img/Common/menu_sub_25s.jpg')">

<div id="wrap">
   <div id="navigation"></div>
    
<!--subbanner-->
	

    
    <div id="contentsWrap">
        <div id="contentsNavi">
            <div id="loginBox">

    <script type="text/javascript">
    
    function setBack(obj, showBg) {
        if (showBg == false) {
            obj.className = 'clearBg';
        }
        
        if (showBg == true && obj.value == '') {
            obj.className = '';
        }
    }
    </script>
<?php 
if($user_auth->haslogin){
$user = $user_auth->getUserInfo();
echo '	
<div style="background:url(\'/img/loginbg2.jpg.png\') no-repeat bottom left;width:190px;height:85px;padding-top:3px">
	<div style="margin-left:20px;margin-top:-4px;color:#ffffff;text-align:left;line-height:16px;">
	<br>

	<strong>Hello, <span id="ctl00_UserID" style="color:#FFE32A;">',$user->userID,'</span></strong><br>
	<strong>Points: <span id="ctl00_GamePoint" style="color:#8FFAD0;">',$user->userPoint,'</span></strong> <a href=mart.php?do=itemorder><font color=#FFFFFF>[Use]</font></a> <a href=member.php?do=payorder><font color=#FFFFFF>[Get]</font></a>
		<br>
	<!-- <strong>You\'re<font color=#FF9E04><span id="ctl00_UserType"></span></font></strong>  -->
	</div>

	</div>
';
}
?>
<?php
if(!$user_auth->haslogin){
	// echo '<img src="/img/common/btn_idpw2.png" usemap="#loginSecuritySettingMap" />';
	// }else{
	// echo '<img src="/img/common/btn_idpw3.png" usemap="#loginSecuritySettingMap" style="margin-top:-6px"/>';	
	}
	?>	
		<map name="loginSecuritySettingMap" id="loginSecuritySettingMap">
		<?php 
		if($user_auth->haslogin){
		echo'
			<area shape="rect" coords="3,5,100,25" href="/member.php?do=editpwd" alt="" />
			<area shape="rect" coords="115,5,170,25" href="/member.php/logout.php" alt="" />
			';
		}else{
		echo'
			<area shape="rect" coords="3,5,100,25" href="javascript:menu(1001);" alt="" />
			<area shape="rect" coords="115,5,170,25" href="javascript:menu(1002);" alt="" />
			';
		}
		?>
		</map>
		


</div>
         <div id="subMenuRing"></div>
		
            <div id="subMenu">
		
<!--leftmenn-->	
	<div class="subMenuBox" style="margin-top:-38px;padding-left:0px;height:180px;">
	<img src="/img/common/menu_sub1_title.png" height="31" style="padding-bottom:8px"" >
		<table border="0" cellspacing="0" cellpadding="0">
		<tr>
<?php include_once('parts/SubMenuBox2.php'); ?>		
		</table>
	</div>
	
            </div>
            <!--div id="subBanner"><script>useSwf("/Common/Flash/sub_quick.swf","204","114",1)</script></div-->

        </div>
        <div id="contentsBody">
    <div id="subContents">
<!--title
	<?php if($title){ ?>
		<div class="title"><h3><?= $title ?><h3></div>
	<?php }else{ ?>
		<div class="title"><img src="img/Title/<?php $imgTitle;?>.jpg" align="left" /></div>		
	<?php } ?>
-->
	<div class="Contents">
	
<!--contents img-->
	<!--<td><img src="/img/Intro/line_h_bdot.gif" alt="" style="margin-top:-12px; border-bottom: none"/><td>-->

        <div id="board" >
		
<?php
if (is_file("parts/extend.". clean_variable(trim(strtolower($_GET['do']))) .".inc.php")) {
  include_once("parts/extend.". clean_variable(trim(strtolower($_GET['do']))) .".inc.php");
} else {	

  jump_location('errorpage');
}
?>
        </div>
    </div>
    <div class="ContentsFooter"></div>
</div> 

        </div>
        <div class="clear">
        </div>
    </div>

</div>
<?php

 include_once('js/globaljs.php');
 include 'parts/global_script.php';
 display_query_console($db);
 $db->Close();

 ?>

</body>
</html>
<?php 
}elseif(!is_file("parts/extend.". clean_variable(trim(strtolower($_GET['do']))) .".inc.php")){
	jump_location('errorpage');
    }else{
	$user_auth->resume_link(clean_variable(trim(strtolower($_GET['do']))));
	jump_location('member.php?do=login');
}
?>