<?php
session_start();
function random_string($len=4, $str='')  {	
	for($i=1; $i<=$len; $i++)        {        
		$ord = rand(48, 122);	 
		if((($ord >= 48) && ($ord <= 57)) || (($ord >= 97) && ($ord <= 122))) 	
			$str.=chr($ord);	
			else		
		$str.=random_string(1);	                                       	
		}	
return $str;
}

function drawBorder(&$img, &$color, $thickness = 1)  {     
$x1 = 0;     
$y1 = 0;      
	$x2 = imagesx($img) - 1;      
	$y2 = imagesy($img) - 1;       
  for($i = 0; $i < $thickness; $i++) {          
 	 imagerectangle($img, $x1++, $y1++, $x2--, $y2--, $color);      
  }  
} 

$rand_str = random_string(4);   
                                  
$_SESSION['checkcode2'] = $rand_str;
                              
$letter1=substr($rand_str,0,1);
$letter2=substr($rand_str,1,1);
$letter3=substr($rand_str,2,1);
$letter4=substr($rand_str,3,1);


$size = 14.3;

$width = 65;
$height = 25;

$image = imagecreatetruecolor($width, $height);
$b_color = imagecolorallocate($image, 207,207,207); 
$a_color = imagecolorallocate($image, 207,207,207); 

imagefill($image, 0, 0, imagecolorallocate($image, 255,255,255));
for ($c = 0; $c < 110; $c++){
	$x = rand(0,$width-1);
	$y = rand(0,$height-1);
	imagesetpixel($image, $x, $y, $a_color);
}

                                  
$angle1 = rand(0, 0);
$angle2 = rand(0, 0);
$angle3 = rand(0, 0);
$angle4 = rand(0, 0);
                                
$font = "images/verdana.ttf";

$colors[0]=array(255,165,0); //Orange
$colors[1]=array(165,42,42); //Brown
$colors[2]=array(0,192,0); //Green
$colors[3]=array(255,0,0); //Red
$colors[4]=array(0,0,128); //Navy
$colors[5]=array(178,34,34); //Firebrick
$colors[6]=array(0,100,0); //Dark Green

$color1=rand(0, 6);
$color2=rand(0, 6);
$color3=rand(0, 6);
$color4=rand(0, 6);

$textColor1 = imagecolorallocate ($image, $colors[$color1][0],$colors[$color1][1], $colors[$color1][2]);
$textColor2 = imagecolorallocate ($image, $colors[$color2][0],$colors[$color2][1], $colors[$color2][2]);
$textColor3 = imagecolorallocate ($image, $colors[$color3][0],$colors[$color3][1], $colors[$color3][2]);
$textColor4 = imagecolorallocate ($image, $colors[$color4][0],$colors[$color4][1], $colors[$color4][2]);



imagettftext($image, $size, $angle1, 5, $size+1, $textColor1, $font, $letter1);
imagettftext($image, $size, $angle2, 20, $size+6, $textColor2, $font, $letter2);
imagettftext($image, $size, $angle3, 35, $size+1, $textColor3, $font, $letter3);
imagettftext($image, $size, $angle4, 48, $size+6, $textColor4, $font, $letter4);
drawBorder($image,$b_color);

header('Content-type: image/jpeg');
imagejpeg($image);
imagedestroy($image); 
unset($font);

?>