
<div id="footer"><FONT color=#ffa500>
<FONT color=#ffa500>Copyright 2020 UG Ran Online Inc. All Rights Reserved</FONT><FONT color=#ffa500> </div>
</div>