<?php
if (strpos('/inc/class.function.php', $_SERVER['SCRIPT_NAME']) !== false) { die('Access Denied'); }

function SchoolType($sc){
	switch ($sc){
		
		case 'SG':
			return '0';
		break;
		
		case 'MP':
			return '1';
		break;
		
		case 'Phoenix':
			return '2';
		break;	
		
		default:  
			return '3'; 
		break;
		
	}
	
}
function GendType($type){
// 0 = Female , 1 = Male
	switch ($type){
			case 'Female':
			return '0';
			break;
			
			case 'Male':
			return '1';
			break;
	}
	
	
}
function ChaClass($type){
	
//1 = Brawler(Boy)
//2 = Swordsman(Boy)
//4 = Archer(Girl)
//8 = Shaman(Girl)
//16 = Extreme(Boy)
//32 = Extreme(Girl)
//64 = Brawler(Girl)
//128 = Swordsman(Girl)
//256 = Archer(Boy)
//512 = Shaman(Boy)
	
	switch ($type)
	{
		case '1':	return "Brawler(Boy)"; break;
		case '2':	return "Swordsman(Boy)"; break;		
		case '4':	return "Archer(Girl)"; break;		
		case '8':	return "Shaman(Girl)"; break;
		case '16':	return "Extreme(Boy)"; break;
		case '32':	return "Extreme(Girl)"; break;
		case '64':	return "Brawler(Girl)"; break;		
		case '128':	return "Swordsman(Girl)"; break;		
		case '256':	return "Archer(Boy)"; break;
		case '512':	return "Shaman(Boy)"; break;		
	}

}
function ChaDept($sid){
	
	switch ($sid)
	{
		case '0':	return "SG"; break;
		case '1':	return "MP"; break;		
		case '2':	return "Phoenix"; break;		
	}
	
}
function rank_Dept($id){
	
	switch ($id)
	{
		case 'SG': return "AND P.ChaSchool = '0'"; break;	
		case 'MP': return "AND P.ChaSchool = '1'"; break;	
		case 'Phoenix': return "AND P.ChaSchool = '2'"; break;
		default: return "AND P.ChaSchool >= 0"; break;	
	}
		
	
}
function toppk_Dept($id){
	
	switch ($id)
	{
		case 'SG': return "AND ChaSchool = '0'"; break;	
		case 'MP': return "AND ChaSchool = '1'"; break;	
		case 'Phoenix': return "AND ChaSchool = '2'"; break;
		default: return "AND ChaSchool >= 0"; break;	
	}
		
	
}
function mart_category($cat){
	switch ($cat){
		
		case '1': return "Weapon"; break;
		case '2': return "Weapon(Leasing)"; break;
		case '3': return "Armor(Suit)"; break;
		case '4': return "Armor(Single)"; break;
		case '5': return "Jewelry"; break;
		case '6': return "Pet Item"; break;
		case '7': return "Scroll"; break;
		case '8': return "Accessories"; break;
		default: return "All Items List"; break;
		
	}
}
function MapsName($loc){
	
	switch ($loc){
		
            case 0: return "SG Campus1F"; break;
            case 2: return "SG Campus"; break;
            case 100: return "StudyRoom1"; break;
            case 101: return "StudyRoom2"; break;
            case 103: return "StudyRoom3"; break;
            case 104: return "HistoryCentre"; break;
            case 105: return "Library"; break;
            case 106: return "SocietyRoom"; break;
            case 107: return "ScienceCentre"; break;
            case 102: return "Dormitory"; break;
            case 3: return "SacredGateHole"; break;
            case 201: return "SG E-Room Front"; break;
            case 211: return "SG E-Room"; break;
            case 4: return "MP_Campus1F"; break;
            case 5: return "MP_Campus"; break;
            case 121: return "StudyRoom1"; break;
            case 120: return "StudyRoom2"; break;
            case 124: return "StudyRoom3"; break;
            case 123: return "ArtCentre"; break;
            case 122: return "Library"; break;
            case 125: return "Library2"; break;
            case 126: return "StudentCentre1"; break;
            case 128: return "StudentCentre2"; break;
            case 6: return "MysticPeakHole"; break;
            case 202: return "MP E-Room Front"; break;
            case 212: return "MP E-Room"; break;
            case 7: return "PhoenixCampus1F"; break;
            case 8: return "PhoenixCampus"; break;
            case 130: return "StudyRoom2"; break;
            case 131: return "StudyRoom1"; break;
            case 136: return "RenovationCentre"; break;
            case 135: return "ScienceCentre"; break;
            case 137: return "Laboratory"; break;
            case 138: return "PracticeRoom"; break;
            case 141: return "SuppliesRoom"; break;
            case 142: return "Library"; break;
            case 134: return "Dormitory"; break;
            case 9: return "PhoenixHole"; break;
            case 203: return "Phx E-Room Front"; break;
            case 213: return "Phx E-Room"; break;
            case 10: return "LeonineCampus"; break;
            case 11: return "LeonineCampus1F"; break;
            case 12: return "LeonineCampus2F"; break;
            case 13: return "LeonineCampus3F"; break;
            case 14: return "LeonineCampusB1"; break;
            case 15: return "LeonineCampusB2"; break;
            case 30: return "LeonineCampusB3"; break;
            case 17: return "SG HolePassage"; break;
            case 16: return "TradingHole"; break;
            case 161: return "Carpark 1"; break;
            case 162: return "Carpark 2"; break;
            case 204: return "Trd E-Room Front"; break;
            case 214: return "Trd E-Room"; break;
            case 18: return "WharfPassage"; break;
            case 19: return "Hangout 1F_A"; break;
            case 20: return "Hangout 2F_A"; break;
            case 21: return "Hangout 3F_A"; break;
            case 150: return "Hangout 1F_B"; break;
            case 152: return "Hangout 2F_B"; break;
            case 154: return "Hangout 3F_B"; break;
            case 151: return "Hangout 1F_C"; break;
            case 153: return "Hangout 2F_C"; break;
            case 155: return "Hangout 3F_C"; break;
            case 26: return "Trading3Passage"; break;
            case 27: return "Prison"; break;
            case 32: return "PrisonTestZone"; break;
            case 33: return "Laboratory7"; break;
            case 28: return "MiddleHole"; break;
            case 29: return "RootHole"; break;
            case 22: return "Market"; break;
            case 23: return "Practicing Yard"; break;
            case 31: return "Wedding Hall"; break;
            case 46: return "Head.B 1F"; break;
            case 35: return "Head.B 30F"; break;
            case 36: return "Head.B 50F"; break;
            case 37: return "Head.B 90F"; break;
            case 40: return "Director Room"; break;
            case 41: return "Director Room2"; break;
            case 42: return "Head.B B1"; break;
            case 43: return "South Temple"; break;
            case 44: return "Central Temple"; break;
            case 38: return "Head.B Left"; break;
            case 39: return "Head.B Right"; break;
            case 45: return "North Temple"; break;
            case 186: return "Another World 1F"; break;
            case 187: return "Another World 2F"; break;
            case 188: return "Another World 3F"; break;
            case 189: return "Another World 4F"; break;
            case 190: return "Another World 5F"; break;
            case 191: return "Another World 6F"; break;
            case 34: return "Shibuya"; break;
            case 24: return "Battle Arena"; break;
            case 215: return "Gymnasium"; break;
            case 180: return "NPC Map 1F"; break;
            case 181: return "NPC Map 2F"; break;
            case 182: return "NPC Map 3F"; break;
            case 183: return "NPC Map 4F"; break;
            case 184: return "NPC Map 5F"; break;
            case 185: return "NPC Map 6F"; break;
            case 236: return "DeathJail_1F"; break;
            case 237: return "DeathJail_2F"; break;
            case 238: return "DeathJail_3F"; break;
            case 239: return "DeathJail_4F"; break;
            case 240: return "DeathJail_5F"; break;
            case 241: return "DeathJail_6F"; break;
            case 242: return "DeathJail_7F"; break;
            case 243: return "DeathJail_8F"; break;
            case 244: return "DeathJail_9F"; break;
            case 166: return "Tunnel 1F"; break;
            case 167: return "Tunnel 2F"; break;
            case 255: return "Chaos Fire"; break;
            case 256: return "Chaos Ice"; break;
            case 257: return "Chaos Poison"; break;
            case 258: return "Chaos Electric"; break;
            case 259: return "Chaos Boss Room"; break;
            case 216: return "Bossroom A"; break;
            case 217: return "Bossroom B"; break;
            case 218: return "Bossroom C"; break;
            case 219: return "Bossroom D"; break;
            case 245: return "LeoCampus B3"; break;
            case 246: return "LeoCampus B2"; break;
            case 247: return "LeoCampus B1"; break;
            case 248: return "LeoCampus Main"; break;
            case 249: return "LeoCampus Field"; break;
            case 250: return "Market 2"; break;
            case 251: return "Ninja 1F"; break;
            case 252: return "Ninja 2F"; break;
            case 253: return "Ninja 3F"; break;
            case 110: return "Com. Room Front"; break;
            case 111: return "Com. Room"; break;
            case 112: return "Com. Room Boss"; break;
            case 113: return "Gymnasium 2"; break;
            case 114: return "Death Match"; break;
            case 115: return "Huenco Mundo1F"; break;
            case 116: return "Huenco Mundo"; break;	
			
			default: return "Unknown"; break;
	}
}
?>