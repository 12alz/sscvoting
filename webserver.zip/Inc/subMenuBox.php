<?php 
if (strpos('/inc/subMenuBox.php', $_SERVER['SCRIPT_NAME']) !== false) { die('Access Denied'); }


?>
<tr>
		<td><a href="javascript:menu(24);"><u><FONT color=#ffffff><?php print _Acc_ResetPass;?></font></u></a></td>
			<td align="right"><a href="javascript:menu(25);"><u><FONT color=#ffffff><?php print _Acc_Logout;?></font></u></a></td>
		</tr>
		<tr>
			<td align="right"><a href="javascript:menu(31);"><u><FONT color=#ffffff><?php print _Cha_Rebirth;?></font></u></a></td>

			<td align="right"><a href="javascript:menu(42);"><u><FONT color=#ffa500><?php print _Cha_ChangeSchool;?></font></u></a></td>
		</tr>
		<tr>
	
		<tr>
			<td><a href="javascript:menu(33);"><u><FONT color=#ffffff><?php print _Cha_ResetStats;?></font></u></a></td>
			<td align="right"><a href="javascript:menu(34);"><u><FONT color=#ffffff><?php print _Cha_AddStats;?></font></u></a></td>
		</tr>

		<tr>
			<td><a href="javascript:menu(35);"><u><FONT color=#ffffff><?php print _Cha_ResetPK;?></font></u></a></td>
			<td align="right"><a href="javascript:menu(36);"><u><FONT color=#ffffff><?php print _Cha_Transsexual;?></font></u></a></td>
		</tr>
		<tr>
			<td><a href="javascript:menu(46);"><u><FONT color=#ffa500><?php print _Acc_TopUp;?></font></u></a></td>
			<td align="right"><a href="javascript:menu(38);"><u><FONT color=#ffffff><?php print _Acc_Reset2ndPass;?></font></u></a></td>

		</tr>
		<tr>
		</tr>
