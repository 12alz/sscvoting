<?php
if (strpos('/inc/member.class.php', $_SERVER['SCRIPT_NAME']) !== false) { die('Access Denied'); }

//////////////////////////////////////////////////////////////////////
	$user_auth = new securelogin;
	$user_auth->use_cookie = false;
	$user_auth->use_session = true;
	$user_auth->handler['checklogin'] = 'user_checklogin';
	$user_auth->handler['encode'] = 'md5_encrypt';
	$check_inject = new sql_inject('sql_injection_log',false,false);
//////////////////////////////////////////////////////////////////////
class Member {
	
	var $login_index = array('id' => 'UserID','pass' => 'UserPWD');
	var $check_code_index = array('code' => 'ValidateCode','imgcode' => 'checkcode');
	var $reg_index = array('id' => null, 'pwd' => null,'re_pwd' => null ,'safepwd' => null ,'re_safepwd' => null, 'email' => null, 'ref_id' => null); 
	var $reset_pwd_index = array('old_pwd' => 'OldSafePWD','new_pwd' => 'NewSafePWD','renew_pwd' => 'Re_NewSafePWD');
	var $msgtype = null;
	var $login_msg_index = array('id_error' => null,'pwd_error' => null,'code_error' => null,'idpwd_error' => null, 'test_mode_msg' => null);
	var $show_result = null;
	var $show_code_check = null;
	var $default_link = 'extend.php?do=webreborn';
	var $show_pwd = false;
	var $uid_msg = null;
	var $pwd_msg = null;
	var $re_pwd_msg = null;
	var $safepwd_msg = null;
	var $re_safepwd_msg = null;
	var $email_msg = null;

	function login(){
	global $user_auth,$check_inject;	
				$check_inject->vstr($_POST[$this->login_index['id']]);
				$check_inject->vstr($_POST[$this->login_index['pass']]);

		if (!$this->_isvalidUserID($_POST[$this->login_index['id']])){
				if ($this->msgtype!=NULL){
				$this->show_result = $this->login_msg_index['id_error'];
				}else{
				$this->_alert($this->login_msg_index['id_error']);}
		}elseif (!$this->_isvalidUserPWD($_POST[$this->login_index['pass']])){
				if ($this->msgtype!=NULL){
				$this->show_result = $this->login_msg_index['pwd_error'];
				}else{
				$this->_alert($this->login_msg_index['pwd_error']);}
		}elseif (!$this->_verify_code()){
				if ($this->msgtype!=NULL){
				$this->show_result = $this->login_msg_index['code_error'];
				}else{
				$this->_alert($this->login_msg_index['code_error']);}
				$user_auth->checklogin = false;
		}else{
				$user_auth->post_index = array(	'user' => clean_variable($this->login_index['id']) ,'pass' => clean_variable($this->login_index['pass']) );
				if ($user_auth->haslogin(true)) {
				$user_auth->savelogin();
				  if ($this->msgtype!=NULL){
					jump('extend.php?do=webreborn');				  
					}else{
				 	$this->_echo('<script language="Javascript">;window.top.location=\'extend.php?do=webreborn\';</script>');
				  }
				}else{
				  if ($this->msgtype!=NULL){
				  $this->show_result = $this->login_msg_index['idpwd_error'];
				  }else{
				  $this->_alert($this->login_msg_index['idpwd_error']);
				  }
				}
		}
		
	}
	
	function editpwd(){
		global $db,$_config,$check_inject;
				$check_inject->vstr($_POST[$this->reset_pwd_index['old_pwd']]);
				$check_inject->vstr($_POST[$this->reset_pwd_index['new_pwd']]);

	    if ($_config['reg_md5']){
		$old_hash = strtoupper(substr(md5(clean_variable($_POST[$this->reset_pwd_index['old_pwd']])),0,19));
		$new_hash = strtoupper(substr(md5(clean_variable($_POST[$this->reset_pwd_index['new_pwd']])),0,19));
		}else{
		$old_hash = clean_variable($_POST[$this->reset_pwd_index['old_pwd']]);
		$new_hash = clean_variable($_POST[$this->reset_pwd_index['new_pwd']]);
		}
		$rs = $db->Execute('Select userid,userpass from ranuser.dbo.userinfo where userid = ? and userpass = ?',array($_SESSION['auth_user'],$old_hash));
		if(!$this->_isvalidUserPWD($_POST[$this->reset_pwd_index['old_pwd']]) || $rs->EOF){
			$this->show_result = _RESET_PASS_FAIL;
		}elseif(!$this->_isvalidUserPWD($_POST[$this->reset_pwd_index['new_pwd']]) || !$this->_isvalidUserPWD($_POST[$this->reset_pwd_index['renew_pwd']]) || clean_variable($_POST[$this->reset_pwd_index['new_pwd']])!=clean_variable($_POST[$this->reset_pwd_index['renew_pwd']])){
			$this->show_result = _RESET_VERIFY_PASS_MSG;
		}elseif(!$this->_verify_code()){
			$this->show_code_check = _CODE_CHECK_MSG;
		}else{
			$auth = $rs->GetArray();
			$full_info = $db->Execute('Select userid,userpass from ranuser.dbo.fulluserinfo where userid = ? and userpass = ?',array($auth[0]['userid'],clean_variable($_POST[$this->reset_pwd_index['old_pwd']])));
			$_result = $db->Execute('update ranuser.dbo.fulluserinfo set userpass = ? where userid = ?',array(clean_variable($_POST[$this->reset_pwd_index['new_pwd']]),$auth[0]['userid']));
			if($_result){
					unset($_SESSION['auth_pass']);
				$_res = $db->Execute('update ranuser.dbo.userinfo set userpass = ? where userid = ?',array($new_hash,$auth[0]['userid']));
				if($_res){
					$_SESSION['auth_pass'] = md5_encrypt(clean_variable($_POST[$this->reset_pwd_index['new_pwd']]));
					$this->_alert(_RESET_PASS_SUCCESS,'index.php');
				}
			}
		}
		
	}
	function reg(){
		global $db,$_config,$check_inject;
				$check_inject->vstr($_POST[$this->reg_index['id']]);
				$check_inject->vstr($_POST[$this->reg_index['pwd']]);
				$check_inject->vstr($_POST[$this->reg_index['re_pwd']]);
				$check_inject->vstr($_POST[$this->reg_index['safepwd']]);
				$check_inject->vstr($_POST[$this->reg_index['re_safepwd']]);
				$check_inject->vstr($_POST[$this->reg_index['email']]);
				
				
		if(!$this->_isvalidUserID($_POST[$this->reg_index['id']])){
		$this->uid_msg = '<font color=Red>'._REG_ID_FORMAT_ERR.'</font>';
		}elseif(!$this->_isvalidUserPWD($_POST[$this->reg_index['pwd']]) || !$this->_isvalidUserPWD($_POST[$this->reg_index['re_pwd']])){
		$this->pwd_msg = '<font color=Red>'._REG_PWD_FORMAT_ERR.'</font>';
		}elseif(clean_variable($_POST[$this->reg_index['pwd']])!=clean_variable($_POST[$this->reg_index['re_pwd']])){
		$this->re_pwd_msg = '<font color=Red>'._REG_RE_PWD_SAFE_MSG.'</font>';
		}elseif(!$this->_isvalidUserPWD($_POST[$this->reg_index['safepwd']]) || !$this->_isvalidUserPWD($_POST[$this->reg_index['re_safepwd']])){
		$this->safepwd_msg = '<font color=Red>'._REG_2ND_PWD_FORMAT_ERR.'</font>';
		}elseif(clean_variable($_POST[$this->reg_index['safepwd']])!=clean_variable($_POST[$this->reg_index['re_safepwd']])){
		$this->re_safepwd_msg = '<font color=Red>'._REG_RE_PWD_SAFE_MSG.'</font>';
		}elseif(!$this->_isvalidEmail($_POST[$this->reg_index['email']])){
		$this->email_msg = '<font color=Red>'._REG_EMAIL_FORMAT_ERR.'</font>';
		}elseif(!$this->_reg_check_userid($db,clean_variable($_POST[$this->reg_index['id']]))){
		$this->show_result = _REG_ID_EXIST;
		}elseif(!$this->_reg_check_email($db,stripslashes($_POST[$this->reg_index['email']])) & $_config['reg_allow_email_check']){
		$this->email_msg = '<font color=Red>'._REG_EMAIL_EXIST.'</font>';
		}elseif(!$this->_verify_code()){
		$this->show_code_check = '<font color=Red>'._CODE_CHECK_MSG.'</font>';
		}else
		{
					
				$Gender = GendType($_config['reg_auto_fill_form']['Gender']);
					
					if($this->_reg_insert_full_info($db,clean_variable($_POST[$this->reg_index['id']]),clean_variable($_POST[$this->reg_index['pwd']]),clean_variable($_POST[$this->reg_index['safepwd']]),clean_variable($_POST[$this->reg_index['id']]),clean_variable($_POST[$this->reg_index['pwd']]),$Gender,stripslashes($_POST[$this->reg_index['email']]),$_config['reg_auto_fill_form']['BirthYear'],$_config['reg_auto_fill_form']['BrithMonth'],$_config['reg_auto_fill_form']['BirthDay'],$_config['reg_auto_fill_form']['Telephone'],$_config['reg_auto_fill_form']['Mobile'],$_config['reg_auto_fill_form']['City'],$_config['reg_auto_fill_form']['Province'],$_config['reg_auto_fill_form']['Post'],$_config['reg_auto_fill_form']['Address'])){
						
								if ($_config['reg_md5']){
									$passhash = strtoupper(substr(md5(clean_variable($_POST[$this->reg_index['pwd']])),0,19));
									$safehash = strtoupper(substr(md5(clean_variable($_POST[$this->reg_index['safepwd']])),0,19));
									}else{
									$passhash = clean_variable($_POST[$this->reg_index['pwd']]);
									$safehash = clean_variable($_POST[$this->reg_index['safepwd']]);
								}

							
							if($this->_reg_insert_user_info($db,clean_variable($_POST[$this->reg_index['id']]),$passhash,$safehash,stripslashes($_POST[$this->reg_index['email']]),$_config['reg_add_points'])){
								
								
								
								if($_config['reg_allow_free_item']){
									$f = count($_config['reg_item_list']['ProductNum']);
										for($p=1;$p<=$f;$p++){
										$this->_item_insert($db,clean_variable($_POST[$this->reg_index['id']]),$_config['reg_item_list']['ProductNum'][$p-1],0,0);
									}
								}
								
								if($this->_reg_insert_vote_info($db,clean_variable($_POST[$this->reg_index['id']]))){
									unset($_SESSION['auth_user']);
									unset($_SESSION['auth_pass']);
									$_SESSION['auth_user'] = clean_variable($_POST[$this->reg_index['id']]);
									$_SESSION['auth_pass'] = md5_encrypt(clean_variable($_POST[$this->reg_index['pwd']]));
									$this->_alert(_REG_SUCCESS,'extend.php?do=webreborn');
								}
								
								
								
								
								
							}//END Insert UserInfo
						
					}//End Insert FullUserInfo
					
					
		}
	}//End Reg
	function _reg_check_email($db,$email){
			$mail_check = $db->Execute('select useremail from ranuser.dbo.userinfo where useremail = ? ',array($email));
			if($mail_check->EOF){
				return true;
			}
		return false;
	}
	function _reg_check_userid($db,$uid){
			$u_check = $db->Execute('select userid from ranuser.dbo.userinfo where userid = ? ',array($uid));
			if($u_check->EOF){
				return true;
			}
		return false;
		
	}
	function _reg_insert_full_info($db,$UID,$PWD,$SafePWD,$Fname,$Lname,$Gender,$Email,$BYear,$BMonth,$BDay,$Tel,$Mob,$City,$Province,$PostCode,$Address){
		$f_result = $db->Execute("Insert Into Ranuser.dbo.fulluserinfo ([UserName], [UserID], [UserPass], [UserPass2], [BodyID], [BodyID2], [Sex], [Email], [BirthY], [BirthM], [BirthD], [TEL], [Mobile], [QQ], [MSN], [City1], [City2], [Post], [Address], [SafeId]) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",array($UID,$UID,$PWD,$SafePWD,$Fname,$Lname,$Gender,$Email,$BYear,$BMonth,$BDay,$Tel,$Mob,0,0,$City,$Province,$PostCode,$Address,0));
		if($f_result){
			return true;
		}
		return false;
		
	}
	function _reg_insert_user_info($db,$UID,$PWD,$SafePWD,$Email,$Points){
		$u_result = $db->Execute("Insert Into Ranuser.dbo.userinfo ([UserName], [UserID], [UserPass], [UserPass2], [UserType], [UserAvailable], [ChaRemain], [ChaTestRemain], [UserEmail], [UserPoint]) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",array($UID,$UID,$PWD,$SafePWD,'1','1','2','8',$Email,$Points));
		if($u_result){
			return true;
		}
		return false;
	}
	function _reg_insert_vote_info($db,$UID){
		$v_result = $db->Execute("Insert Into Ranuser.dbo.Vote ([UserID],[last_vote],[hits]) VALUES(?,?,?)",array($UID,1,0));
		if($v_result){
			return true;
		}
		return false;
	}
	function _item_insert($db,$uid,$p_num,$price,$flag){
			
			$purKeyMax = $db->Execute("Select MAX(Purkey+1) as MaxPurkey From RanShop.dbo.ShopPurchase");
			$new_key = (int)$purKeyMax->fields["MaxPurkey"];
			$item_res = $this->_identify_shoppur($db,$new_key,$uid,$p_num,$price,$flag);
			if($item_res){
				if($this->_update_item_stock($db,$p_num)){
				return true;
				}
			}

		return false;
		
	}
	function _identify_shoppur($db,$new_key,$uid,$p_num,$price,$flag){
			$shop_res = $db->Execute('INSERT INTO RanShop.dbo.ShopPurchase ([PurKey],[UserUID],[ProductNum],[PurPrice],[PurFlag]) VALUES (?,?,?,?,?)', array($new_key,$uid,$p_num,$price,$flag));
			if($shop_res==false){
			$shop_res = $db->Execute('INSERT INTO RanShop.dbo.ShopPurchase ([UserUID],[ProductNum],[PurPrice],[PurFlag]) VALUES (?,?,?,?)', array($uid,$p_num,$price,$flag));
			}
			return $shop_res;
	}
	#Check Details
	function _getbkpwd_check_uid_pass_email($db,$uid,$safepwd,$email){
		$rs = $db->Execute('Select userid,userpass,userpass2 from ranuser.dbo.fulluserinfo where userid = ? and userpass2 = ? and email = ?',array($uid,$safepwd,$email));
		if(!$rs->EOF){
				return true;		
		}
		return false;
	}
	//Function Validator
	function _isvalidUserID($IDcheck){
		global $_config;
	if ($this->_validatorTrim($IDcheck)){
		$ex = preg_match('/^[a-zA-Z0-9\_\s]{4,12}$/i', $IDcheck);
		if($_config['allow_exp_check'])
		$ex = preg_match('/^[_a-z][_a-z0-9]{4,12}/', $IDcheck);
		if ($ex) {
		return true;
		} 
		
		
	}
		return false;
	}
	function _isvalidUserPWD($Pwdcheck){
		global $_config;
	if ($this->_validatorTrim($Pwdcheck)){
		$ex = preg_match('/^[a-zA-Z0-9\_\s]{6,12}$/i', $Pwdcheck);
		if($_config['allow_exp_check'])
		$ex = preg_match('/^[_0-9a-z]{6,12}/', $Pwdcheck);
		if ($ex) {
		return true;
		}
	}
		return false;
	}
	function _isvalidCode($Codecheck){
	if ($this->_validatorTrim($Codecheck)){
		if (preg_match('/^[0-9a-z]{4}$/', $Codecheck)) {
		return true;
		} 
	}
		return false;
	}
	function _isvalidEmail($Emailcheck){
	if ($this->_validatorTrim($Emailcheck)){
		if (preg_match('/^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*/', $Emailcheck)) {
		return true;
		} 
	}
		return false;	
	}
	function _isvalidCodeNumber($Codecheck){
	if ($this->_validatorTrim($Codecheck)){
		if (preg_match('/^[_\sA-Z0-9]{21}$/i', $Codecheck)) {
		return true;
		} 
	}
		return false;	
	}
	function _validatorTrim($s) {
	$m = preg_match('/^\s*(\S+(\s+\S+)*)\s*$/', $s);
    return ($m != null) ? true : false;
	}
	#End
	function _verify_code(){
	if ($this->_isvalidCode($_POST[$this->check_code_index['code']])){
		return ($_POST[$this->check_code_index['code']]==$_SESSION[$this->check_code_index['imgcode']]) ? true : false;
	}
	return false;	
	}	
	function _echo($p) {
		echo $p;
	}
	function _msgbox($p) {
		$t  = '<table width="500" border="0" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC" align="center">  ';
		$t .= '<tr>  	';
		$t .= '<td bgcolor="#FFFFFF" >';
		$t .= '<font color="#FF0000">&nbsp;&nbsp;';
		$t .= $p;
		$t .= '</font></td>  </tr></table>';
		return $t;
	}
	
	function _alert($txt,$link=NULL) {
		 $v = '<script language="Javascript">alert("';
		 $v.= $txt;
		 if($link)  $v.= '");window.top.location=\''.$link.'\';</script>';
		 $v.= '");window.refresh();</script>';
		 echo $v;
		 exit();
	}
	function _charge_point($db,$id,$cost){
		$sub_point_res = $db->Execute('update ranuser.dbo.userinfo set UserPoint = UserPoint-? where usernum = ?',array($cost,$id));
		if($sub_point_res){
			return true;
		}
		return false;			
	}
	function _add_points($db,$id,$points){
		$add_point_res = $db->Execute('update ranuser.dbo.userinfo set UserPoint = UserPoint+? where usernum = ?',array($points,$id));
		if($add_point_res){
			return true;
		}
		return false;	
	}
	function _check_item_stock($db,$p_num){
		$stock_check = $db->Execute('select ItemStock from ranshop.dbo.ShopItemMap where ProductNum = ? ',array($p_num));
		if(!$stock_check->EOF){
			$stock = $stock_check->GetArray();
			$stock = $stock[0];
		if($stock['itemstock'] > 2){
			return true;
		}
		}
		return false;
	}
	function _update_item_stock($db,$p_num){
		$stock_res = $db->Execute('update ranshop.dbo.shopitemmap set ItemStock = ItemStock-? where ProductNum = ?',array(1,$p_num));
		if($stock_res)	{
			return true;
		}else
		return false;
		
	}
	function productLabelView(){
	 global $_config;
		if(isset($_config['ProductCategory'][$_GET['Itemtype']])){ 
		echo str_replace(" (","<br>(",$_config['ProductCategory'][(int)$_GET['Itemtype']]); 
	 	}else{ 
		echo 'All Items List';
		}
	}	
	function productCategoryList(){
	   global $_config;
	   $categoryList = $_config['ProductCategory'];
	   $categoryKeys = array_keys($categoryList);
	   $totalCategoryList = count($categoryList);
	   if($totalCategoryList){
	echo '<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#000000">
			<tr align="center" valign="middle" bgcolor="#000000"  height=22 >';  	   
	   for($c=0;$c<$totalCategoryList;$c++){
		echo '<td onmouseover="this.style.backgroundColor=\'#FFCC66\'" onmouseout="this.style.backgroundColor=\'#000000\'" ><a href="?Itemtype=',$categoryKeys[$c],'"><font color=#FFFFFF> ',str_replace(" (","<br>(",$categoryList[$categoryKeys[$c]]),'</font></a></td>'."\n";  
	   }
	echo '</tr>
		</table>';
   	}
   }

	function _vote_update_info($db,$uid,$vote=NULL){
		if($vote!=NULL){
		$t_result = $db->Execute("update Ranuser.dbo.vote set last_vote = ? where userid = ?",array($vote,$uid));
		}else{
		$t_result = $db->Execute("update Ranuser.dbo.vote set date = ?, hits = hits+? where userid = ?",array(date('Y-m-d H:i:s'),1,$uid));
		}
		if($t_result){
			return true;
		}
		return false;
		
		
	}
	function online_check($db,$ac) {
	$userc = $db->Execute("SELECT usernum,userloginstate FROM userinfo where usernum = ?", array($ac));
	if ($userc) {
	$rs = $userc->GetArray();
	return $rs[0]['userloginstate'] == 0 ? true : false;
	} else { return false; }
	
}

	
}

/////////////////////////////////////////////////////////////////
	$_user = new Member;
/////////////////////////////////////////////////////////////////
	if(MAINTMODE){
	jump('errorpage');
	}

?>