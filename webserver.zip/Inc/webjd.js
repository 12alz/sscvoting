	var ChaStRemain;
	var OldChaStRemain=document.phpnetForm.OldChaStRemain.value;
	function Remain()
	{
		var s1=document.phpnetForm.AddChaPower.value;
		var s2=document.phpnetForm.AddChaStrong.value;
		var s3=document.phpnetForm.AddChaStrength.value;
		var s4=document.phpnetForm.AddChaSpirit.value;
		var s5=document.phpnetForm.AddChaDex.value;
		var s0=parseInt(OldChaStRemain)-s1-s2-s3-s4-s5;
		document.phpnetForm.OldChaStRemain.value=parseInt(OldChaStRemain)-s1-s2-s3-s4-s5;
	}

	function valnum1(val)
	{
		ChaStRemain=document.phpnetForm.OldChaStRemain.value;
		if (val ==""){val=0;}

		
		var s1value=document.getElementById("ctl00_ContentPlaceHolder_main_OldChaPower").value;

		var s1=document.getElementById("s1");
	
		s1.innerHTML=parseInt(s1value)+parseInt(val); 
		Remain();
		if (document.phpnetForm.OldChaStRemain.value<0)
		{
			document.getElementById("ctl00_ContentPlaceHolder_main_AddChaPower").value=0;
			s1.innerHTML=parseInt(s1value);
			Remain();
		}
	}
	function valnum2(val)
	{
		ChaStRemain=document.phpnetForm.OldChaStRemain.value;
		if (val ==""){val=0;}
		
		var s2value=document.getElementById("ctl00_ContentPlaceHolder_main_OldChaStrong").value;
		var s2=document.getElementById("s2");
		
		s2.innerHTML=parseInt(s2value)+parseInt(val); 
		Remain();
		if (document.phpnetForm.OldChaStRemain.value<0)
		{
			document.getElementById("ctl00_ContentPlaceHolder_main_AddChaStrong").value=0;
			s2.innerHTML=parseInt(s2value);
			Remain();
		}
	}
	function valnum3(val)
	{
		ChaStRemain=document.phpnetForm.OldChaStRemain.value;
		if (val ==""){val=0;ChaStRemain=parseInt(OldChaStRemain);}
		
		var s3value=document.getElementById("ctl00_ContentPlaceHolder_main_OldChaStrength").value;
		var s3=document.getElementById("s3");
		
		s3.innerHTML=parseInt(s3value)+parseInt(val); 
		Remain();		
		if (document.phpnetForm.OldChaStRemain.value<0)
		{
			document.getElementById("ctl00_ContentPlaceHolder_main_AddChaStrength").value=0;
			s3.innerHTML=parseInt(s3value);
			Remain();
		}
	}
	function valnum4(val)
	{
		ChaStRemain=document.phpnetForm.OldChaStRemain.value;
		if (val ==""){val=0;ChaStRemain=parseInt(OldChaStRemain);}
		
		var s4value=document.getElementById("ctl00_ContentPlaceHolder_main_OldChaSpirit").value;
		var s4=document.getElementById("s4");
		
		s4.innerHTML=parseInt(s4value)+parseInt(val);
		Remain();
		if (document.phpnetForm.OldChaStRemain.value<0)
		{
			document.getElementById("ctl00_ContentPlaceHolder_main_AddChaSpirit").value=0;
			s4.innerHTML=parseInt(s4value);
			Remain();
		}
	}
	function valnum5(val)
	{
		ChaStRemain=document.phpnetForm.OldChaStRemain.value;
		if (val ==""){val=0;ChaStRemain=parseInt(OldChaStRemain);}
		
		var s5value=document.getElementById("ctl00_ContentPlaceHolder_main_OldChaDex").value;
		var s5=document.getElementById("s5");
		
		s5.innerHTML=parseInt(s5value)+parseInt(val);
		Remain();
		if (document.phpnetForm.OldChaStRemain.value<0)
		{
			document.getElementById("ctl00_ContentPlaceHolder_main_AddChaDex").value=0;
			s5.innerHTML=parseInt(s5value);
			Remain();
		}
	}