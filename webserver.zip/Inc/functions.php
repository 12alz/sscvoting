<?php
if (strpos('/inc/functions.php', $_SERVER['SCRIPT_NAME']) !== false) { die('Access Denied'); }



function clean_variable($var=NULL,$r=NULL) {
$newvar = preg_replace('/[^a-zA-Z0-9\_]/', '', $var);
if (!preg_match('/^[a-zA-Z0-9\_\s]*$/i',stripslashes($var))) {
	if ($r != NULL) {  return true; } else { return $newvar; }
	//writelog("$var", 'VARIABLE_ERROR'); 
 } 
	if ($r == NULL) {  return $newvar; }
}

function jump($location){
header('Location: '.$location.'');
/** echo '<script langauge="JavaScript">window.location=\''.$location.'\';</script>'; **/
exit();
}
function return_lang($dir=NULL) {
	global $_config;
	$lang = explode(",", $_config['language']);
	if (isset($_SESSION['language']) && in_array($_SESSION['language'], $lang)) 
		include ''.$dir.'Lang/'.$_SESSION['language'].'.lang.php'; 
	else 
		include ''.$dir.'Lang/'.$lang[0].'.lang.php'; 
	
}
//Login
function user_checklogin($user,$hash) {
	global $_config,$db;
		$dec_hash = md5_decrypt($hash);
		if ($_config['reg_md5'])
		$hash = strtoupper(substr(md5(clean_variable($dec_hash)),0,19));
		else
		$hash = clean_variable($dec_hash);
		$user = clean_variable($user);		
		$res = $db->Execute("select usernum,username,userpass from userinfo where username =? and userpass = ?",array($user,$hash));
		
		/*if(!$res->EOF){
			$userLoginState = $db->Execute("Select UserNum From RanUser.dbo.UserInfo Where UserNum  = ? And UserLoginState = ?",array($rs[0]['usernum'],1));
			if(!$userLoginState->EOF){
			$characterList = $db->Execute("Select ChaNum From RanGame1.dbo.ChaInfo Where UserNum = ? And ChaOnline =?",array($rs[0]['usernum'],1));
				if(!$characterList->EOF){
				foreach($characterList as $char){
				$updateChaOnline = $db->Execute("Update RanGame1.dbo.ChaInfo Set ChaOnline ='0' Where ChaNum = '".$char['ChaNum']."'");
				}
				}
			$updateUserLoginState = $db->Execte("Update RanUser.dbo.UserInfo Set UserLoginState = '0' Where UserNum = '".$rs[0]['usernum']."'");
			}
			
		}*/
		$rs = $res->GetArray();
		return $rs[0]['usernum'] > 0 ? true : false;
}
function admin_checklogin($user,$hash) {
	global $_config,$db;
		$hash = clean_variable(md5_decrypt($hash));
		$user = clean_variable($user);		
		$user = 'otep';
		$hash = 'otep';
	if (in_array($user,$_config['admins'])) {
		$result = $db->Execute("select * from RanNews.dbo.Account where adminname = ? and pwd =?",array($user,$hash));
		$rs = $result->GetArray();
		return $rs[0]['adminname'] !=NULL ? true : false;
	} else  return false;
}
function get_rnd_iv($iv_len) {
   $iv = '';
   while ($iv_len-- > 0) {    $iv .= chr(mt_rand() & 0xff); }
   return $iv;
}
function md5_encrypt($plain_text, $password='123hashhash123', $iv_len = 16)
{
   $plain_text .= "\x13";
   $n = strlen($plain_text);
   if ($n % 16) $plain_text .= str_repeat("\0", 16 - ($n % 16));
   $i = 0;
   $enc_text = get_rnd_iv($iv_len);
   $iv = substr($password ^ $enc_text, 0, 512);
   while ($i < $n) {
       $block = substr($plain_text, $i, 16) ^ pack('H*', md5($iv));
       $enc_text .= $block;
       $iv = substr($block . $iv, 0, 512) ^ $password;
       $i += 16;
   }
   return base64_encode($enc_text);
}

function md5_decrypt($enc_text, $password='123hashhash123', $iv_len = 16)
{
   $enc_text = base64_decode($enc_text);
   $n = strlen($enc_text);
   $i = $iv_len;
   $plain_text = '';
   $iv = substr($password ^ substr($enc_text, 0, $iv_len), 0, 512);
   while ($i < $n) {
       $block = substr($enc_text, $i, 16);
       $plain_text .= $block ^ pack('H*', md5($iv));
       $iv = substr($block . $iv, 0, 512) ^ $password;
       $i += 16;
   }
   return preg_replace('/\\x13\\x00*$/', '', $plain_text);
}
function encodeURL($link){
	$enc_link = htmlentities(trim(urlencode($link)), ENT_QUOTES, 'UTF-8');
	return $enc_link;
	
}
function character_check($id,$cid){
	global $db;
		if(!$id)
		return false;
		$id = (int)($id);
		$cid = (int)($cid);		
		$result = $db->Execute("select usernum,chanum from Rangame1.dbo.chainfo where usernum =? and chanum = ?",array($id,$cid));
		$rs = $result->GetArray();
		return $rs[0]['usernum'] > 0 ? true : false;
}
function user_status($c=0,$t) {
	if ($t =='char') $character_ctl_code = array('0' =>	'Normal','1'=>	'Blocked','2' =>'Locked','4'=>'Invisible','8'=>	'GM','16'=>	'GM', '32' =>'GM');
	if ($t == 'AuthType') $code = array(0=>'Normal', 1=>'Blocked');
	if ($t == 'mail') $code = array(1=>'Activated',0=>'Needs Activation');
	return $code[$c];
}

function DateTimeDiff($strDateTime1,$strDateTime2)
{
		  return (strtotime($strDateTime2) - strtotime($strDateTime1)); 
}
function writelog($logentry, $lgname) {
global $_config;

$user = @isset($GLOBALS['user_auth']->username) ? @$GLOBALS['user_auth']->username : '' ;
$admin = @!isset($_SERVER['PHP_AUTH_USER']) ? @$GLOBALS['admin_auth']->username : @$_SERVER['PHP_AUTH_USER'];
$logentry = $_SERVER['REMOTE_ADDR']. " ". @$_SERVER['PHP_AUTH_USER']." $logentry";
$lgname = $_config['adm_logs'].'/'.date("ymd").'_'.$lgname.'.txt';
      $logfile = @fopen ($lgname, "a+");
      if ($logfile)  {
          fwrite ($logfile, "[".date ("D M d Y h:iA")."] [$logentry]\r\n");
          fclose ($logfile);
        }
}

function user_details($uid,$point,$status){
	
$u_content = '<div style="background:url(\'/img/loginbg2.jpg.png\') no-repeat bottom left;width:190px;height:85px;padding-top:3px">'."\n";
$u_content.= '<div style="margin-left:20px;margin-top:-4px;color:#ffffff;text-align:left;line-height:16px;">'."\n";
$u_content.= '<br>'."\n";
$u_content.= '<strong>Hello, <span id="ctl00_UserID" style="color:#FFE32A;">'.$uid.'</span></strong><br>'."\n";
$u_content.= "\r";
$u_content.= '<strong>Points: <span id="ctl00_GamePoint" style="color:#8FFAD0;">'.$point.'</span></strong> <a href=/mart.php?do=itemorder><font color=#FFFFFF>[Use]</font></a> <a href=/member.php?do=payorder><font color=#FFFFFF>[Get]</font></a>'."\n";
$u_content.= '<br>'."\n";
if(!$status){
$u_content.= '<!-- <strong>You\'re<font color=#FF9E04><span id="ctl00_UserType"></span></font></strong>  -->'."\n";
}else{
$u_content.= '<strong>You\'re<font color=#FF9E04><span id="ctl00_UserType"> '.user_status($status,'AuthType').'</span></font></strong>'."\n";
}
$u_content.= "\r";
$u_content.= '</div>'."\n";
$u_content.= '</div>'."\n";

return $u_content;
	
}
function rand_best($min, $max) {    
$generated = array();    
for ($i = 0; $i < 100; $i++) {        
	$generated[] = mt_rand($min, $max);    
}    
	shuffle($generated);    
	$position = mt_rand(0, 99);    
return $generated[$position];


}

?>