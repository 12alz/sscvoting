<?php
if (strpos('/inc/checkerr.php', $_SERVER['SCRIPT_NAME']) !== false) { die('Access Denied'); }

function check_errs($db,$db2,$db3,$db4){
$dbTableList = $db->MetaTables();
$db2TableList = $db2->MetaTables();
$db3TableList = $db3->MetaTables();
$db4TableList = $db4->MetaTables();

$colUserTableNames = $db->MetaColumnNames('UserInfo');
$colChaTableNames = $db2->MetaColumnNames('ChaInfo');
$colVoteTableNames = $db->MetaColumnNames('Vote');
$colItemupTableNames = $db2->MetaColumnNames('ItemCustomize');
$colShopTableNames = $db3->MetaColumnNames('ShopItemMap');

if(!in_array('Account',$db4TableList)){
	$errtble = '<hr>';
	$errtble.= '<b>RanNews</b> Database Not Exists !<br>';
	$errtble.= '<b>Please Create a New Database and Name it RanNews then restore the rannews database file</b>.<br>';
	print $errtble;
	die();
}

if(!in_array('ItemMoney',$colShopTableNames)){
	$errtble = '<hr>';
	$errtble.= '<b>ItemMoney</b> Column Not Exists in <b>RanShop</b> Database!<br>';
	$errtble.= '<b>Please Edit the <b>Price</b> column name and Name it <b>ItemMoney</b> or Execute this query if it doesn\'t allow you to make changes</b>.<br>';
	$errtble.= '<textarea rows="16" cols="125">
USE [RanShop]
GO

/****** Object:  Table [dbo].[ShopItemMap]    Script Date: 05/14/2011 09:45:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ShopItemMap](
	[ProductNum] [int] IDENTITY(1,1) NOT NULL,
	[ItemMain] [int] NULL,
	[ItemSub] [int] NULL,
	[ItemName] [varchar](100) NULL,
	[ItemList] [smallint] NULL,
	[Duration] [varchar](50) NULL,
	[Category] [int] NULL,
	[ItemStock] [int] NOT NULL,
	[ItemImage] [varchar](300) NULL,
	[ItemMoney] [int] NULL,
	[ItemComment] [varchar](50) NULL,
 CONSTRAINT [PK_ShopItemMap] PRIMARY KEY CLUSTERED 
(
	[ProductNum] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ShopItemMap] ADD  CONSTRAINT [DF_ShopItemMap_ItemList]  DEFAULT ((1)) FOR [ItemList]
GO

ALTER TABLE [dbo].[ShopItemMap] ADD  CONSTRAINT [DF__ShopItemM__ItemS__38996AB5]  DEFAULT ((0)) FOR [ItemStock]
GO


	</textarea>';
	$errtble.= '<br><b>Use Ran Manager to Add items on the ItemShop but make sure you only click Re-Create Data</b>.<br>';
	$errtble.= '<hr>';
	print $errtble;
	
	die();
}

if(!in_array('WEB_DOWNLOAD',$dbTableList)){
	$errtble = '<hr>';
	$errtble.= '<b>Web_Download</b> Table Not Exists in <b>RanUser</b> Database!<br>';
	$errtble.= '<b>Execute the code below to solve the problem</b>.<br>';
	$errtble.= "\r";
	$errtble.= '<textarea rows="16" cols="125">
USE [RanUser]
GO

/****** Object:  Table [dbo].[WEB_DOWNLOAD]    Script Date: 05/06/2011 18:36:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[WEB_DOWNLOAD](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[NAME] [varchar](100) NOT NULL,
	[DOWNLOADURL] [text] NULL,
	[EXPLAIN] [int] NULL,
	[ADDTIME] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[WEB_DOWNLOAD] ADD  CONSTRAINT [DF_WEB_DOWNLOAD_ADDTIME]  DEFAULT (getdate()) FOR [ADDTIME]
GO
	</textarea>';
	$errtble.= '<hr>';
	print $errtble;
	die();
}
if(!in_array('Vote',$dbTableList) || !in_array('last_vote',$colVoteTableNames) & !in_array('UserID',$colVoteTableNames) & !in_array('date',$colVoteTableNames)& !in_array('hits',$colVoteTableNames)){
	$errtble = '<hr>';
	$errtble.= '<b>Vote</b> Table Not Exists or Column Names are <b>Invalid</b> in <b>RanUser</b> Database!<br>';
	$errtble.= 'Delete the <b>Vote</b> Table in RanUser Database and<br>';
	$errtble.= '<b>Execute the code below to solve the problem</b>.<br>';
	$errtble.= '<textarea rows="16" cols="125">
USE [RanUser]
GO

/****** Object:  Table [dbo].[Vote]    Script Date: 04/29/2011 14:44:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Vote](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [varchar](20) NOT NULL,
	[last_vote] [int] NULL,
	[date] [datetime] NOT NULL,
	[hits] [int] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Vote] ADD  CONSTRAINT [DF_VoteTime_UserName]  DEFAULT (\'\') FOR [UserID]
GO

ALTER TABLE [dbo].[Vote] ADD  CONSTRAINT [DF_VoteTime_date]  DEFAULT (\'1970-02-01\') FOR [date]
GO
	</textarea>';
	$errtble.= '<hr>';
	print $errtble;
	die();
}

}
if(count($_config['ucp_vote_links']) < 4 || count($_config['ucp_vote_links']) > 4){
	$errtble = '<hr>';
	$errtble.= '<b>Vote</b> Links Configuration Error!<br>';
	$errtble.= 'Vote is less then or greater then 4, must contain the total of 4 sites only.';
	print $errtble;
	die();
}
?>