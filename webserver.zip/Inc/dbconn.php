<?php
if (strpos('/inc/dbconn.php', $_SERVER['SCRIPT_NAME']) !== false) { die('Access Denied'); }


include('adodb5/adodb.inc.php');
define('ADODB_ASSOC_CASE', 0); 
define('ADODB_FETCH_DEFAULT',0);
$ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;

$db = ADONewConnection('mssql');
$db->locale = 'us_english';
$db->debug = $_config['dbdebug'];
$rs = $db->Connect($_config['Server'], $_config['User'], $_config['Pass'], $_config['DB']) or die("Unable to connect Microsoft SQL Server! " .$db->ErrorMsg());

function selectdb($dbname){
global $_config;
$db = new COM("ADODB.Connection") or die("Unable to connect ".$_config['DB']."!");
$db->Open("Driver={SQL Server};Server=".$_config['Server'].";Database=".$dbname.";UID=".$_config['User'].";PWD=".$_config['Pass'].";");
return $db;

}
 
function fncSelectRecord($strConn,$strTable,$strCondition=NULL)
{
		if($strCondition!=NULL)
		$strSQL = "SELECT * FROM $strTable WHERE $strCondition ";
		else
		$strSQL = "SELECT * FROM $strTable ";
		$objRec = selectdb($strConn)->Execute($strSQL);
		return $objRec;
}
function fncListRecord($strConn,$strTable,$strCondition=NULL,$strSelect=NULL)
{
		if ($strSelect!=NULL || $strCondition!=NULL)
		$strSQL = "SELECT $strSelect FROM $strTable WHERE $strCondition ";
		else
		$strSQL = "SELECT * FROM $strTable ";
		$objRec = new COM("ADODB.Recordset");
		$objRec->Open($strSQL, selectdb($strConn), 1,3);
		return $objRec;
}
?>