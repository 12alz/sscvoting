<?php

function getItemString(){
	$myFile = "item_names_string.txt";
	$lines = file($myFile);
	$data = array();
	
	foreach($lines as $key => $value){
		$str = explode('	',$value);
		$str1 = $str[0];
		$str2 = $str[1];
		
		if (strpos($str1, 'IN') !== false) {
			$data[str_replace('IN_','',$str1)] = $str2;
		}
	}
	return $data;
}

function CHECKREQUIRED(){
		
		global 	$_IS_ITEM_COMPLETE,
				$materials,
				$selectedItem,
				$chaInfo;
				// console($materials);
		
		foreach($materials as $key => $value){
			
			if($key != 0){
				
				if(isset($value[0]) && isset($value[1])){
					$ITEMREQ = $value[0]; //MATERIALS REQUIRED
					$ITEMQTY = $value[1]; //CURRENT ITEM QTY 
					if( $ITEMQTY >= $ITEMREQ ){
						$_IS_ITEM_COMPLETE = true;
					}else{
						$_IS_ITEM_COMPLETE = false;
						return false;
					}
				}
				
			}
		}
		
		$_IS_ITEM_COMPLETE = $chaInfo->chaMoney < (int)$selectedItem['gold'] ? false:true;
		
	}
	
	function loadHTML($var,$data){
		
		$html = '';
		$html = $var($data);
		return $html;
	}
	
	function itemMix_reqQTY(){
		
		global  $materials,
				$items;
		
		// console($items);
		$cnt = 0;
		foreach($materials as $key => $value){
			
			if($key != 0){
				//check materials
				if(isset($items[$key])){
					$materials[$key][1] = $items[$key]['qty'];
				}else{
					$materials[$key][1] = 0;
				}
				
			}
			$cnt++;
		}
		
	}
	
	function GET_NEW_ITEM(){
		
		global 	$selectedItem,
				$NEWITEM,
				$itemInventory,
				$ItemAttribs,
				$itemcustomize;
		
		// $NEWITEM = ITEM_FORMATS()[$selectedItem['type']];
		// $NEWITEM = ITEM_FORMATS();
		// $NEWITEM = $NEWITEM[$selectedItem['type']];
		$NEWITEM = $selectedItem['data'];
		// console($NEWITEM);
		//function fusionAddOn($infoArray,$subOption,$added){
		
		$data = $NEWITEM;
		foreach($ItemAttribs as $key => $value){
			
			$items = item_decode($data,null,null,false);
			// console($ItemAttribs);
			$option = -1;
			switch($key){
				case 'Damage':
					$option = 12;
				break;
				case 'Defense':
					$option = 13;
				break;
				case 'Atkrate':
					$value = (int)$value / 100;
					$option = 1;
				break;
				case 'Defrate':
					$value = (int)$value / 100;
					$option = 2;
				break;
				case 'HP':
					$option = 5;
				break;
				case 'HMSrate':
					$value = (int)$value / 100;
					$option = 11;
				break;
				case 'Hitrate':
					$value = (int)$value / 100;
					$option = 3;
				break;
				default:
					$option = $option;
				break;
			}
			
			if($option >= 0){
				
				$itemz = $itemcustomize->fusionAddOn($items,$option,$value);
				$data = $itemz['Data'];
				// echo '<br ><br ><br >';
				// echo '<pre>';
				// var_dump($data);
			}
			
		}
		$NEWITEM = $data;
		// console('sdfsfd');
		$INV['Data'] = $NEWITEM;
		// console($itemInventory);
		array_unshift($itemInventory,$INV);
		// console($itemInventory);
		// $itemInventory[] = $INV;
		
		return $NEWITEM;
	}
	
	function RECODEITEM(){
		global 	$itemInventory;
		// console($itemInventory);
		$newdata = array();
		$cnt = 0;
		foreach($itemInventory as $key => $value){
			$dt = $value['Data'];
		
			$str = strval($cnt);
			if($cnt >= 9){
				
				$dt[1] = $str[0];
				$dt[5] = $str[1];
			}else{
				$dt[1] = 0;
				$dt[5] = $str[0];
				// console($cnt);
			}
			
			$newdata[] = $dt;
			
			$cnt++;
		}
		return $newdata;
	}
	
	function getItemPosition($data){
		return $data[1].$data[5];
	}
	
	function PUT_IN_INVE($RESORT_ITEM_INVE){
		global 	$character,
				$USER_ID,
				$CID,
				$HEADERITEM,
				$REMAINING_ITEM,
				$status;
		
		//$chaInfo->chaInven.' where ChaNum = ?',array($chaInfo->chaNum
		// console($user);
		
		// $strlen = strlen($str);
		// if ($strlen % 2 !== 0) {
			// user_error('Hexadecimal input string must have an even length', E_USER_WARNING);
			// return false;
		// }
		
		if($status)
			$REMAINING_ITEM++;
		
		// console($RESORT_ITEM_INVE);
		$compressItem = implode('',$RESORT_ITEM_INVE);
		$header = fix_header_element($REMAINING_ITEM,$HEADERITEM);
		
		
		// $itemInventoryEncoded = hex2bin($compressItem);
		// $obj = (object) array( 'chaInven' => $itemInventoryEncoded, 'chaNum' => $CID);
		$character->characterVO->chaInven = strtoupper($header.$compressItem);
		// console($character->characterVO->chaInven);
		$res = $character->CharUpdateInventory($character->characterVO);
		
	}
	
	// function enc_dec($str,$type){
		// global $CRYPTPASS;
		// return $type ? openssl_encrypt($str,"AES-128-ECB",$CRYPTPASS) : openssl_decrypt($str,"AES-128-ECB",$CRYPTPASS);
	// }
	
	function encrypt($str) {
		global $CRYPTPASS;
		
		if(!$str){return false;}
		$skey = substr($CRYPTPASS, 2, 4);
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$crypttext = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $skey, $str, MCRYPT_MODE_ECB, $iv);
		return trim(safe_encode($crypttext)); 
	}

	/**
	 * Returns decrypted original string
	 */
	function decrypt($str) {
		global $CRYPTPASS;
		
		if(!$str){return false;}
		$skey = substr($CRYPTPASS, 2, 4);
		$crypttext = safe_decode($str);
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$decrypttext = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $skey, $crypttext, MCRYPT_MODE_ECB, $iv);
		return trim($decrypttext);
	}
	
	function safe_encode($string) {
		$data = base64_encode($string);
		$data = str_replace(array('+','/','='),array('ZZZ','DOL',''),$data);
		return $data;
	}

	function safe_decode($string) {
		$data = str_replace(array('ZZZ','DOL'),array('+','/'),$string);
		$mod4 = strlen($data) % 4;
		if ($mod4) {
			$data .= substr('====', $mod4);
		}
		return stripslashes(base64_decode($data));
	}
	
	function temper_id($id){
		$id = explode('_',$id);
		
		$newSUBID = '';
		if($id[1][0] == 0){
			$newSUBID = $id[1][1].$id[1][2];
		}else{
			$newSUBID = $id[1];
		}
		
		return $id[0].'_'.$newSUBID;
		
	}
	
	function fix_header_element($remain,$headeritem){
		
		$remain = strval(dechex($remain));
		if(strlen($remain) == 2){
			$idx1 = $remain[0];
			$idx2 = $remain[1];
		}else{
			$idx1 = "0";
			$idx2 = $remain[0];
		}
		// $remainHex = dechex($idx1.$idx2);
		$headeritem[16] = $idx1;
		$headeritem[17] = $idx2;
		return $headeritem;
	}
	
	function REMOVE_MATERIALS($process){
		
		//remove materials from inventory
		
		global 	$itemInventory,
				$materials,
				$REMAINING_ITEM,
				$selectedItemMaterial;
				
		$excludeITEM = array('122_189');

		$cnt = 0;
		// console($itemInventory);
		foreach($materials as $key => $value){
			$ITEMID = $key;
			$ITEMQTY = $value[0];
			
			//not include main item of materials
			
			if($process == 'failed'){
				if($cnt == 0){
					$cnt++;
					continue;
				}
			}
				foreach($itemInventory as $k => $v){
					$ITEMID_INVE = $v['Main'].'_'.$v['Sub'];
					$ITEMQTY_INVE = $v['Makenum'];
					
					if($ITEMID == $ITEMID_INVE){
						$ITEMQTY = (int)$ITEMQTY - (int)$ITEMQTY_INVE;
						
						// if($ITEMQTY >= 0){
							
							if($ITEMQTY < 0){
							
								$qty = $ITEMQTY * -1;
								
								$quantity = strval(dechex($qty));
								
								if(strlen($quantity) == 2){
									$idx1 = $quantity[0];
									$idx2 = $quantity[1];
								}else{
									$idx1 = "0";
									$idx2 = $quantity[0];
								}
								
								$itemInventory[$k]['Data'][80] = $idx1;
								$itemInventory[$k]['Data'][81] = $idx2;
								
								$itemInventory[$k]['Makenum'] = $qty;
								
								break;
								
							}else{
								unset($itemInventory[$k]);
							}
						// }
					}
				}
			
			$cnt++;
		}
		
		$REMAINING_ITEM = count($itemInventory);
		
	}
	
	function EXTRACT_MATERIALS_ADDON(){
		global 	$itemInventory,
				$materials,
				$selectedItemMaterial,
				$ItemAttribs;
				
		$mainMaterial = explode('|',$selectedItemMaterial);
		$MID = $mainMaterial[0];
		$INVENT_POSITION = $mainMaterial[1];
		
		foreach($itemInventory as $key => $value){
			$data = $value['Data'];
			$INV_MID = $value['Main'].'_'.$value['Sub'];
			$INV_POST = $data[1].$data[5];
			
			if($INV_MID == $MID && $INV_POST == $INVENT_POSITION){
				
				if($value['Damage'] > 0 && $value['Damage'] != NULL){
					$ItemAttribs['Damage'] = $value['Damage'];
				}
				
				if($value['Defense'] > 0 && $value['Defense'] != NULL){
					$ItemAttribs['Defense'] = $value['Defense'];
				}
				
				if($value['Atkrate'] > 0 && $value['Atkrate'] != NULL){
					$ItemAttribs['Atkrate'] = $value['Atkrate'];
				}
				
				if($value['Defrate'] > 0 && $value['Defrate'] != NULL){
					$ItemAttribs['Defrate'] = $value['Defrate'];
				}
				
				if($value['HP'] > 0 && $value['HP'] != NULL){
					$ItemAttribs['HP'] = $value['HP'];
				}
				
				if($value['HMSrate'] > 0 && $value['HMSrate'] != NULL){
					$ItemAttribs['HMSrate'] = $value['HMSrate'];
				}
				
				if($value['Hitrate'] > 0 && $value['Hitrate'] != NULL){
					$ItemAttribs['Hitrate'] = $value['Hitrate'];
				}
				
				// if($value['Makenum'] > 0 && $value['Makenum'] != NULL){
					// $ItemAttribs['Makenum'] = $value['Makenum'];
				// }
				
			}
		}
	}
	
	function fix_arr($data){
		$dt = array();
		$tempITEM = array();
		foreach($data as $key => $value){
			
			$ITEMID = $value['Main'].'_'.$value['Sub'];
			
			if(! in_array($ITEMID,$tempITEM)){
				$dt[$ITEMID] = $value;
				$dt[$ITEMID]['ITEMID'] = $ITEMID;
				$dt[$ITEMID]['Name'] = $value['Name'];
				$dt[$ITEMID]['qty'] = $value['Makenum'];
				
				$tempITEM[] = $ITEMID;
			}else{
				$qty = (int)$dt[$ITEMID]['qty'] + (int)$value['Makenum'];
				$dt[$ITEMID] = $value;
				$dt[$ITEMID]['ITEMID'] = $ITEMID;
				$dt[$ITEMID]['Name'] = $value['Name'];
				$dt[$ITEMID]['qty'] = $qty;
				
			}
			
		}
		return $dt;
	}
	
	function item_view($chaInven,$reverse=false,$filterMode=true,$character) {
		global $HEADERITEM;
		$items = item_cut(strtoupper(substr(bin2hex($chaInven),24)),0,160);
		$HEADERITEM = strtoupper(substr(bin2hex($chaInven),0,24));
		
		$items = preg_split("/-/", $items, -1,PREG_SPLIT_OFFSET_CAPTURE);
		
		$totalItems = count($items);
		for ($i=0;$i<$totalItems;$i++){
			if(strlen($items[$i][0])==160){
			$num = $items[$i][0];	
			$itemz[] = item_decode($num,$i,NULL,$filterMode);
			}
		}	
		// echo '<pre>';
			// var_dump($itemz);
			// exit();
		if($reverse){
			return $items; 
		}else{
			return $itemz; 
		}
		
	}
	
	function item_cut($string, $begin, $shortlength, $number=1) {   
		   $length = strlen($string);
		   if($length > ($shortlength * $number) )     
		   {
				   $end = $begin + $shortlength;
				   $flag = 0;
				   for($x=$begin; $x < $end; $x++){   
					   if(ord($string[$x]) <= 120) { 
					   $flag++;  
					   } 
				   }
					   if($flag%2==1){	 
					   $end++;    
					   }
		   $first_part = substr($string, 0, $end);
		   $last_part = substr($string, $end);
		   
		   $newstring = $first_part. "-" .$last_part;
		   $number++;		
		   return item_cut($newstring, $end+1, $shortlength, $number);	
		   }else 
		   return $string;
	}
	
	function item_decode($_item,$itemNum=NULL,$lblNo=NULL,$filterMode=true) {
		global $_config;
		$types = array(8);
		// $item_ids = array('369_122');
		if (substr($_item,0,2)=='0x') 
		$_item = substr($_item,2);

		// if(in_array(hexdec($_item[84].$_item[85]),$types) 
		// || in_array(
			// hexdec($_item[19].$_item[16].$_item[17]).'_'.hexdec($_item[23].$_item[20].$_item[21]),
			// $item_ids)){
			
			// Get the hex contents
			$item1 = $_item[1];
			$item5 = $_item[5];
			$itemh = $item1;	
			$itemv = $item5;
			
			$item16 = $_item[16];
			$item17 = $_item[17];
			$item19 = $_item[19];
			$_id 	=  hexdec($item19.$item16.$item17);	//itemMain
			
			$item20 = $_item[20];
			$item21 = $_item[21];
			$item23 = $_item[23];
			$_idsub =  hexdec($item23.$item20.$item21); // itemSub
			
			$item64 = $_item[64];
			$item65 = $_item[65];
			$model =  hexdec($item64.$item65); //  model
			
			$item80 = $_item[80];
			$item81 = $_item[81];
			
			
			
			$makenum =  hexdec($item80.$item81); // makenum
			
			$item90 = $_item[90];
			$item91 = $_item[91];
			$damage =  hexdec($item90.$item91); // damage
			
			$item92 = $_item[92];
			$item93 = $_item[93];
			$defense =  hexdec($item92.$item93); // defense
			
			$item98 = $_item[98];
			$item99 = $_item[99];
			$elec =  hexdec($item98.$item99); // elec
			
			$item94 = $_item[94];
			$item95 = $_item[95];
			$fire =  hexdec($item94.$item95); // fire
			
			$item96 = $_item[96];
			$item97 = $_item[97];
			$ice =  hexdec($item96.$item97); // ice
			
			$item100 = $_item[100];
			$item101 = $_item[101];
			$poison =  hexdec($item100.$item101); // poison
			
			$item102 = $_item[102];
			$item103 = $_item[103];
			$spirit =  hexdec($item102.$item103); // spirit
			
			$item104 = $_item[104];
			$item105 = $_item[105];
			$rv1slot =  hexdec($item104.$item105); // rv1slot
			
			$item112 = $_item[112];
			$item113 = $_item[113];
			$item114 = $_item[114];
			$item115 = $_item[115];
			$rv1 =  hexdec($item114.$item115.$item112.$item113); // rv1
			
			$item106 = $_item[106];
			$item107 = $_item[107];
			$rv2slot =  hexdec($item106.$item107); // rv2slot
			
			$item116 = $_item[116];
			$item117 = $_item[117];
			$item118 = $_item[118];
			$item119 = $_item[119];
			$rv2 =  hexdec($item118.$item119.$item116.$item117); // rv2
			
			$item108 = $_item[108];
			$item109 = $_item[109];
			$rv3slot =  hexdec($item108.$item109); // rv3slot
			
			
			$item120 = $_item[120];
			$item121 = $_item[121];
			$item122 = $_item[122];
			$item123 = $_item[123];
			$rv3 =  hexdec($item122.$item123.$item120.$item121); // rv3
			
			$item110 = $_item[110];
			$item111 = $_item[111];
			$rv4slot =  hexdec($item110.$item111); // rv4slot
			
			$item124 = $_item[124];
			$item125 = $_item[125];
			$item126 = $_item[126];
			$item127 = $_item[127];
			$rv4 =  hexdec($item126.$item127.$item124.$item125); // rv4
			
			$item84 = $_item[84];
			$item85 = $_item[85];
			$type =  hexdec($item84.$item85); // type
			
			$item86 = $_item[86];
			$item87 = $_item[87];
			$chn =  hexdec($item86.$item87); // chn
			
			$item88 = $_item[88];
			$item89 = $_item[89];
			$field =  hexdec($item88.$item89); // field
			
			$item64 = $_item[64];
			$item65 = $_item[65];
			$unique =  hexdec($item64.$item65); // unique
			
			// $itemName = $character->getItemName($_id,$_idsub);
			// $itemName = strval(trim($this->getItemString($_id,$_idsub)));
			$itemName='';
			//getname
			$info['lblNo'] = $lblNo;
			$info['Num'] = $itemNum;
			$info['Data'] = $_item;
			$info['Makenum'] = $makenum;
			$info['Model'] = $model;
			$info['Main'] = $_id;
			$info['Sub'] = $_idsub;
			$info['Name'] = $itemName;
			$info['Hor'] = $itemh;
			$info['Ver'] = $itemv;
			$info['Damage'] = $damage;
			$info['Defense'] = $defense;
			$info['Elec'] = $elec;
			$info['Fire'] = $fire;
			$info['Ice'] = $ice;
			$info['Poison'] = $poison;
			$info['Spirit'] = $spirit;
			
			$info['Rv1Slot'] = $rv1slot;
			$info['Rv1'] = $rv1;
			$info['Rv2Slot'] = $rv2slot;
			$info['Rv2'] = $rv2;
			$info['Rv3Slot'] = $rv3slot;
			$info['Rv3'] = $rv3;
			$info['Rv4Slot'] = $rv4slot;
			$info['Rv4'] = $rv4;
			
			$info['Type'] = $type;
			$info['Field'] = $field;
			$info['Unique'] = $unique;
			$info['Gen'] = "".$type."/".$chn."/".$field."/".$unique."";
			#-- Item Addon
			$item_addon = itemAddonValue($info);
			$info['Atkrate'] = $item_addon['Atkrate'];
			$info['Defrate'] = $item_addon['Defrate'];
			$info['Hitrate'] = $item_addon['Hitrate'];
			$info['HP'] = $item_addon['HP'];
			//$info['HPrate'] = $item_addon['HPrate'];
			$info['HMSrate'] = $item_addon['HMSrate'];

			#-- Item Addon Slot
			$info['Atkrate_SlotNo'] = $item_addon['Atkrate_SlotNo'];
			$info['Defrate_SlotNo'] = $item_addon['Defrate_SlotNo'];
			$info['Hitrate_SlotNo'] = $item_addon['Hitrate_SlotNo'];
			$info['HP_SlotNo'] = $item_addon['HP_SlotNo'];
			//$info['HPrate_SlotNo'] = $item_addon['HPrate_SlotNo'];
			$info['HMSrate_SlotNo'] = $item_addon['HMSrate_SlotNo'];
			$info['Qty_SlotNo'] 	= $item_addon['Qty_SlotNo'];
			
			if($filterMode){
				if(itemFilter($_config['InventoryFilter'],$info)){
				return $info;
				}
			}else{
				return $info;
			}
				return false;
		// }
	}
	
	function itemFilter($type,$info){
		
		switch ($type){
					
			case "all":
				return true;
				break;	
					
			default:
				if ((check_ItemAddon($info,1,true) || check_ItemAddon($info,2,true) || check_ItemAddon($info,3,true) || check_ItemAddon($info,5,true) || check_ItemAddon($info,11,true) || ($info['Damage']!=0 & (check_ItemAddonSlot($info,false,false,true,false) || check_ItemAddonSlot($info,true,false,false,false) || check_ItemAddonSlot($info,false,true,false,false) ))  || ($info['Defense']!=0 & (check_ItemAddonSlot($info,false,false,true,false) || check_ItemAddonSlot($info,true,false,false,false)|| check_ItemAddonSlot($info,false,true,false,false)  ))  ) ){ 
				return true;
				}
				break;	
			
		}
		
		return false;
		
	}
	
	function check_ItemAddonSlot($item,$addonCheck=false,$isallAddon=false,$isallSlotEmpty=false,$isSlotEmpty=false){
		$rv1check = check_ItemAddonSlotNo($item['Rv1Slot']);
		$rv2check = check_ItemAddonSlotNo($item['Rv2Slot']);
		$rv3check = check_ItemAddonSlotNo($item['Rv3Slot']);
		$rv4check = check_ItemAddonSlotNo($item['Rv4Slot']);
		
		//if one of the rv slot contains the addon No
		if($addonCheck){
			if (($rv1check==true || $rv2check==true || $rv3check==true || $rv4check==true) & ($item['Rv1Slot']==0 & $item['Rv2Slot']==0 & $item['Rv3Slot']==0 & $item['Rv4Slot']==0))		
			return true;
		}
		//check if all addon is present
		if($isallAddon){
			if ($rv1check==true || $rv2check==true || $rv3check==true || $rv4check==true)	
			return true;
		}
		//Check if all slot in the item in empty
		if($isallSlotEmpty){
			if ($item['Rv1Slot']==0 & $item['Rv2Slot']==0 & $item['Rv3Slot']==0 & $item['Rv4Slot']==0)		
			return true;
		}
		//check if one of the addon is empty
		if($isSlotEmpty){
			if ($item['Rv1Slot']==0 || $item['Rv2Slot']==0 || $item['Rv3Slot']==0 || $item['Rv4Slot']==0)		
			return true;
		}
		
		  
		return false;
	}
	
	function check_ItemAddonSlotNo($rvslot){
		switch ($rvslot){
				case 1: case 2: case 3: case 5: case 11:
				return true;
				break;
		}
			return false;
	}
	
	function itemAddonValue($item){
		for($d=0;$d<4;$d++){
			switch ($item['Rv'.($d+1).'Slot']){
				case 1:
					$info['Atkrate'] = $item['Rv'.($d+1)];
					$info['Atkrate_SlotNo'] = 1;
					break;
				case 2:
					$info['Defrate'] = $item['Rv'.($d+1)];
					$info['Defrate_SlotNo'] = 2;
					break;
				case 3:
					$info['Hitrate'] = $item['Rv'.($d+1)];
					$info['Hitrate_SlotNo'] = 3;
					break;	
				case 5:
					$info['HP'] = $item['Rv'.($d+1)];
					$info['HP_SlotNo'] = 5;
					break;
				/*case 6:
					$info['Makenum'] = $item['Rv'. ($d+1)];
					$info['Qty_SlotNo'] = 6;
					break;*/
				//case 8: #-- HP Rate Only - Disabled
					//$info['HPrate'] = $item['Rv'.($d+1)];
					//$info['HPrate_SlotNo'] = 8;
					//break;	
				case 11: #-- HP+MP+SP Recovery Rate
					$info['HMSrate'] = $item['Rv'.($d+1)];
					$info['HMSrate_SlotNo'] = 11;
					break;
				}
		}	
			return $info;
	}
	
	function check_ItemAddonType($info,$addonNo,$slot1,$slot2,$slot3){
				switch ($addonNo){
					case 1: case 2: case 118:
					if(isItemAddonType($info,$addonNo,$slot1,$slot2,$slot3)){
						return true;
					}
					break;
									
				}	
		return false;
	}
	function check_ItemAddon($info,$addonNo,$checkAddonSlot=false){
		if ($info['Rv1Slot']==$addonNo){
			if($checkAddonSlot){
				if (check_ItemAddonType($info,$addonNo,'Rv2Slot','Rv3Slot','Rv4Slot')){
						return true;
				}
			}else
			return true;
		}elseif ($info['Rv2Slot']==$addonNo){
			if($checkAddonSlot){
				if (check_ItemAddonType($info,$addonNo,'Rv1Slot','Rv3Slot','Rv4Slot')){
						return true;
				}
			}else
			return true;
		}elseif ($info['Rv3Slot']==$addonNo){
			if($checkAddonSlot){
				if (check_ItemAddonType($info,$addonNo,'Rv1Slot','Rv2Slot','Rv4Slot')){
						return true;
				}
			}else
			return true;
		}elseif ($info['Rv4Slot']==$addonNo){
			if($checkAddonSlot){
				if (check_ItemAddonType($info,$addonNo,'Rv1Slot','Rv2Slot','Rv3Slot')){
						return true;
				}
			}else
			return true;
		}
		return false;
	}
	
	function hex2bin($str) {
		$map = array(
			'00'=>"\x00", '10'=>"\x10", '20'=>"\x20", '30'=>"\x30", '40'=>"\x40", '50'=>"\x50", '60'=>"\x60", '70'=>"\x70",
			'01'=>"\x01", '11'=>"\x11", '21'=>"\x21", '31'=>"\x31", '41'=>"\x41", '51'=>"\x51", '61'=>"\x61", '71'=>"\x71",
			'02'=>"\x02", '12'=>"\x12", '22'=>"\x22", '32'=>"\x32", '42'=>"\x42", '52'=>"\x52", '62'=>"\x62", '72'=>"\x72",
			'03'=>"\x03", '13'=>"\x13", '23'=>"\x23", '33'=>"\x33", '43'=>"\x43", '53'=>"\x53", '63'=>"\x63", '73'=>"\x73",
			'04'=>"\x04", '14'=>"\x14", '24'=>"\x24", '34'=>"\x34", '44'=>"\x44", '54'=>"\x54", '64'=>"\x64", '74'=>"\x74",
			'05'=>"\x05", '15'=>"\x15", '25'=>"\x25", '35'=>"\x35", '45'=>"\x45", '55'=>"\x55", '65'=>"\x65", '75'=>"\x75",
			'06'=>"\x06", '16'=>"\x16", '26'=>"\x26", '36'=>"\x36", '46'=>"\x46", '56'=>"\x56", '66'=>"\x66", '76'=>"\x76",
			'07'=>"\x07", '17'=>"\x17", '27'=>"\x27", '37'=>"\x37", '47'=>"\x47", '57'=>"\x57", '67'=>"\x67", '77'=>"\x77",
			'08'=>"\x08", '18'=>"\x18", '28'=>"\x28", '38'=>"\x38", '48'=>"\x48", '58'=>"\x58", '68'=>"\x68", '78'=>"\x78",
			'09'=>"\x09", '19'=>"\x19", '29'=>"\x29", '39'=>"\x39", '49'=>"\x49", '59'=>"\x59", '69'=>"\x69", '79'=>"\x79",
			'0a'=>"\x0a", '1a'=>"\x1a", '2a'=>"\x2a", '3a'=>"\x3a", '4a'=>"\x4a", '5a'=>"\x5a", '6a'=>"\x6a", '7a'=>"\x7a",
			'0b'=>"\x0b", '1b'=>"\x1b", '2b'=>"\x2b", '3b'=>"\x3b", '4b'=>"\x4b", '5b'=>"\x5b", '6b'=>"\x6b", '7b'=>"\x7b",
			'0c'=>"\x0c", '1c'=>"\x1c", '2c'=>"\x2c", '3c'=>"\x3c", '4c'=>"\x4c", '5c'=>"\x5c", '6c'=>"\x6c", '7c'=>"\x7c",
			'0d'=>"\x0d", '1d'=>"\x1d", '2d'=>"\x2d", '3d'=>"\x3d", '4d'=>"\x4d", '5d'=>"\x5d", '6d'=>"\x6d", '7d'=>"\x7d",
			'0e'=>"\x0e", '1e'=>"\x1e", '2e'=>"\x2e", '3e'=>"\x3e", '4e'=>"\x4e", '5e'=>"\x5e", '6e'=>"\x6e", '7e'=>"\x7e",
			'0f'=>"\x0f", '1f'=>"\x1f", '2f'=>"\x2f", '3f'=>"\x3f", '4f'=>"\x4f", '5f'=>"\x5f", '6f'=>"\x6f", '7f'=>"\x7f",

			'80'=>"\x80", '90'=>"\x90", 'a0'=>"\xa0", 'b0'=>"\xb0", 'c0'=>"\xc0", 'd0'=>"\xd0", 'e0'=>"\xe0", 'f0'=>"\xf0",
			'81'=>"\x81", '91'=>"\x91", 'a1'=>"\xa1", 'b1'=>"\xb1", 'c1'=>"\xc1", 'd1'=>"\xd1", 'e1'=>"\xe1", 'f1'=>"\xf1",
			'82'=>"\x82", '92'=>"\x92", 'a2'=>"\xa2", 'b2'=>"\xb2", 'c2'=>"\xc2", 'd2'=>"\xd2", 'e2'=>"\xe2", 'f2'=>"\xf2",
			'83'=>"\x83", '93'=>"\x93", 'a3'=>"\xa3", 'b3'=>"\xb3", 'c3'=>"\xc3", 'd3'=>"\xd3", 'e3'=>"\xe3", 'f3'=>"\xf3",
			'84'=>"\x84", '94'=>"\x94", 'a4'=>"\xa4", 'b4'=>"\xb4", 'c4'=>"\xc4", 'd4'=>"\xd4", 'e4'=>"\xe4", 'f4'=>"\xf4",
			'85'=>"\x85", '95'=>"\x95", 'a5'=>"\xa5", 'b5'=>"\xb5", 'c5'=>"\xc5", 'd5'=>"\xd5", 'e5'=>"\xe5", 'f5'=>"\xf5",
			'86'=>"\x86", '96'=>"\x96", 'a6'=>"\xa6", 'b6'=>"\xb6", 'c6'=>"\xc6", 'd6'=>"\xd6", 'e6'=>"\xe6", 'f6'=>"\xf6",
			'87'=>"\x87", '97'=>"\x97", 'a7'=>"\xa7", 'b7'=>"\xb7", 'c7'=>"\xc7", 'd7'=>"\xd7", 'e7'=>"\xe7", 'f7'=>"\xf7",
			'88'=>"\x88", '98'=>"\x98", 'a8'=>"\xa8", 'b8'=>"\xb8", 'c8'=>"\xc8", 'd8'=>"\xd8", 'e8'=>"\xe8", 'f8'=>"\xf8",
			'89'=>"\x89", '99'=>"\x99", 'a9'=>"\xa9", 'b9'=>"\xb9", 'c9'=>"\xc9", 'd9'=>"\xd9", 'e9'=>"\xe9", 'f9'=>"\xf9",
			'8a'=>"\x8a", '9a'=>"\x9a", 'aa'=>"\xaa", 'ba'=>"\xba", 'ca'=>"\xca", 'da'=>"\xda", 'ea'=>"\xea", 'fa'=>"\xfa",
			'8b'=>"\x8b", '9b'=>"\x9b", 'ab'=>"\xab", 'bb'=>"\xbb", 'cb'=>"\xcb", 'db'=>"\xdb", 'eb'=>"\xeb", 'fb'=>"\xfb",
			'8c'=>"\x8c", '9c'=>"\x9c", 'ac'=>"\xac", 'bc'=>"\xbc", 'cc'=>"\xcc", 'dc'=>"\xdc", 'ec'=>"\xec", 'fc'=>"\xfc",
			'8d'=>"\x8d", '9d'=>"\x9d", 'ad'=>"\xad", 'bd'=>"\xbd", 'cd'=>"\xcd", 'dd'=>"\xdd", 'ed'=>"\xed", 'fd'=>"\xfd",
			'8e'=>"\x8e", '9e'=>"\x9e", 'ae'=>"\xae", 'be'=>"\xbe", 'ce'=>"\xce", 'de'=>"\xde", 'ee'=>"\xee", 'fe'=>"\xfe",
			'8f'=>"\x8f", '9f'=>"\x9f", 'af'=>"\xaf", 'bf'=>"\xbf", 'cf'=>"\xcf", 'df'=>"\xdf", 'ef'=>"\xef", 'ff'=>"\xff",
		);
		$strlen = strlen($str);
		if ($strlen % 2 !== 0) {
			user_error('Hexadecimal input string must have an even length', E_USER_WARNING);
			return false;
		}
		if (strspn($str, '0123456789ABCDEFabcdef') !== $strlen) {
			return false;
		}
		return strtr(strtolower($str), $map);
	}
	
	function getItemString2($mid,$sid){
		$myFile = "item_names_string.txt";
		$lines = file($myFile);
		$data = array();
		$strname = '';
		$s_id = '';
		if(strlen($sid) ==  2){
			$s_id = '0'.$sid;
		}else{
			$s_id = $sid;
		}
		
		$msid = $mid.'_'.$s_id;
		
		foreach($lines as $key => $value){
			$str = explode('	',$value);
			$str1 = $str[0];
			$str2 = $str[1];
			
			if (strpos($str1, 'IN') !== false) {
				$strMSID = str_replace('IN_','',$str1);
				
				if($msid == $strMSID){
					
					$strname = $str2;
					
					break;
				}
				
			}
		}
		return $strname;
	}
	
	function console($dt){
		echo '<pre>';
		var_dump($dt);
		exit();
	}