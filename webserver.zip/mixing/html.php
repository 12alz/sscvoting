<?php

function loadInit($materials){
	global 	$selectedItem,
			$chaInfo,
			$itemMix,
			$strItems;
	$body = '';
	// var_dump($itemMix);
	$insugold = $chaInfo->chaMoney <= (int)$selectedItem['gold'] ? 'insu_gold':'';
	$cnt = 0;
	ob_start(); 
	
	?>
		<div class="itemMix">
				<div class="name_item_craft padd"><span>?1Copper Genesis Hood111</span></div>
				<ul class="material_list padd mar15">
					<li><img src="itemmix/136-20.jpg" /></li>
				</ul>
				<div class="req_text" style="text-align:center;">Required Materials</div>
				<ul class="material_list fusions_items padd">
						<?php foreach($materials as $k => $v){ ?>
							<?php if($k == 0){ ?>
								<li></li>
							<?php }else{ 
								$insu_material = $v[1] < $v[0] ? 'insu_material' : '';
								$dataid = $cnt == 0 ? "data-id='".$k."'" : '';
							?>
								<li <?= $dataid ?> class="have_material">
									<img src="itemmix/<?= str_replace('_','-',$k) ?>.jpg" />
									<div class="material_over <?= $insu_material ?>"> <?= $v[1] ?>/<?= $v[0] ?></div>
								</li>
							<?php }?>
							
						<?php $cnt++; }?>
				</ul>
				<div class="req_text_bottom" style="text-align:center;">Crafting is <?= $selectedItem['succesRate'] ?>% successfully rate</div>
				<ul class="req_material_resources">
					<li class="<?= $insugold ?>">Current Gold: <?= number_format($chaInfo->chaMoney); ?></li>
					<li>Required Gold: <?= number_format($selectedItem['gold']) ?></li>
				</ul>
				<button class="generate_action">Generate</button>
		</div>
	<?php 
	
	$body = ob_get_contents();
	ob_clean();
	
	//left sidebar
	ob_start(); 
	$cnt=0;
	?>
		<ul>
			<?php foreach($itemMix as $k => $v){ 
				$active = $cnt == 0 ? 'active':'';
				
				$strName = setMID($v['output'][0]);
				// console($strName);
			?>
				<li data-mid="<?= $v['output'][0] ?>" class="<?= $active ?>"><?= $strName ?></li>
			<?php $cnt++; } ?>
		</ul>
	<?php 
	
	$left = ob_get_contents();
	ob_clean();
	
	$out['right'] = $body;
	$out['left'] = $left;
	return $out;
}

function setMID($dt){
	global $strItems;
	$MID = explode('_',$dt);
	$main = strlen($MID[0]) == 2 ? '0'.$MID[0] : $MID[0];
	$sub = strlen($MID[1]) == 2 ? '0'.$MID[1] : $MID[1];
	$MID = $main.'_'.$sub;
	$strName = $strItems[$MID];
	return $strName;
}

function getItemHTML($items){
	global 	$FMID,
			$strItems;
	
	$mid_sid = explode('_',$FMID);
	$MID = $mid_sid[0];
	$SID = $mid_sid[1];
	$data = array();
	// console($items);
	ob_start(); 
	$cnt=0;
	
	?>
		
		<?php 
			foreach($items as $key => $value){ 
				if($MID == $value['Main'] && $SID == $value['Sub']){
					$data[] = $value;
				}
			}
		?>
		
		<?php if(count($data) > 0){ ?>
			<?php foreach($data as $key => $value){ 
				$MAINSUB = $value['Main'].'_'.$value['Sub'];
				$strName = setMID($MAINSUB);
				$itemPosition = encrypt($MAINSUB.'|'.getItemPosition($value['Data']));
				
				// console($itemPosition);
			?>
				<tr class="rowstyle" onmouseover="this.style.backgroundColor='#DAEAFD';this.style.color='blue'" onmouseout="this.style.backgroundColor=''" style="height: 20px; color: blue;"> 
					<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"> 
						<input type="radio" name="item" data-id="<?= $MAINSUB.'|'.getItemPosition($value['Data']) ?>" data-position="<?= getItemPosition($value['Data']) ?>" value="<?= $itemPosition ?>" />
					</td>
					<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"><?= $strName ? $strName : '--' ?></td>
					<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"><?= $value['Damage'] ?></td>
					<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"><?= $value['Defense'] ?></td>
					<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"><?= $value['Atkrate'] ? $value['Atkrate'] / 100 :'--'?>%</td>
					<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"><?= $value['Defrate'] ? $value['Defrate'] / 100 :'--' ?>%</td>
					<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"><?= $value['HP'] ? $value['HP'] :'--'  ?></td>
					<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"><?= $value['HMSrate'] ? $value['HMSrate'] / 100 :'--' ?>%</td>
					<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"><?= $value['Hitrate'] ? $value['Hitrate'] / 100 :'--' ?>%</td>
					<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"><?= $value['Makenum'] ? $value['Makenum'] :'--' ?></td>
				</tr>
				
			<?php } ?>
		<?php }else{ ?>
			<tr class="rowstyle" onmouseover="this.style.backgroundColor='#DAEAFD';this.style.color='blue'" onmouseout="this.style.backgroundColor=''" style="height: 20px; color: blue;"> 
				<td colspan="10" align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"> 
					Item Not found in you're inventory
				</td>
			</tr>
		<?php } ?>
		
	<?php 
	
	$item = ob_get_contents();
	ob_clean();
	
	$out['item'] = $item;
	return $out;
}