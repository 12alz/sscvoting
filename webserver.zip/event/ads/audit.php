<script type="text/javascript"><!--
google_ad_client = "pub-9246739212694120";
/* 728x90, created 12/14/09 */
google_ad_slot = "4669219598";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
