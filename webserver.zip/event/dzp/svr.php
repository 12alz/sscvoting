<?php
include_once('../../root.inc.php');
include_once('../../lib/logic/ItemPurchase.php');
include_once('../../lib/logic/ShopItemMap.php');
include_once('../../control/ctl_shopitemmap.inc.php');
$event = new ShopItemMapController;
$event->playBingo();
?>
