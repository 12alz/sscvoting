<?php
include_once('../../root.inc.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title><?php echo PAGE_TITLE;?></title>
<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<meta name="description" content="<?php echo PAGE_TITLE;?>" />
<meta name="keywords" content="<?php echo PAGE_TITLE;?>" />
<meta http-equiv="imagetoolbar" content="no" />	
<link rel="shortcut icon" href="../../common/ran.ico" type="image/x-icon" />
<link rel="stylesheet" href="../../common/css/Layout.css" />
<link rel="stylesheet" href="../../common/css/main.css" />
<link rel="stylesheet" href="../../common/css/SubPage.css" />
<link rel="stylesheet" href="../../common/css/table.css" />
<link rel="stylesheet" href="../../common/css/common.css" />
<script type="text/javascript" src="../../common/main.js"></script>

<script type="text/javascript" src="../../common/menu.js"></script>	
<script type="text/JavaScript">
</script>
</head>
<body onload="MM_preloadImages('../../img/Common/menu_sub_31s.jpg','../../img/Common/menu_sub_33s.jpg','../../img/Common/menu_sub_34s.jpg','../../img/Common/menu_sub_35s.jpg','../../img/Common/menu_sub_36s.jpg','../../img/Common/menu_sub_37s.jpg','../../img/Common/menu_sub_38s.jpg','../../img/Common/menu_sub_22s.jpg','../../img/Common/menu_sub_391s.jpg','../../img/Common/menu_sub_24s.jpg','../../img/Common/menu_sub_25s.jpg')">

<div id="wrap">
    <div id="navigation"></div>
    
<!--subbanner-->
	<div id="subVisual"></div>

    
    <div id="contentsWrap">
        <div id="contentsNavi">
            <div id="loginBox" >

    <script type="text/javascript">
    
    function setBack(obj, showBg) {
        if (showBg == false) {
            obj.className = 'clearBg';
        }
        
        if (showBg == true && obj.value == '') {
            obj.className = '';
        }
    }
    </script>
<?php 
if($user_auth->haslogin){
$user = $user_auth->getUserInfo();
echo '	
	<div style="background:url(\'../../img/loginbg2.jpg.png\') no-repeat bottom left;width:190px;height:85px;padding-top:3px">
	<div style="margin-left:20px;margin-top:-4px;color:#ffffff;text-align:left;line-height:16px;">
	<br>

	<strong>Hello, <span id="ctl00_UserID" style="color:#FFE32A;">',$user->userID,'</span></strong><br>
	<strong>Points: <span id="ctl00_GamePoint" style="color:#8FFAD0;">',$user->userPoint,'</span></strong> <a href=../../mart.php?do=itemorder><font color=#FFFFFF>[Use]</font></a> <a href=../../member.php?do=payorder><font color=#FFFFFF>[Get]</font></a>
		<br>
	<!-- <strong>You\'re<font color=#FF9E04><span id="ctl00_UserType"></span></font></strong>  -->
	</div>

	</div>
';
}else{
?>
<div id="loginIDNPW" style="margin:26px 2px 0px 0px;margin: 2px 0 0 1px!important; /* IE7+FF */">
	<iframe name="inner2" width="190" allowTransparency="true" height="85" src="../../member/ilogin.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no"></iframe>
</div>
<?php 
}
if(!$user_auth->haslogin){
//echo '<img src="../../img/common/btn_idpw2.gif" usemap="#loginSecuritySettingMap" />';
//}else{
//echo '<img src="../../img/common/btn_idpw3.gif" usemap="#loginSecuritySettingMap" style="margin-top:-6px"/>';	
}
?>	
    <map name="loginSecuritySettingMap" id="loginSecuritySettingMap">
    <?php 
	if($user_auth->haslogin){
	echo'
        <area shape="rect" coords="3,5,100,25" href="../../member.php?do=editpwd" alt="" />
        <area shape="rect" coords="115,5,170,25" href="../../member/logout.php" alt="" />
		';
	}else{
	echo'
        <area shape="rect" coords="3,5,100,25" href="javascript:menu(1001);" alt="" />
        <area shape="rect" coords="115,5,170,25" href="javascript:menu(1002);" alt="" />
		';
	}
	?>
    </map>
		


</div>
            <div id="subMenuRing"></div>
            <div id="subMenu">
<!--leftmenn-->
<div class="subMenuBox" style="margin-top:-38px;padding-left:0px;height:180px;">
	<a href="/"><img src="/img/common/menu_sub1_title.png" style="padding-bottom:8px" height="31" onContextMenu="return false;" ></a>	
		<table border="0" cellspacing="0" cellpadding="0">
		<tr>
<?php include_once('../../parts/SubMenuBox2.php'); ?>		
		
		</table>
	</div>
	<!-- <a href="javascript:menu(101)"><img src="../../img/Main/Banner_Left090304_Check.jpg" alt="" /></a> -->
            </div>
            <!--div id="subBanner"><script>useSwf("/Common/Flash/sub_quick.swf","204","114",1)</script></div-->
        </div>
        <div id="contentsBody" >
    <div id="subContents">

	
<!--title-->
	<!--<div class="title"><img src="../../img/Title/title_301.jpg" align="left" /></div>-->

	<div class="Contents">
	
<!--contents img-->
	<img src="../../img/Intro/line_h_bdot.gif" alt="" style="margin-top:-12px"/>

        <div id="board" >
		
<table width="100%" height="350" border="0" cellspacing="0" cellpadding="0">
  <tr>

    <td  style="border-bottom:1px solid #ffffff;" valign=top>
		 <!--content/s-->
<form name="phpnetForm" method="post" action="index.php" id="phpnetForm">

<div class="space"></div>
<table width="100%" border="0" cellpadding="10" cellspacing="1" align="center" class="showdetail">
  <tr>
  	<td>
  	<span id="ctl00_ContentPlaceHolder_main__userinfo"><?php if($user_auth->haslogin){ echo '<font color=#ff0000>Hello ',$user->userID,'，You have [ ',$user->userPoint,' Points ]</font>   <input type=\'submit\' value=\'Refresh\' onclick=\'javascript:location.reload();\' class=\'btn2\' style=\'font-size:12px;height:20px;width:50px;\' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=../../mart.php?do=itemorder>>> <b>Draw record</b></a><br>'; }?></span>

		<b>
Play once wheel need <?php echo $_config['BingoPay'];?> points,100 percent winning!

<br><br>
<!--Choose The Wheel: <a href=./?id=1>[Wheel 1]</a>&nbsp;&nbsp;<a href=./?id=2>[Wheel 2]</a>
--></b><br>

		<br>
  	</td>
  </tr>
</table>

<div class="space"></div>
<div class="space"></div>
<div align=center>
		<script language="JavaScript" src="js/flashWrite.js"></script>
		<script language="javascript">
		<!--
			flashWrite('dzp01.swf','400','400','roulette','#f0f0f0','','transparent');
		//-->
		</script>
</div>
</form>
		 <!--content/e-->

	</td>
</tr>

</table>

        </div>
    </div>
    <div class="ContentsFooter"></div>
</div> 

        </div>
        <div class="clear">
        </div>
    </div>
    <div id="footer">

    </div>
</div>
<?php
display_query_console($db);
$db->Close();
?>
</body>
</html>