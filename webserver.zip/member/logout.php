<?php
include_once('../root.inc.php');
$user_auth->logout();
?>
