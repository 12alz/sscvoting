<?php
include_once('../root.inc.php');
$user_auth->iLogin();
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>login</title>
<style>
/* loginBox */
#loginBox {
	background:url("/img/common/bg_login_sub.jpg") no-repeat bottom left;
	height:114px;
	width:184px;
	padding:10px; 
}
#loginIDNPW {
    width:132px;
    _width:130px;
    float:left;
    text-align:left;
    margin:0 0 0 3px;
}
#loginIDNPW input 
{
    color:#fff; 
    font-weight:bold;
    font-size:9pt;
    height:19px; 
    width:109px; 
    padding:3px 0 0 0;
    margin:0 0 0 7px;
}

#loginIDNPW div.loginInputBack { background:url(/img/common/bg_idpw.png) no-repeat 0 0; margin-top:4px; }
#loginIDNPW div.codeInputBack { background:url(/img/common/bg_code.gif) no-repeat 0 0; margin-top:4px; }
#txtLocalID { background:url(/img/common/id_txt.gif) no-repeat 2px 3px !important; }
#txtLocalID.clearBg { background-image:none !important;}

#ValidateCode { background:url(/img/common/id_code.gif) no-repeat 2px 3px !important; }
#ValidateCode.clearBg { background-image:none; }
#txtPassword { background:url(/img/common/pw_txt.gif) no-repeat 2px 3px !important; }
#txtPassword.clearBg { background-image:none !important;}
#loginButton { display:block; float:left; margin-top:3px; }

.loginSecuritySetting {
	height:20px;
    margin:7px 0 7px 0px;
    font:normal 11px dotum; 
    color:#5899c6;
    clear:both;
}
td{font-size:9pt;color:#333333}
btna{width:48px;height:48px}
a{color:#999999}
a:link{color:#999999;text-decoration:none; font-size: 12px;} 
a:visited{color:#999999; text-decoration:none; font-size: 12px;} 
a:hover{color:#999999; text-decoration:none; font-size: 12px;} 
a:active { color:#999999; text-decoration:none; } 
body {
	margin-left: 0px;
	margin-top: 0px;
}

.boxesWShadow{
		background: rgba(56, 56, 56, 0.8) !important;
		border: 2px solid #7bbfe4 !important;
		border-radius: 19px !important;
		box-shadow: -5px 5px 6px 0px #272727 !important;
		overflow: hidden !important;
	}
	.inputOuter{
		background: rgba(0,0,0,0.5) !important;
		border-radius: 20px !important;
	}
	.inputInner{
		background: rgba(0,0,0,0) !important;
		outline: none !important;
	}
	.inputCusWidth{
		    width: 47% !important;
	}
	.boxCusMarginLeft{
		margin-left: 5px !important;
	}
	#txtPassword,#ValidateCode,#txtLocalID{
		background: rgba(0,0,0,0);
		outline: none;
	}
	.inputOuter input{color:#fff;}
	#imgVerify { 
		margin-left: 70px;
		margin-top: -20px;
		}
</style>
<link rel="stylesheet" href="../common/css/Layout.css" />

</head>

<body style="background-color=transparent">
   <script type="text/javascript">
    
    function setBack(obj, showBg) {
        if (showBg == false) {
            obj.className = 'clearBg';
        }
        
        if (showBg == true && obj.value == '') {
            obj.className = '';
        }
    }
    </script>
    

      <form name="form1" method="post" action="<?php echo 'ilogin.php'; ?>" id="form1">
<div>
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="<?php echo 'iLogin'; ?>" />
</div>
<div id="loginIDNPW">
<div class="loginInputBack ">
	<input name="txtLocalID" class="" type="text" maxlength="12" id="txtLocalID" tabindex="1" onFocus="setBack(this, false);" onKeyDown="setBack(this, false);" onBlur="setBack(this, true);" />
</div>
<div class="loginInputBack ">
	<input name="txtPassword" class="" type="password" maxlength="20" id="txtPassword" tabindex="2" onKeyPress="if (event.keyCode==13) {LoginNexon();}" onFocus="setBack(this, false);" onKeyDown="setBack(this, false);" onBlur="setBack(this, true);" />

</div>
<div class="codeInputBack ">
	<input name="ValidateCode" class="" type="text" maxlength="4" id="ValidateCode" tabindex="3" onFocus="setBack(this, false);" onKeyDown="setBack(this, false);" onBlur="setBack(this, true);" />
</div>
<img height=22 width=58 id="imgVerify" name="imgVerify" onClick="this.src='../VerifyCode2.php?'+Math.random()+';'" alt="Change the picture." />

<script language="JavaScript" type="text/javascript">
  form1.imgVerify.src="../VerifyCode2.php?" + Math.random();
</script>
</div>
<input type="image" name="loginButton" id="loginButton" src="../img/contents/btn_login.gif" style="height:48px;width:48px;border-width:0px;" />
  </form>
</body>
</html>
