<?php
include_once('../root.inc.php');
include_once('../control/ctl_vote.inc.php');
$userVote = new VoteController;
$userVote->vote();
?>
