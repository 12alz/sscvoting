<html xml:lang="utf-8" lang="utf-8">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta http-equiv="Cache-Control" content="no-cache; must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
</style></head>
 
<body>
<div align="center"><br>
  <br>
  
  
</div>
<div class="inspection">
<p align="center" class="text01 text_margin01">Greetings Frontiers,</p>
<p align="center" class="text02">
YongRan is currently undergoing server maintenance <br>
Preventive time: every friday from 07:00am to 09:00am (GMT+8).<br>
Access to our website and game is unavailable during these hours.<br>
This page will be available after maintenance.</p>
<div align="center"><br>
</div>
<p align="center" class="team">- Team YongRan</p>
</div>
 

 

 
<div class="copy">

<p align="center" class="copy_text">YongRan Online Copyrights © 2007 - 2099 Yongran, INC. All Rights Reserved.</p>
</div>
 
</body>
</html>