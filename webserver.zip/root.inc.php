<?php
ob_start();
session_start();
header("Cache-control: private"); 
header("Expires: ");
header("Pragma: ");
header("X-XSS-Protection: 1");
//clearstatcache();
include_once('lib/Base.inc.php');
include_once('lib/logic/FullUserInfo.php');
include_once('lib/logic/Vote.php');
include_once('lib/logic/User.php');
include_once('lib/logic/Referrer.php');
include_once('control/ctl_user.inc.php');
include_once('control/ctl_referrer.inc.php');
$db = db_conn();
$user_auth = new UserController();
$user_auth->expressionCheck = $_config['FormatExpCheck'];
?>