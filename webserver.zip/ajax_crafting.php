<?php 
// if(ENTER != 'otep') die('Access Invalid');
	include_once('root.inc.php');
	include_once('lib/common/ItemPagination.php');
	
	include_once('lib/logic/itemcustomize.php');
	include_once('lib/logic/ChaReborn.php');
	include_once('lib/logic/character.php');
	
	include_once('control/ctl_itemcustomize.inc.php');
	include_once('control/ctl_character.inc.php');
	include_once('control/ctl_chareborn.inc.php');
	include_once('control/ctl_chareborn.inc.php');
	include_once('mixing/functions.php');
	include_once('mixing/format_items.php');
	include_once('mixing/html.php');
	
	/**
		//MIXING
		//GET MATERIALS
		//CHECK ITEM
	**/
	
	$evt = clean_variable(trim(strtolower($_POST['evt'])));
	
	if(isset($_POST['MID']) && isset($_POST['CID'])){
		
		$itemid = clean_variable(trim(strtolower($_POST['MID'])));
		// $itemid = '136_02';
		$CID = clean_variable(trim(strtolower($_POST['CID'])));
		
		$FMID = '';
		
		$itemint = implode('',explode('_',$itemid));
		
		$itemMix = array();
		
		//get character info
		$character = new CharacterController;
		
		$itemcustomize = new ItemCustomizeController;
		
		$items = array();
		
		$CRYPTPASS = "*#)@(!KDiw($8!slq@_239";
		
		//bools
		$_IS_ITEM_COMPLETE = false;
		
		$materials = array();
		
		$SUCCESS_RATE = 0;
		
		//user
		$user = new UserController();
		$CUser = $user->getUserInfo();
		
		$USER_ID = $CUser->userNum;

		//Check Char exist
		$charExist = $character->checkCharExist($USER_ID,$CID);

		$data = array();
		
		$msg = '';
		
		$itemInventory = array();
		
		$HEADERITEM = '';
		
		$REMAINING_ITEM = 0;
		
		$NEWITEM = null;
		
		$selectedItem = array();
		
		$status = false;
		
		$chaInfo = array();
		
		//get all item data
		$ItemAttribs = array();
		
		//get the first item. don't delete
		$firstItem = '';
		
		$strItems = array();
		
		$selectedItemMaterial = '';
		
		//SUCCESS RATE DOMINATION---
		$SD =array(
			"100" => 100,
			"90" => 95,
			"80" => 85,
			"70" => 75,
			"60" => 65,
			"50" => 55,
			"5" => 5
		);
		
		$html = '';
		
		if($charExist)
		{
			if($character->check_UserOnline($character->member))
			{	
				
				if(! isset($_POST['evt'])){
					$msg = 'Invalid Request';
				}else{
					
					$actions =array('generate','load','click','getitem','importfusionitem');
					
					if(! in_array($evt,$actions)){
						$msg = 'Invalid Request';
					}else{
						
						//get character inventory
						$strItems = getItemString();
						$itemMix = ITEM_FORMATS();
						$character->characterVO->userNum = $CUser->userNum;
						$character->characterVO->chaNum = $CID;
						$chaInfo = $character->getChaInformation($character);
						$itemid = temper_id($itemid);
						switch($evt){
							case 'generate':
								if(is_numeric($itemint) || is_numeric($CID))
								{	
									
									if(isset($itemMix[$itemid]) && isset($_POST['enc'])){
										
										if($_POST['enc']){
											$encdata = clean_variable(trim($_POST['enc']));
											
											$selectedItemMaterial = decrypt($encdata);
											
											$selectedItem = $itemMix[$itemid];
											// console(bin2hex($character->characterVO->chaInven));
											CHECK_ITEM_MATERIAL($selectedItem,$chaInfo,$character);
											// console($selectedItem);
											if($_IS_ITEM_COMPLETE){
												
												DO_MIXING();
												
											}else{
												$msg = 'Required Gold or Material Not Complete';
											}
										}else{
											$msg = 'Item required to make fusion!';
										}
									}else{
										$msg = 'Item is invalid';
									}
									
								}else{
									$msg = 'Not allowed';
								}
							break;
							case 'load':
								if(! is_numeric($CID) ){
									$msg = 'Invalid Request';
								}else{
									
									$selectedItem = reset($itemMix);
									
									load($selectedItem,$chaInfo,$character);
									
									$html = loadHTML('loadInit',$materials);
									
								}
							break;
								
							case 'getitem':
								if(is_numeric($itemint) || is_numeric($CID))
								{	
									if( isset($_POST['fmid']) && is_numeric(implode('',explode('_',$_POST['fmid']))) ){
										
										$fmid = clean_variable(trim(strtolower($_POST['fmid'])));
										
										$selectedItem = $itemMix[$itemid];
										
										$materials = $selectedItem['materials'];

										if(isset($materials[$fmid]) && $fmid == key($materials)){
											$FMID = $fmid;
											$html = getItem($chaInfo,$character);
										}else{
											$msg = 'Invalid Request';
										}
										
									}else{
										$msg = 'Invalid Request';
									}
									
								}else{
									$msg = 'Invalid Request';
								}
								
							break;
						}
						
					}
					
				}
			}else{
				$msg = 'You Need To Logout';
			}
		}else
		{
			$msg = 'Invalid Character';
		}
		
		$data['msg'] = $msg;
		$data['func'] = 'crafting_out';
		$data['html'] = $html;
		$data['evt'] = $evt;
		echo json_encode($data);exit();
	}
	
	function getItem($chaInfo,$character){
				
		$items = item_view($chaInfo->chaInven,false,false,$character);
		$items = getItemHTML($items);
		return $items;
	}
	
	function load($selectedItem,$chaInfo,$character){
		
		global 	$items,
				$materials,
				$_IS_ITEM_COMPLETE,
				$SUCCESS_RATE,
				$SD,
				$itemInventory;
				
		$materials = $selectedItem['materials'];
		
		$items = item_view($chaInfo->chaInven,false,false,$character);
	
		$itemInventory = $items;
		
		$items = fix_arr($items);
		
		//GET req ITEM
		itemMix_reqQTY();
		
		//check if item complete
		CHECKREQUIRED();
		
	}
	
	function DO_MIXING(){
		global 	$items,
				$materials,
				$_IS_ITEM_COMPLETE,
				$SUCCESS_RATE,
				$itemInventory,
				$status;
				
		$rate = rand(0,100);
		
		if( $rate <= $SUCCESS_RATE ) {
			
			//crafting success
			
			$status = true;
			// console($itemInventory);
			//extract addon material
			EXTRACT_MATERIALS_ADDON();
			
			//remove item from inventory
			REMOVE_MATERIALS('success');
			
			//get new generated item
			GET_NEW_ITEM();
			
			//Re sort inventory
			$RESORT_ITEM_INVE = RECODEITEM();
			
			//Put item in inventory
			PUT_IN_INVE($RESORT_ITEM_INVE);
			
			//check data completed
			$_IS_ITEM_COMPLETE = true;
			
		}else{
			
			//remove sub materials but not main materials,
			//remove first materials element since this is not material not include
			//in delete.
			
			$status = false;
			REMOVE_MATERIALS('failed');
			$RESORT_ITEM_INVE = RECODEITEM();
			PUT_IN_INVE($RESORT_ITEM_INVE);
			$_IS_ITEM_COMPLETE = true;
		}
		
	}
	
	function CHECK_ITEM_MATERIAL($selectedItem,$chaInfo,$character){
		
		global 	$items,
				$materials,
				$_IS_ITEM_COMPLETE,
				$SUCCESS_RATE,
				$SD,
				$itemInventory;
		
		//Item materials
		$materials = $selectedItem['materials'];
		
		//ItemMix success rate
		$SUCCESS_RATE = $SD[$selectedItem['succesRate']];
		
		//Item type
		$type = $selectedItem['type'];
		
		//Item ID MAIN AND SUB
		$ID_MAINSUB = $selectedItem['output'][0];
		
		//How many item
		$HMI = $selectedItem['output'][1];
		
		//get get item inventory
		$items = item_view($chaInfo->chaInven,false,false,$character);
		
		// console($items);
		
		$itemInventory = $items;
		
		$items = fix_arr($items);
		
		$firstItem = key($selectedItem['materials']);
		
		//GET req ITEM
		itemMix_reqQTY();
		
		//check if item complete
		CHECKREQUIRED();
		// console();
		
	}
	
