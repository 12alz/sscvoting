<?php
	$secretKey = $_POST["Key"];
	if($secretKey == "SSdtIGdsYWQgeW91IHJlYWNoIHRoaXMgZmFy")
	{
		$search = "$_SERVER[REMOTE_ADDR]";
		$lines = file('log.txt');
		$found = false;
		foreach($lines as $line)
		{
		  if(strpos($line, $search) !== false)
		  {
			$found = true;
		  }
		}
		if(!$found)
		{
		  		$myfile = fopen("log.txt", "a");
				fwrite($myfile, $_SERVER['REMOTE_ADDR'].PHP_EOL);
				fclose($myfile);
		}else{}
	}else{die();}
?>