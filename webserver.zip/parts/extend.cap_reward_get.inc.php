
		 <!--content/s-->
<form name="phpnetForm" method="post" action="<?php echo 'extend.php?do=cap_reward_get&cid='.(int)$_GET["cid"] ?>" onsubmit="javascript:return WebForm_OnSubmit();" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ctl00_ContentPlaceHolder_main_HyperLink2')" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET3" id="__EVENTTARGET3" value="" />
<input type="hidden" name="__EVENTARGUMENT4" id="__EVENTARGUMENT4" value="" />

</div>

<script type="text/javascript">

var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        // theForm.__EVENTTARGET.value = eventTarget;
        // theForm.__EVENTARGUMENT.value = eventArgument;
		theForm.__EVENTTARGET3.value = eventTarget;
        theForm.__EVENTARGUMENT4.value = eventArgument;
        theForm.submit();
    }
}

if(sessionStorage.ses != ''){
	if(sessionStorage.ses != '<?= $getCurrentTabSession ?>'){
		alert('This tab is active. Use Reset Session to Unlock some pages');
		window.self.location='extend.php?do=cap_reward';
	}
}
</script>
<style>
.claimBtn{
	background: grey;
    padding: 9px 17px;
    color: #000;
}
.claimBtn.claim{
	color: #fff;
	background: #195791;
}
.claim_btn{
    font-weight: normal;
    background: #e3a412;
    color: #fff;
    padding: 5px 8px;
    margin-bottom: 3px;
    cursor: pointer;	
}


</style>

<?php
if($_config['AjaxMode']){
echo '<script src="/WebResource.axd/4a26f1ecae0a33a44b198d94629e3bfb.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/5460f4dfbd221bcd575ca1292a108cfa.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/42c740683f0709257bab43d28ea0de90.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/b4b17b0bafa5744aeb3dfe229abd0952.js" type="text/javascript"></script>'."\n",
	 '<script src="/WebResource.axd/8873f142ec7ff7723ba99c2d06688bce.js" type="text/javascript"></script>'."\n";
}
?>

<script type="text/javascript">
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
</script>

<html>
<body>
	
	<font color="Blue">
		<br>
		<P><FONT color=yellow size=2 face=Verdana>♦ Read the following before Claim the Cap Reward:</font></font></p>
		<P><FONT color=green size=2 face=Verdana>
		[1]. Account must be log-out ingame, before claiming rewards.<br>
		[2]. Make sure you meet your character Level and reborn  so you can claim your rewards. <br>
		[3]. Once you click the rewards it will automatically sent into you inventory.<br>
		[4]. You can only claim your reward Once (Per Account).<br>
		[5]. Be careful, The claim reward is tradable and dropable.</font></font></p>
	</font>

	<table cellspacing="0" cellpadding="4" rules="all" border="1" id="ctl00_ContentPlaceHolder_main_GridView1" style="background-color:#bceaf7;border-color:green;border-width:1px;border-style:solid;font-family:Verdana;font-size:9pt;width:100%;border-collapse:collapse;">
   <tbody>
      <tr class="headerstyle" style="font-size:9pt;font-weight:normal;height:23px;">
         <th scope="col" style="color: #fff;">Required Rebirth</th>
         <th scope="col" style="color: #fff;">Required Level</th>
         <th scope="col" style="color: #fff;">Reward</th>
         <th scope="col" style="color: #fff;">Action</th>
      </tr>
	  
		<?php 
			$dt = $itemcustomize->generateReward();
		
			foreach($dt as $key => $value){ 
			$claim = $value['claim'] ? 'claim' : '';
			?>
			
			<tr class="rowstyle" data-table="<?= $value['rewardid'] ?>" onmouseover="this.style.backgroundColor='#DAEAFD';this.style.color='blue'" onmouseout="this.style.backgroundColor=''" style="height: 20px; background-color: rgb(218, 234, 253); color: blue;">
				 <td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">
					<span id="ctl00_ContentPlaceHolder_main_GridView1_ctl02_lblNo"><?= $value['reqRB'] ?></span>
				 </td>
				 <td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;"><?= $value['reqLvl'] ?></td>
				 <td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">
				 
					<?php foreach($value['rewards'] as $k => $v){ ?>
						<p><?= $v['data']['Name'] ?> (<?= $v['pcs'] ?> <?= $v['type'] == 'materials'? 'pcs':''?>)</p>
					<?php } ?>
				 </td>
				 <td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">
					<!--<button class="claimBtn <?= $claim ?>">Claim</button>-->
					<?php if($value['claim']){ ?>
						<span>Already Claimed</span>
					<?php }else{ ?>
						<input type="submit" name="ctl00$ContentPlaceHolder_main$GridView1$ctl02$ctl00" value="Get Reward" onclick="if(confirm('Claim Reward'))__doPostBack('ctl00ContentPlaceHoldermainClientReward','RewardWB$<?= $value['rewardid'] ?>');return false;" class="btn002 claim_btn" style="font-weight:normal;">
					<?php } ?>

				 </td>
			</tr>
			
		<?php } ?>
	  
      

   </tbody>
</table>
</form>