<table width="100%" height="263" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;" valign=top>
<br>
<table width="100%" height="30" border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td width="35%" class="fontblue14px"><font style="font-size:12px;color:#ff0000"><span id="ctl00_ContentPlaceHolder_main_Result"></span></font></td>

    <td width="65%" align="right">
<a href="member.php?do=tguser" Class="button1" ><span>  User statistics </span></a> &nbsp;&nbsp;&nbsp;&nbsp;
<a href="member.php?do=tgreport" Class="button1" ><span>  Points statistics </span></a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="member.php?do=tgtext" Class="button1" ><b><span>  Referral Text </span></b></a>&nbsp;&nbsp;
    </td>
  </tr>
</table>

<div class="space"></div>
<table width="100%" border="0" cellpadding="10" cellspacing="1" align="center" class="showdetail">
  <tr>
  	<td style="padding:8px">
		<P><STRONG>Award Description:</STRONG></P>
<P><STRONG>You can get <FONT color=#ff0000 size=5><?php echo $_config['PublicityAddPoint'];?></FONT> points when your referral player level up to <?php echo $_config['PublicityRbRequest'];?>th rebirth.</STRONG></P>
  	</td>
  </tr>

</table>
<form name="phpnetForm" method="post" action="<?php echo 'member.php?do=tgtext';?>" id="phpnetForm">
<div>
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwULLTE4MTIzNDc0OTMPZBYCZg9kFgYCAQ8PFgIeBFRleHQFB2VjbzE5OTFkZAICDw8WAh8ABQEyZGQCAw8PFgIfAGRkZGS+bYW5D0lePXtNSd29cTAUyKotNw==" />
</div>

  <table width="100%" align="center" cellpadding="0" cellspacing="0" >
	<tr>
	  <td >

	    
<span id="ctl00_ContentPlaceHolder_main_Label1" style="color:Red;"></span>
      </td></tr>

  </table>
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <td align="center"><input style="width:100%;" name="button" type="button" onclick="copy('txt')" value="Copy Referral Text" /></td>
    </tr>
  </table>
  <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >
    <tr>
      <td align="center"><label>

<script language=JavaScript>
function copy(ob) {
  var obj=findObj(ob); if (obj) { 
  obj.select();js=obj.createTextRange();js.execCommand("Copy");}
}
function findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}
</script>
<textarea name="txt" id="txt" cols="80" rows="9">

Welcome to BabyRanV2 Online!

My Referral URL is: 
BabyRanV2 Online
<?php echo 'http://',$_SERVER['HTTP_HOST'],'/member.php?do=reg&uid=',$user->tj,''; ?>


Full Client Download:
<?php echo 'http://',$_SERVER['HTTP_HOST'],'/download.php'; ?>

</textarea>
<br />
      </label></td>
    </tr>
  </table>
</form>
    </td>
  </tr>
</table>