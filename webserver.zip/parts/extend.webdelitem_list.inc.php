<link type="text/css" href="img/Progress.css" rel="stylesheet" />
<table width="100%" height="350" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;" valign=top>
		 <!--content/s-->
	<form name="phpnetForm" method="post" action="<?php echo 'extend.php?do=webdelitem_list&cid='.$character->characterVO->chaNum.''; ?>" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />

</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>
<br>
<style>
#ccc th { height:22px; }
.progress {
	PADDING-RIGHT: 3px; DISPLAY: block; PADDING-LEFT: 3px; PADDING-BOTTOM: 2px; PADDING-TOP: 2px; POSITION: absolute;
MARGIN-RIGHT: auto;
MARGIN-LEFT: auto; 
vertical-align:middle;
height:69px;
width:250px;

	top: 50%;
	left: 50%;
	margin: -34px 0 0 -115px; /* -height/2 0 0 -width/2 */
	z-index:103;
}
.container {
	BORDER-RIGHT: #808080 0px solid; BORDER-TOP: #808080 1px solid; BORDER-LEFT: #808080 0px solid; BORDER-BOTTOM: #808080 1px solid
}
.header {
	BORDER-RIGHT: #808080 1px solid; PADDING-RIGHT: 10px; BORDER-TOP: #808080 0px solid; PADDING-LEFT: 10px; FONT-WEIGHT: bold; FONT-SIZE: 9pt; BACKGROUND: url('img/sprite.png') repeat-x 0px 0px; PADDING-BOTTOM: 0px; BORDER-LEFT: #808080 1px solid; COLOR: #000000; LINE-HEIGHT: 1.9; PADDING-TOP: 0px; BORDER-BOTTOM: #ccc 1px solid; FONT-FAMILY: arial,helvetica,clean,sans-serif
}
.body {
	BORDER-RIGHT: #808080 1px solid; PADDING-RIGHT: 10px; BORDER-TOP: #808080 0px solid; PADDING-LEFT: 10px; PADDING-BOTTOM: 10px; BORDER-LEFT: #808080 1px solid; PADDING-TOP: 10px; BORDER-BOTTOM: #808080 0px solid; BACKGROUND-COLOR: #f2f2f2
}
#center1{ MARGIN-RIGHT: auto;
MARGIN-LEFT: auto; 
vertical-align:middle;
}
* html .progress{ /* ie6 hack */
position: absolute;
margin-top: expression(0 - parseInt(this.offsetHeight / 2) + (TBWindowMargin = document.documentElement && document.documentElement.scrollTop || document.body.scrollTop) + 'px');
}

.headerstyle th 
{
    background: url('img/sprite.png') repeat-x 0px 0px;
    border-color: #989898 #cbcbcb #989898 #989898;
    border-style: solid solid solid none;
    border-width: 1px 1px 1px medium;
    color: #4D4D4D;
    padding: 2px 3px 2px 5px;
    text-align: center;
    vertical-align: bottom;
    font-weight: normal;
}
.altrowstyle 
{
    background-color: #edf5ff;
}
.rowstyle .sortaltrow, .altrowstyle .sortaltrow 
{
    background-color: #edf5ff;
}

.rowstyle .sortrow, .altrowstyle .sortrow 
{
    background-color: #dbeaff;
}
select {
	text-decoration: none;
	padding-top:4px;
	cursor:hand;
	BORDER: #2F89EF 1px solid;
	FONT-SIZE: 9pt; 
	color:#000000; 
	HEIGHT: 22px; 
	width:73px; 
	BACKGROUND-COLOR: #BAD9FB;
}
.btn001{
	text-decoration: none;
	padding-top:4px;
	cursor:hand;
	BORDER: #2F89EF 1px solid;
	FONT-SIZE: 9pt; 
	color:#000000; 
	HEIGHT: 22px; 
	width:130px; 
	BACKGROUND-COLOR: #BAD9FB;
}
.btn002{text-decoration: none;padding-top:4px;cursor:hand;BORDER-RIGHT: #CD9F01 1px solid; BORDER-TOP: #CD9F01 1px solid; FONT-SIZE: 9pt; BORDER-LEFT: #CD9F01 1px solid; BORDER-BOTTOM: #CD9F01 1px solid;  color:#000000;FONT-FAMILY: "宋體"; HEIGHT: 22px; width:130px; BACKGROUND-COLOR: #F8F4D0}
.btn01{
BORDER: #2F89EF 1px solid; 
FONT-SIZE: 9pt; 
cursor:hand;
color:#000000;FONT-FAMILY: "宋體"; HEIGHT: 22px; width:60px; BACKGROUND-COLOR: #BAD9FB}

.btn02{text-decoration: none;padding-top:4px;cursor:hand;BORDER-RIGHT: #CD9F01 1px solid; BORDER-TOP: #CD9F01 1px solid; FONT-SIZE: 9pt; BORDER-LEFT: #CD9F01 1px solid; BORDER-BOTTOM: #CD9F01 1px solid;  color:#000000;FONT-FAMILY: "宋體"; HEIGHT: 22px; width:60px; BACKGROUND-COLOR: #F8F4D0}

</style>
	<div id=ccc>

	<span id="ctl00_ContentPlaceHolder_main_label_UserID" style="font-weight:bold;"><a href=extend.php?do=webdelitem title='Change a Character'>Character Name: <?php echo $character->characterVO->chaName;?></a></span>
	<div class="space"></div>
	<table width="100%" border="0" cellpadding="10" cellspacing="1" align="center" class="showdetail">
	  <tr>

	  	<td style="padding:6px">
		<FONT color=#000000 size=2 face=Verdana>Item to delete will automatically deduc</FONT> <FONT color=#ff0000 size=2 face=Verdana><STRONG><?php echo $_config['DeleteItemsPay'];?></STRONG></FONT><FONT size=2 color=#000000 face=Verdana> Points.</FONT> 
		<P><FONT color=#006400 size=2 face=Verdana>1. Please logoff the game first.<BR>2. All items will appear in the web item list(character inventory) .<BR>3. The selected item will disappear.</FONT></P>

<P><FONT size=2 face=Verdana></FONT> </P>
	  	</td>
	  </tr>
	</table>
	<div class="space"></div>

	<div id="ctl00_ContentPlaceHolder_main_UpdatePanel1">
	
		<table width="100%" border="0" cellpadding="10" cellspacing="1" align="left">

		  <tr>
		  	<td>
				<div align="center" style="font-size:10pt"><span id="ctl00_ContentPlaceHolder_main_Result" style="color:Red;"></span></div>
                <b><font color="#0057DA">@ Character Inventory</font></b>
				<div class="space"></div>
				<div>
		<table cellspacing="0" cellpadding="4" rules="all" border="1" id="ctl00_ContentPlaceHolder_main_GridView1" style="background-color:White;border-color:#666666;border-width:1px;border-style:solid;font-size:9pt;width:100%;border-collapse:collapse;">
			<tr class="headerstyle" style="background-color:#CECFD6;font-size:9pt;font-weight:normal;height:23px;">

				<th scope="col">No.</th><th scope="col">Item Name</th><th scope="col">Attack</th><th scope="col">Defense</th><th scope="col">Number</th><th scope="col">Operation</th>
			</tr><?php $character->characterAllItemsView();?>
		</table>
	</div>


				</td>
			</tr>
		</table>
        
</div>
	

</form>
</div>
<br>		 <!--content/e-->
	</td>
</tr>
</table>