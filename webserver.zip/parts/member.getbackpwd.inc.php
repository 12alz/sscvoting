<table width="100%" height="263" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;" valign=top>
<form name="phpnetForm" method="post" action="<?php echo 'member.php?do=getbackpwd'; ?>" onsubmit="javascript:return WebForm_OnSubmit();" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>


<?php
if($_config['AjaxMode']){
echo '<script src="/WebResource.axd/4a26f1ecae0a33a44b198d94629e3bfb.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/5460f4dfbd221bcd575ca1292a108cfa.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/42c740683f0709257bab43d28ea0de90.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/b4b17b0bafa5744aeb3dfe229abd0952.js" type="text/javascript"></script>'."\n",
	 '<script src="/member.axd/AjaxControlToolkit.Compat.Timer.Timer.js" type="text/javascript"></script>'."\n";
}
?>
<script type="text/javascript">
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
</script>


  <img height=20 width=0><br>
<?php
if($fullUserInfo->showPassword){
echo '	
  <table width="550" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <td width="100%"><br>
        <br>
        <font style=\'font:bold 14px ;color:#ff0000 ;\'>
        <span id="ctl00_ContentPlaceHolder_main_txt">Your User ID: ',$fullUserInfo->member->userID,'&nbsp;&nbsp; Password: ',$fullUserInfo->member->userPass,' &nbsp;&nbsp;Keep in mind that!</span>

        </font><br>
        <br>
        <br>
      </td>
    </tr>
  </table>
  <table width="550" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center"><a id="ctl00_ContentPlaceHolder_main_HyperLink5" tabindex="4" class="button1" href="javascript:window.location=\'member.php?do=login\'"><b><span> Back </span></b></a> </td>

    </tr>
  </table>
  ';
}else{
?>   
  <table width="550" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <td width="25%"><img src="/images/point_b.gif" /> User ID </td>

      <td width="75%"><input name="UserID" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_UserID" style="width:143px;" tabindex="1" value="<?php echo htmlentities($_POST["UserID"], ENT_QUOTES, 'UTF-8');?>" maxlength="20" />
        <span id="ctl00_ContentPlaceHolder_main_UserIDReq" style="color:Red;display:none;"></span>
        
        <span id="ctl00_ContentPlaceHolder_main_UserID_RegEx" style="color:Red;display:none;"></span>
        
      </td>
    </tr>
  </table>
  <table width="550" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <td width="25%"><img src="/images/point_b.gif" /> Input second password </td>

      <td width="75%"><input name="SafePWD" type="password" maxlength="50" id="ctl00_ContentPlaceHolder_main_SafePWD" tabindex="2" class="form_pay" value="" style="width:143px;" />
        <span id="ctl00_ContentPlaceHolder_main_SafePWDReq" style="color:Red;display:none;"></span>
        
        <span id="ctl00_ContentPlaceHolder_main_SafePWD_RegEx" style="color:Red;display:none;"></span>
        
      </td>
    </tr>
  </table>
  <table width="550" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <td width="25%"><img src="/images/point_b.gif" /> Input Email </td>

      <td width="75%"><input name="Email" type="text" class="form_pay2" id="ctl00_ContentPlaceHolder_main_Email" style="width:243px;" tabindex="2" value="<?php echo htmlentities($_POST["Email"], ENT_QUOTES, 'UTF-8');?>" maxlength="32" />
        <span id="ctl00_ContentPlaceHolder_main_EmailReq" style="color:Red;display:none;"></span>
        
        <span id="ctl00_ContentPlaceHolder_main_Email_RegEx" style="color:Red;display:none;"></span>
        
      </td>
    </tr>
  </table>
  <table width="550" border="0" align="center" cellpadding="5" cellspacing="0"  class="boardList_03">
    <tr>
      <td width="25%"><img src="/images/point_b.gif" /> Input Identifying Code </td>

      <td width="30%"><input name="ValidateCode" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_ValidateCode" style="width:143px;" tabindex="3" value="<?php echo htmlentities($_POST["ValidateCode"], ENT_QUOTES, 'UTF-8');?>" maxlength="4" /></td>
      <td><img id="imgVerify" name="imgVerify" onclick="this.src='/VerifyCode.php?'+Math.random()+';'" alt="Change the picture." />
        <SCRIPT language=javascript>
				  phpnetForm.imgVerify.src="/VerifyCode.php?" + Math.random();
				  </script>
        <span id="ctl00_ContentPlaceHolder_main_Code_Check_Null" style="color:Red;display:none;">required.</span>
        <span id="ctl00_ContentPlaceHolder_main_ValidateCode_Check" style="color:Red;display:none;">Identifying Code Input error, please re-enter.</span>
        <span id="ctl00_ContentPlaceHolder_main_Code_Check" style="color:Red;"><?php echo $fullUserInfo->errs['CodeCheck'];?></span></td>
    </tr>

  </table><br>
  <span id="ctl00_ContentPlaceHolder_main_Result"><?php echo $fullUserInfo->errs['Result'];?></span>
  		  <br>

          <table width="550" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td align="center">
              <input type="submit" name="HyperLink2" value="Submit" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;HyperLink2&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ContentPlaceHolder_main_HyperLink2" tabindex="4" class="btn2" style="font-size:12px;height:24px;width:50px;" />
                &nbsp;&nbsp;&nbsp;&nbsp;

              <input type="reset" name="reset" value="Reset" tabindex="5" class="btn2" style="font-size:12px;height:24px;width:50px;" />
              <br><img height=20 width=0>
              </td>
            </tr>
          </table>
<script type="text/javascript">
var Page_Validators =  new Array(document.getElementById("ctl00_ContentPlaceHolder_main_UserIDReq"), document.getElementById("ctl00_ContentPlaceHolder_main_UserID_RegEx"), document.getElementById("ctl00_ContentPlaceHolder_main_SafePWDReq"), document.getElementById("ctl00_ContentPlaceHolder_main_SafePWD_RegEx"), document.getElementById("ctl00_ContentPlaceHolder_main_EmailReq"), document.getElementById("ctl00_ContentPlaceHolder_main_Email_RegEx"), document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check"));
</script>

<script type="text/javascript">
var ctl00_ContentPlaceHolder_main_UserIDReq = document.all ? document.all["ctl00_ContentPlaceHolder_main_UserIDReq"] : document.getElementById("ctl00_ContentPlaceHolder_main_UserIDReq");
ctl00_ContentPlaceHolder_main_UserIDReq.controltovalidate = "ctl00_ContentPlaceHolder_main_UserID";
ctl00_ContentPlaceHolder_main_UserIDReq.errormessage = "<font style=\'font-size:12px\'>User ID can not be empty</font>";
ctl00_ContentPlaceHolder_main_UserIDReq.display = "None";
ctl00_ContentPlaceHolder_main_UserIDReq.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_UserIDReq.initialvalue = "";
var ctl00_ContentPlaceHolder_main_UserID_RegEx = document.all ? document.all["ctl00_ContentPlaceHolder_main_UserID_RegEx"] : document.getElementById("ctl00_ContentPlaceHolder_main_UserID_RegEx");
ctl00_ContentPlaceHolder_main_UserID_RegEx.controltovalidate = "ctl00_ContentPlaceHolder_main_UserID";
ctl00_ContentPlaceHolder_main_UserID_RegEx.errormessage = "<font style=\'font-size:12px\'>User ID by the numbers, letters or composition of the underscore,<br>Length of 4 to 12, must be the first letters of the alphabet.</font>";
ctl00_ContentPlaceHolder_main_UserID_RegEx.display = "None";
ctl00_ContentPlaceHolder_main_UserID_RegEx.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_UserID_RegEx.validationexpression = "^[0-9a-zA-Z_]{4,16}$";
var ctl00_ContentPlaceHolder_main_SafePWDReq = document.all ? document.all["ctl00_ContentPlaceHolder_main_SafePWDReq"] : document.getElementById("ctl00_ContentPlaceHolder_main_SafePWDReq");
ctl00_ContentPlaceHolder_main_SafePWDReq.controltovalidate = "ctl00_ContentPlaceHolder_main_SafePWD";
ctl00_ContentPlaceHolder_main_SafePWDReq.errormessage = "<font style=\'font-size:12px\'>Identifying Code can not be empty.</font>";
ctl00_ContentPlaceHolder_main_SafePWDReq.display = "None";
ctl00_ContentPlaceHolder_main_SafePWDReq.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_SafePWDReq.initialvalue = "";
var ctl00_ContentPlaceHolder_main_SafePWD_RegEx = document.all ? document.all["ctl00_ContentPlaceHolder_main_SafePWD_RegEx"] : document.getElementById("ctl00_ContentPlaceHolder_main_SafePWD_RegEx");
ctl00_ContentPlaceHolder_main_SafePWD_RegEx.controltovalidate = "ctl00_ContentPlaceHolder_main_SafePWD";
ctl00_ContentPlaceHolder_main_SafePWD_RegEx.errormessage = "<font style=\'font-size:12px\'>Second password incorrect format.</font>";
ctl00_ContentPlaceHolder_main_SafePWD_RegEx.display = "None";
ctl00_ContentPlaceHolder_main_SafePWD_RegEx.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_SafePWD_RegEx.validationexpression = "^[0-9a-zA-Z_]{6,12}";
var ctl00_ContentPlaceHolder_main_EmailReq = document.all ? document.all["ctl00_ContentPlaceHolder_main_EmailReq"] : document.getElementById("ctl00_ContentPlaceHolder_main_EmailReq");
ctl00_ContentPlaceHolder_main_EmailReq.controltovalidate = "ctl00_ContentPlaceHolder_main_Email";
ctl00_ContentPlaceHolder_main_EmailReq.errormessage = "<font style=\'font-size:12px\'>Email can not be empty.</font>";
ctl00_ContentPlaceHolder_main_EmailReq.display = "None";
ctl00_ContentPlaceHolder_main_EmailReq.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_EmailReq.initialvalue = "";
var ctl00_ContentPlaceHolder_main_Email_RegEx = document.all ? document.all["ctl00_ContentPlaceHolder_main_Email_RegEx"] : document.getElementById("ctl00_ContentPlaceHolder_main_Email_RegEx");
ctl00_ContentPlaceHolder_main_Email_RegEx.controltovalidate = "ctl00_ContentPlaceHolder_main_Email";
ctl00_ContentPlaceHolder_main_Email_RegEx.errormessage = "<font style=\'font-size:12px\'>Email incorrect format.</font>";
ctl00_ContentPlaceHolder_main_Email_RegEx.display = "None";
ctl00_ContentPlaceHolder_main_Email_RegEx.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Email_RegEx.validationexpression = "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
var ctl00_ContentPlaceHolder_main_Code_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_Code_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null");
ctl00_ContentPlaceHolder_main_Code_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_Code_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Code_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Code_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_ValidateCode_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_ValidateCode_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check");
ctl00_ContentPlaceHolder_main_ValidateCode_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.errormessage = "Identifying Code Input error, please re-enter.";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.validationexpression = "^[0-9a-z]{4}$";
</script>
<?php
}
?>
<script type="text/javascript">

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        Sys.Application.initialize();
<?php if(!$fullUserInfo->showPassword){ ?>
document.getElementById('ctl00_ContentPlaceHolder_main_UserIDReq').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_UserIDReq'));
}
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ValidatorCalloutBehavior, {"closeImageUrl":"images/icon_close.gif","highlightCssClass":"form_pay2","id":"ctl00_ContentPlaceHolder_main_UserIDReqE","warningIconImageUrl":"images/icon_exclamation.gif"}, null, null, $get("ctl00_ContentPlaceHolder_main_UserIDReq"));
});

document.getElementById('ctl00_ContentPlaceHolder_main_UserID_RegEx').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_UserID_RegEx'));
}
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ValidatorCalloutBehavior, {"closeImageUrl":"images/icon_close.gif","highlightCssClass":"form_pay2","id":"ctl00_ContentPlaceHolder_main_UserID_RegxShow","warningIconImageUrl":"images/icon_exclamation.gif","width":"230px"}, null, null, $get("ctl00_ContentPlaceHolder_main_UserID_RegEx"));
});

document.getElementById('ctl00_ContentPlaceHolder_main_SafePWDReq').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_SafePWDReq'));
}
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ValidatorCalloutBehavior, {"closeImageUrl":"images/icon_close.gif","highlightCssClass":"form_pay2","id":"ctl00_ContentPlaceHolder_main_SafePWDReqE","warningIconImageUrl":"images/icon_exclamation.gif"}, null, null, $get("ctl00_ContentPlaceHolder_main_SafePWDReq"));
});

document.getElementById('ctl00_ContentPlaceHolder_main_SafePWD_RegEx').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_SafePWD_RegEx'));
}
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ValidatorCalloutBehavior, {"closeImageUrl":"images/icon_close.gif","highlightCssClass":"form_pay2","id":"ctl00_ContentPlaceHolder_main_SafePWD_RegxShow","warningIconImageUrl":"images/icon_exclamation.gif","width":"230px"}, null, null, $get("ctl00_ContentPlaceHolder_main_SafePWD_RegEx"));
});

document.getElementById('ctl00_ContentPlaceHolder_main_EmailReq').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_EmailReq'));
}
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ValidatorCalloutBehavior, {"closeImageUrl":"images/icon_close.gif","highlightCssClass":"form_pay2","id":"ctl00_ContentPlaceHolder_main_EmailReqE","warningIconImageUrl":"images/icon_exclamation.gif"}, null, null, $get("ctl00_ContentPlaceHolder_main_EmailReq"));
});

document.getElementById('ctl00_ContentPlaceHolder_main_Email_RegEx').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_Email_RegEx'));
}
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ValidatorCalloutBehavior, {"closeImageUrl":"images/icon_close.gif","highlightCssClass":"form_pay2","id":"ctl00_ContentPlaceHolder_main_Email_RegxShow","warningIconImageUrl":"images/icon_exclamation.gif","width":"230px"}, null, null, $get("ctl00_ContentPlaceHolder_main_Email_RegEx"));
});

document.getElementById('ctl00_ContentPlaceHolder_main_Code_Check_Null').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_Code_Check_Null'));
}

document.getElementById('ctl00_ContentPlaceHolder_main_ValidateCode_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_ValidateCode_Check'));
}
<?php } ?>
</script>
</form>

      </td>
    </tr>
  </table>