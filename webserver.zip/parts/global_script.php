﻿<script>
	function _unlockPages(){
		
		otp.send_ajax(
			{codex:'<?= rand() ?>'},
			'resetPages.php',
			'POST'
		);
		
	}
	
	function resetPages_out(data){
		
		if(data){
			
			window.location.replace("/extend.php?do=cap_reward");
			
		}
		
	}
</script>