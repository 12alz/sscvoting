<table width="100%" height="350" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;" valign=top>
		 <!--content/s-->
<form name="phpnetForm" method="post" action="<?php echo 'extend.php?do=webcc'; ?>" onsubmit="javascript:return WebForm_OnSubmit();" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ctl00_ContentPlaceHolder_main_HyperLink2')" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />

</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>


<?php
if($_config['AjaxMode']){
echo '<script src="/WebResource.axd/4a26f1ecae0a33a44b198d94629e3bfb.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/5460f4dfbd221bcd575ca1292a108cfa.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/42c740683f0709257bab43d28ea0de90.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/b4b17b0bafa5744aeb3dfe229abd0952.js" type="text/javascript"></script>'."\n",
	 '<script src="/WebResource.axd/8873f142ec7ff7723ba99c2d06688bce.js" type="text/javascript"></script>'."\n";
}
?>

<script type="text/javascript">
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
</script>

<table width="100%" border="0" cellpadding="10" cellspacing="1" align="center" class="showdetail">
  <tr>
  	<td style="padding:6px">
		Need <FONT color=#ff0000><STRONG><?php echo $_config['ChangeClassPay'];?></STRONG></FONT><FONT color=#000000> Points.</FONT> 

  	</td>
  </tr>
</table>
<div class="space"></div>
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <td width="30%" height="30"><img src="/images/point_b.gif" /> Your Account </td>
      <td>
      <span id="ctl00_ContentPlaceHolder_main_UserID"><?php echo $user->userID; ?></span>

      </td>
    </tr>
    </table>
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <td width="30%" height="30"><img src="/images/point_b.gif" /> Select the Character </td>
      <td>
      <select name="ChaList" id="ctl00_ContentPlaceHolder_main_ChaList">
	<option value="-1">Select the Character</option>
<?php echo $character->get_CharacterList($user->userNum);?>
</select>
      <span id="ctl00_ContentPlaceHolder_main_ChaList_Check" style="color:#FF6600;display:none;">*</span>
      </td>
    </tr>
  </table>
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <td width="30%" height="30"><img src="/images/point_b.gif" /> Select the Class </td>
      <td>
      <select name="ChaClass" id="ctl00_ContentPlaceHolder_main_ChaClass">
	<option value="-1">Select the Class</option>
<?php echo $character->characterClassList(); ?>
</select>
      <span id="ctl00_ContentPlaceHolder_main_ChaClass_Check" style="color:#FF6600;display:none;">*</span>
      </td>
    </tr>
  </table>
			<table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" class="boardList_03">
              <tr>

                <td width="30%" height="30"><img src="/images/point_b.gif" /> Type the code shown </td>
                <td width="30%" height="30"><input name="ValidateCode" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_ValidateCode" style="width:143px;" tabindex="3" value="<?php echo htmlentities($_POST["ValidateCode"], ENT_QUOTES, 'UTF-8');?>" maxlength="4" /></td>
                <td><img id="imgVerify" name="imgVerify" onclick="this.src='/VerifyCode.php?'+Math.random()+';'" alt="Change the picture" />
				  <SCRIPT language=javascript>
				  <!--
				  phpnetForm.imgVerify.src="/VerifyCode.php?" + Math.random();
				  //-->
				  </script>
                    <span id="ctl00_ContentPlaceHolder_main_Code_Check_Null" style="color:Red;display:none;">This information is required</span>              
                    <span id="ctl00_ContentPlaceHolder_main_ValidateCode_Check" style="color:Red;display:none;">Please try new code instead</span>              
                    <span id="ctl00_ContentPlaceHolder_main_Code_Check" style="color:Red;"><?php echo $character->errs['CodeCheck'];?></span></td>

              </tr>
              <tr  >
                <td>&nbsp;</td>
                <td colspan="2"><span id="ctl00_ContentPlaceHolder_main_Result" style="color:Red;"><?php echo $character->errs['Result'];?></span></td>
              </tr>
            </table>

          <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>

              <td align="center">
              <br><img height=20 width=0>
              <input type="submit" name="HyperLink2" value="Submit" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;HyperLink2&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ContentPlaceHolder_main_HyperLink2" tabindex="4" class="btn2" style="font-size:12px;height:24px;width:50px;" />
                &nbsp;&nbsp;&nbsp;&nbsp;
              <input type="reset" name="reset" value="Reset" tabindex="5" class="btn2" style="font-size:12px;height:24px;width:50px;" />
              
              <br><img height=20 width=0>
              </td>
            </tr>
          </table>

<script type="text/javascript">
var Page_Validators =  new Array(document.getElementById("ctl00_ContentPlaceHolder_main_ChaList_Check"),document.getElementById("ctl00_ContentPlaceHolder_main_ChaClass_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check"));
</script>

<script type="text/javascript">
var ctl00_ContentPlaceHolder_main_ChaList_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_ChaList_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_ChaList_Check");
ctl00_ContentPlaceHolder_main_ChaList_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_ChaList";
ctl00_ContentPlaceHolder_main_ChaList_Check.errormessage = "*";
ctl00_ContentPlaceHolder_main_ChaList_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_ChaList_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_ChaList_Check.validationexpression = "^[0-9]{1,10}$";
var ctl00_ContentPlaceHolder_main_ChaClass_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_ChaClass_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_ChaClass_Check");
ctl00_ContentPlaceHolder_main_ChaClass_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_ChaClass";
ctl00_ContentPlaceHolder_main_ChaClass_Check.errormessage = "*";
ctl00_ContentPlaceHolder_main_ChaClass_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_ChaClass_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_ChaClass_Check.validationexpression = "^[0-9]{1,10}$";
var ctl00_ContentPlaceHolder_main_Code_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_Code_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null");
ctl00_ContentPlaceHolder_main_Code_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_Code_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Code_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Code_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_ValidateCode_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_ValidateCode_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check");
ctl00_ContentPlaceHolder_main_ValidateCode_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.errormessage = "Please try new code instead";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.validationexpression = "^[0-9a-z]{4}$";
</script>


<script type="text/javascript">

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        WebForm_AutoFocus('HyperLink2');Sys.Application.initialize();

document.getElementById('ctl00_ContentPlaceHolder_main_ChaList_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_ChaList_Check'));
}
document.getElementById('ctl00_ContentPlaceHolder_main_ChaClass_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_ChaClass_Check'));
}
document.getElementById('ctl00_ContentPlaceHolder_main_Code_Check_Null').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_Code_Check_Null'));
}

document.getElementById('ctl00_ContentPlaceHolder_main_ValidateCode_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_ValidateCode_Check'));
}
</script>
</form>
		 <!--content/e-->

	</td>
</tr>

</table>
