<table width="100%" height="350" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;" valign=top>
		 <!--content/s-->
 <form name="phpnetForm" method="post" action="<?php echo 'extend.php?do=editsafepwd'; ?>" onsubmit="javascript:return WebForm_OnSubmit();" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ctl00_ContentPlaceHolder_main_HyperLink2')" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />

</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>
<?php
if($_config['AjaxMode']){
echo '<script src="/WebResource.axd/4a26f1ecae0a33a44b198d94629e3bfb.js" type="text/javascript"></script>'."\n",
 	 '<script src="/WebResource.axd/f553e4b43b481582b298229a49734eca.js" type="text/javascript"></script>'."\n",
 	 '<script src="/WebResource.axd/8873f142ec7ff7723ba99c2d06688bce.js" type="text/javascript"></script>'."\n";
}
?>
<script type="text/javascript">
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
</script>

 <div class="space"></div>
<table width="100%" border="0" cellpadding="10" cellspacing="1" align="center" class="showdetail">
  <tr>
  	<td style="padding:6px">
		Need <FONT color=#ff0000><STRONG><?php echo $_config['EditSafePasswordPay'];?></STRONG></FONT><FONT> Points.</FONT> 
  	</td>

  </tr>
</table>
<div class="space"></div>
    <table width="100%" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="20%"  height="30"><img src="/images/point_b.gif" /> Account</td>
        <td  >
          <span id="ctl00_ContentPlaceHolder_main_UserID" tabindex="1" MaxLength="12"><?php echo $user->userID; ?></span></td>

        <td width="1">&nbsp;</td>
        <td width="320"  >&nbsp;</td>
      </tr>
      <tr>
        <td height="30"  ><img src="/images/point_b.gif" /> Original Second Password </td>
        <td  ><input name="OldSafePWD" type="password" maxlength="20" id="ctl00_ContentPlaceHolder_main_OldSafePWD" tabindex="2" class="form_pay" style="width:150px;" /></td>
        <td>&nbsp;</td>
        <td  ><span id="ctl00_ContentPlaceHolder_main_OldSafePWD_Check_Null" style="color:Red;display:none;">This information is required</span>

          <span id="ctl00_ContentPlaceHolder_main_OldSafePWD_Check" style="color:Red;display:none;">This information is required</span></td>
      </tr>
      <tr>
        <td height="30"  ><img src="/images/point_b.gif" /> New Second Password </td>
        <td  ><input name="NewSafePWD" type="password" maxlength="20" id="ctl00_ContentPlaceHolder_main_NewSafePWD" tabindex="3" class="form_pay" style="width:150px;" /></td>
        <td>&nbsp;</td>
        <td  ><span id="ctl00_ContentPlaceHolder_main_NewSafePWD_Check_Null" style="color:Red;display:none;">This information is required</span>

           &nbsp;Use 6 to 12 characters, no spaces, and don't use your Account or Password<br />
          <span id="ctl00_ContentPlaceHolder_main_NewSafePWD_Check" style="color:Red;display:none;">This information is required</span></td>
      </tr>
      <tr>
        <td height="30"   ><img src="/images/point_b.gif" /> Re-type Second Password</td>
        <td ><input name="Re_NewSafePWD" type="password" maxlength="20" id="ctl00_ContentPlaceHolder_main_Re_NewSafePWD" tabindex="4" class="form_pay" style="width:150px;" /></td>
        <td>&nbsp;</td>

        <td ><span id="ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check_Null" style="color:Red;display:none;">This information is required</span>
          &nbsp;Re-type Second Password
This information is incorrect,Please re-enter<br />
          <span id="ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check" style="color:Red;display:none;">This information is required。</span></td>
      </tr>
    </table>

    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" class="boardList_03">
      <tr>

        <td width="20%"><img src="/images/point_b.gif" /> Type the code shown </td>
        <td width="30%"><input name="ValidateCode" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_ValidateCode" style="width:150px;" tabindex="5" value="<?php echo htmlentities($_POST["ValidateCode"], ENT_QUOTES, 'UTF-8');?>" maxlength="4" /></td>
        <td> &nbsp;&nbsp;&nbsp;<img id="imgVerify" name="imgVerify" onclick="this.src='/VerifyCode.php?'+Math.random()+';'" alt="Change the picture" />
          <SCRIPT language=javascript>
					  phpnetForm.imgVerify.src="/VerifyCode.php?" + Math.random();
					  </script>
          <span id="ctl00_ContentPlaceHolder_main_Code_Check_Null" style="color:Red;display:none;">This information is required</span>
          <span id="ctl00_ContentPlaceHolder_main_ValidateCode_Check" style="color:Red;display:none;">Incorrect Validate Code,please re-enter.</span>

          <span id="ctl00_ContentPlaceHolder_main_Code_Check" style="color:Red;"><?php echo $character->errs['CodeCheck'];?></span>
        </td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="2"><span id="ctl00_ContentPlaceHolder_main_Result"><?php echo $character->errs['Result'];?></span></td>
      </tr>
      <tr>
        <td colspan="3" align="center"></td>

      </tr>
    </table>
    <table width="100%" align="center">
      <tr>
        <td align="center">
              <br><img height=20 width=0>
               <input type="submit" name="HyperLink2" value="Submit" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;HyperLink2&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ContentPlaceHolder_main_HyperLink2" tabindex="6" class="btn2" style="font-size:12px;height:24px;width:50px;" />
                &nbsp;&nbsp;&nbsp;&nbsp;
              <input type="reset" name="reset" value="Reset" tabindex="7" class="btn2" style="font-size:12px;height:24px;width:50px;" />

          
              <br><img height=20 width=0>
        </td>
      </tr>
    </table>
  
<script type="text/javascript">
var Page_Validators =  new Array(document.getElementById("ctl00_ContentPlaceHolder_main_OldSafePWD_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_OldSafePWD_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_NewSafePWD_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_NewSafePWD_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check"));
</script>

<script type="text/javascript">
var ctl00_ContentPlaceHolder_main_OldSafePWD_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_OldSafePWD_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_OldSafePWD_Check_Null");
ctl00_ContentPlaceHolder_main_OldSafePWD_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_OldSafePWD";
ctl00_ContentPlaceHolder_main_OldSafePWD_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_OldSafePWD_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_OldSafePWD_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_OldSafePWD_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_OldSafePWD_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_OldSafePWD_Check");
ctl00_ContentPlaceHolder_main_OldSafePWD_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_OldSafePWD";
ctl00_ContentPlaceHolder_main_OldSafePWD_Check.errormessage = "This information is required";
ctl00_ContentPlaceHolder_main_OldSafePWD_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_OldSafePWD_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_OldSafePWD_Check.validationexpression = "^[0-9a-zA-Z_]{6,12}";
var ctl00_ContentPlaceHolder_main_NewSafePWD_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_NewSafePWD_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_NewSafePWD_Check_Null");
ctl00_ContentPlaceHolder_main_NewSafePWD_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_NewSafePWD";
ctl00_ContentPlaceHolder_main_NewSafePWD_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_NewSafePWD_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_NewSafePWD_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_NewSafePWD_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_NewSafePWD_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_NewSafePWD_Check");
ctl00_ContentPlaceHolder_main_NewSafePWD_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_NewSafePWD";
ctl00_ContentPlaceHolder_main_NewSafePWD_Check.errormessage = "This information is required";
ctl00_ContentPlaceHolder_main_NewSafePWD_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_NewSafePWD_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_NewSafePWD_Check.validationexpression = "^[0-9a-zA-Z_]{6,12}";
var ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check_Null");
ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_Re_NewSafePWD";
ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check");
ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_Re_NewSafePWD";
ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check.errormessage = "This information is required。";
ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Re_NewSafePWD_Check.validationexpression = "^[0-9a-zA-Z_]{6,12}";
var ctl00_ContentPlaceHolder_main_Code_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_Code_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null");
ctl00_ContentPlaceHolder_main_Code_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_Code_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Code_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Code_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_ValidateCode_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_ValidateCode_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check");
ctl00_ContentPlaceHolder_main_ValidateCode_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.errormessage = "Incorrect Validate Code,please re-enter.";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.validationexpression = "^[0-9a-z]{4}$";
</script>


<script type="text/javascript">

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        WebForm_AutoFocus('HyperLink2');

</script>
</form>
		 <!--content/e-->

	</td>
</tr>
</table>