<link type="text/css" href="img/Progress.css" rel="stylesheet" />
<table width="100%" height="350" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;" valign=top>
		 <!--content/s-->
	<form name="phpnetForm" method="post" action="<?php echo 'extend.php?do=webupitem_list&cid=',$itemcustomize->characterVO->chaNum,''; ?>" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />

</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>


<!--<script src="/WebResource.axd?d=l1YJlaZVV9LMwMy5fbF8P4UCk2EF5AaoM4aZ6M691ixDncG7_7Kigw7wVXJdPH1aN6OanT01nWA0LGOtj1Osx9OPWxQ1&amp;t=634221829538125000" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=qP2y9Qi03lIboE7Vg43ECqXvByrT2eyxSyoX1rI7ArM1gMWvUcujE165iFJul1opO7JIS81NAsME2oQoHiA1h9SigGKgbaIXfVjCXx6LbgxTGNJQJMyH-vl2-YHf74jwm8UF7Q2&amp;t=633346407082728750" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=ZkLBcD9zBFsLDDtOd-TgzrDvNEBWY9z5eKrtL2aQWmWChY8TwWmlwtC-4gHn_yRMwKVP2Qzjhnh_fbAXWloc8dD8zY-LJT_W7CF669Kg-GM9hersBRN0XlZ56IVNJ0vTDlgEUA2&amp;t=633346407082728750" type="text/javascript"></script>
-->
<br>
<style>
#ccc th { height:22px; }
.progress {
	PADDING-RIGHT: 3px; DISPLAY: block; PADDING-LEFT: 3px; PADDING-BOTTOM: 2px; PADDING-TOP: 2px; POSITION: absolute;
MARGIN-RIGHT: auto;
MARGIN-LEFT: auto; 
vertical-align:middle;
height:69px;
width:250px;

	top: 50%;
	left: 50%;
	margin: -34px 0 0 -115px; /* -height/2 0 0 -width/2 */
	z-index:103;
}
.container {
	BORDER-RIGHT: #808080 0px solid; BORDER-TOP: #808080 1px solid; BORDER-LEFT: #808080 0px solid; BORDER-BOTTOM: #808080 1px solid
}
.header {
	BORDER-RIGHT: #808080 1px solid; PADDING-RIGHT: 10px; BORDER-TOP: #808080 0px solid; PADDING-LEFT: 10px; FONT-WEIGHT: bold; FONT-SIZE: 9pt; BACKGROUND: url('img/sprite.png') repeat-x 0px 0px; PADDING-BOTTOM: 0px; BORDER-LEFT: #808080 1px solid; COLOR: #000000; LINE-HEIGHT: 1.9; PADDING-TOP: 0px; BORDER-BOTTOM: #ccc 1px solid; FONT-FAMILY: arial,helvetica,clean,sans-serif
}
.body {
	BORDER-RIGHT: #808080 1px solid; PADDING-RIGHT: 10px; BORDER-TOP: #808080 0px solid; PADDING-LEFT: 10px; PADDING-BOTTOM: 10px; BORDER-LEFT: #808080 1px solid; PADDING-TOP: 10px; BORDER-BOTTOM: #808080 0px solid; BACKGROUND-COLOR: #f2f2f2
}
#center1{ MARGIN-RIGHT: auto;
MARGIN-LEFT: auto; 
vertical-align:middle;
}
* html .progress{ /* ie6 hack */
position: absolute;
margin-top: expression(0 - parseInt(this.offsetHeight / 2) + (TBWindowMargin = document.documentElement && document.documentElement.scrollTop || document.body.scrollTop) + 'px');
}

.headerstyle th 
{
    background: url('img/sprite.png') repeat-x 0px 0px;
    border-color: #989898 #cbcbcb #989898 #989898;
    border-style: solid solid solid none;
    border-width: 1px 1px 1px medium;
    color: #4D4D4D;
    padding: 2px 3px 2px 5px;
    text-align: center;
    vertical-align: bottom;
    font-weight: normal;
}
.altrowstyle 
{
    background-color: #edf5ff;
}
.rowstyle .sortaltrow, .altrowstyle .sortaltrow 
{
    background-color: #edf5ff;
}

.rowstyle .sortrow, .altrowstyle .sortrow 
{
    background-color: #dbeaff;
}
select {
	text-decoration: none;
	padding-top:4px;
	cursor:hand;
	BORDER: #2F89EF 1px solid;
	FONT-SIZE: 9pt; 
	color:#000000; 
	HEIGHT: 22px; 
	width:73px; 
	BACKGROUND-COLOR: #BAD9FB;
}
.btn001{
	text-decoration: none;
	padding-top:4px;
	cursor:hand;
	BORDER: #2F89EF 1px solid;
	FONT-SIZE: 9pt; 
	color:#000000; 
	HEIGHT: 22px; 
	width:130px; 
	BACKGROUND-COLOR: #BAD9FB;
}
.btn002{text-decoration: none;padding-top:4px;cursor:hand;BORDER-RIGHT: #CD9F01 1px solid; BORDER-TOP: #CD9F01 1px solid; FONT-SIZE: 9pt; BORDER-LEFT: #CD9F01 1px solid; BORDER-BOTTOM: #CD9F01 1px solid;  color:#000000;FONT-FAMILY: "宋體"; HEIGHT: 22px; width:130px; BACKGROUND-COLOR: #F8F4D0}
.btn01{
BORDER: #2F89EF 1px solid; 
FONT-SIZE: 9pt; 
cursor:hand;
color:#000000;FONT-FAMILY: "宋體"; HEIGHT: 22px; width:60px; BACKGROUND-COLOR: #BAD9FB}

.btn02{text-decoration: none;padding-top:4px;cursor:hand;BORDER-RIGHT: #CD9F01 1px solid; BORDER-TOP: #CD9F01 1px solid; FONT-SIZE: 9pt; BORDER-LEFT: #CD9F01 1px solid; BORDER-BOTTOM: #CD9F01 1px solid;  color:#000000;FONT-FAMILY: "宋體"; HEIGHT: 22px; width:60px; BACKGROUND-COLOR: #F8F4D0}

</style>
	<div id=ccc>
	<span id="ctl00_ContentPlaceHolder_main_label_UserID" style="font-weight:bold;"><a href=extend.php?do=webupitem title='Change a Character'>Character Name: <?php echo $itemcustomize->characterVO->chaName;?></a></span>
	<div class="space"></div>
	<table width="100%" border="0" cellpadding="10" cellspacing="1" align="center" class="showdetail">
	  <tr>

	  	<td style="padding:6px">
		  <P><FONT color=#006400 size=2 face=Verdana>Please read and understand carefully the upgrading system policy. Items that has been lose due to not properly following the instruction will not be the responsibility of the staff. Items that has been lose will not be return or points will not be refund to you. Unless you have a concrete proof of your lose item such as taking a video from the start and up to end of the procedure of upgrading.</FONT></STRONG></P>
		<BR>
		<P><FONT color=#006400 size=2 face=Verdana>Read the following before upgrading an item:</font></font></p>
		<P><FONT color=#006400 size=2 face=Verdana>[1]. Account must be log-out in Game.<BR>[2]. Item for upgrading must be on 1ST the slot of the inventory. <BR>[3]. Item for upgrading must be the ONLY Item in inventory and nothing else.<BR>[4]. Always use TAKE BACK when you’re done else Item will be lose in your inventory.<BR>[5]. Be patient on upgrading the item, clicking it multiple times to make it faster is not advisable. It might cause for you to lose the item.</STRONG></FONT></FONT></P>

<BR><P><FONT color=#ff0000 size=2 face=Verdana>Each weapon only has four maximum properties, except the three mentioned above, player only can choose a new property to add. Example: You also can choose from Hp is maximum upgrade to +3000 OR Hp+MP+SP recovery rate is maximum upgrade to +30%. Only one property you can choose to add.  </FONT></P>
<P><FONT face=Verdana><FONT size=2><FONT color=#ff0000>Note: Weapon can not upgrade Defense or Defense Rate<BR><BR></FONT><font color="red">****************************************************************<BR><BR></FONT></FONT><FONT color=#ffa500 size=2 face=Verdana>Armor buy from Mall has two fixed properties: <BR>1. Defense or Defense Grinding（Defense + A）  <BR>2. Defense Rate + B% <BR>Online upgrade can increase the Maximum of these two properties. (Old version only can upgrade the 1. Defense) </FONT></P>
<P><FONT face=Verdana><FONT size=2><FONT color=#ffa500>Each armor only has four properties, except the two from mentioned above, you also can choose from Hp is maximum upgrade to +3000 OR Hp+MP+SP recovery rate is maximum upgrade to +30%.  Only two new properties you can choose to add. <BR>Note: Armor can not upgrade Attack or Attack Rate.  <BR>Armor ups effect by dexterity and power attack but not effect by spirit attack. Reminding: ups for weapon or armor can not roll back to EP.We recommend to upgrade HP or Hp+MP+SP recovery rate<BR><BR></FONT><font color="red">****************************************************************<BR><BR></FONT></FONT><FONT face=Verdana><FONT size=2><FONT color=#ff1493>The jewelry buy from mall can also add a new property:   Hp is maximum upgrade to +3000 OR Hp+MP+SP recovery rate is maximum upgrade to +30%<BR><BR></FONT><font color="red">****************************************************************<BR><BR></FONT></FONT><FONT face=Verdana><FONT size=2><FONT color=#0000ff>Please do not be shocked by the list of seven upgrade options. Because of each item only contains certain properties. When you import the item from "Character Inventory" to "Web Warehouse" then click "Select properties" at right side, you will notice that only 4-5 options you can choose. Besides, if the item already has four properties, "Select properties" will show in gray color.<BR><BR></FONT><font color="red">****************************************************************</FONT></FONT></P>

<P><FONT size=2 face=Verdana></FONT> </P>
  	</td>
	  </tr>
	</table>
	<div class="space"></div>

	<div id="ctl00_ContentPlaceHolder_main_UpdatePanel1">	
		<table width="100%" border="0" cellpadding="10" cellspacing="1" align="left"> 
		  <tr>
		  	<td>
				<div align="center" style="font-size:10pt"><span id="ctl00_ContentPlaceHolder_main_Result" style="color:Red;"></span></div>
                <b><font color="RED">@ Character Inventory</font></b>
				<div class="space"></div>
				<div>
				<table cellspacing="0" cellpadding="4" rules="all" border="1" id="ctl00_ContentPlaceHolder_main_GridView1" style="background-color:White;border-color:#666666;border-width:1px;border-style:solid;font-size:9pt;width:100%;border-collapse:collapse;">
				
				<tr class="headerstyle" style="background-color:#72aedd;font-size:9pt;font-weight:normal;height:23px;">
					<th scope="col">No.</th><th scope="col">Item Name</th><th scope="col">Attack</th><th scope="col">Defense</th><th scope="col">Attack Rate</th><th scope="col">Defense Rate</th><th scope="col">HP</th><th scope="col">Recovery rate</th><th scope="col">Hit rate</th><th scope="col">Quantity</th><th scope="col">Operation</th>
					</tr><?php $character->characterItemsView();?>
				</table>
				</div>
				<br/>				

					<iframe style="display:none" name=if0></iframe>
					<b><font color="RED">@ Web Warehouse</font><font color="#666666"></font></b>

					<div class="space"></div>
					<div>
					<table cellspacing="0" cellpadding="4" rules="all" border="1" id="ctl00_ContentPlaceHolder_main_GridView2" style="background-color:White;border-color:#666666;font-size:9pt;width:100%;border-collapse:collapse;">
						<tr class="headerstyle" style="font-size:9pt;font-weight:normal;height:20px;">
							<th scope="col">No.</th><th scope="col">Item Name</th><th scope="col">Attack</th><th scope="col">Defense</th><th scope="col">Attack Rate</th><th scope="col">Defense Rate</th><th scope="col">HP</th><th scope="col">Recovery rate</th><th scope="col">Hit rate</th><th scope="col">Select Properties</th><th scope="col">Upgrade</th><th scope="col">Operation</th>				
						</tr>
						<?php $itemcustomize->itemStorageListView();?>
					</table>
					</div>

				</td>
			</tr>
		</table>
        
</div>
    <div id="ctl00_ContentPlaceHolder_main_UpdateProgress3" style="display:none;">
	
			<div class="progress">
                <div class="container">
                    <div class="header">Loading, please wait...</div>

                    <div class="body">
                        <img src="img/activity.gif" />
                    </div>
                </div>
			</div>
        
</div>
	<div class="space"></div>
	<table width="100%" border="0" cellpadding="10" cellspacing="1" align="center" class="showdetail">
	  <tr>

	  	<td style="padding:6px">
			<P><STRONG><FONT color=#0000ff size=2 face=Verdana>The ceiling and the success rate is as follows:<BR><BR></FONT></STRONG><FONT color=#ff0000 size=2 face=Verdana>The sum of the attack and attack grinding is maximum upgrade to +<?php echo $_config['ItemUpgradeAtk']['MaxGrade'];?><BR></FONT><FONT color=#0000ff size=2 face=Verdana><?php echo $_config['ItemUpgradeAtk']['Pay']?> points once and increased by <?php echo $_config['ItemUpgradeAtk']['Addval'];?> attack<BR><?php echo $_config['ItemUpgradeAtk']['Range'][1][0],'-',$_config['ItemUpgradeAtk']['Range'][1][1];?> <?php echo $_config['ItemUpgradeAtk']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeAtk']['Range'][2][0],'-',$_config['ItemUpgradeAtk']['Range'][2][1];?> <?php echo $_config['ItemUpgradeAtk']['Range'][2]['Rate'];?> success<BR><BR></FONT><FONT color=#ff0000 size=2 face=Verdana>The sum of the defense and defense grinding is maximum upgrade to +<?php echo $_config['ItemUpgradeDef']['MaxGrade'];?><BR></FONT><FONT color=#0000ff size=2 face=Verdana><?php echo $_config['ItemUpgradeDef']['Pay']?> points once and increased by<?php echo $_config['ItemUpgradeDef']['Addval'];?> defense<BR><?php echo $_config['ItemUpgradeDef']['Range'][1][0],'-',$_config['ItemUpgradeDef']['Range'][1][1];?> <?php echo $_config['ItemUpgradeDef']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeDef']['Range'][2][0],'-',$_config['ItemUpgradeDef']['Range'][2][1];?> <?php echo $_config['ItemUpgradeDef']['Range'][2]['Rate'];?> success<BR><BR></FONT><FONT color=#ff0000 size=2 face=Verdana>Attack rate is maximum upgrade to +<?php echo $_config['ItemUpgradeAtkRate']['MaxGrade']?>%</FONT><BR></FONT></FONT><FONT color=#0000ff size=2 face=Verdana><?php echo $_config['ItemUpgradeAtkRate']['Pay']?> points once and increased by <?php echo $_config['ItemUpgradeAtkRate']['Addval']?> attack rate<BR><?php echo $_config['ItemUpgradeAtkRate']['Range'][1][0],'-',$_config['ItemUpgradeAtkRate']['Range'][1][1];?> <?php echo $_config['ItemUpgradeAtkRate']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeAtkRate']['Range'][2][0],'-',$_config['ItemUpgradeAtkRate']['Range'][2][1];?> <?php echo $_config['ItemUpgradeAtkRate']['Range'][2]['Rate'];?> success,<?php echo (100-str_replace("%","",$_config['ItemUpgradeAtkRate']['Range'][2]['Rate']));?>% remain the same level<BR><BR></FONT><FONT color=#ff0000 size=2 face=Verdana>Defense rate is maximum upgrade to +<?php echo $_config['ItemUpgradeDefRate']['MaxGrade'];?>%<BR></FONT><FONT face=Verdana><FONT size=2><FONT color=#0000ff><?php echo $_config['ItemUpgradeDefRate']['Pay'];?> points once and increased by <?php echo $_config['ItemUpgradeDefRate']['Addval'];?> defense rate<BR><?php echo $_config['ItemUpgradeDefRate']['Range'][1][0],'-',$_config['ItemUpgradeDefRate']['Range'][1][1];?> <?php echo $_config['ItemUpgradeDefRate']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeDefRate']['Range'][2][0],'-',$_config['ItemUpgradeDefRate']['Range'][2][1];?> <?php echo $_config['ItemUpgradeDefRate']['Range'][2]['Rate'];?> success,<?php echo (100-str_replace("%","",$_config['ItemUpgradeDefRate']['Range'][2]['Rate']));?>% remain the same level<BR><BR></FONT><FONT color=#ff0000>Hp is maximum upgrade to +<?php echo $_config['ItemUpgradeHP']['MaxGrade'];?></FONT><BR></FONT></FONT><FONT face=Verdana><FONT size=2><FONT color=#0000ff><?php echo $_config['ItemUpgradeHP']['Pay'];?> points once and increased by <?php echo $_config['ItemUpgradeHP']['Addval'];?> HP<BR><?php echo $_config['ItemUpgradeHP']['Range'][1][0],'-',$_config['ItemUpgradeHP']['Range'][1][1];?> <?php echo $_config['ItemUpgradeHP']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeHP']['Range'][2][0],'-',$_config['ItemUpgradeHP']['Range'][2][1];?> <?php echo $_config['ItemUpgradeHP']['Range'][2]['Rate'];?> success,<?php echo (100-str_replace("%","",$_config['ItemUpgradeHP']['Range'][2]['Rate']));?>% remain the same level<BR><BR></FONT><FONT color=#ff0000>Hp+MP+SP recovery rate is maximum upgrade to +<?php echo $_config['ItemUpgradeHMSRate']['MaxGrade'];?>%</FONT><BR></FONT></FONT><FONT face=Verdana><FONT size=2><FONT color=#0000ff><?php echo $_config['ItemUpgradeHMSRate']['Pay'];?> points once and increased by <?php echo $_config['ItemUpgradeHMSRate']['Addval'];?>% recovery rate<BR><?php echo $_config['ItemUpgradeHMSRate']['Range'][1][0],'-',$_config['ItemUpgradeHMSRate']['Range'][1][1];?> <?php echo $_config['ItemUpgradeHMSRate']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeHMSRate']['Range'][2][0],'-',$_config['ItemUpgradeHMSRate']['Range'][2][1];?> <?php echo $_config['ItemUpgradeHMSRate']['Range'][2]['Rate'];?> success,<?php echo (100-str_replace("%","",$_config['ItemUpgradeHMSRate']['Range'][2]['Rate']));?>% remain the same level<BR><BR></FONT><FONT color=#ff0000>Hit rate is maximum upgrade to +<?php echo $_config['ItemUpgradeHitRate']['MaxGrade'];?>%</FONT><BR></FONT></FONT><FONT color=#0000ff size=2 face=Verdana><?php echo $_config['ItemUpgradeHitRate']['Pay'];?> points once and increased by <?php echo $_config['ItemUpgradeHitRate']['Addval'];?>% hit rate<BR><?php echo $_config['ItemUpgradeHitRate']['Range'][1][0],'-',$_config['ItemUpgradeHitRate']['Range'][1][1];?> <?php echo $_config['ItemUpgradeHitRate']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeHitRate']['Range'][2][0],'-',$_config['ItemUpgradeHitRate']['Range'][2][1];?> <?php echo $_config['ItemUpgradeHitRate']['Range'][2]['Rate'];?> success,<?php echo (100-str_replace("%","",$_config['ItemUpgradeHitRate']['Range'][2]['Rate']));?>% remain the same level</FONT></P>

	  	</td>
	  </tr>
	</table>
	

</form>
</div>
<br>		 <!--content/e-->
	</td>
</tr>
</table>