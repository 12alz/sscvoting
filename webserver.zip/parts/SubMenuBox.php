
   		<tr>
		<td><div align="left"><a href="javascript:menu(40);"><u>Download</u></a></td>        
		<td><div align="right"><a href="javascript:menu(903);"><u>Ranking</u></a></div></td>
		</tr>
		
    	<tr>
		<td><div align="left"><a href="javascript:menu(32);"><u><FONT color=#ffa500>Items Upgrade</font></u></a></div></td>		
            <!--<td><div align="right"><a href="javascript:menu(955);"><u>Cap Reward</font></u></a></div></td>
			<td><div align="right"><a href="javascript:menu(35);"><u>Reset PK Status</font></u></a></div></td>-->
			<td><div align="right" ><a href="javascript:menu(955);" onclick="if(confirm('Claim Rewards?'))_unlockPages();return false;"><u><FONT style="color: #ffa500;">Reborn Reward</font></u></a></div></td>
		</tr>

    	<tr>
		<td><div align="left"><a href="javascript:menu(50);"><u><FONT color=#ffa500>Item Mall</font></u></a></div></td>
		<!--<td><div align="right"><a href="javascript:menu(391);"><u><FONT color=#ffa500>Lucky Turntable</font></u></a></div></td>-->
		<!--<td><div align="right"><a href="javascript:menu();"><u><FONT color=#ffa500>Auto TopUp</font></u></a></div></td>-->
		</tr>



		<tr>
    	<td><div align="left"><a href="/show.php?articleid=198"><u>Change School</u></a></div></td>
		</tr>
		
		<tr>
		<td><div align="left"><a href="javascript:menu(31);"><u><FONT color=#ffa500>Character Reborn</font></u></a></div></td>
		</tr>	

		<tr>
		<!--td><div align="right"><a href="javascript:menu(24);"><u>Reset Pass</u></a></td>-->
		</tr>
		
		
		
				





<!-- 		<td><a href="javascript:menu(31);"><u>Character Reborn</u></a></td>
			<td align="right"><a href="javascript:menu(32);"><u><font color="yellow">Item Upgrade</font></u></a></td>
		</tr>
		<tr>
	
		<tr>
			<td><a href="javascript:menu(33);"><u>Reset Stats</u></a></td>
			<td align="right"><a href="javascript:menu(40);"><u><font color="yellow"><u>Download</font></u></a></td>

		</tr>
		<tr>
			<td><a href="member.php?do=editpwd"><u>Reset Password</u></a></td>
			<td align="right"><a href="javascript:menu(50);"><u><font color="yellow">Item Mall</font></u></a></td>
		</tr>
		<tr>
			<td><a href="javascript:menu(34);"><u>Add Stats</u></a></td>
		</tr>
	 -->
<!-- 	 <style type="text/css">
	 	#subMenuBoxNav {
	 		font-weight: normal;
	 	}
	 </style>

	 <tr>
	 	<td id="subMenuBoxNav"><a href="javascript:menu(40);"><font style="color: orange;"><u>Download</u></a></td>
	 </tr>
	 <tr>
	 	<td id="subMenuBoxNav"><a href="javascript:menu(50);"><font style="color: orange;"><u>Item Mall</u></a></td>
	 </tr>
	  <tr>
	 	<td id="subMenuBoxNav"><a href="javascript:menu(32);"><font style="color: orange;"><u>Item Upgrade</u></a></td>
	 </tr>
	  <tr>
	 	<td id="subMenuBoxNav"><a href="javascript:menu(31);"><u>Character Reborn</u></a></td>
	 </tr>
	  <tr>
	 	<td id="subMenuBoxNav"><a href="extend.php?do=webreborn2"><font style="color: orange;"><u>Purchase VIP Reborn</u></a></td>
	 </tr>
	 <tr>
	 	<td id="subMenuBoxNav"><a href="extend.php?do=webp2g"><font style="white: lime;"><u>EPoints to Game Gold</u></a></td>
	 </tr>
	 	<td id="subMenuBoxNav"><a href="extend.php?do=webr2p"><font style="white: lime;"><u>Reborn to EPoints</u></a></td>
	 </tr>
 -->

	 

		
