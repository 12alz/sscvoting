<table width="100%" height="350" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;" valign=top>
		 <!--content/s-->
<form name="phpnetForm" method="post" action="<?php echo 'extend.php?do=webupitem'; ?>" onsubmit="javascript:return WebForm_OnSubmit();" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ctl00_ContentPlaceHolder_main_HyperLink2')" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />

</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>


<?php
if($_config['AjaxMode']){
echo '<script src="/WebResource.axd/4a26f1ecae0a33a44b198d94629e3bfb.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/5460f4dfbd221bcd575ca1292a108cfa.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/42c740683f0709257bab43d28ea0de90.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/b4b17b0bafa5744aeb3dfe229abd0952.js" type="text/javascript"></script>'."\n",
	 '<script src="/WebResource.axd/8873f142ec7ff7723ba99c2d06688bce.js" type="text/javascript"></script>'."\n";
}
?>

<script type="text/javascript">
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
</script>


<div class="space"></div>
<table width="100%" border="0" cellpadding="10" cellspacing="1" align="center" class="showdetail">
  <tr>
  	<td style="padding:6px">

		<P><FONT color=#006400 size=2 face=Verdana>1. Please logoff the game first.<BR>2. Only the applicable items will appear in the web item list(character inventory) .<BR>3. There are two kinds of escalation of the results: success and failures (not going to the lower grade, not disappear).<BR>4. The items must import from the web item list into the web warehouse to upgrade.<BR>5. Please import from the web warehouse  to the web item list(character inventory) when upgrade completed.<BR>6. After the upgrade, items can not drop or trade in the game,just only store in the account warehouse.<BR>7. There are a total of five type to upgrade weapons  and four type to another, but you just can to choose four type for one item.</FONT></P>
<P><FONT face=Verdana><FONT size=2><FONT color=#006400>Armor ups effect by dexterity and power attack but not effect by spirit attack. Reminding: ups for items can not roll back to EP.<BR><BR></FONT>****************************************************************<BR><BR></FONT></FONT><FONT color=#ff0000 size=2 face=Verdana>Weapon buy from Mall has three fixed properties: <BR>1. Attack or Attack Grinding  (Attack + X) <BR>2. Attack Rate (Attack Rate + Y%)<BR>3. Hit Rate (Hit Rate + Z%)<BR>Online upgrade can increase the Maximum of these three properties. (Old version only can upgrade the 1. Attack)    </FONT></P>

<P><FONT color=#ff0000 size=2 face=Verdana>Each weapon only has four maximum properties, except the three mentioned above, player only can choose a new property to add. Example: You also can choose from Hp is maximum upgrade to +3000 OR Hp+MP+SP recovery rate is maximum upgrade to +30%. Only one property you can choose to add.  </FONT></P>
<P><FONT face=Verdana><FONT size=2><FONT color=#ff0000>Note: Weapon can not upgrade Defense or Defense Rate<BR><BR></FONT>****************************************************************<BR><BR></FONT></FONT><FONT color=#ffa500 size=2 face=Verdana>Armor buy from Mall has two fixed properties: <BR>1. Defense or Defense Grinding（Defense + A）  <BR>2. Defense Rate + B% <BR>Online upgrade can increase the Maximum of these two properties. (Old version only can upgrade the 1. Defense) </FONT></P>
<P><FONT face=Verdana><FONT size=2><FONT color=#ffa500>Each armor only has four properties, except the two from mentioned above, you also can choose from Hp is maximum upgrade to +3000 OR Hp+MP+SP recovery rate is maximum upgrade to +30%.  Only two new properties you can choose to add. <BR>Note: Armor can not upgrade Attack or Attack Rate.  <BR>Armor ups effect by dexterity and power attack but not effect by spirit attack. Reminding: ups for weapon or armor can not roll back to EP.We recommend to upgrade HP or Hp+MP+SP recovery rate<BR><BR></FONT>****************************************************************<BR><BR></FONT></FONT><FONT face=Verdana><FONT size=2><FONT color=#ff1493>The jewelry buy from mall can also add a new property:   Hp is maximum upgrade to +3000 OR Hp+MP+SP recovery rate is maximum upgrade to +30%<BR><BR></FONT>****************************************************************<BR><BR></FONT></FONT><FONT face=Verdana><FONT size=2><FONT color=#0000ff>Please do not be shocked by the list of seven upgrade options. Because of each item only contains certain properties. When you import the item from "Character Inventory" to "Web Warehouse" then click "Select properties" at right side, you will notice that only 4-5 options you can choose. Besides, if the item already has four properties, "Select properties" will show in gray color.<BR><BR></FONT>****************************************************************</FONT></FONT></P>

<P><FONT size=2 face=Verdana></FONT> </P>
  	</td>
  </tr>
</table>
<div class="space"></div>
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <td width="30%" height="30"><img src="/images/point_b.gif" /> Your Account </td>
      <td>

      <span id="ctl00_ContentPlaceHolder_main_UserID"><?php echo $user->userID; ?></span>
      </td>
    </tr>
    </table>
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <td width="30%" height="30"><img src="/images/point_b.gif" /> Select the Character </td>
      <td>

      <select name="ChaList" id="ctl00_ContentPlaceHolder_main_ChaList">
	<option value="-1">Select the Character</option>
<?php echo $character->get_CharacterList($user->userNum);?>

</select>
      <span id="ctl00_ContentPlaceHolder_main_ChaList_Check" style="color:#FF6600;display:none;">*</span>
      </td>
    </tr>

  </table>
			<table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" class="boardList_03">
              <tr>
                <td width="30%" height="30"><img src="/images/point_b.gif" /> Type the code shown </td>
                <td width="30%" height="30"><input name="ValidateCode" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_ValidateCode" style="width:143px;" tabindex="3" value="<?php echo htmlentities($_POST["ValidateCode"], ENT_QUOTES, 'UTF-8');?>" maxlength="4" /></td>
                <td><img id="imgVerify" name="imgVerify" onclick="this.src='/VerifyCode.php?'+Math.random()+';'" alt="Change the picture" />
				  <SCRIPT language=javascript>
				  phpnetForm.imgVerify.src="/VerifyCode.php?" + Math.random();
				  </script>

                    <span id="ctl00_ContentPlaceHolder_main_Code_Check_Null" style="color:Red;display:none;">This information is required</span>              
                    <span id="ctl00_ContentPlaceHolder_main_ValidateCode_Check" style="color:Red;display:none;">Please try new code instead</span>              
                    <span id="ctl00_ContentPlaceHolder_main_Code_Check" style="color:Red;"><?php echo $character->errs['CodeCheck'];?></span></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td colspan="2"><span id="ctl00_ContentPlaceHolder_main_Result" style="color:Red;"><?php echo $character->errs['Result'];?></span></td>
              </tr>
            </table>

          <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td align="center">
              <br><img height=20 width=0>
              <input type="submit" name="HyperLink2" value="Submit" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;HyperLink2&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ContentPlaceHolder_main_HyperLink2" tabindex="4" class="btn2" style="font-size:12px;height:24px;width:50px;" />
                &nbsp;&nbsp;&nbsp;&nbsp;
              <input type="reset" name="reset" value="Reset" tabindex="5" class="btn2" style="font-size:12px;height:24px;width:50px;" />
              <br><img height=20 width=0>
                </td>

            </tr>
          </table>
	<div class="space"></div>
	<table width="100%" border="0" cellpadding="10" cellspacing="1" align="center" class="showdetail">
	  <tr>
	  	<td style="padding:6px">
			<P><STRONG><FONT color=#0000ff size=2 face=Verdana>The ceiling and the success rate is as follows:<BR><BR></FONT></STRONG><FONT color=#ff0000 size=2 face=Verdana>The sum of the attack and attack grinding is maximum upgrade to +<?php echo $_config['ItemUpgradeAtk']['MaxGrade'];?><BR></FONT><FONT color=#0000ff size=2 face=Verdana><?php echo $_config['ItemUpgradeAtk']['Pay']?> points once and increased by <?php echo $_config['ItemUpgradeAtk']['Addval'];?> attack<BR><?php echo $_config['ItemUpgradeAtk']['Range'][1][0],'-',$_config['ItemUpgradeAtk']['Range'][1][1];?> <?php echo $_config['ItemUpgradeAtk']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeAtk']['Range'][2][0],'-',$_config['ItemUpgradeAtk']['Range'][2][1];?> <?php echo $_config['ItemUpgradeAtk']['Range'][2]['Rate'];?> success<BR><BR></FONT><FONT color=#ff0000 size=2 face=Verdana>The sum of the defense and defense grinding is maximum upgrade to +<?php echo $_config['ItemUpgradeDef']['MaxGrade'];?><BR></FONT><FONT face=Verdana><FONT size=2><FONT color=#0000ff><?php echo $_config['ItemUpgradeDef']['Pay'];?> points once and increased by <?php echo $_config['ItemUpgradeDef']['Addval'];?> defense<BR><?php echo $_config['ItemUpgradeDef']['Range'][1][0],'-',$_config['ItemUpgradeDef']['Range'][1][1];?> <?php echo $_config['ItemUpgradeDef']['Range'][1]['Rate'];?> success<BR><BR></FONT><FONT color=#ff0000>Attack rate is maximum upgrade to +<?php echo $_config['ItemUpgradeAtkRate']['MaxGrade']?>%</FONT><BR></FONT></FONT><FONT color=#0000ff size=2 face=Verdana><?php echo $_config['ItemUpgradeAtkRate']['Pay']?> points once and increased by <?php echo $_config['ItemUpgradeAtkRate']['Addval']?> attack rate<BR><?php echo $_config['ItemUpgradeAtkRate']['Range'][1][0],'-',$_config['ItemUpgradeAtkRate']['Range'][1][1];?> <?php echo $_config['ItemUpgradeAtkRate']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeAtkRate']['Range'][2][0],'-',$_config['ItemUpgradeAtkRate']['Range'][2][1];?> <?php echo $_config['ItemUpgradeAtkRate']['Range'][2]['Rate'];?> success,<?php echo (100-str_replace("%","",$_config['ItemUpgradeAtkRate']['Range'][2]['Rate']));?>% remain the same level<BR><BR></FONT><FONT color=#ff0000 size=2 face=Verdana>Defense rate is maximum upgrade to +<?php echo $_config['ItemUpgradeDefRate']['MaxGrade'];?>%<BR></FONT><FONT face=Verdana><FONT size=2><FONT color=#0000ff><?php echo $_config['ItemUpgradeDefRate']['Pay'];?> points once and increased by <?php echo $_config['ItemUpgradeDefRate']['Addval'];?> defense rate<BR><?php echo $_config['ItemUpgradeDefRate']['Range'][1][0],'-',$_config['ItemUpgradeDefRate']['Range'][1][1];?> <?php echo $_config['ItemUpgradeDefRate']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeDefRate']['Range'][2][0],'-',$_config['ItemUpgradeDefRate']['Range'][2][1];?> <?php echo $_config['ItemUpgradeDefRate']['Range'][2]['Rate'];?> success,<?php echo (100-str_replace("%","",$_config['ItemUpgradeDefRate']['Range'][2]['Rate']));?>% remain the same level<BR><BR></FONT><FONT color=#ff0000>Hp is maximum upgrade to +<?php echo $_config['ItemUpgradeHP']['MaxGrade'];?></FONT><BR></FONT></FONT><FONT face=Verdana><FONT size=2><FONT color=#0000ff><?php echo $_config['ItemUpgradeHP']['Pay'];?> points once and increased by <?php echo $_config['ItemUpgradeHP']['Addval'];?> HP<BR><?php echo $_config['ItemUpgradeHP']['Range'][1][0],'-',$_config['ItemUpgradeHP']['Range'][1][1];?> <?php echo $_config['ItemUpgradeHP']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeHP']['Range'][2][0],'-',$_config['ItemUpgradeHP']['Range'][2][1];?> <?php echo $_config['ItemUpgradeHP']['Range'][2]['Rate'];?> success,<?php echo (100-str_replace("%","",$_config['ItemUpgradeHP']['Range'][2]['Rate']));?>% remain the same level<BR><BR></FONT><FONT color=#ff0000>Hp+MP+SP recovery rate is maximum upgrade to +<?php echo $_config['ItemUpgradeHMSRate']['MaxGrade'];?>%</FONT><BR></FONT></FONT><FONT face=Verdana><FONT size=2><FONT color=#0000ff><?php echo $_config['ItemUpgradeHMSRate']['Pay'];?> points once and increased by <?php echo $_config['ItemUpgradeHMSRate']['Addval'];?>% recovery rate<BR><?php echo $_config['ItemUpgradeHMSRate']['Range'][1][0],'-',$_config['ItemUpgradeHMSRate']['Range'][1][1];?> <?php echo $_config['ItemUpgradeHMSRate']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeHMSRate']['Range'][2][0],'-',$_config['ItemUpgradeHMSRate']['Range'][2][1];?> <?php echo $_config['ItemUpgradeHMSRate']['Range'][2]['Rate'];?> success,<?php echo (100-str_replace("%","",$_config['ItemUpgradeHMSRate']['Range'][2]['Rate']));?>% remain the same level<BR><BR></FONT><FONT color=#ff0000>Hit rate is maximum upgrade to +<?php echo $_config['ItemUpgradeHitRate']['MaxGrade'];?>%</FONT><BR></FONT></FONT><FONT color=#0000ff size=2 face=Verdana><?php echo $_config['ItemUpgradeHitRate']['Pay'];?> points once and increased by <?php echo $_config['ItemUpgradeHitRate']['Addval'];?>% hit rate<BR><?php echo $_config['ItemUpgradeHitRate']['Range'][1][0],'-',$_config['ItemUpgradeHitRate']['Range'][1][1];?> <?php echo $_config['ItemUpgradeHitRate']['Range'][1]['Rate'];?> success<BR><?php echo $_config['ItemUpgradeHitRate']['Range'][2][0],'-',$_config['ItemUpgradeHitRate']['Range'][2][1];?> <?php echo $_config['ItemUpgradeHitRate']['Range'][2]['Rate'];?> success,<?php echo (100-str_replace("%","",$_config['ItemUpgradeHitRate']['Range'][2]['Rate']));?>% remain the same level</FONT></P>

	  	</td>
	  </tr>
	</table>

<script type="text/javascript">
var Page_Validators =  new Array(document.getElementById("ctl00_ContentPlaceHolder_main_ChaList_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check"));
</script>

<script type="text/javascript">
var ctl00_ContentPlaceHolder_main_ChaList_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_ChaList_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_ChaList_Check");
ctl00_ContentPlaceHolder_main_ChaList_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_ChaList";
ctl00_ContentPlaceHolder_main_ChaList_Check.errormessage = "*";
ctl00_ContentPlaceHolder_main_ChaList_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_ChaList_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_ChaList_Check.validationexpression = "^[0-9]{1,10}$";
var ctl00_ContentPlaceHolder_main_Code_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_Code_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null");
ctl00_ContentPlaceHolder_main_Code_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_Code_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Code_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Code_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_ValidateCode_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_ValidateCode_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check");
ctl00_ContentPlaceHolder_main_ValidateCode_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.errormessage = "Please try new code instead";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.validationexpression = "^[0-9a-z]{4}$";
</script>


<script type="text/javascript">

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        WebForm_AutoFocus('HyperLink2');Sys.Application.initialize();

document.getElementById('ctl00_ContentPlaceHolder_main_ChaList_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_ChaList_Check'));
}

document.getElementById('ctl00_ContentPlaceHolder_main_Code_Check_Null').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_Code_Check_Null'));
}

document.getElementById('ctl00_ContentPlaceHolder_main_ValidateCode_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_ValidateCode_Check'));
}
</script>
</form>

	</td>
</tr>
</table>