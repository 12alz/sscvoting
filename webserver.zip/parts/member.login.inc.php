<table width="100%" height="263" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;" valign=top>
<form name="phpnetForm" method="post" action="<?php echo 'member.php?do=login'; ?>" onsubmit="javascript:return WebForm_OnSubmit();" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>
<?php
if($_config['AjaxMode']){
echo '<script src="/WebResource.axd/4a26f1ecae0a33a44b198d94629e3bfb.js" type="text/javascript"></script>'."\n",
	 '<script src="/WebResource.axd/f553e4b43b481582b298229a49734eca.js" type="text/javascript"></script>'."\n";
}
?>
<script type="text/javascript">
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
</script>

         
          <table width="550" border="0" align="center" valign=top cellpadding="5" cellspacing="0">
            <tr>
              <td width="22%"><img src="/images/point_b.gif" /> User ID </td>
              <td width="34%"><input name="UserID" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_UserID" tabindex="1" value="<?php echo htmlentities($_POST["UserID"], ENT_QUOTES, 'UTF-8');?>" maxlength="12" />

              </td>
              <td rowspan="3" valign=top>
              <div style="padding-top:3px">
              <img src="/images/point_c.gif" />  Have not user ID?</img>
              <a href="member.php?do=reg">Register now!</a><br><br>
              <img src="/images/point_c.gif" />  <a href="member.php?do=getbackpwd">Forgot your password?</a>
              </div>
              </td>
            </tr>
            <tr>
              <td><img src="/images/point_b.gif" /> Password</td>
              <td><input name="UserPWD" type="password" maxlength="12" id="ctl00_ContentPlaceHolder_main_UserPWD" tabindex="2" class="form_pay" value="" />
              </td>
              <td></td>

            </tr>
          </table>

          <table width="550" border="0" align="center" cellpadding="5" cellspacing="0">
            <tr>
              <td width="22%"><img src="/images/point_b.gif" /> Code </td>
              <td width="34%"><input name="ValidateCode" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_ValidateCode" style="width:143px;" tabindex="3" value="<?php echo htmlentities($_POST["ValidateCode"], ENT_QUOTES, 'UTF-8');?>" maxlength="4" /></td>
              <td><img id="imgVerify" name="imgVerify" onclick="this.src='/VerifyCode.php?'+Math.random()+';'" alt="Change the picture" />

                <script language="JavaScript" type="text/javascript">
				  <!--
				  phpnetForm.imgVerify.src="/VerifyCode.php?" + Math.random();
				  //-->
				  </script>
				</td>
            </tr>
            <tr>
              <td colspan="3">
              <span id="ctl00_ContentPlaceHolder_main_Result" style="color:Red;"><?php echo $user_auth->errs['Result'];?></span>
<span id="ctl00_ContentPlaceHolder_main_UserID_Check_Null" style="color:Red;display:none;"><br>Account can not be empty.</span>
<span id="ctl00_ContentPlaceHolder_main_UserID_Check" style="color:Red;display:none;"><br>Incorrect User ID!</span>

<span id="ctl00_ContentPlaceHolder_main_UserPWD_Check_Null" style="color:Red;display:none;"><br>Password can not be empty!</span>
<span id="ctl00_ContentPlaceHolder_main_UserPWD_Check" style="color:Red;display:none;"><br>Incorrect Password!</span>
                <span id="ctl00_ContentPlaceHolder_main_ValidateCodeMessage"></span>
                <span id="ctl00_ContentPlaceHolder_main_ValidateCode_Check" style="color:Red;display:none;"><br>Incorrect Validate Code!</span>
                <span id="ctl00_ContentPlaceHolder_main_Code_Check" style="color:Red;"></span>
              <br><br>
              </td>
            </tr>

          </table>
          <br>
          <table width="550" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td align="center">
              <input type="submit" name="HyperLink2" value="Submit" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;HyperLink2&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ContentPlaceHolder_main_HyperLink2" tabindex="4" class="btn2" style="font-size:12px;height:24px;width:50px;" />
                &nbsp;&nbsp;&nbsp;&nbsp;
              <input type="reset" name="reset" value="Reset" tabindex="5" class="btn2" style="font-size:12px;height:24px;width:50px;" />
              <br><img height=20 width=0>

              </td>
            </tr>
          </table>
        
<script type="text/javascript">
var Page_Validators =  new Array(document.getElementById("ctl00_ContentPlaceHolder_main_UserID_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_UserID_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_UserPWD_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_UserPWD_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check"));
</script>

<script type="text/javascript">
var ctl00_ContentPlaceHolder_main_UserID_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_UserID_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_UserID_Check_Null");
ctl00_ContentPlaceHolder_main_UserID_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_UserID";
ctl00_ContentPlaceHolder_main_UserID_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_UserID_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_UserID_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_UserID_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_UserID_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_UserID_Check");
ctl00_ContentPlaceHolder_main_UserID_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_UserID";
ctl00_ContentPlaceHolder_main_UserID_Check.errormessage = "<br>Incorrect User ID!";
ctl00_ContentPlaceHolder_main_UserID_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_UserID_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_UserID_Check.validationexpression = "^[a-zA-Z_][a-zA-Z0-9_]{4,12}";
var ctl00_ContentPlaceHolder_main_UserPWD_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_UserPWD_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_UserPWD_Check_Null");
ctl00_ContentPlaceHolder_main_UserPWD_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_UserPWD";
ctl00_ContentPlaceHolder_main_UserPWD_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_UserPWD_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_UserPWD_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_UserPWD_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_UserPWD_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_UserPWD_Check");
ctl00_ContentPlaceHolder_main_UserPWD_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_UserPWD";
ctl00_ContentPlaceHolder_main_UserPWD_Check.errormessage = "<br>Incorrect Password!";
ctl00_ContentPlaceHolder_main_UserPWD_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_UserPWD_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_UserPWD_Check.validationexpression = "^[0-9a-zA-Z_]{6,12}";
var ctl00_ContentPlaceHolder_main_ValidateCode_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_ValidateCode_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check");
ctl00_ContentPlaceHolder_main_ValidateCode_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.errormessage = "<br>Incorrect Validate Code!";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.validationexpression = "^[0-9a-z]{4}$";
</script>


<script type="text/javascript">

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
</script>
</form>

    </td>
  </tr>
</table>
