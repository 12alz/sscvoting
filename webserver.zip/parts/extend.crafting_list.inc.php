<?php 
	$items = $getItems->getAllItemsFromProduct();
	$itemMix = array(
		array(
			'type' => 'hood',
			'materials' => array(
				'122_189' => 1,
				'122_190' => 1,
				'122_191' => 1,
				'334_37' => 10,
				'0' => 0
			),
			'output' => array('136_20', 1)
		)
	);
?>

<style>
	.itemMix ul.material_list li{
		display: inline-block;
		margin-right: 5px;
		width: 40px;
		height: 40px;
		overflow: hidden;
		background: #afaeae;
	}
	.itemMix ul li img {
		width: 100%;
	}
	.itemMixInner {
		float: left;
	}
	.itemMixInner.right_section {
		width: 400px;
		height: 400px;
		background: #000;
		background: #f3f3f3;
		border: 1px solid #bbb;
		border-radius: 2px;
		overflow: hidden;
		margin-left:20px;
	}
	.itemMixInner.left_section {
		width: 175px;
		height: 400px;
		background: #f3f3f3;
		border: 1px solid #bbb;
		border-radius: 2px;
		overflow: hidden;
	}
	.itemMixInner.left_section ul li.active {
		background: #35668c;
		color: #fff;
	}
	.itemMixInner.left_section ul li {
		cursor:pointer;
	}
	.itemMixInner.left_section ul li:hover{
		background: #35668c;
		color: #fff;
	}
	.itemMixInner.left_section ul li {
		padding: 5px 8px;
		border-bottom: 1px solid #c7c7c7;
	}
	.padd{padding:7px;}
	.name_item_craft{
		    border-bottom: 1px solid #d0d0d0;
		text-align: center;
		font-weight: bold;
		font-size: 13px;
		color: #000;
	}
	.material_list{text-align:center;}
	.mar15{
		margin-top: 15px;
    margin-bottom: 15px;
	}
	.req_text{
		text-align: center;
		color: #10881a;
	}
	.itemMix ul li.have_material{
		height: 62px !important;
	}
	.have_material .material_over{
		width: 100%;
		height: 25px;
		background: #000;
		margin-top: -6px;
		font-size: 10px;
	}
	.req_text_bottom{
		text-align: center;
    padding: 9px;
    background: #353535;
	color: #8bf193;
	}
	.insu_material,
	.insu_gold{
		    font-weight: bold;
		color: red !important;
	}
	.req_material_resources{
		width: 100%;
		margin-top: 6px;
	}
	ul.req_material_resources li {
		display: inline-block;
		padding: 9px;
		background: #353535;
	}
	ul.req_material_resources li {
		display: inline-block;
		padding: 2.22%;
		background: #353535;
		width: 45.1%;
		text-align: center;
		font-size: 10px;
		color: #fff;
	}
	.generate_action{
		text-align: center;
		width: 95%;
		background: #23770d;
		color: #fff;
		padding: 7px;
		margin-top: 12px;
		cursor: pointer;
		margin: 12px 10px;
	}
	.header_categories ul li {
    display: inline-block;
  background: #35668c;
    color: #fff;
    padding: 5px 7px;
    text-align: center;
    width: 46px;
}
.header_categories {
    margin-bottom: 16px;
}
.popupContainer{
	display:none;
	    position: fixed;
    top: 0%;
    left: 0%;
    width: 100%;
    height: 100%;
    background: rgba(255,255,255,0);
	z-index: 999;
}
.popupContainerInner{
	width: 900px;
	height: auto;
    background: #fff;
    margin: 0 auto;
    margin-top: 7%;
    border: 3px solid #757575;
	    padding: 9px;
}
.loader{
	width: 477px;
    margin: 0 auto;
    display: block;
}
.closeInv{
	    width: 10px;
    position: absolute;
    right: 5px;
    top: 3px;
}
.headpopup{
	position: relative;
}
.footerpopup{
	    text-align: right;
    margin-top: 8px;
}
.importfusion{
	    padding: 5px 11px;
    background: #5a98c7;
    color: #fff;
}
.importfusion,
.closeInv,
.fusions_items li:first-child
{
	cursor:pointer;
}
</style>
<table width="100%" height="350" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;" valign=top>
		 <!--content/s-->
<form name="phpnetForm" method="post" action="<?php echo 'extend.php?do=crafting'; ?>" onsubmit="javascript:return WebForm_OnSubmit();" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ctl00_ContentPlaceHolder_main_HyperLink2')" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />

</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>


<?php
if($_config['AjaxMode']){
echo '<script src="/WebResource.axd/4a26f1ecae0a33a44b198d94629e3bfb.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/5460f4dfbd221bcd575ca1292a108cfa.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/42c740683f0709257bab43d28ea0de90.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/b4b17b0bafa5744aeb3dfe229abd0952.js" type="text/javascript"></script>'."\n",
	 '<script src="/WebResource.axd/8873f142ec7ff7723ba99c2d06688bce.js" type="text/javascript"></script>'."\n";
}
?>

<script type="text/javascript">
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
</script>


<div class="space"></div>

<html>
<body>


<div class="space"></div>
	<div class="itemMixContainer">
		<div class="header_categories">
			<ul>
				<li>All</li>
				<li>Cloth</li>
				<li>Pants</li>
				<li>Gloves</li>
				<li>Booths</li>
				<li>Wing</li>
				<li>Hood</li>
				<li>Footring</li>
				<li>Ring</li>
				<li>Belt</li>
			</ul>
		</div>
		<div class="itemMixInner left_section">
			<div class="itemMix_list">
				<ul>
					<?php foreach($itemMix as $key => $value){ ?>
						<li><?= $items[$value['output'][0]]['ItemName'] ?></li>
					<?php } ?>
				</ul>
			</div>
		</div>
		<div class="itemMixInner right_section">
		</div>
	</div>
	
          
<div class="space"></div>

<?php include_once('js/globaljs.php'); ?>

<script type="text/javascript">

$(function(){
	
	$(document).on('click','.generate_action',function(e){
		e.preventDefault();
		
		var len = $('.itemMixInner.left_section ul li.active').length;
		
		if(len > 0){
			var MID = $('.itemMixInner.left_section ul li.active').attr('data-mid');
			var enc = $('.fusions_items li:first-child').data('enc') ? $('.fusions_items li:first-child').data('enc') : null;
			var data = {'MID':MID,'CID':<?= $_GET['cid'] ?>,enc:enc,evt:'generate'};
			otp.send_ajax(
				data,
				'ajax_crafting.php',
				'POST'
			);
		}else{
			alert('No Data Selected');
		}
		
	});
	
	$(document).on('click','.fusions_items li:first-child',function(e){
		e.preventDefault();
		var _elem = $(this);
		$('.itemscrafting').html('<tr class="rowstyle" style="height: 20px; color: blue; background-color: rgb(218, 234, 253);"><td colspan="10"><img class="loader" src="images/loader.gif" /></td></tr>');
		if($('.material_list li').length == 6){
			// elem.closest('.material_list').eq(0);
			$('.popupContainer').show();
		}else{
			alert('Invalid Materials');
		}
		var MID = $('.itemMixInner.left_section ul li.active').attr('data-mid');
		var fmid = $(this).attr('data-id');
		var data = {'fmid':fmid,'MID':MID,'CID':<?= $_GET['cid'] ?>,evt:'getitem'};
		otp.send_ajax(
			data,
			'ajax_crafting.php',
			'POST'
		);
	});
	
	$('.importfusion').click(function(){
		
		if($('.itemscrafting tr td input[type="radio"]:checked').length > 0){
			var val = $('.itemscrafting tr td input[type="radio"]:checked').val();
			$('.fusions_items li:first-child').data('enc',val);
			$('.popupContainer').hide();
		}else{
			alert('No Selected Item');
		}
		
	});
	
	$('.closeInv').click(function(){
		$('.itemscrafting').html('');
		$('.popupContainer').hide();
	});
	
	initLoad();
});

function initLoad(){
	var data = {'MID':null,'CID':<?= $_GET['cid'] ?>,evt:'load'}
	otp.send_ajax(
		data,
		'ajax_crafting.php',
		'POST'
	);
}



function crafting_out(data){
	if(data.msg){
		alert(data.msg);
	}
	switch(data.evt){
		case 'load':
			$('.right_section').html(data.html.right);
			$('.left_section .itemMix_list').html(data.html.left);
		break;
		case 'getitem':
			$('.itemscrafting').html(data.html.item);
		break;
	}
	
}
</script>
</form>

	</td>
</tr>
<center>
<div class="radio_bg">
	<div class="radio_holder">
	<!-- FM LINK HERE-->
	<div class="aligner">
	<iframe src="http://www.teeradyo.net/radioplayer2/index.html" 
	width="0" 
	height="0" 
	scrolling="no" 
	frameborder="0" 
	allowtransparency="true";>
	</iframe>
	</div>
</table>
<div class="popupContainer">
	<div class="popupContainerInner">
		<div class="headpopup"><h3>Web Inventory</h3><img class="closeInv" src="images/icon_close.gif" /></div>
		<div class="bodypopup">
			<table cellspacing="0" cellpadding="4" rules="all" border="1" id="ctl00_ContentPlaceHolder_main_GridView1" style="background-color:White;border-color:#666666;border-width:1px;border-style:solid;font-size:9pt;width:100%;border-collapse:collapse;">
				<thead>
					<tr class="headerstyle" style="background-color:#CECFD6;font-size:9pt;font-weight:normal;height:23px;color: #fff;">

						<th scope="col"></th>
						<th scope="col">Item Name</th>
						<th scope="col">Attack</th>
						<th scope="col">Defense</th>
						<th scope="col">Attack Rate</th>
						<th scope="col">Defense Rate</th>
						<th scope="col">HP</th>
						<th scope="col">Recovery rate</th>
						<th scope="col">Hit rate</th>
						<th scope="col">Quantity</th>
					</tr>
					
				</thead>
				<tbody class="itemscrafting">
				</tbody>
			</table>
		
			
		</div>
		<div class="footerpopup">
			<input class="importfusion" type="button" value="Import into Fusion Mixer" />
		</div>
	</div>
</div>