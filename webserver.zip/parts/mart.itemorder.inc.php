<table width="100%" height="265" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;" valign=top>
<br>
<form name="phpnetForm" method="post" action="<?php echo 'mart.php?do=itemorder'; ?>" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
</div>
<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>
</div>

  <table width="100%" align="center" cellpadding="0" cellspacing="0" class="pk01">
    
	<tr>
	  <td>
		<div>
	<table cellspacing="0" cellpadding="4" rules="all" border="1" id="ctl00_ContentPlaceHolder_main_CustomersGridView" style="border-color:#EEEEEE;font-size:9pt;width:100%;border-collapse:collapse;color:#000">
		<?php $itemShopPurchase->itemOrderList();?>
	</table>
</div>
        
	    
	    <br />
<span id="ctl00_ContentPlaceHolder_main_Label1" style="color:Red;"></span>
      </td></tr>

  </table>
</form>

	</td>
</tr>
</table>