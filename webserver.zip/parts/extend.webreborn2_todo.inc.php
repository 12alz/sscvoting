<table width="100%" height="350" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;" valign=top>
		 <!--content/s-->
<form name="phpnetForm" method="post" action="<?php echo 'extend.php?do=webreborn2_todo&cid=',$character->characterVO->chaNum,''; ?>" onsubmit="javascript:return WebForm_OnSubmit();" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ctl00_ContentPlaceHolder_main_HyperLink2')" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />

</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>


<?php
if($_config['AjaxMode']){
echo '<script src="/WebResource.axd/4a26f1ecae0a33a44b198d94629e3bfb.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/5460f4dfbd221bcd575ca1292a108cfa.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/42c740683f0709257bab43d28ea0de90.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/b4b17b0bafa5744aeb3dfe229abd0952.js" type="text/javascript"></script>'."\n",
	 '<script src="/WebResource.axd/8873f142ec7ff7723ba99c2d06688bce.js" type="text/javascript"></script>'."\n";
}
?>

<script type="text/javascript">
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
</script>


<br>
<div class="space"></div>
<table width="100%" border="0" cellpadding="10" cellspacing="1" align="center" class="showdetail">
  <tr>
    <td style="padding:6px">


<p>1. Please logoff the game first and wait 30 seconds. </p>
<p>2. Increase one reborn need <?php echo $_config['PurchaseRebornVip'];?> Epoints.</p>
<p>3. Level,Stat Points,Location,Skill,Task will not change.</p>
<p>4. You don't need do anything about inventory.</p>
<p>5. Purchase one reborn you can get 25 stats points like "Normal Reborn".</p>
<p>6. You can go Reborn page to update "Normal Reborn" to "VIP Reborn".</p>
<p style="float:right;color:Red;">Maximum Reborn Number: <span id="ctl00_ContentPlaceHolder_main_zs">435</span> th</p>


  	</td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="3" cellspacing="1">
  <tr>
    <td  width="30%" height="30"><img src="/images/point_b.gif" /> Your Account:</td>
    <td  width="30"><span id="ctl00_ContentPlaceHolder_main_UserID"><?php echo $user->userID; ?> </span> / <span id="ctl00_ContentPlaceHolder_main_ChaName"><?php echo $reborn->characterVO->chaName; ?> </span></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="3" cellspacing="1">
  <tr>
    <td  width="30%" height="30"><img src="/images/point_b.gif" /> Your Character In-Game Level:</td>
    <td ><input name="OldChaLevel" type="text" value="<?php echo (int)$reborn->characterVO->chaLevel;?>" id="ctl00_ContentPlaceHolder_main_OldChaLevel" disabled="disabled" style="border-width:0px;width:80px;color:red;" /></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="3" cellspacing="1">
  <tr>
    <td  width="30%" height="30"><img src="/images/point_b.gif" /> Your Character In-Game Rebirth:</td>
    <td ><input name="OldChaRebirth" type="text" value="<?php echo (int)$reborn->characterVO->chaReborn;?>" id="ctl00_ContentPlaceHolder_main_OldChaRebirth" disabled="disabled" style="border-width:0px;width:80px;color:red" /></td>
  </tr>
</table>
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
      <td width="30%"  height="30"><img src="/images/point_b.gif" /> Your Account Total Points:</td>
      <td>
        <span id="ctl00_ContentPlaceHolder_main_GameTime"><?php echo $user->userPoint; ?></span> Points
      </td>
    </tr>
  </table>
   <!--  <table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
    <tr>
      <td width="30%" height="30"><img src="/images/point_b.gif" /> Rebirth Type </td>
      <td>
      <select name="RebornType" id="ctl00_ContentPlaceHolder_main_RebornType">

  <option <?php if (clean_variable($_POST["RebornType"])=="standard") {echo 'selected="selected"';}?> value="standard">standard</option>
  <option <?php if (clean_variable($_POST["RebornType"])=="vip") {echo 'selected="selected"';}?> value="vip">vip</option>

      </select>
      <span id="ctl00_ContentPlaceHolder_main_RebornType_Check" style="color:#FF6600;display:none;">*</span>
      </td>
    </tr>
  </table> -->
   <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
       <td width="13%" height="30"><img src="/images/point_b.gif" /> Reborn Number you want to buy: </td>
       <td width="30%" height="30"><input name="RebornNum" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_RebornNum" style="width: :143px;" tabindex="3" value="<?php echo htmlentities($_POST["RebornNum"], ENT_QUOTES, 'UTF-8');?>" onkeyup="value=value.replace(/[^\d]/g,'');Calculate();" pattern="[0-9]*" maxlength="3" />
       <span style="color:#ff0000" id="s1" value=""></span>
      </td>
    </tr>
  </table>
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr>
       <td width="13%" height="30"><img src="/images/point_b.gif" /> Total Purchase: </td>
       <td width="30%" height="30"><input name="RebornTotalPurchase" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_RebornTotalPurchase" style="width: :143px;" tabindex="3" value="<?php echo htmlentities($_POST["RebornTotalPurchase"], ENT_QUOTES, 'UTF-8');?>" onkeyup="value=value.replace(/[^\d]/g,'');" pattern="[0-9]*" maxlength="8" disabled/>
       <span style="color:#ff0000" id="s1" value=""></span>
      </td>
    </tr>
  </table>

<br>
	<table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" class="boardList_03">

      <tr>
        <td width="30%" height="30"><img src="/images/point_b.gif" /> Type the code shown </td>
        <td width="30%" height="30"><input name="ValidateCode" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_ValidateCode" style="width:143px;" tabindex="3" value="<?php echo htmlentities($_POST["ValidateCode"], ENT_QUOTES, 'UTF-8');?>" maxlength="4" /></td>
        <td><img id="imgVerify" name="imgVerify" onclick="this.src='/VerifyCode.php?'+Math.random()+';'" alt="Change the picture" />
		  <SCRIPT language=javascript>
		  phpnetForm.imgVerify.src="/VerifyCode.php?" + Math.random();
		  </script>
            <span id="ctl00_ContentPlaceHolder_main_Code_Check_Null" style="color:Red;display:none;">This information is required</span>              
            <span id="ctl00_ContentPlaceHolder_main_ValidateCode_Check" style="color:Red;display:none;">Please try new code instead</span>              
            <span id="ctl00_ContentPlaceHolder_main_Code_Check" style="color:Red;"><?php echo $reborn->errs['CodeCheck'];?></span></td>

      </tr>
    </table>
<span id="ctl00_ContentPlaceHolder_main_Result" style="color:Red;"><?php echo $reborn->errs['Result'];?></span>
  		  <br>

          <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td align="center">
              <br><img height=20 width=0>
              <input type="submit" name="HyperLink2" value="Submit" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;HyperLink2&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ContentPlaceHolder_main_HyperLink2" tabindex="4" class="btn2" style="font-size:12px;height:24px;width:50px;" />

                &nbsp;&nbsp;&nbsp;&nbsp;
              <input type="reset" name="reset" value="Reset" tabindex="5" class="btn2" style="font-size:12px;height:24px;width:50px;" />
              <br><img height=20 width=0>
              </td>
            </tr>
          </table>


<script type="text/javascript">
var Page_Validators =  new Array(document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check"));
</script>

<script type="text/javascript">
var ctl00_ContentPlaceHolder_main_Code_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_Code_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null");
ctl00_ContentPlaceHolder_main_Code_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_Code_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Code_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Code_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_ValidateCode_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_ValidateCode_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check");
ctl00_ContentPlaceHolder_main_ValidateCode_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.errormessage = "Please try new code instead";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.validationexpression = "^[0-9a-z]{4}$";
</script>


<script type="text/javascript">

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        WebForm_AutoFocus('HyperLink2');Sys.Application.initialize();

document.getElementById('ctl00_ContentPlaceHolder_main_Code_Check_Null').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_Code_Check_Null'));
}

document.getElementById('ctl00_ContentPlaceHolder_main_ValidateCode_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_ValidateCode_Check'));
}

  
  function Calculate(){
  var ratestandard = 1000;
  var ratevip = 150;
  var Num_ = parseInt(document.getElementById("ctl00_ContentPlaceHolder_main_RebornNum").value);
  
  /*var s = document.getElementById("ctl00_ContentPlaceHolder_main_RebornType");
  var item1 = s.options[s.selectedIndex].value;*/

  var result = document.getElementById("s1").innerHTML="Total EPoints " + Num_ * ratevip;
  var result1 = document.getElementById("ctl00_ContentPlaceHolder_main_RebornTotalPurchase").value = Num_ * ratevip;

  /*if(item1 == "standard"){

      var result = document.getElementById("s1").innerHTML="Total EPoints " + Num_ * ratestandard;
      var result1 = document.getElementById("ctl00_ContentPlaceHolder_main_RebornTotalPurchase").value = Num_ * ratestandard;

  }else if(item1 == "vip"){

      var result = document.getElementById("s1").innerHTML="Total EPoints " + Num_ * ratevip;
      var result1 = document.getElementById("ctl00_ContentPlaceHolder_main_RebornTotalPurchase").value = Num_ * ratevip;
  }
*/

}


</script>
</form>
		 <!--content/e-->
<script type="text/javascript" src="inc/webjd.js"> </script>
	</td>
</tr>
</table>

