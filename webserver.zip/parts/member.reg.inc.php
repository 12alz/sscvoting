<form name="phpnetForm" method="post" action="<?php echo $regInfo = (clean_variable($_GET['uid'])!=NULL) ? 'member.php?do=reg&uid='.clean_variable($_GET['uid']).'': 'member.php?do=reg'; ?>" onsubmit="javascript:return WebForm_OnSubmit();" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ctl00_ContentPlaceHolder_main_HyperLink2')" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>


<?php
if($_config['AjaxMode']){
echo '<script src="/WebResource.axd/4a26f1ecae0a33a44b198d94629e3bfb.js" type="text/javascript"></script>'."\n",
 	 '<script src="/ScriptResource.axd/5460f4dfbd221bcd575ca1292a108cfa.js" type="text/javascript"></script>'."\n",
 	 '<script src="/ScriptResource.axd/42c740683f0709257bab43d28ea0de90.js" type="text/javascript"></script>'."\n",
 	 '<script src="/ScriptResource.axd/b4b17b0bafa5744aeb3dfe229abd0952.js" type="text/javascript"></script>'."\n",
 	 '<script src="/member.axd/AjaxControlToolkit.Compat.Timer.Timer.js" type="text/javascript"></script>'."\n",
 	 '<script src="/WebResource.axd/8873f142ec7ff7723ba99c2d06688bce.js" type="text/javascript"></script>'."\n";

}
?>
<script type="text/javascript">
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
</script>


<table width="550" border="0" cellspacing="0" cellpadding="0" align=center>
  <tr>
    <td>
<br>
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
  <tr>
    <td></td>
  </tr>
  <tr>

    <td><img src="/images/point_b.gif" /> Your Account</td>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0" class="boardList_03">
      <tr>
        <td width="112px"><input name="UserID" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_UserID" style="width:112px;margin-left:4px" tabindex="1" value="<?php echo htmlentities($_POST["UserID"], ENT_QUOTES, 'UTF-8');?>" maxlength="12" /></td>
        <td align="left">
        <a class="button" id="ctl00_ContentPlaceHolder_main_HyperLink" onclick="JavaScript:doCallAjax();"><span style="overflow:hidden;">Check</span></a>
        </td>
        <td width="250" align="left">

       <span id="ctl00_ContentPlaceHolder_main_UserID_RegEx" style="color:Red;display:none;"></span>
        
        <div id="ctl00_ContentPlaceHolder_main_up1" <!--style="float:left;padding-left: 15px;"-->>
	
                <span id="ctl00_ContentPlaceHolder_main_UserIDMessage"><?php echo $user_auth->errs['UserID'];?></span>
            
		</div>
        </td>
      </tr>
    </table></td>

  </tr>
  <tr height=15>
    <td height=15>&nbsp;</td>
    <td height=15>《<?php echo $_config['SystemName'];?> 》Account by the numbers, letters or an underscore composition, <br>length of 4 to 16, the first letters of the alphabet must be.
	</td>
  </tr>

  <tr>
    <td width="24%"><img src="/images/point_b.gif" /> Password</td>

    <td>
    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="boardList_03">
      <tr>
        <td width="112px">
        <input name="UserPWD" type="password" maxlength="12" id="ctl00_ContentPlaceHolder_main_UserPWD" tabindex="2" class="form_pay" style="width:112px;margin-left:4px" />
        </td>
        <td align="left">
		<div id="ctl00_ContentPlaceHolder_main_up3">
	
                <span id="ctl00_ContentPlaceHolder_main_UserPWDMessage"><?php echo $user_auth->errs['UserPWD'];?></span>

            
</div>
        <span id="ctl00_ContentPlaceHolder_main_UserPWD_RegEx" style="color:Red;display:none;"></span>
        
        </td>
      </tr>
    </table>
    </td>      
  </tr>

  <tr>
    <td>&nbsp;</td>

    <td>Password by the numbers, letters or an underscore composition, <br>length of 6 to 12</td>
  </tr>
  <tr>
    <td><img src="/images/point_b.gif" /> Once again</td>
    <td><input name="Re_UserPWD" type="password" maxlength="12" id="ctl00_ContentPlaceHolder_main_Re_UserPWD" tabindex="3" class="form_pay" style="width:112px;margin-left:4px" />
      <span id="ctl00_ContentPlaceHolder_main_Re_UserPWD_Check" style="color:Red;<?php if($user_auth->errs['ReUserPWD']==NULL){ echo 'display:none;'; }?>"><?php if($user_auth->errs['ReUserPWD']!=NULL){ echo $user_auth->errs['ReUserPWD']; }else{ echo 'Two different input, please re-enter'; }?></span></td>

  </tr>



  <tr>
    <td width="24%"><img src="/images/point_b.gif" /> 2nd Password</td>
    <td>
    <table width="100%" border="0" cellspacing="0" cellpadding="0"  class="boardList_03">
      <tr>

        <td width="112px">
        <input name="SafePWD" type="password" maxlength="12" id="ctl00_ContentPlaceHolder_main_SafePWD" tabindex="3" class="form_pay" style="width:112px;margin-left:4px" />
        </td>
        <td align="left">
		<div id="ctl00_ContentPlaceHolder_main_up4">
	
                <span id="ctl00_ContentPlaceHolder_main_SafePWDMessage"><?php echo $user_auth->errs['SafePWD'];?></span>
            
</div>
        <span id="ctl00_ContentPlaceHolder_main_SafePWD_RegEx" style="color:Red;display:none;"></span>
        
        </td>

      </tr>
    </table>
    </td>      
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>2nd Password by the numbers, letters or an underscore composition, <br>length of 6 to 12</td>
  </tr>

  <tr>
    <td><img src="/images/point_b.gif" /> Once again</td>
    <td><input name="Re_SafePWD" type="password" maxlength="12" id="ctl00_ContentPlaceHolder_main_Re_SafePWD" tabindex="3" class="form_pay" style="width:112px;margin-left:4px" />
      <span id="ctl00_ContentPlaceHolder_main_Re_SafePWD_Check" style="color:Red;<?php if($user_auth->errs['ReSafePWD']==NULL){ echo 'display:none;'; }?>"><?php if($user_auth->errs['ReSafePWD']!=NULL){ echo $user_auth->errs['ReSafePWD']; }else{ echo 'Two different input, please re-enter'; }?></span></td>
  </tr>


  <tr>

    <td><img src="/images/point_b.gif" /> Email</td>
    <td><input name="Email" type="text" class="form_pay2" id="ctl00_ContentPlaceHolder_main_Email" style="width:232px;margin-left:4px" tabindex="4" value="<?php echo htmlentities($_POST["Email"], ENT_QUOTES, 'UTF-8');?>" maxlength="32" />  <span id="ctl00_ContentPlaceHolder_main_msgemail"><?php echo $user_auth->errs['Email'];?></span>
        <span id="ctl00_ContentPlaceHolder_main_Email_Check" style="color:Red;display:none;">Incorrect,please input again</span>
  </tr>
</table>
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" >
  <tr>
    <td width="24%"><img src="/images/point_b.gif" /> Code </td>

    <td width="22%"> <input name="ValidateCode" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_ValidateCode" style="width:112px;margin-left:4px" tabindex="4" value="<?php echo htmlentities($_POST["ValidateCode"], ENT_QUOTES, 'UTF-8');?>" maxlength="4" /></td>
    <td><img id="imgVerify" name="imgVerify" onclick="this.src='/VerifyCode.php?'+Math.random()+';'" alt="Change the picture" />
	  <SCRIPT language=javascript>
	  phpnetForm.imgVerify.src="/VerifyCode.php?" + Math.random();
	  </script>
	  <span id="ctl00_ContentPlaceHolder_main_ValidateCodeMessage"></span>
	  <span id="ctl00_ContentPlaceHolder_main_ValidateCode_Check" style="color:Red;display:none;">Incorrect code,please input again</span>
    <span id="ctl00_ContentPlaceHolder_main_Code_Check" style="color:Red;"><?php echo $user_auth->errs['CodeCheck'];?></span>
	</td>

  </tr>
</table>
<div class="space"></div><div class="space"></div>
<div align=center>
          <span id="ctl00_ContentPlaceHolder_main_Result"><?php echo $user_auth->errs['Result'];?></span>
</div>
          <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td align="center">
              <input type="submit" name="HyperLink2" value="Submit" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;HyperLink2&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ContentPlaceHolder_main_HyperLink2" tabindex="4" class="btn2" style="font-size:12px;height:24px;width:50px;" />
                &nbsp;&nbsp;&nbsp;&nbsp;

              <input type="reset" name="reset" value="Reset" tabindex="5" class="btn2" style="font-size:12px;height:24px;width:50px;" />
              <br><img height=20 width=0>
              </td>
            </tr>
          </table>
  </td>
</tr>
</table>

<script type="text/javascript">
var Page_Validators =  new Array(document.getElementById("ctl00_ContentPlaceHolder_main_UserID_RegEx"), document.getElementById("ctl00_ContentPlaceHolder_main_UserPWD_RegEx"), document.getElementById("ctl00_ContentPlaceHolder_main_Re_UserPWD_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_SafePWD_RegEx"), document.getElementById("ctl00_ContentPlaceHolder_main_Re_SafePWD_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_Email_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check"));
</script>

<script type="text/javascript">
var ctl00_ContentPlaceHolder_main_UserID_RegEx = document.all ? document.all["ctl00_ContentPlaceHolder_main_UserID_RegEx"] : document.getElementById("ctl00_ContentPlaceHolder_main_UserID_RegEx");
ctl00_ContentPlaceHolder_main_UserID_RegEx.controltovalidate = "ctl00_ContentPlaceHolder_main_UserID";
ctl00_ContentPlaceHolder_main_UserID_RegEx.errormessage = "<font style=\'font-size:12px;color:red;\'>Account by the numbers, letters or an underscore composition, <br>length of 4 to 16, the first letters of the alphabet must be.</font>";
ctl00_ContentPlaceHolder_main_UserID_RegEx.display = "None";
ctl00_ContentPlaceHolder_main_UserID_RegEx.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_UserID_RegEx.validationexpression = "^[a-zA-Z][a-zA-Z0-9_]{3,15}$";
var ctl00_ContentPlaceHolder_main_UserPWD_RegEx = document.all ? document.all["ctl00_ContentPlaceHolder_main_UserPWD_RegEx"] : document.getElementById("ctl00_ContentPlaceHolder_main_UserPWD_RegEx");
ctl00_ContentPlaceHolder_main_UserPWD_RegEx.controltovalidate = "ctl00_ContentPlaceHolder_main_UserPWD";
ctl00_ContentPlaceHolder_main_UserPWD_RegEx.errormessage = "<font style=\'font-size:12px\'>Password by the numbers, letters or an underscore composition, <br>length of 6 to 12</font>";
ctl00_ContentPlaceHolder_main_UserPWD_RegEx.display = "None";
ctl00_ContentPlaceHolder_main_UserPWD_RegEx.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_UserPWD_RegEx.validationexpression = "^[0-9a-zA-Z_]{6,12}";
var ctl00_ContentPlaceHolder_main_Re_UserPWD_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_Re_UserPWD_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_Re_UserPWD_Check");
ctl00_ContentPlaceHolder_main_Re_UserPWD_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_Re_UserPWD";
ctl00_ContentPlaceHolder_main_Re_UserPWD_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Re_UserPWD_Check.evaluationfunction = "CompareValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Re_UserPWD_Check.controltocompare = "ctl00_ContentPlaceHolder_main_UserPWD";
ctl00_ContentPlaceHolder_main_Re_UserPWD_Check.controlhookup = "ctl00_ContentPlaceHolder_main_UserPWD";
var ctl00_ContentPlaceHolder_main_SafePWD_RegEx = document.all ? document.all["ctl00_ContentPlaceHolder_main_SafePWD_RegEx"] : document.getElementById("ctl00_ContentPlaceHolder_main_SafePWD_RegEx");
ctl00_ContentPlaceHolder_main_SafePWD_RegEx.controltovalidate = "ctl00_ContentPlaceHolder_main_SafePWD";
ctl00_ContentPlaceHolder_main_SafePWD_RegEx.errormessage = "<font style=\'font-size:12px\'>2nd Password by the numbers, letters or an underscore composition, <br>length of 6 to 12</font>";
ctl00_ContentPlaceHolder_main_SafePWD_RegEx.display = "None";
ctl00_ContentPlaceHolder_main_SafePWD_RegEx.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_SafePWD_RegEx.validationexpression = "^[0-9a-zA-Z_]{6,12}";
var ctl00_ContentPlaceHolder_main_Re_SafePWD_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_Re_SafePWD_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_Re_SafePWD_Check");
ctl00_ContentPlaceHolder_main_Re_SafePWD_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_Re_SafePWD";
ctl00_ContentPlaceHolder_main_Re_SafePWD_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Re_SafePWD_Check.evaluationfunction = "CompareValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Re_SafePWD_Check.controltocompare = "ctl00_ContentPlaceHolder_main_SafePWD";
ctl00_ContentPlaceHolder_main_Re_SafePWD_Check.controlhookup = "ctl00_ContentPlaceHolder_main_SafePWD";
var ctl00_ContentPlaceHolder_main_Email_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_Email_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_Email_Check");
ctl00_ContentPlaceHolder_main_Email_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_Email";
ctl00_ContentPlaceHolder_main_Email_Check.errormessage = "Incorrect,please input again";
ctl00_ContentPlaceHolder_main_Email_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Email_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Email_Check.validationexpression = "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
var ctl00_ContentPlaceHolder_main_ValidateCode_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_ValidateCode_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check");
ctl00_ContentPlaceHolder_main_ValidateCode_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.errormessage = "Incorrect code,please input again";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.validationexpression = "^[0-9a-z]{4}$";
</script>


<script type="text/javascript">

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        WebForm_AutoFocus('HyperLink2');Sys.Application.initialize();

document.getElementById('ctl00_ContentPlaceHolder_main_UserID_RegEx').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_UserID_RegEx'));
}
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ValidatorCalloutBehavior, {"closeImageUrl":"images/icon_close.gif","highlightCssClass":"form_pay2","id":"ctl00_ContentPlaceHolder_main_UserID_RegxShow","warningIconImageUrl":"images/icon_exclamation.gif","width":"280px"}, null, null, $get("ctl00_ContentPlaceHolder_main_UserID_RegEx"));
});

document.getElementById('ctl00_ContentPlaceHolder_main_UserPWD_RegEx').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_UserPWD_RegEx'));
}
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ValidatorCalloutBehavior, {"closeImageUrl":"images/icon_close.gif","highlightCssClass":"form_pay2","id":"ctl00_ContentPlaceHolder_main_UserPWD_RegxShow","warningIconImageUrl":"images/icon_exclamation.gif","width":"230px"}, null, null, $get("ctl00_ContentPlaceHolder_main_UserPWD_RegEx"));
});

document.getElementById('ctl00_ContentPlaceHolder_main_Re_UserPWD_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_Re_UserPWD_Check'));
}

document.getElementById('ctl00_ContentPlaceHolder_main_SafePWD_RegEx').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_SafePWD_RegEx'));
}
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ValidatorCalloutBehavior, {"closeImageUrl":"images/icon_close.gif","highlightCssClass":"form_pay2","id":"ctl00_ContentPlaceHolder_main_SafePWD_RegxShow","warningIconImageUrl":"images/icon_exclamation.gif","width":"230px"}, null, null, $get("ctl00_ContentPlaceHolder_main_SafePWD_RegEx"));
});

document.getElementById('ctl00_ContentPlaceHolder_main_Re_SafePWD_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_Re_SafePWD_Check'));
}

document.getElementById('ctl00_ContentPlaceHolder_main_Email_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_Email_Check'));
}

document.getElementById('ctl00_ContentPlaceHolder_main_ValidateCode_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_ValidateCode_Check'));
}
</script>
</form>