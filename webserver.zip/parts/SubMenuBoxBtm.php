                  <tr>
            		<td id="subMenuBoxNav">
            			<a href="javascript:menu(37);"><font style="color: orange;"><u>GameTime to EPoints</u></a>
            		</td>
            	</tr>
            	<tr>
            		<td id="subMenuBoxNav"><a href="erank.php"><font style="color: ;"><u>Rankings</u></a></td>
            	</tr>
            	<tr>
            		<td id="subMenuBoxNav"><a href="javascript:menu(35);"><font style="color: ;"><u>Reset PK Status</u></a>
            		</td>
            	</tr>
            	<tr>
	 			<td id="subMenuBoxNav"><a href="member.php?do=editpwd"><u>Reset Password</u></a></td>
	 			</tr>
	 			<br>
            	<tr>
					<td id="subMenuBoxNav"><a href="javascript:menu(38);"><u>Reset Second Password</u></a>
					</td>
				</tr>
				<tr>
			 	<td id="subMenuBoxNav"><a href="javascript:menu(33)"><u>Reset Stat Points</u></a></td>
			 </tr>
			  <tr>
			 	<td id="subMenuBoxNav"><a href="javascript:menu(34);"><u>Add Stat Points</u></a></td>
			 </tr>
			 			 	<td id="subMenuBoxNav"><a href="/member/logout.php"><u>Log Out</a></td>
			 </tr>
			 			 			 	<td id="subMenuBoxNav"><a href="javascript:menu(1002);"><u><font style="color: red;">Find Password</a></td>
			 </tr>
			 			 			 			 	<td id="subMenuBoxNav"><a href="javascript:menu(54);"><u><font style="color: red;">Recover Deleted Character</a></td>
			 </tr>
			 			 			 			 			 	<td id="subMenuBoxNav"><a href="javascript:menu(34);"><u>Distribution of Stat Points</a></td>
			 </tr>
			 			 			 			 			 			 	<!--<td id="subMenuBoxNav"><a href="javascript:menu(101);"><u><font style="color: orange;">Agent's Contact LiveChat</a></td>-->
			 </tr>