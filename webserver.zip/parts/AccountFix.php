<?
session_start();
error_reporting(E_ALL ^E_NOTICE ^E_WARNING);
header("Cache-control: private");
ob_start();
include ('settings.php');
if ($EnD[accfix]!=1)
{
?>
	

<?
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="main.css" rel="stylesheet" type="text/css" />


    
    

	<script type="text/javascript" src="App/user/js/jquery-1.2.6.min.js"></script>
	<script type="text/javascript" src="App/user/js/jquery-ui-personalized-1.5.2.packed.js"></script>
	<script type="text/javascript" src="App/user/js/sprinkle.js"></script>
	<script type="text/javascript" src="App/user/js/jquery.jgrowl.js"></script>
    
    <script type="text/javascript" src="App/user/js/main.js"></script>

    
    
    
    
    
    
    
   
</head>

<body>


<div class="context">
<div class="label"><img src="themes/images/arrow.png" width="5" height="8" /> ACCOUNT FIX</div>


<form name="myForm" method="post">


  <table width="100%" class="table">
    <tr>
      <td  width="37%" align="right"><l1>UserName:</l1></td>
      <td width="63%"><input name="Username" class="login_form" value="Username" type="text"/></td>
    </tr>
    <tr>
      <td align="right"><l1>Password :</l1></td>
      <td><input name="Password" class="login_form" value="Password" type="password"/></td>
    </tr>
  </table>

  <div class="button_container">
  
   
    <input type="submit" name="login" id="log_button" Value="Submit">
  
  
  </div>
  </form>
</div>

<?
if (isset($_POST[login]))
{







$user = $_POST[Username];
$pass = $_POST[Password];


			if ($user=="Username" || $pass=="Password")
			{

				
				echo'<script>$.jGrowl("<b><u>Login Failed</u></b><br>Username and Password must be fill up.<br> Fix Denied!", { 
					theme:  "error",
					speed:  "fast",
				});</script>';
					
			}
				else
			{
				
				$userid = strlen($user);
				$passid = strlen($pass);
	  			if (($userid < 4 || $userid > 19)||($passid < 4 || $passid > 19))
				{
				echo'<script>$.jGrowl("<b><u>Login Failed</u></b><br>Username and Password  is incorrect,<br> it must be 6 to 20.<br> Fix Denied!", { 
					theme:  "error",
					speed:  "fast",
				});</script>';
					
				}
				else
				{
					
				$userid = stripslashes($user);
				$pass = stripslashes($pass);
				if(preg_match('/[^a-zA-Z0-9_.]/i', $userid) || preg_match('/[^a-zA-Z0-9_.]/i', $pass))
				{
					
								echo'<script>$.jGrowl("<b><u>Login Failed</u></b><br>Username and Password not match.<br> Fix Denied!", { 
									theme:  "error",
									speed:  "fast",
								});</script>';
					
					
				}
				else
				{
					
					
					
					
$userid = stripslashes($user);	
$getpass = stripslashes($pass);		
$userpass = strtoupper(substr(md5($getpass),0,19));
		    		  
		    		  
$username_error = mssql_query("SELECT * FROM $dfsql[db4].dbo.UserInfo WHERE UserName = '".$userid."' ");
$username = mssql_fetch_array($username_error);
if($username)
{
	if ($username[UserPass]!=$userpass)
	{

	echo'<script>$.jGrowl("<b><u>Login Failed</u></b><br>Username and Password not match.<br> Fix Denied!", { 
					theme:  "error",
					speed:  "fast",
				});</script>';
		
	}
	else
	{
		

	    mssql_query("UPDATE $dfsql[db4].dbo.UserInfo SET UserLoginState = '0' WHERE Username = '$userid' ");
    mssql_query("UPDATE $dfsql[db4].dbo.UserInfo SET UserAvailable = '1' WHERE Username = '$userid' ");

	echo'<script>$.jGrowl("<b><u>Account Fix</u></b><br>Success....", { 
					theme:  "success",
					speed:  "fast",
				});</script>';	

	}
}
else
{
	echo'<script>$.jGrowl("<b><u>Login Failed</u></b><br>Username and Password not match.<br> Fix Denied!", { 
					theme:  "error",
					speed:  "fast",
				});</script>';	
			
}
				
					
					
					
					
					
				}
				
					
				}
				
				
				
				
			}










}

?>
 	



</body>
</html>
