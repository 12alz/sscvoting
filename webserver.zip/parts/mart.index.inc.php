<style type="text/css" media="all">
@import "Mart/Upimg/thickbox.css";
</style>
<script src="Mart/Upimg/jquery-latest.js" type="text/javascript"></script>
<script src="Mart/Upimg/thickbox.js" type="text/javascript"></script>
<?php $itemshop->productCategoryListView();?>
<form name="phpnetForm" method="post" action="<?php echo $itemshop->getQueryLinks(); ?>" onsubmit="javascript:return WebForm_OnSubmit();" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>


<?php
if($_config['AjaxMode']){
echo '<script src="/WebResource.axd/4a26f1ecae0a33a44b198d94629e3bfb.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/5460f4dfbd221bcd575ca1292a108cfa.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/42c740683f0709257bab43d28ea0de90.js" type="text/javascript"></script>'."\n",
	 '<script src="/ScriptResource.axd/b4b17b0bafa5744aeb3dfe229abd0952.js" type="text/javascript"></script>'."\n";
}
?>
<script type="text/javascript">
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
</script>

	<div id="ctl00_ContentPlaceHolder_main_UpdatePanel1">
<table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-bottom:none;">
  <tr>
  	<td height=22 style="border-bottom:none;"><strong>&nbsp;&nbsp;&nbsp;<span id="ctl00_ContentPlaceHolder_main_Result_Label" style="text-align: center;"><h2><?php ''; #$itemshop->productLabelView();?><h2></span></strong></td>
    <td style="border-bottom:none;"><span id="ctl00_ContentPlaceHolder_main_Result" style="color:Red;"></span></td>
  </tr>
</table>
  <table style="background: #000"  width="100%" border="0" cellpadding="0" cellspacing="0" align="center">

    

    <tr>
      <td  >
<table id="ctl00_ContentPlaceHolder_main_MartList" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
		<?php $itemshop->productSaleListView();  ?>
	</table>
	  <table width="100%" border="0" cellpadding="0" cellspacing="0">

          <tr>
            <td style="border-bottom:none !important;"></td>
          </tr>
        </table>
        <table width="100%" class="postdown">
            <tr><td align="center" height="30" style="border-bottom:none;">
			<?php $itemshop->productPaginationLinks();  ?>
            </td></tr>
		</table></td>
    </tr>
  </table>
        

</div>

<script type="text/javascript">
var Page_Validators =  new Array(document.getElementById("ctl00_ContentPlaceHolder_main_goto_text_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_goto_text_Check"));
</script>

<script type="text/javascript">
var ctl00_ContentPlaceHolder_main_goto_text_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_goto_text_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_goto_text_Check_Null");
ctl00_ContentPlaceHolder_main_goto_text_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_goto_text";
ctl00_ContentPlaceHolder_main_goto_text_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_goto_text_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_goto_text_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_goto_text_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_goto_text_Check");
ctl00_ContentPlaceHolder_main_goto_text_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_goto_text";
ctl00_ContentPlaceHolder_main_goto_text_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_goto_text_Check.validationexpression = "^[0-9]{1,3}$";
</script>


<script type="text/javascript">

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        Sys.Application.initialize();

document.getElementById('ctl00_ContentPlaceHolder_main_goto_text_Check_Null').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_goto_text_Check_Null'));
}

document.getElementById('ctl00_ContentPlaceHolder_main_goto_text_Check').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl00_ContentPlaceHolder_main_goto_text_Check'));
}
</script>
</form>
