<table width="100%" height="263" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  style="border-bottom:1px solid #ffffff;">
 <form name="phpnetForm" method="post" action="<?php echo 'member.php?do=editpwd'; ?>" onsubmit="javascript:return WebForm_OnSubmit();" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ctl00_ContentPlaceHolder_main_HyperLink2')" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
</div>

<script type="text/javascript">
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
</script>


<?php
if($_config['AjaxMode']){
echo '<script src="/WebResource.axd/4a26f1ecae0a33a44b198d94629e3bfb.js" type="text/javascript"></script>'."\n",
	 '<script src="/WebResource.axd/f553e4b43b481582b298229a49734eca.js" type="text/javascript"></script>'."\n",
	 '<script src="/WebResource.axd/8873f142ec7ff7723ba99c2d06688bce.js" type="text/javascript"></script>'."\n";
}
?>
<script type="text/javascript">
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
</script>

<img height=8><br>
    <table width="550" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="20%"  height="35"><img src="/images/point_b.gif" /> Account</td>
        <td  >
          <span id="ctl00_ContentPlaceHolder_main_UserID" tabindex="1" MaxLength="15"><?php echo $user->userID; ?></span></td>

        <td width="0"></td>
        <td >&nbsp;</td>
      </tr>
      <tr>
        <td height="35"  ><img src="/images/point_b.gif" /> OriginalPassword </td>
        <td  ><input name="UserPWD" type="password" maxlength="30" id="ctl00_ContentPlaceHolder_main_UserPWD" tabindex="2" class="form_pay" style="width:150px;" /></td>
        <td></td>
        <td  ><span id="ctl00_ContentPlaceHolder_main_UserPWD_Check_Null" style="color:Red;display:none;">This information is required</span>

          <span id="ctl00_ContentPlaceHolder_main_UserPWD_Check" style="color:Red;display:none;">This information is incorrect,Please re-enter</span></td>
      </tr>
      <tr>
        <td height="35"  ><img src="/images/point_b.gif" /> New Password </td>
        <td  ><input name="NewPWD" type="password" maxlength="30" id="ctl00_ContentPlaceHolder_main_NewPWD" tabindex="3" class="form_pay" /></td>
        <td></td>
        <td  ><span id="ctl00_ContentPlaceHolder_main_NewPWD_Check_Null" style="color:Red;display:none;">This information is required</span>

           &nbsp;Use 6 to 12 characters, no spaces, and don't use your Account<br />
          <span id="ctl00_ContentPlaceHolder_main_NewPWD_Check" style="color:Red;display:none;">This information is incorrect,Please re-enter</span></td>
      </tr>
      <tr>
        <td height="35"   ><img src="/images/point_b.gif" /> Re-type New Password</td>
        <td ><input name="Re_NewPWD" type="password" maxlength="30" id="ctl00_ContentPlaceHolder_main_Re_NewPWD" tabindex="4" class="form_pay" /></td>
        <td></td>

        <td ><span id="ctl00_ContentPlaceHolder_main_Re_NewPWD_Check_Null" style="color:Red;display:none;">This information is required</span>
          &nbsp;Re-type New Password<br />
          <span id="ctl00_ContentPlaceHolder_main_Re_NewPWD_Check" style="color:Red;display:none;">This information is incorrect,Please re-enter</span></td>
      </tr>
    </table>

    <table width="550" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>

        <td width="20%"><img src="/images/point_b.gif" /> Type the code shown </td>
        <td width="30%"><input name="ValidateCode" type="text" class="form_pay" id="ctl00_ContentPlaceHolder_main_ValidateCode" tabindex="5" value="<?php echo htmlentities($_POST["ValidateCode"], ENT_QUOTES, 'UTF-8');?>" maxlength="4" /></td>
        <td><img id="imgVerify" name="imgVerify" onclick="this.src='/VerifyCode.php?'+Math.random()+';'" alt="Try a different image" />
          <SCRIPT language=javascript>
					  phpnetForm.imgVerify.src="/VerifyCode.php?" + Math.random();
					  </script>
          <span id="ctl00_ContentPlaceHolder_main_Code_Check_Null" style="color:Red;display:none;">This information is required</span>
          <span id="ctl00_ContentPlaceHolder_main_ValidateCode_Check" style="color:Red;display:none;">Please try new code instead</span>

          <span id="ctl00_ContentPlaceHolder_main_Code_Check" style="color:Red;"><?php echo $user_auth->errs['CodeCheck'];?></span>
        </td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="2"><span id="ctl00_ContentPlaceHolder_main_Result" style="color:Red;"><?php echo $user_auth->errs['Result'];?></span></td>
      </tr>
      <tr>
        <td colspan="3" align="center"></td>

      </tr>
    </table>
    <table width="550" align="center">
      <tr>
        <td align="center">
               <input type="submit" name="HyperLink2" value="Submit" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;HyperLink2&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ContentPlaceHolder_main_HyperLink2" tabindex="6" class="btn2" style="font-size:12px;height:24px;width:50px;" />
                &nbsp;&nbsp;&nbsp;&nbsp;
              <input type="reset" name="reset" value="Reset" tabindex="7" class="btn2" style="font-size:12px;height:24px;width:50px;" />
          
              <br><img height=20 width=0>

        </td>
      </tr>
    </table>
  
<script type="text/javascript">
var Page_Validators =  new Array(document.getElementById("ctl00_ContentPlaceHolder_main_UserPWD_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_UserPWD_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_NewPWD_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_NewPWD_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_Re_NewPWD_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_Re_NewPWD_Check"), document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null"), document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check"));
</script>

<script type="text/javascript">
var ctl00_ContentPlaceHolder_main_UserPWD_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_UserPWD_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_UserPWD_Check_Null");
ctl00_ContentPlaceHolder_main_UserPWD_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_UserPWD";
ctl00_ContentPlaceHolder_main_UserPWD_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_UserPWD_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_UserPWD_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_UserPWD_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_UserPWD_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_UserPWD_Check");
ctl00_ContentPlaceHolder_main_UserPWD_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_UserPWD";
ctl00_ContentPlaceHolder_main_UserPWD_Check.errormessage = "This information is incorrect,Please re-enter";
ctl00_ContentPlaceHolder_main_UserPWD_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_UserPWD_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_UserPWD_Check.validationexpression = "^[0-9a-zA-Z_]{6,12}";
var ctl00_ContentPlaceHolder_main_NewPWD_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_NewPWD_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_NewPWD_Check_Null");
ctl00_ContentPlaceHolder_main_NewPWD_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_NewPWD";
ctl00_ContentPlaceHolder_main_NewPWD_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_NewPWD_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_NewPWD_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_NewPWD_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_NewPWD_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_NewPWD_Check");
ctl00_ContentPlaceHolder_main_NewPWD_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_NewPWD";
ctl00_ContentPlaceHolder_main_NewPWD_Check.errormessage = "This information is incorrect,Please re-enter";
ctl00_ContentPlaceHolder_main_NewPWD_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_NewPWD_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_NewPWD_Check.validationexpression = "^[0-9a-zA-Z_]{6,12}";
var ctl00_ContentPlaceHolder_main_Re_NewPWD_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_Re_NewPWD_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_Re_NewPWD_Check_Null");
ctl00_ContentPlaceHolder_main_Re_NewPWD_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_Re_NewPWD";
ctl00_ContentPlaceHolder_main_Re_NewPWD_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Re_NewPWD_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Re_NewPWD_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_Re_NewPWD_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_Re_NewPWD_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_Re_NewPWD_Check");
ctl00_ContentPlaceHolder_main_Re_NewPWD_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_Re_NewPWD";
ctl00_ContentPlaceHolder_main_Re_NewPWD_Check.errormessage = "This information is incorrect,Please re-enter";
ctl00_ContentPlaceHolder_main_Re_NewPWD_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Re_NewPWD_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Re_NewPWD_Check.validationexpression = "^[0-9a-zA-Z_]{6,12}";
var ctl00_ContentPlaceHolder_main_Code_Check_Null = document.all ? document.all["ctl00_ContentPlaceHolder_main_Code_Check_Null"] : document.getElementById("ctl00_ContentPlaceHolder_main_Code_Check_Null");
ctl00_ContentPlaceHolder_main_Code_Check_Null.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_Code_Check_Null.display = "Dynamic";
ctl00_ContentPlaceHolder_main_Code_Check_Null.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_Code_Check_Null.initialvalue = "";
var ctl00_ContentPlaceHolder_main_ValidateCode_Check = document.all ? document.all["ctl00_ContentPlaceHolder_main_ValidateCode_Check"] : document.getElementById("ctl00_ContentPlaceHolder_main_ValidateCode_Check");
ctl00_ContentPlaceHolder_main_ValidateCode_Check.controltovalidate = "ctl00_ContentPlaceHolder_main_ValidateCode";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.errormessage = "Please try new code instead";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.display = "Dynamic";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl00_ContentPlaceHolder_main_ValidateCode_Check.validationexpression = "^[0-9a-z]{4}$";
</script>


<script type="text/javascript">

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        WebForm_AutoFocus('HyperLink2');
</script>
</form>

    </td>
  </tr>
</table>