<style>
u{
text-decoration-color: #000000;
}
a{
	white-space:nowrap;
}
</style>

		<tr>
		<td><div align="left"><a href="javascript:menu(24);"><u><FONT color=#ffffff>Reset Password</font></u></a></td>
        <td><div align="right"><a href="/member/logout.php"><u><FONT color=#ffffff>Logout</u></a></td>
		</tr>

 		<tr>
		<td><div align="left"><a href="javascript:menu(40);"><u><FONT color=#ffffff>Download</font></u></a></td>
        <td><div align="right"><a href="javascript:menu(21);"><font color="ffffff"><u>Ranking</font></u></a></div></td>
		</tr>
		
        <tr>
			<td>
				<div align="left"><a href="javascript:menu(32);">
					<u><FONT color=#ffa500>Items Upgrade</font></u></a>
				</div>				
				<td><div align="right" ><a href="javascript:menu(955);" onclick="if(confirm('Claim Rewards?'))_unlockPages();return false;"><u><FONT style="color: #ffa500;">Reborn Reward</font></u></a></div></td>
			</td>
            <!--<td><div align="right"><a href="javascript:menu(35);"><u>Reset PK Status</font></u></a></div></td>-->
			<!--<td><div align="right"><a href="javascript:menu(955);"><u><FONT style="color: lime;font-weight: bold;">Cap Reward</font></font></u></a></div></td>-->
		</tr>

         <tr>
		<td><div align="left"><a href="javascript:menu(50);"><u><FONT color=ffa500>Item Mall</font></u></a></div></td>	
		<!--<td><div align="right"><a href="javascript:menu(50);"><u><FONT color=ffa500>Auto TopUp</font></u></a></div></td>	-->
		</tr>	
		
		<!--<tr>
			<td><div align="left"><a href="#" onclick="if(confirm('Unlock Pages?'))_unlockPages();return false;" style="color: #ffa500;"><u>Fix Reward</u></a></div></td>
			<td><div align="right"><a href="javascript:menu(955);" style="color: green;font-weight: bold;"><u>Daily Rewards</u></a></div></td>
			<td><div align="left"><a href="javascript:menu(955);" onclick="if(confirm('Unlock Pages?'))_unlockPages();return false;"><u><FONT style="color: #ffa500;">Claim</font></u></a></div></td>
		</tr>-->
		
	<table border="0" cellspacing="0" cellpadding="0">



<!-- <tr>
<td><div align="left"><a href="/show.php?articleid=120"><u><font color=ffffff>Change Gender</font></u></a></div></td>
</tr>

<tr>
	<td><div align="left"><a href="/show.php?articleid=124"><u><FONT color=#ffffff>Change School</font></u></a></div></td>
</tr> -->



<tr>
<td><div align="left"><a href="javascript:menu(31);"><u><FONT color=#ffa500>Character Reborn</font></u></a></div></td>
</tr>	

<tr>
<td><div align="left"><a href="javascript:menu(46);"><u><FONT color=#ffa500>Purchase VIP Reborn</u></a></div></td>
</tr>	

<tr>
<td><div align="left"><a href="javascript:menu(35);"><u><FONT color=#ffffff>Reset PK Status</font></u></a></div></td>
</tr>

<tr>
<td><div align="left"><a href="javascript:menu(33);"><u><FONT color=#ffffff>Reset Stat Points</font></u></a></div></td>
</tr>	

<tr>
<td><div align="left"><a href="javascript:menu(34);"><u><FONT color=#ffffff>Distribution of Stat Points</font></u></a></div></td>
</tr>


<tr>
<td><div align="left"><a href="javascript:menu(41);"><u><FONT color=#ffa500>Exchange GameGold to EPoints</font></u></a></div></td>
</tr>	

<tr>
<td><div align="left"><a href="javascript:menu(47);"><u><FONT color=#ffa500>Exchange EPoints to GameGold</u></a></div></td>
</tr>

<tr>
<td><div align="left"><a href="javascript:menu(48)"><u><FONT color=#ffa500>Exchange Reborn to EPoints</u></a></div></td>
</tr>

<!--<tr>
<td><div align="left"><a href="javascript:menu(777);"><u><FONT color=#ffa500>Point Ticket Exchange to Epoints</font></u></a></div></td>
</tr>-->	

<tr>
<td><div align="left"><a href="javascript:menu(37);"><u><FONT color=#ffffff>Game time exchange to Epoints</u></a></div></td>
</tr>

<tr>
<td><div align="left"><a href="javascript:menu(22);"><u><FONT color=#ffffff>Earn Epoints from Publicity</u></a></div></td>
</tr>

<tr>
<td><div align="left"><a href="javascript:menu(54);"><u><FONT color=#ffa500>Recover Deleted Character</u></a></div></td>
</tr>

<tr>
<td><div align="left"><a href="javascript:menu(38);"><u><FONT color=#ffffff>Reset Second Password</u></a></div></td>
</tr>

<tr>
	<td><div align="left"><a href="javascript:menu(65);"><FONT color=#ffffff><u>Epoints Got Records</u></FONT></a></div></td>
</tr>
<tr>
	<td><div align="left"><a href="javascript:menu(39);"><FONT color=#ffffff><u>Epoints Used Records</u></FONT></a></div></td>
</tr>

<tr>
<td><div align="left"><a href="javascript:menu(64);"><u><FONT color=#3F80AC>Agent's Contact LiveChat</u></a></div></td>
</tr>

<tr>
<td><div align="left"><a href="/"><u><FONT color=#ffffff>Go To HomePage</u></a></div></td>
</tr>



		</table>

		
