<?php
class ReferrerController extends UserController {

  function updateReferrerStatus($referrer) {
	  $this->referrer->updateReferrerInfo($referrer);
  }

  function checkReferrer($referrer,$character,$userInfo){
	  global $_config;
	  $referrer->userID = $userInfo->userID;
	  $result = $this->referrer->getReferrerStatus($referrer);
	  if($result){
		  if(($character->chaReborn+1) == $_config['PublicityRbRequest']){
		  $referrer->chaNum = $character->chaNum;
		  $referrer->chaRB =  $character->chaReborn+1;
		  $referrer->getPoints = $_config['PublicityAddPoint'];
		  $this->updateReferrerStatus($referrer);
		  $userInfo->userNum = $result->reFUserNum;
		  $userInfo->userPoint = $referrer->getPoints;
		  $this->user->add_Point($userInfo);
		  }
	  }
  }
  function referrerUserListView($user){
	 $this->referrer->referrerUserList($this->referrerVO,$user);
  }
  
  function referrerReportListView($user){
	 $this->referrer->referrerReportList($this->referrerVO,$user);
  }
}
?>