<?php
class ShopItemMapController extends UserController {

	  var $shopItemMapVO;
	  var $shopItemMap;
	  var $shopPurchaseVO;
	  var $shopPurchase;
	  var $user;
	  
	function ShopItemMapController(){
	  $this->shopItemMapVO = new ShopItemMap();
	  $this->shopItemMap = new ShopItemMapLogic;
      $this->member = new User();
	  $this->user = new UserLogic;
	  $this->shopPurchaseVO = new ShopPurchase();
	  $this->shopPurchase = new ShopPurchaseLogic;
	}
	function productCategoryListView(){
		$this->shopItemMap->productCategoryList();
	}
	function getProductLinksQuery(){
	  global $_config;
	  if(!isset($_GET['itemtype']) || (int)$_GET['itemtype'] > count($_config['ProductCategory']) || (int)$_GET['itemtype']==0){
	  $this->shopItemMapVO->category = 0;	
	  $this->itemOperator = ">";	
	  }else{
	  $this->shopItemMapVO->category = (int)$_GET['itemtype'];
	  $this->itemOperator = "=";
	  }		
	}
	function productSaleListView(){
	  $this->getProductLinksQuery();
	  $this->shopItemMap->getProductSaleList($this->shopItemMapVO,$this->itemOperator);
		
	}
	
	function getAllItemsFromProduct(){
		$data = array();
		$res = $this->shopItemMap->getAllItemsFromProduct();
		
		$data = array();
	 
		for($p=0;$p<$res->RecordCount();$p++){
			 
			$data[$res->fields['ItemMain'].'_'.$res->fields['ItemSub']] = $res->fields;
			$res->movenext();
		}
		return $data;
	}
	
	function productPaginationLinks(){
	 echo $this->shopItemMap->productPaginationLinks();   
	}
	/*Bingo Wheel 4*/
	function playBingo4(){
		global $_config;
		if($this->user->haslogin(true)){
			$this->member->userID = $_SESSION['auth_user'];
			$userInfo = $this->user->userAuth($this->member);
				if(!$this->user->check_UserOnline($userInfo)){
					echo '&id=0&msg=',USER_ONLINE_ERR_MSG;
				}elseif($userInfo->userPoint < $_config['BingoPay']){
					echo '&id=0&msg=',USER_POINT_ERR_MSG;
				}else{
					$bingoRand = mt_rand(1, 8);
					$pointReward = $_config['BingoPointsList']['PointsList'][$bingoRand-1];

					if($pointReward == NULL){
						echo '&id=0&msg=',POINT_BINGO_NOT_EXIST,'';
					}else{
						$userInfo->userPoint = $_config['BingoPay'];
						$this->user->charge_Point($userInfo);
						$userInfo->userPoint = $pointReward;
						$this->user->add_Point($userInfo);

						echo '&id=',$bingoRand,'&msg=',$pointReward,'EP'; 
					}

				}
		}else{
			$this->user->goto_link('event/dzp/',false);	
	  			echo '&id=-1&msg=Time out,please re-login';
		}
	}
	/*Bingo Wheel 1*/
	function playBingo(){
	global $_config;
	  if($this->user->haslogin(true)){
	  $this->member->userID = $_SESSION['auth_user'];
	  $userInfo = $this->user->userAuth($this->member);
		if($this->shopItemMap->checkProductAll()==0){
		  echo '&id=0&msg=',MART_NO_PRODUCT;
		}elseif($userInfo->userPoint < $_config['BingoPay']){
		  echo '&id=0&msg=',USER_POINT_ERR_MSG;
		}elseif(!$this->user->check_UserOnline($userInfo)){
		  echo '&id=0&msg=',USER_ONLINE_ERR_MSG;
		}else{
			$bingoRand = mt_rand(1, 8);
			$this->shopItemMapVO->productNum = $_config['BingoItemList']['ProductNumList'][$bingoRand-1];
			
			if($this->shopItemMap->checkBingoProductExists($this->shopItemMapVO)==false){
		  	echo '&id=0&msg=',MART_ITEM_NOT_EXISTS,'';
			}else
			{
				  $this->shopItemMap->getProductInfo($this->shopItemMapVO);
				  if($this->shopItemMapVO->itemStock < 2){
				  $this->shopItemMapVO->itemStock = 999999999;	
				  $this->shopItemMap->add_ItemStock($this->shopItemMapVO);
				  echo '&id=0&msg=',MART_ITEM_STOCK_ERR_MSG;
				  }else{
					  $this->shopPurchaseVO->purKey = $this->shop_PurKeyIdentity();
					  $this->shopPurchaseVO->userUID = $userInfo->userID;
					  $this->shopPurchaseVO->productNum = $this->shopItemMapVO->productNum;
					  $this->shopPurchaseVO->purPrice = $_config['BingoPay'];
					  $this->shopPurchaseVO->purFlag = 0;
					  $result = $this->shopPurchase->insertBingoItemPurchase($this->shopPurchaseVO);
					  if($result===true){
					  $this->shopItemMapVO->itemStock = 1;
					  $this->shopItemMap->update_ItemStock($this->shopItemMapVO);
					  $userInfo->userPoint = $this->shopPurchaseVO->purPrice;
					  $this->user->charge_Point($userInfo);
					  echo '&id=',$bingoRand,'&msg=',$this->shopItemMapVO->itemName;
					  }else{
					  echo '&id=',$bingoRand,'&msg=',$result;
					  }
					  
				  }
			}
		}
  
	  }else{
		$this->user->goto_link('event/dzp/',false);	
	  	echo '&id=-1&msg=Time out,please re-login';
	  }
	
	}
	/*Bingo Wheel 2*/
	function playBingo2(){
	global $_config;
	  if($this->user->haslogin(true)){
	  $this->member->userID = $_SESSION['auth_user'];
	  $userInfo = $this->user->userAuth($this->member);
		if($this->shopItemMap->checkProductAll()==0){
		  echo '&id=0&msg=',MART_NO_PRODUCT;
		}elseif($userInfo->userPoint < $_config['BingoPay']){
		  echo '&id=0&msg=',USER_POINT_ERR_MSG;
		}elseif(!$this->user->check_UserOnline($userInfo)){
		  echo '&id=0&msg=',USER_ONLINE_ERR_MSG;
		}else{
			$bingoRand = mt_rand(1, 8);
			$this->shopItemMapVO->productNum = $_config['BingoItemList2']['ProductNumList'][$bingoRand-1];
			
			if($this->shopItemMap->checkBingoProductExists($this->shopItemMapVO)==false){
		  	echo '&id=0&msg=',MART_ITEM_NOT_EXISTS,'';
			}else
			{
				  $this->shopItemMap->getProductInfo($this->shopItemMapVO);
				  if($this->shopItemMapVO->itemStock < 2){
				  $this->shopItemMapVO->itemStock = 999999999;	
				  $this->shopItemMap->add_ItemStock($this->shopItemMapVO);
				  echo '&id=0&msg=',MART_ITEM_STOCK_ERR_MSG;
				  }else{
					  $this->shopPurchaseVO->purKey = $this->shop_PurKeyIdentity();
					  $this->shopPurchaseVO->userUID = $userInfo->userID;
					  $this->shopPurchaseVO->productNum = $this->shopItemMapVO->productNum;
					  $this->shopPurchaseVO->purPrice = $_config['BingoPay'];
					  $this->shopPurchaseVO->purFlag = 0;
					  $result = $this->shopPurchase->insertBingoItemPurchase($this->shopPurchaseVO);
					  if($result===true){
					  $this->shopItemMapVO->itemStock = 1;
					  $this->shopItemMap->update_ItemStock($this->shopItemMapVO);
					  $userInfo->userPoint = $this->shopPurchaseVO->purPrice;
					  $this->user->charge_Point($userInfo);
					  echo '&id=',$bingoRand,'&msg=',$this->shopItemMapVO->itemName;
					  }else{
					  echo '&id=',$bingoRand,'&msg=',$result;
					  }
					  
				  }
			}
		}
  
	  }else{
		$this->user->goto_link('event/dzp/',false);	
	  	echo '&id=-1&msg=Time out,please re-login';
	  }
	
	}
	/*Bingo Wheel 3*/
	function playBingo3(){
	global $_config;
	  if($this->user->haslogin(true)){
	  $this->member->userID = $_SESSION['auth_user'];
	  $userInfo = $this->user->userAuth($this->member);
		if($this->shopItemMap->checkProductAll()==0){
		  echo '&id=0&msg=',MART_NO_PRODUCT;
		}elseif($userInfo->userPoint < $_config['BingoPay']){
		  echo '&id=0&msg=',USER_POINT_ERR_MSG;
		}elseif(!$this->user->check_UserOnline($userInfo)){
		  echo '&id=0&msg=',USER_ONLINE_ERR_MSG;
		}else{
			$bingoRand = mt_rand(1, 8);
			$this->shopItemMapVO->productNum = $_config['BingoItemList3']['ProductNumList'][$bingoRand-1];
			
			if($this->shopItemMap->checkBingoProductExists($this->shopItemMapVO)==false){
		  	echo '&id=0&msg=',MART_ITEM_NOT_EXISTS,'';
			}else
			{
				  $this->shopItemMap->getProductInfo($this->shopItemMapVO);
				  if($this->shopItemMapVO->itemStock < 2){
				  $this->shopItemMapVO->itemStock = 999999999;	
				  $this->shopItemMap->add_ItemStock($this->shopItemMapVO);
				  echo '&id=0&msg=',MART_ITEM_STOCK_ERR_MSG;
				  }else{
					  $this->shopPurchaseVO->purKey = $this->shop_PurKeyIdentity();
					  $this->shopPurchaseVO->userUID = $userInfo->userID;
					  $this->shopPurchaseVO->productNum = $this->shopItemMapVO->productNum;
					  $this->shopPurchaseVO->purPrice = $_config['BingoPay'];
					  $this->shopPurchaseVO->purFlag = 0;
					  $result = $this->shopPurchase->insertBingoItemPurchase($this->shopPurchaseVO);
					  if($result===true){
					  $this->shopItemMapVO->itemStock = 1;
					  $this->shopItemMap->update_ItemStock($this->shopItemMapVO);
					  $userInfo->userPoint = $this->shopPurchaseVO->purPrice;
					  $this->user->charge_Point($userInfo);
					  echo '&id=',$bingoRand,'&msg=',$this->shopItemMapVO->itemName;
					  }else{
					  echo '&id=',$bingoRand,'&msg=',$result;
					  }
					  
				  }
			}
		}
  
	  }else{
		$this->user->goto_link('event/dzp/',false);	
	  	echo '&id=-1&msg=Time out,please re-login';
	  }
	
	}
	//END BINGO
    function buyProduct(){
		if(isset($_POST["__EVENTARGUMENT"])){
		$itemArg = explode("$",$_POST["__EVENTARGUMENT"]);
			
				if($itemArg[0]=="Select"){
					if($this->user->haslogin(true)){
	  				$this->getProductLinksQuery();
					$product = $this->shopItemMap->productList($this->shopItemMapVO,$this->itemOperator);
					if(count($product)){
					$productID = $product[$itemArg[1]];
					$this->shopItemMapVO->itemName = $productID[3];
					$this->shopItemMapVO->productNum = $productID[7];
					$this->shopItemMapVO->itemStock = $productID[6];
					
					$this->member->userID = $_SESSION['auth_user'];
					$userInfo = $this->user->userAuth($this->member);
					
					$this->shopPurchaseVO->purKey = $this->shop_PurKeyIdentity();
					$this->shopPurchaseVO->userUID = $userInfo->userID;
					$this->shopPurchaseVO->productNum = $this->shopItemMapVO->productNum;
					$this->shopPurchaseVO->purPrice = $productID[4];
					$this->shopPurchaseVO->purFlag = 0;
					
					if($this->shopItemMapVO->itemStock < 2){
						
						$this->shopItemMapVO->itemStock = 999999999;	
						$this->shopItemMap->add_ItemStock($this->shopItemMapVO);
				    	
						echo '<script type="text/javascript">alert("',MART_ITEM_STOCK_ERR_MSG,'");window.self.location=\'',$this->getQueryLinks(),'\';</script>'; 
					}elseif(!$this->user->check_UserOnline($this->member)){
				    	echo '<script type="text/javascript">alert("',USER_ONLINE_ERR_MSG,'");window.self.location=\'',$this->getQueryLinks(),'\';</script>'; 
					}elseif($userInfo->userPoint < $this->shopPurchaseVO->purPrice){
				    	echo '<script type="text/javascript">alert("',USER_POINT_ERR_MSG,'");window.self.location=\'',$this->getQueryLinks(),'\';</script>'; 
					}else{
							
							
							$this->shopPurchase->insert_ItemPurchase($this->shopPurchaseVO);	
							$this->shopItemMapVO->itemStock = 1;
							$this->shopItemMap->update_ItemStock($this->shopItemMapVO);
							$userInfo->userPoint = $this->shopPurchaseVO->purPrice;
							$this->user->charge_Point($userInfo);
							
							echo '<script type="text/javascript">alert("',MART_ITEM_BUY_SUCCESS_MSG,'");window.self.location=\'',$this->getQueryLinks(),'\';</script>'; 
						
						
						}
					
					}else{
						jump_location('errorpage');
					}
					
					
					
					}else{
						$this->user->goto_link($this->getQueryLinks(),false);	
				   	    echo '<script type="text/javascript">alert("',MART_RE_LOGIN_MSG,'");window.self.location=\'member.php?do=login\';</script>'; 
					}
				}
		
		}
	}
		
	function getQueryLinks(){
		if(isset($_GET['itemtype'])){ 
		if((int)$_GET['page']!=NULL){ 
		$pageQuery = "&page=".(int)$_GET['page']; 
		} 
		$link = 'mart.php?itemtype='.(int)$_GET['itemtype'].$pageQuery; 
		}elseif((int)$_GET['page']!=NULL){ 
		$link = 'mart.php?itemtype='.(int)$_GET['itemtype'].'&page='.(int)$_GET['page']; 
		}else{ 
		$link = 'mart.php'; 
		}	
		return $link;	
	}
	
	function productLabelView(){
		$this->shopItemMap->productLabelView();
		
	}
	function shop_PurKeyIdentity(){
		global $_config;
		if($_config['ShopPurKeyIdentity']==true)	{
			return false;
		}else{
			return (int)$this->shopPurchase->get_PurKeyMax();
			//return (int)$this->shopPurchase->random_ShopPurKey(10000000, 99999999999);
		}
	}
	
}
?>