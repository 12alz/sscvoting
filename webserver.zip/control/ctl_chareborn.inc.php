<?php
class ChaRebornController extends CharacterController{



/*Purchase Reborn BUGGY and INCOMPLETE!*/
  function purchaseReborn(){
  	global $_config;

  	//declaration 
  	$this->characterVO->chaNum = (int)$_GET['cid'];
    $characterInfo = $this->get_CharacterInfo(); //call chaInfo instanc
    $checkTotalReborn = (int)$_POST['RebornNum'] + $characterInfo->chaReborn;
    $rebornType = array(0,$_config['RebornStandard']);
    //end of declaration

    $totalPurchaseResultVip = (int)$_config['PurchaseRebornVip'] * $_POST['RebornNum'];
    //$totalPurchaseResult = (int)$_config['PurchaseRebornStandard'] * $_POST['RebornNum'];

  	if(isset($_POST['HyperLink2'])){
  		if(!$this->isvalidCheckCode()){
  			$this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;

  		}elseif(!$this->character->isCharacterOnline($this->characterVO)){
  			$this->errs['Result'] = CHARACTER_ONLINE_ERR_MSG;
  		}elseif($characterInfo->chaReborn >= $_config['RebornLimit']){ //bug also
  			$this->errs['Result'] = REBORN_LIMIT_MSG;
  		}elseif($checkTotalReborn > $_config['RebornLimit']){
  			$this->errs['Result'] = PURCHASE_RB_LIMIT_EXCEEDED;
  		//}elseif($this->userInfo->userPoint < $totalPurchaseResult){
  			//$this->errs['Result'] = PURCHASE_RB_LESS_POINT_MSG;
  		}elseif($this->userInfo->userPoint < $totalPurchaseResultVip){
  			$this->errs['Result'] = PURCHASE_RB_LESS_POINT_MSG;
  		}else{
  			
		  			$totalGainedStats = (int)$_POST['RebornNum'] * 50;
		  			$totalRebornPurchased = (int)$_POST['RebornNum'];
		  			/*test stuff for logs*/
		  			$this->rebirthVO->rbNum = $characterInfo->chaReborn;
					$this->rebirthVO->userNum = $characterInfo->userNum;
					$this->rebirthVO->chaNum = $characterInfo->chaNum;
					$this->rebirthVO->chaLevel = $characterInfo->chaLevel;
					/*end*/

		  			$this->userInfo->userPoint = $totalPurchaseResultVip;
		  			$this->user->charge_Point($this->userInfo);
		  			$this->characterVO->chaStRemain = (int)$totalGainedStats;
		  			$this->characterVO->chaReborn = (int)$totalRebornPurchased;
		  			$this->rebirth->updatePurchaseReborn($characterInfo);
		  			//$this->rebirth->insertRebornPurchaseDetails($this->rebirthVO); //logs

		  			echo '<script type="text/javascript">alert("Congratulations! You have done purchasing VIP Reborn!.");window.self.location=\'index.php\';</script>'; 

	  		}
 		}
  	}
  

  function rebornDetail(){
  	global $_config;
	$this->characterVO->chaNum = (int)$_GET['cid'];
	$characterInfo = $this->get_CharacterInfo();
	if(isset($_POST["HyperLink2"])){
		switch ($_POST["RebornType"]){
			case "standard";
				$rebornType = array(0,$_config['RebornStandard']);
				$payType = $characterInfo->chaMoney;
				break;
			
			case "vip";
				$rebornType = array(1,$_config['RebornVip']);
				$payType = $this->userInfo->userPoint;
				break;
			
			default: 
				jump_location('errorpage'); 
				break;
		}
		$rebornRange = $this->rebirth->getRebornRange($characterInfo->chaReborn+1,$rebornType[1]);
		if($this->validateReborn($characterInfo,$payType,$rebornRange)){
				$this->rebirthVO->rbNum = $characterInfo->chaReborn;
				$this->rebirthVO->userNum = $characterInfo->userNum;
				$this->rebirthVO->chaNum = $characterInfo->chaNum;
				$this->rebirthVO->chaLevel = $characterInfo->chaLevel;
				$this->rebirth->updateRebornData($characterInfo);
				$rebornUpdateType = $this->rebirth->updateRebornType($rebornType,$this->rebirthVO,$characterInfo,$this->userInfo,$rebornRange['Pay']);	
				if($rebornUpdateType){
				$this->checkReferrer($this->referrerVO,$characterInfo,$this->userInfo);	
				echo '<script type="text/javascript">alert("Success, gained ',$characterInfo->chaStRemain,' stats");window.self.location=\'extend.php?do=webreborn_detail&cid=',$characterInfo->chaNum,'\';</script>'; 
				}
		}
		
	}
	if($_POST["__EVENTTARGET"]=="ctl00ContentPlaceHoldermainCustomersGridView"){
	   $rebornPageArg = explode("$", $_POST["__EVENTARGUMENT"]);
	   switch($rebornPageArg[0])
	   {
		   case "Select":
						$this->rebirthVO->rbNum = $rebornPageArg[1];
						$this->rebirthVO->userNum = $characterInfo->userNum;
						$this->rebirthVO->chaNum = $characterInfo->chaNum;
						$standardRebornResult = $this->rebirth->getRebornStandardDetail($this->rebirthVO);
						$upgradeRebornRange = $this->rebirth->getRebornRange($standardRebornResult->rbNum,$_config['RebornVip']);
						if($this->validateUpgradeReborn($upgradeRebornRange['Pay'])){
							$this->userInfo->userPoint = $upgradeRebornRange['Pay'];
							$this->rebirth->updateUpgradeReborn($this->rebirthVO,$this->userInfo);
							$characterInfo->chaStRemain = 25;
							$result = $this->rebirth->addCharacterStats($characterInfo);
							if($result){
							echo '<script type="text/javascript">alert("',REBORN_UPGRADE_SUCCESS_MSG,'");window.self.location=\'extend.php?do=webreborn_detail&cid=',$characterInfo->chaNum,'\';</script>'; 
							}
						
						}
						break;
		   
		   
	   }
	}
  
	  
  }
  function rebornListView($rebirth){
	return  $this->rebirth->getRebornList($rebirth);
  }
  function validateUpgradeReborn($pay){
	  		if(!$this->character->isCharacterOnline($this->characterVO)){
				$this->errs['Result'] = CHARACTER_ONLINE_ERR_MSG;
			}elseif($this->userInfo->userPoint < $pay){
				$this->errs['Result'] = USER_POINT_ERR_MSG;
			}else{
				return true;
			}
	  return false;
	  
  }
  function validateReborn($character,$payType,$rebornRange){
	global $_config;  
		if (!$this->isvalidCheckCode()){
			$this->errs['Result'] = CHECK_CODE_ERR_MSG;
		}elseif(!$this->character->isCharacterOnline($this->characterVO)){
			$this->errs['Result'] = CHARACTER_ONLINE_ERR_MSG;
		}elseif($character->chaReborn >= $_config['RebornLimit']){
			$this->errs['Result'] = REBORN_LIMIT_MSG;
		}elseif($character->chaLevel < $rebornRange['Lvl']){
			$this->errs['Result'] = $rebornRange['LvlErrMsg'];
		}elseif($payType < $rebornRange['Pay']){
			$this->errs['Result'] = USER_CHARACTER_POINT_MONEY_ERR_MSG;
		}else{
			return true;
		}
	  return false;
  }
   
  
}
?>