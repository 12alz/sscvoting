<?php 
include_once('../root.inc.php');
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Token Access</title>
 </head>
 <body>
 <h2>Token Access</h2>
 <?php echo $_config['ServerName']; ?> 
 <br>
 <?php echo $_config['Login']; ?>
 <br>
 <?php echo $_config['Password']; ?>
 </body>
 </html>