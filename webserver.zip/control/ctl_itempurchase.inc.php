<?php
class ShopPurchaseController {
  
	var $member;
	var $user;
	var $shopPurchaseVO;
	var $shopPurchase;
	var $shopItemMapVO;
	
  function ShopPurchaseController() {
	$this->member = new User();
	$this->user = new UserLogic;
	$this->shopPurchaseVO = new ShopPurchase();
	$this->shopPurchase = new ShopPurchaseLogic;
	$this->member->userID = $_SESSION['auth_user'];
	$this->userInfo = $this->user->userAuth($this->member);
  }

  
  function itemOrderList(){
	$this->shopItemMapVO = new ShopItemMap();
	$this->shopPurchaseVO->userUID = $this->userInfo->userID;
	$this->shopPurchase->itemOrderList($this->shopPurchaseVO,$this->shopItemMapVO);
  }

  function payOrderList(){
	$this->shopPurchaseVO->userUID = $this->userInfo->userID;
	$this->shopPurchase->payOrderList($this->shopPurchaseVO);
  }


}
?>