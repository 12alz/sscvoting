<?php
class NewsController {
	
  var $newsVO;
  var $newsCataVO;
  var $news;
  var $newsListPerPage;
  var $newsUpdateHits = true;
  var $pagination;
  
  function NewsController(){
    $this->newsVO = new News();
	$this->newsCataVO = new NewsCata;
	$this->news = new NewsLogic;
  }
  
  function launcherNews(){
	$this->news->launcherNews($this->newsVO);
  }

  function top12News(){
	$this->news->getTop12News($this->newsVO);
  }
  
  function showNews(){
	$this->newsCataVO->id = clean_variable($_GET['articleid']);
	$showNews = $this->news->getShowNews($this->newsCataVO->id); 
	$newsCata = $this->news->getNewsCategory($showNews->cataid); 
	if($this->newsUpdateHits){
	  $this->news->updateNewsHits($newsCata->id);
	}
	$newsResult = array($showNews->title,$showNews->nfrom,date('Y-m-d', strtotime($showNews->addtime)),$showNews->content,$newsCata->title,$newsCata->id);
	return $newsResult;
  }
  
  
  function showNewsList(){
	global $_config;
	$this->newsCataVO->title = clean_variable($_GET['classname']);
	$this->news->getNewsList($this->newsCataVO,$this->newsListPerPage = $_config['NewsListPerPage']);	
	  
  }
  function newsListPaging(){
	  
	return $this->news->links($_GET['classname']);
	  
  }
    
}
?>