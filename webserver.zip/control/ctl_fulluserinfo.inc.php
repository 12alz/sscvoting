<?php
class FullUserInfoController extends UserController {

  function findUserPassword(){
	  if(isset($_POST["HyperLink2"])){
	  $this->parseFindUserPasswordForm();
	  if(!$this->isvalidUserID($this->member->userID)){
		  $this->errs['Result'] = FIND_PASSWORD_ID_FORMAT_ERR_MSG;
	  }elseif(!$this->isvalidUserPWD($this->member->userPass2)){
		  $this->errs['Result'] = FIND_PASSWORD_SAFE_FORMAT_ERR_MSG;
	  }elseif(!$this->isvalidEmail($this->member->userEmail) || !$this->isvalidCheckCode() || !$this->user->checkUserPassEmail($this->member)){	  
  		  $this->errs['Result'] = FIND_PASSWORD_EMAIL_CODE_SAFE_ERR_MSG;
	  }else{
	  	  $this->user->getUserInfo($this->member);
	  	  $this->showPassword = true;
	  }
	  }
  }
  
  
  function parseFindUserPasswordForm(){
	  $this->member->userID = $_POST["UserID"];
	  $this->member->userPass2 = $_POST["SafePWD"];
	  $this->member->userEmail = $_POST["Email"];
  }
  
  
  
}
?>