<?php
require_once('lib/logic/Rank.php');

class RankController {
  var $character,$rankings;
  var $hideGM = false;
  var $chaClassName,$chaSchoolName,$rankLimit,$perPage;
  
  function RankController() {
    $this->character = new Character();
	$this->rankings = new RankLogic;
  }

  function top5Character(){
	global $_config;
	 $this->rankings->getTop5Character($this->character,$this->hideGM = $_config['HideGM']);
  }
  
  function clubWarWinner() {
	 global $_config;
	 $guild = new Guild();
	 $this->rankings->getClubWarWinner($guild,$this->guildRegion = $_config['GuildRegion']);
  }
  
  function rankList(){
	 global $_config;
	if(!isset($_POST["rankTopx"])){
	$rankSelectLimit = (empty($this->rankLimit)) ?  '100':$this->rankLimit;
	}else{
	$rankSelectLimit = (int)$_POST["rankTopx"];
	if($rankSelectLimit > 300)
	$rankSelectLimit = 300;
	}
	$this->rankings->rankList($this->character,$this->perPage,$this->hideGM = $_config['HideGM'],$rankSelectLimit,$_POST["rankChaSchool"],$this->chaClassName,$this->chaSchoolName,$this->chaExp,$this->ChaPkWin);
  }
  function rankPagination(){
	  
	 echo  $this->rankings->links();
	  
  }
  function donorankList(){
	 global $_config;
	$this->rankings->donorankList($this->character,$this->hideGM = $_config['HideGM'],$_POST["rankChaSchool"],$this->chaClassName,$this->chaSchoolName,$this->ChaPkWin);
  }
}
?>