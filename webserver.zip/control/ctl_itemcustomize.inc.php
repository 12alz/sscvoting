<?php
class ItemCustomizeController extends ReferrerController {
  
  var $characterVO;
  var $character;
  var $itemcustomizeVO;
  var $itemcustomize;
  
  var $rebirthVO;
  var $rebirth;
  
  var $referrerVO;
  var $referrer;
  
  function ItemCustomizeController() {
    $this->fullUserInfoVO = new FullUserInfo();
    $this->fullUserInfo = new FullUserInfoLogic;
	
	$this->member = new User();
	$this->user = new UserLogic;
	
    $this->characterVO = new Character();
	$this->character = new CharacterLogic;	
	
	$this->rebirthVO = new ChaRebornList();
	$this->rebirth = new ChaRebornLogic;	
	
	$this->referrerVO = new Referrer();
	$this->referrer = new ReferrerLogic();

	$this->itemcustomizeVO = new ItemCustomize();
	$this->itemcustomize = new ItemCustomizeLogic;
	
	$this->member->userID = $_SESSION['auth_user'];
	$this->userInfo = $this->user->userAuth($this->member);
	$this->characterVO->userNum = $this->userInfo->userNum;
	$this->characterVO->chaNum = (int)$_GET['cid'];
	$this->itemcustomizeVO->chaNum = $this->characterVO->chaNum;
  }
  
  function capReward(){
		echo 'sample';
		$action = $_POST["__EVENTTARGET"];
		
		if($action=="ctl00ContentPlaceHoldermainCustomersGridBack"){
			if(!$this->character->isCharacterOnline($this->characterVO)){		//character online
				echo '<script type="text/javascript">alert("',CHARACTER_ONLINE_ERR_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
			}else{
				
				
				
			}
		}
	  
  }
  
  function itemUpgrade(){
	$action = $_POST["__EVENTTARGET"];
	$itemArg = explode("$", $_POST["__EVENTARGUMENT"]);
	$itemNo = explode("-", $itemArg[1]);
	
	$this->parseItemUpgradeForm($itemNo);
	$characterInfo = $this->character->get_CharacterInfo($this->characterVO);
	if($action=="ctl00ContentPlaceHoldermainCustomersGridBack"){
		
		switch($itemArg[0]){
			case "Select":
					if(!$this->character->isCharacterOnline($this->characterVO)){		//character online
						echo '<script type="text/javascript">alert("',CHARACTER_ONLINE_ERR_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
					}else{// fix takeback item missing;
						//Get Item Storage Data and Decode
						$storageItem = $this->itemcustomize->decodeItemStorageData($this->itemcustomizeVO);
						$importItemBackLog = "| User:".$this->userInfo->userID." | ChaName:".$characterInfo->chaName." | ItemName:".$storageItem['Name']." | Attack:".$storageItem['Damage']." | Defense:".$storageItem['Defense'].""; 
						$this->itemcustomizeVO->chaInven = $storageItem['Data'];
						//Get Inventory Data and Decode and Set Header and Count All Items
						$characterItemData = $this->character->getCharacterItemData($this->characterVO);
						$this->characterVO->chaInven = $characterItemData['Data'];
						//Append Imported Item
						$newStorageItemData = $this->itemcustomize->getImportItemDataBack($this->itemcustomizeVO,$this->characterVO);
						if($this->character->checkInventorySlot($characterItemData['TotalItems'],$this->characterVO)){
							$this->characterVO->chaInven = $newStorageItemData;
							$this->character->characterUpdateInventory($this->characterVO);
							$this->itemcustomize->deleteItemStorage($this->itemcustomizeVO);
							//Get Updated Inventory Data
							$newChaInvenData = $this->character->get_CharacterInfo($this->characterVO);
							//Prepare and get The Updated New Data
							$itemsData = $this->character->prepareCharacterItemData($newChaInvenData);
							//Execute the Slot Constructor
							$this->character->characterItemSlotRebuild($itemsData,$newChaInvenData);
											
							write_log($importItemBackLog, 'ItemImportBack_Success');
							echo '<script type="text/javascript">alert("',ITEM_IMPORT_BACK_SUCCESS_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
						
						}else{
							write_log($importItemBackLog, 'ItemImportBack_Failed');
							echo '<script type="text/javascript">alert("',ITEM_IMPORT_BACK_NO_SLOT_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
						}
					}
					break;
			case "Upgrade":

					//Get Fresh Item Storafe Info
					$itemStorage = $this->itemcustomize->get_ItemStorageInfo($this->itemcustomizeVO);
					
					//Decode Item Storage Data
					$itemStorageDecode = $this->itemcustomize->decodeItemStorageData($this->itemcustomizeVO);
			
					$itemCustomizeResult = $this->itemcustomize->customizeItem($itemStorageDecode,(int)$_POST["subOptList".$itemStorage->gmID.""]);
					$this->itemcustomizeVO->chaInven = $itemCustomizeResult['Data'];
					
					$newItemData = $this->itemcustomize->changeItem2NonDrop($this->itemcustomizeVO);
					
					$addonInfo = $itemCustomizeResult['AddonType'];
					$rate = $this->itemcustomize->addon_GradeRate($addonInfo,$itemCustomizeResult['Result']);
					$randRate = mt_rand(1, 100);
					
					if(!$this->character->isCharacterOnline($this->characterVO)){					
						echo '<script type="text/javascript">alert("',CHARACTER_ONLINE_ERR_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
					}elseif($this->userInfo->userPoint < $addonInfo['Pay']){
						echo '<script type="text/javascript">alert("',ITEM_UPGRADE_USER_POINT_ERR_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
					}elseif($itemCustomizeResult['CurrentValue'] >= $addonInfo['MaxGrade']){
						echo '<script type="text/javascript">alert("Your ('.$itemStorage->itemName.') is at max '.$addonInfo['AddonName'].' level");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
					}elseif(strlen($newItemData)!=160){
						echo '<script type="text/javascript">alert("',ITEM_ADDON_NO_SLOT_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
					}else{
						  if($itemCustomizeResult['CurrentValue'] < 0){
								if($itemCustomizeResult['Result']==0){
								$itemCustomizeResult['Result'] = '+'.(0);
								}
								$successMsg = $itemCustomizeResult['CurrentValue'].' '.$addonInfo['AddonName'].' is now '.$itemCustomizeResult['Result'];
								$failedMsg = $itemCustomizeResult['CurrentValue'].' '.$addonInfo['AddonName'].' is now '.$itemCustomizeResult['CurrentValue'];
						  }else{
								if($itemCustomizeResult['CurrentValue']==NULL){
								$itemCustomizeResult['CurrentValue'] = 0;
								}
								$successMsg = '+'.$itemCustomizeResult['CurrentValue'].' '.$addonInfo['AddonName'].' is now +'.$itemCustomizeResult['Result'];
								$failedMsg = $itemCustomizeResult['CurrentValue'].' '.$addonInfo['AddonName'].' is now '.$itemCustomizeResult['CurrentValue'];
						  }
						  $this->parseItemUpgradeInfo($itemStorageDecode);
						  $this->itemcustomizeVO->gmID = $itemStorage->gmID;
						  $this->itemcustomizeVO->chaNum = $itemStorage->chaNum;
						  $this->itemcustomizeVO->point = $itemCustomizeResult['Result'];
						  $this->itemcustomizeVO->chaInven = $newItemData;
						  $this->userInfo->userPoint = $addonInfo['Pay'];
						  $this->user->charge_Point($this->userInfo);
						 
						  $itemUpLogEntryline = "| User: ".$this->userInfo->userID." | ChaName:".$characterInfo->chaName." | ItemName:".$itemStorage->itemName." | ".$addonInfo['AddonName']." Value:".$itemCustomizeResult['CurrentValue']." | Result:"; 

							if($randRate <= $rate['Rate']){
								$this->itemcustomize->updateItemUpgradeInfo($this->itemcustomizeVO);
								write_log($itemUpLogEntryline.$itemCustomizeResult['Result'], 'ItemUpgrade_Success');
								echo '<script type="text/javascript">alert("Your ('.$itemStorage->itemName.') '.$successMsg,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
							}else{
								write_log($itemUpLogEntryline.$itemCustomizeResult['CurrentValue'], 'ItemUpgrade_Failed');
								echo '<script type="text/javascript">alert("Failed, your ('.$itemStorage->itemName.') '.$failedMsg.'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
							}
						
					}
					break;	
		}
	  
	}//End Event Target
	//Import Items to web storage
	if($action=="ctl00ContentPlaceHoldermainCustomersGridView"){
		
	global $_config;
		if($itemArg[0]=="ImportWB"){
			$this->itemcustomizeVO->chaNum = $characterInfo->chaNum;
			if($this->itemcustomize->getTotalItemStorage($this->itemcustomizeVO) == $_config['WebWarehouseMaxStorage']){
				echo '<script type="text/javascript">alert("',ITEM_IMPORT_FULL_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
			}elseif(!$this->user->check_UserOnline($this->member)){ //fix web storage import items to duplicate.
				echo '<script type="text/javascript">alert("',CHARACTER_ONLINE_ERR_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
			}else{
				
				$itemImportData = $this->character->importItemStorage($characterInfo,$itemArg);	
				if(empty($itemImportData['Decode']['Data'])){
					jump_location('errorpage');
				}else{
					$this->characterVO->chaInven = $itemImportData['NewData'];
					
					$this->character->characterUpdateInventory($this->characterVO);
					$this->parseItemImportData($itemImportData['Decode']);
					//If the Data is inserted
				if($this->itemcustomize->insertItemStorage($this->itemcustomizeVO)){
					echo '<script type="text/javascript">alert("',ITEM_IMPORT_SUCCESS_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
				}else{
					echo '<script type="text/javascript">alert("',ITEM_IMPORT_FAILED_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
				}
				}
			}
		}
		
	}//End import Back
  
  }
  function itemStorageListView(){
	  $this->itemcustomize->itemStorageList($this->itemcustomizeVO);
  }
  function parseItemUpgradeInfo($itemDecode){
		$this->itemcustomizeVO->attackUpgrade = $itemDecode['Damage'];
		$this->itemcustomizeVO->defenceUpgrade = $itemDecode['Defense'];
		$this->itemcustomizeVO->gfInfo = $itemDecode['Rv1']."||".$itemDecode['Rv2']."||".$itemDecode['Rv3']."||".$itemDecode['Rv4']."";	
		$this->itemcustomizeVO->editBol = true;
		$this->itemcustomizeVO->addBol = true;
  }
  function parseItemImportData($itemDecode){
	  	$itemAddonNames = $this->itemcustomize->getitemAddonValNames($itemDecode);
	  	$itemAddonValue = $this->itemcustomize->getitemAddonValNames($itemDecode,true);
		$this->itemcustomizeVO->mainID = $itemDecode['Main'];
		$this->itemcustomizeVO->subID = $itemDecode['Sub'];
		$this->itemcustomizeVO->itemName = $itemDecode['Name'];
		$this->itemcustomizeVO->gmType = $itemAddonNames;
		$this->itemcustomizeVO->gfInfo = $itemDecode['Rv1'].$itemDecode['Rv2'].$itemDecode['Rv3'].$itemDecode['Rv4'];
		$this->itemcustomizeVO->point = $itemAddonValue;
		$this->itemcustomizeVO->chaInven = $itemDecode['Data'];
  }
  function parseItemUpgradeForm($itemNo){
		$this->itemcustomizeVO->mainID = (int)$itemNo[0];
		$this->itemcustomizeVO->subID = (int)$itemNo[1];
		$this->itemcustomizeVO->gmID = (int)$itemNo[2];
  }
  function storageItemsView(){
	  	return $this->character->storageItemsView($this->characterVO);
  }
  
  //added by otep
  
	function getItemStorageListCha($cha){
		return $this->itemcustomize->getItemStorageListCha($cha->itemcustomizeVO);
	}
	
	function fusionAddOn($items,$option,$value){
		return $this->itemcustomize->fusionAddOn($items,$option,$value);
	}
	
	function generateReward(){
		global $_config;
		$data = array();
		// $Rewards = $_config['rewards'];
		$rewardsRB_LVL = $_config['rewardsRB_LVL'];
		
		//check rebirth and level first;
		
		$char = $this->character->checkCharacter($this->characterVO);
		$getLogReward = $this->character->getLogReward($this->characterVO);
	
		$currCharRB = $char->chaReborn;
		$currCharLVL = $char->chaLevel;
		// consoleLOGS($randomReward);
		
		foreach($rewardsRB_LVL as $key => $value){
			
			$claim = false;
			
			if($currCharRB >= $value['rb'] || $currCharLVL >= $value['lvl']) $claim = true ;
			
			foreach($value['reward'] as $k => $v){
				if($v['type'] == 'materials'){
					$itemDecode = $this->itemcustomize->item_decode2($value['reward'][$k]['data']);
					$value['reward'][$k]['data'] = $itemDecode;
				}elseif($v['type'] == 'gold'){
					$value['reward'][$k]['data']['Name'] = 'Gold';
				}elseif($v['type'] == 'ep'){
					$value['reward'][$k]['data']['Name'] = 'E-Points';
				}elseif($v['type'] == 'box'){
					$msid = explode('_',$v['id']);
					$itemName = strval(trim($this->itemcustomize->getItemString($msid[0],$msid[1])));
					$value['reward'][$k]['data']['Name'] =$itemName;
				}
				
			}
			
			$data[] = array(
				'rewardid' => $key,
				'reqRB' => $value['rb'],
				'reqLvl' => $value['lvl'],
				'rewards' => $value['reward'],
				'claim' => isset($getLogReward[$key]) ? true : false,
			);
		}
		// consoleLOGS($data);
		return $data;
	}
	
	public function cliamReward(){
		global $_config;
		if($_POST["__EVENTTARGET3"] == 'ctl00ContentPlaceHoldermainClientReward'){
			$characterInfo = $this->character->get_CharacterInfo($this->characterVO);
			if(!$this->user->check_UserOnline($this->member)){ //fix web storage import items to duplicate.
				echo '<script type="text/javascript">alert("',CHARACTER_ONLINE_ERR_MSG,'");window.self.location=\'extend.php?do=cap_reward\';</script>'; 
			}else{
				// $characterInfo = $this->character->get_CharacterInfo($this->characterVO);
				$param = explode('$',$_POST["__EVENTARGUMENT4"]);
				$param1 = $param[0];
				$param2 = $param[1];
				// consoleLOGS($this->characterVO);
				if($param1 == 'RewardWB'){
					$param2 = clean_variable(trim($param2));
					if(is_numeric($param2)){
						
						$Reward = $_config['rewardsRB_LVL'];
						
						if(isset($Reward[$param2])){
							$Reward = $Reward[$param2];
							$requiredRB = (int)$Reward['rb'];
							$requiredLVL = (int)$Reward['lvl'];
							$reward = $Reward['reward'];
							$decodedData = array();
							$cnt = 0;
							$getArrayItem = array();
							$goldReward = 0;
							$EPReweard = 0;
							
							$chaLevel = (int)$characterInfo->chaLevel;
							$chaReborn = (int)$characterInfo->chaReborn;
							$chaMoney = (int)$characterInfo->chaMoney;
							$userPoint = (int)$this->userInfo->userPoint;
							$arrayType = array();
							
							$getCapReborn = $this->character->getCapReborn($this->characterVO,$param2);
							if($chaLevel < $requiredLVL || $chaReborn < $requiredRB){
								echo '<script type="text/javascript">alert("Insufficient Reborn or Level");window.self.location=\'extend.php?do=cap_reward_get&cid='.$this->characterVO->chaNum.'\';</script>'; 
								exit();
							}if($getCapReborn > 0){
								echo '<script type="text/javascript">alert("Reward Already Claim");window.self.location=\'extend.php?do=cap_reward_get&cid='.$this->characterVO->chaNum.'\';</script>'; 
								exit();
							}else{
								
								//get character item in inventory
								$characterItemData = $this->character->getCharacterItemData($this->characterVO);
								// $characterInfo = $this->character->get_CharacterInfo($this->characterVO);
								//extracted decoded items in inventory
								$getArrayItem = $this->itemcustomize->item_view2($characterInfo->chaInven);
								
								//item header
								$itemHeaders = $this->character->getHeaderItem($characterItemData['Data']);
								// $currentInvenItem = $this->character->getCurrentInvenItemWOheader($this->characterVO);
								$newItemArray = array();
								$isBox = false;
								foreach($reward as $key => $value){
									
									if($value['type'] == 'materials'){
										$itemPileSet = $this->itemcustomize->addItemPileNum($value['data'],$value['pcs']);
										$itemDecoded = $this->itemcustomize->item_decode2($itemPileSet);
										// consoleLOGS($itemDecoded);
										$newItem = $this->itemcustomize->changeItem2NonDrop2($itemDecoded);
										$itemDecoded = $this->itemcustomize->item_decode2($newItem);
										
										$newItemArray[] =  $itemDecoded;
									}elseif($value['type'] == 'gold'){
										$characterInfo->chaMoney = $chaMoney + $value['pcs'];
									}elseif($value['type'] == 'ep'){
										$this->userInfo->userPoint = $userPoint + $value['pcs'];
									}elseif($value['type'] == 'box'){
										$newItemArray[] = $value['pNum'];
										$isBox = true;
									}
									
									if(! in_array($value['type'], $arrayType)){
										$arrayType[] = $value['type'];
									}
									
									$cnt++;
								}
								//item merge the new and old
								// consoleLOGS($getArrayItem);
								if(count($newItemArray) > 0){
									
									if(! $isBox ){
										if(count($getArrayItem) > 0){
											$combineNewOldItem = array_merge($newItemArray,$getArrayItem);
										}else{
											$combineNewOldItem = $newItemArray;
										}
										
										// consoleLOGS($combineNewOldItem);
										//count combine item
										$cntItems = count($combineNewOldItem);
										$newDT = array();
										$sample = array();
										foreach($combineNewOldItem as $key => $value){
											
											if(isset($value['Data'])){
												$dt = $this->itemcustomize->recodeItemz($value['Data'],$key);
												$newDT[] = $dt;
											}
											// $sample[] = $this->itemcustomize->item_decode($dt);
										}
									}
									
									if(! $isBox){
										if($this->character->checkInventorySlot($cntItems,$this->characterVO) ){
											$this->characterVO->chaInven = $this->itemcustomize->headerItems($cntItems,$itemHeaders) . implode('',$newDT);
											// consoleLOGS($this->characterVO->chaInven);
											$this->character->CharUpdateInventory($this->characterVO);
										
										}else{
											echo '<script type="text/javascript">alert("',ITEM_IMPORT_BACK_NO_SLOT_MSG,'");window.self.location=\'extend.php?do=cap_reward_get&cid='.$this->characterVO->chaNum.'\';</script>'; 
										}
									}else{
										//box reward update here...
										// echo '<pre>';var_dump($newItemArray);exit();
										$this->character->insertReward($this->characterVO,$newItemArray);
									}
									
										
									if(in_array('gold',$arrayType) || in_array('ep',$arrayType)){
										//update database
										$this->character->updateGoldEp($characterInfo,$this->userInfo,$arrayType);
									}
										
									$data = array(
										'rb'=>$chaReborn,
										'lvl'=>$chaLevel,
										'date' => date('Y-m-d H:i:s'),
										'indexReward' => $param2
									);
										
									$text = $isBox ? 'Bank' : 'Inventory';
									$res = $this->character->rewardUpdateSuccess($this->characterVO,$data);
									if($res){
										
										echo '<script type="text/javascript">alert("Reward has been Claim! Check your '.$text.'");window.self.location=\'extend.php?do=cap_reward_get&cid='.$this->characterVO->chaNum.'\';</script>';
									}else{
										echo '<script type="text/javascript">alert("Reward has been Claim! Check your '.$text.'");window.self.location=\'extend.php?do=cap_reward_get&cid='.$this->characterVO->chaNum.'\';</script>';
									}
										 
									
									
									
								}
							}
						}else{
							jump_location('errorpage');
						}
					}else{
						jump_location('errorpage');
					}
				}else{
					jump_location('errorpage');
				}
			}
			
			
		}else{
			jump_location('errorpage');
		}
		
	}
}







?>