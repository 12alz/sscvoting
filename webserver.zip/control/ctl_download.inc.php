<?php
require_once('lib/logic/Download.php');
class DownloadController {
	
  var $download;
  var $downloadVO;
  
  function DownloadController() {
    $this->downloadVO = new Download();
	$this->download = new DownloadLogic;
  }
  
  function showClientList(){
	  $this->downloadVO->explain = 0;
	  $this->download->downloadList($this->downloadVO);
	  
	  
  }
  
  function showPatchList(){
	  $this->downloadVO->explain = 1;
	  $this->download->downloadList($this->downloadVO);
	  
  }
  
}
?>