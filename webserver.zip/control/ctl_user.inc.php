<?php
class UserController {
	
  var $member; #$person is used by the HTML page
  var $errs;
  var $expressionCheck;
  var $haslogin;
  var $user;
  var $referrerVO;
  var $referrer;
  var $fullUserInfoVO;
  var $fullUserInfo;
  var $voteVO;
  var $vote;
  
  function UserController() {
    $this->fullUserInfoVO = new FullUserInfo();
    $this->fullUserInfo = new FullUserInfoLogic;
	
	$this->member = new User();
	$this->user = new UserLogic;
	
	$this->referrerVO = new Referrer();
	$this->referrer = new ReferrerLogic;
	
	$this->voteVO = new Vote();
	$this->vote = new VoteLogic;

	$this->errs = array();
	$this->haslogin = $this->user->haslogin(true);
	
	$this->isMaintenance();
  }
  
  
  function checkBtnUserID(){
	 $this->parseBtnUserIDForm();
	if(strlen($this->member->userID) < 4){
		echo '<font color=#ff0000>',REGISTER_ID_LESS_MSG,'</font>';
	}elseif(!$this->isvalidUserID($this->member->userID)){
		echo '<font color=#ff0000>',REGISTER_ID_FORMAT_ERR_MSG,'</font>';
	}elseif(!$this->fullUserInfo->check_UserID($this->fullUserInfoVO)){
		echo '<font color=#ff0000>',REGISTER_ID_EXIST_MSG,'</font>';
	}else{
		echo '<font color=Green>',REGISTER_ID_OK_MSG,'</font>';
	}	  
  }
  function editUserPassword(){
  if($this->haslogin){
	  if(isset($_POST["HyperLink2"])){
	  	$this->parseEditPasswordForm();
		$this->getUserInfo();
		$this->fullUserInfoVO->userID = $this->member->userID;
	    if(!$this->isvalidUserPWD($this->fullUserInfoVO->userPass) || !$this->fullUserInfo->checkUserPassword($this->fullUserInfoVO)){
			$this->errs['Result'] =  '<font color=#ff0000>'.RESET_PASSWORD_FAILED_MSG.'</font>';
		}elseif(!$this->isvalidUserPWD($_POST["NewPWD"]) || !$this->isvalidUserPWD($_POST["Re_NewPWD"]) || clean_variable($_POST["NewPWD"])!=clean_variable($_POST["Re_NewPWD"])){
			$this->errs['Result'] =  '<font color=#ff0000>'.RESET_PASSWORD_VERIFY_MSG.'</font>';
		}elseif(!$this->isvalidCheckCode()){
			$this->errs['CodeCheck'] = '<font color=#ff0000>'.CHECK_CODE_ERR_MSG.'</font>';
		}else{
			$this->fullUserInfoVO->userPass = $_POST["NewPWD"];
			$this->member->userPass = $this->fullUserInfoVO->userPass;
			$this->fullUserInfo->updateUserPass($this->fullUserInfoVO);
			$this->user->updateUserPass($this->member);
			$_SESSION['auth_pass'] = md5_encrypt(clean_variable($_POST["NewPWD"]));
			echo '<script type="text/javascript">alert("',RESET_PASSWORD_SUCCESS_MSG,'");window.self.location=\'index.php\';</script>'; 
		}
	  }
  }else{
		$this->resume_link(clean_variable(trim(strtolower($_GET['do']))));	
		jump_location('member.php?do=login'); 	
		}
  }
  function resume_link($link){
	  $this->user->goto_link($link);
  }
  function iLogin(){
    if ($_POST["__EVENTVALIDATION"] == 'iLogin') {
       $this->parseiLoginForm();
	   $this->loginType = "ilogin";
       if($this->validateLoginForm($this->isvalidCheckCode2())){
		 if($this->user->userLogin($this->member)==false){
		 echo '<script type="text/javascript">alert("',ILOGIN_ID_PWD_FAILED_MSG,'");window.self.location=\'ilogin.php\';</script>'; 
		/* }elseif($this->user->checkUserBlock($this->member)==true){ //check if user is blocked TODO
		 echo '<script type="text/javascript">alert("',ILOGIN_USER_BANNED_MSG,'");window.self.location=\'ilogin.php\';</script>'; */
		 }else{
		 echo '<script type="text/javascript">;window.top.location=\'../extend.php?do=webreborn\';</script>';
		 }
	   }
    }
  }
  function login(){
	  if(isset($_POST["HyperLink2"])){
	   $this->parseLoginForm(); 
	   $this->loginType = "login";
	   if($this->validateLoginForm($this->isvalidCheckCode())){
	   if($this->user->userLogin($this->member)==false){
	   $this->errs['Result'] = LOGIN_ID_PWD_FAILED_MSG; 
	   }else{
			  if($_SESSION['goto_link']==null){
			  jump_location('extend.php?do=webreborn');
			  }else{
			  jump_location($_SESSION['goto_link']);
			  unset($_SESSION['goto_link']);
			  }
	   }
	   }
	}
  }
  function register(){
  $this->isRegisterOpen(); 
  $this->user->checkMaxAccount();
  if(isset($_POST["HyperLink2"])){
	    $this->parseRegistrationForm();	
		if(strlen($this->member->userID) < 4){
		$this->errs['UserID'] = '<font color=#ff0000>'.REGISTER_ID_LESS_MSG.'</font>';
		}elseif(!$this->isvalidUserID($this->member->userID)){
		$this->errs['UserID'] = '<font color=#ff0000>'.REGISTER_ID_FORMAT_ERR_MSG.'</font>';
		}elseif(!$this->isvalidUserPWD($this->member->userPass) || !$this->isvalidUserPWD($_POST["Re_UserPWD"])){
		$this->errs['UserPWD'] = '<font color=#ff0000>'.REGISTER_PWD_FORMAT_ERR_MSG.'</font>';
		}elseif(clean_variable($this->member->userPass)!=clean_variable($_POST["Re_UserPWD"])){
		$this->errs['ReUserPWD'] = '<font color=#ff0000>'.REGISTER_RE_PWD_SAFE_ERR_MSG.'</font>';
		}elseif(!$this->isvalidUserPWD($this->member->userPass2) || !$this->isvalidUserPWD($_POST["Re_SafePWD"])){
		$this->errs['SafePWD'] = '<font color=#ff0000>'.REGISTER_2ND_PWD_FORMAT_ERR_MSG.'</font>';
		}elseif(clean_variable($this->member->userPass2)!=clean_variable($_POST["Re_SafePWD"])){
		$this->errs['ReSafePWD'] = '<font color=#ff0000>'.REGISTER_RE_PWD_SAFE_ERR_MSG.'</font>';
		}elseif(!$this->isvalidEmail($this->member->userEmail)){
		$this->errs['Email'] = '<font color=#ff0000>'.REGISTER_EMAIL_FORMAT_ERR_MSG.'</font>';
		}elseif(!$this->fullUserInfo->check_UserID($this->fullUserInfoVO)){
		$this->errs['Result'] = REGISTER_ID_EXIST_MSG;
		}elseif(!$this->fullUserInfo->checkEmail($this->fullUserInfoVO)){
		$this->errs['Email'] = '<font color=#ff0000>'.REGISTER_EMAIL_EXIST_MSG.'</font>';
		}elseif(!$this->isvalidCheckCode()){
		$this->errs['CodeCheck'] = '<font color=#ff0000>'.REGISTER_CHECK_CODE_ERR_MSG.'</font>';
		}else
		{
				
			if(isset($this->member->tj)){
				$getReferrerResult = $this->user->getReferrerInfo($this->member);
				//Insert Referrer Info
				if($getReferrerResult){
	   			$this->referrerVO->userID = clean_variable($_POST["UserID"]);
	  			$this->referrerVO->getPoints = 0;
	   			$this->referrerVO->reFUserNum = $getReferrerResult->userNum;
				$this->referrer->insertReferrerInfo($this->referrerVO,$getReferrerResult);
				}
				unset($getReferrerResult);
			}
				
			$this->parseRegistrationForm();				
			//Insert UserInfo
			if($this->user->insertUserInfo($this->member)){
						
			//Insert FullUserInfo
			$this->fullUserInfo->insertFullUserInfo($this->fullUserInfoVO);

			//Insert Vote Info
			$this->voteVO->userID = $this->member->userID;
			$this->vote->insertVoteInfo($this->voteVO);
			
			if($this->haslogin){
			  unset($_SESSION['auth_user']);
			  unset($_SESSION['auth_pass']);
			}
			$_SESSION['auth_user'] = clean_variable($_POST["UserID"]);
			$_SESSION['auth_pass'] = md5_encrypt(clean_variable($_POST["UserPWD"]));
			echo '<script type="text/javascript">alert("',REGISTER_SUCCESS_MSG,'");window.self.location=\'extend.php?do=webreborn\';</script>'; 
			}
			
		}
	  
  }
	  
  }
  function logout(){
	  $this->user->userLogout();
  }
  function parseiLoginForm(){
	 $this->member->userID = "txtLocalID";
	 $this->member->userPass = "txtPassword";
	 $this->member->userBlock = 1;
  }
  function parseLoginForm(){
	 $this->member->userID = "UserID";
	 $this->member->userPass = "UserPWD";
  }
  function parseEditPasswordForm(){
	 $this->fullUserInfoVO->userPass = $_POST["UserPWD"];
  }
  function parseRegistrationForm(){
	global $_config;
	$this->member->userName = $_POST["UserID"];
	$this->member->userID = $this->member->userName;
	$this->member->userPass = $_POST["UserPWD"];
	$this->member->userPass2= $_POST["SafePWD"];
	$this->member->userEmail = stripslashes($_POST["Email"]);
	$this->member->userPoint = $_config['RegisterAddPoint'];
	$this->member->tj = clean_variable($_GET['uid']);
	$this->fullUserInfoVO->userName = $this->member->userID; 
	$this->fullUserInfoVO->userID = $this->member->userID;
	$this->fullUserInfoVO->userPass = $this->member->userPass;
	$this->fullUserInfoVO->userPass2 = $this->member->userPass2;
	$this->fullUserInfoVO->bodyID = $_config['RegisterAutoFillForm']["FirstName"];
	$this->fullUserInfoVO->bodyID2 = $_config['RegisterAutoFillForm']["LastName"];
	$this->fullUserInfoVO->sex = $_config['RegisterAutoFillForm']["Gender"];
	$this->fullUserInfoVO->email = $this->member->userEmail;
	$this->fullUserInfoVO->birthY = $_config['RegisterAutoFillForm']["BirthYear"];
	$this->fullUserInfoVO->birthM = $_config['RegisterAutoFillForm']["BirthMonth"];
	$this->fullUserInfoVO->birthD = $_config['RegisterAutoFillForm']["BirthDay"];
	$this->fullUserInfoVO->tel = $_config['RegisterAutoFillForm']["Telephone"];
	$this->fullUserInfoVO->mobile = $_config['RegisterAutoFillForm']["Mobile"];
	$this->fullUserInfoVO->city1 = $_config['RegisterAutoFillForm']["City"];
	$this->fullUserInfoVO->city2 = $_config['RegisterAutoFillForm']["Province"];
	$this->fullUserInfoVO->post = $_config['RegisterAutoFillForm']["Post"];
	$this->fullUserInfoVO->address = $_config['RegisterAutoFillForm']["Address"];

  }
  function parseBtnUserIDForm(){
	$this->member->userID = $_POST["ctl00_ContentPlaceHolder_main_HyperLink3"];
	$this->fullUserInfoVO->userID = $this->member->userID;
  }
  function validateLoginForm($checkcode) {
    if(!$this->isvalidUserID($_POST[$this->member->userID])) {
	$this->loginMsgType(0);
	}elseif(!$this->isvalidUserPWD($_POST[$this->member->userPass])) {
	$this->loginMsgType(1);
	}elseif(!$checkcode) {
	$this->loginMsgType(2);
	}else{
	return true;	
	}
  }
  #-- Private Funtion
	function add_Point($user){
	   return $this->user->add_Point($user);
	}
	function charge_Point($user){
		$result = $this->user->charge_Points($user);
	}
	function check_UserOnline($user){
		return $this->user->check_UserOnline($user);
	}
	function getUserInfo(){
	  $this->member->userID = $_SESSION['auth_user'];
	  return $this->user->userAuth($this->member);
	}
	function isMaintenance(){		
		if(MAINTENANCE_MODE){
		jump_location('errorpage'); 	
		}
	}
   function isRegisterOpen(){
   global $_config;
	    if(!$_config['RegisterOpen']){
		jump_location('errorpage'); 	
		}
   }
  function isvalidCheckCode(){
	  if ($this->isvalidCode($_POST["ValidateCode"])){
		  return ($_POST["ValidateCode"]==$_SESSION['checkcode']) ? true : false;
	  }
	  return false;	
  }
  function isvalidCheckCode2(){
	  if ($this->isvalidCode($_POST["ValidateCode"])){
		  return ($_POST["ValidateCode"]==$_SESSION['checkcode2']) ? true : false;
	  }
	  return false;	
  }
  function isvalidUserID($IDcheck){
  if ($this->validatorTrim($IDcheck)){
	  if(!$this->expressionCheck){
	  $exp = preg_match('/^[a-zA-Z0-9\_\s]{4,12}$/i', $IDcheck);
	  }else{
	  $exp = preg_match('/^[_a-z][_a-z0-9]{4,12}/', $IDcheck);
	  }
	  if ($exp) {
	  return true;
	  } 
  }
	  return false;
  }
  function isvalidUserPWD($Pwdcheck){
  if ($this->validatorTrim($Pwdcheck)){
	  if(!$this->expressionCheck){
	  $exp = preg_match('/^[a-zA-Z0-9\_\s]{6,12}$/i', $Pwdcheck);
	  }else{
	  $exp = preg_match('/^[_0-9a-z]{6,12}/', $Pwdcheck);
	  }
	  if ($exp) {
	  return true;
	  } 
  }
	  return false;
  }
  function isvalidCode($Codecheck){
  if ($this->validatorTrim($Codecheck)){
	  if (preg_match('/^[0-9a-z]{4}$/', $Codecheck)) {
	  return true;
	  } 
  }
	  return false;
  }
  function isvalidEmail($Emailcheck){
  if ($this->validatorTrim($Emailcheck)){
	  if (preg_match('/^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*/', $Emailcheck)) {
	  return true;
	  } 
  }
	  return false;	
  }
  function validatorTrim($s) {
  $m = preg_match('/^\s*(\S+(\s+\S+)*)\s*$/', $s);
  return ($m != null) ? true : false;
  }
  function loginMsgType($which){
	  $msgArray = array(array(LOGIN_ID_ERR_FORMAT_MSG,LOGIN_PWD_ERR_FORMAT_MSG,LOGIN_CODE_ERR_MSG,
	  			  			 ),
				        array(ILOGIN_ID_ERR_FORMAT_MSG,ILOGIN_PWD_ERR_FORMAT_MSG,ILOGIN_CODE_ERR_MSG
						     )
					   );
	  switch ($this->loginType){
		  case 'login':
		  $this->errs['Result'] = $msgArray[0][$which];
		  break;	
		  
		  case 'ilogin':
		  echo '<script type="text/javascript">alert("',$msgArray[1][$which],'");window.self.location=\'ilogin.php\';</script>';
		  break;
	  }
  }
}
?>