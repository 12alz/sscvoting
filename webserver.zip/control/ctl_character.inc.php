<?php
class CharacterController extends ItemCustomizeController {

  function character_FunctionJump($link){
	 
	if(isset($_POST["HyperLink2"])){
		 
		if($this->validate_Character()==true){
			unset($this->characterVO);
			jump_location('extend.php?do='.$link.'');
		}
	}else{
		//exit('No');
	}
  }
  
  function checkCharacterSinglePage($page,$link,$ses){
	  
	$ses = base64_encode(clean_variable($_POST["__EVENTARGUMENT2"]));
	$dbSes = $this->character->getSesData($this->characterVO,$page,$ses); 
	if($dbSes != $ses){
		//echo '<script type="text/javascript">alert("This tab is active. Use Reset Session to Unlock some pages");window.self.location=\'extend.php?do=cap_reward\';</script>';
		// jump_location('extend.php?do='.$link.'');
		return true;
	}else{
		return false;
	}
  }
  
	function getCurrentTabSession($page,$link){
		$res =  $this->character->getCurrentTabSession($this->characterVO,$page); 
		
		if($res == false || $res == NULL){
			jump_location('extend.php?do='.$link.'');
		}
		
		return $res;
	}
  
  function addStatsToDo(){
	$this->characterVO->chaNum = (int)$_GET['id'];
	$this->get_CharacterInfo();
	if(isset($_POST["HyperLink2"])){
	  $totalStats = (int)($_POST["AddChaPower"] +  $_POST["AddChaStrong"] +  $_POST["AddChaStrength"] + $_POST["AddChaSpirit"] + $_POST["AddChaDex"]);
	  $addStatsLog = "| UserID:".$this->userInfo->userID." | ChaName:".$this->characterVO->chaName." | ChaPower = ".$this->characterVO->chaPower."+".(int)$_POST["AddChaPower"]."(".(int)($this->characterVO->chaPower+$_POST["AddChaPower"]).") | ChaStrong = ".$this->characterVO->chaStrong."+".(int)($_POST["AddChaStrong"])."(".(int)($this->characterVO->chaStrong+$_POST["AddChaStrong"]).") | ChaStrength = ".$this->characterVO->chaStrength."+".(int)$_POST["AddChaStrength"]."(".(int)($_POST["AddChaStrength"]+$this->characterVO->chaStrength).") | ChaSpirit = ".$this->characterVO->chaSpirit."+".(int)$_POST["AddChaSpirit"]."(".(int)($this->characterVO->chaSpirit+$_POST["AddChaSpirit"]).") | ChaDex = ".$this->characterVO->chaDex."+".(int)$_POST["AddChaDex"]."(".(int)($this->characterVO->chaDex+$_POST["AddChaDex"]).") | ChaStRemain = ".$this->characterVO->chaStRemain."-".$totalStats." | Total = ".((int)$this->characterVO->chaStRemain-$totalStats)."";
	  if(!$this->isvalidCheckCode()){
		$this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;
	  }elseif(!$this->character->isCharacterOnline($this->characterVO)){
		$this->errs['Result'] = $this->msg_Table(CHARACTER_ONLINE_ERR_MSG);
	  }elseif(!(int)$totalStats){
		$this->errs['Result'] = $this->msg_Table(ADD_STATS_ERR_MSG);
	  }elseif($totalStats > $this->characterVO->chaStRemain){
		write_log($addStatsLog, 'AddStats_Failed');
		echo '<script type="text/javascript">alert("',ADD_STATS_POINTS_MSG,'");window.self.location=\'extend.php?do=webjd_todo&id=',$this->characterVO->chaNum,'\';</script>'; 
	  }else{
	    $this->parseAddStatsForm();
		$this->addStatsLimit();
		$this->character->addStats($this->characterVO);
		write_log($addStatsLog, 'AddStats_Success');
		echo '<script type="text/javascript">alert("',ADD_STATS_SUCCESS_MSG,'");window.self.location=\'extend.php?do=webjd\';</script>'; 
	  }
	}
  }

  /*Purchase Reborn*/
 function purchaseReborn(){
  	global $_config;
  	$this->characterVO->chaNum = (int)$_GET['id'];
  	$this->get_CharacterInfo();
  	$totalPurchaseResult = (int)$_config['PurchaseRebornPay'] * $_POST['RebornNum'];
  	if(isset($_POST['HyperLink2'])){
  		if(!$this->isvalidCheckCode()){
  			$this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;

  		}elseif(!$this->character->isCharacterOnline($this->characterVO)){
  			$this->errs['Result'] = $this->msg_Table(CHARACTER_ONLINE_ERR_MSG);
  		}elseif($this->character->chaReborn >= $_config['RebornLimit']){
  			$this->errs['Result'] = $this->msg_Table(REBORN_LIMIT_MSG);
  		}elseif($this->userInfo->userPoint != $totalPurchaseResult){
  			$this->errs['Result'] = $this->msg_Table(PURCHASE_RB_LESS_POINT_MSG);
  		}elseif($_POST['RebornNum'] > $_config['RebornLimit']) {
  			$this->errs['Result'] = $this->msg_Table(PURCHASE_RB_LIMIT_EXCEEDED);
  		
  		}else{
  			
  			$totalGainedStats = (int)$_POST['RebornNum'] * 25;
  			$totalRebornPurchased = (int)$_POST['RebornNum'];
  			$this->userInfo->userPoint = (int)$totalPurchaseResult;
  			$this->user->charge_Point($this->userInfo);
  			$this->characterVO->chaStRemain = (int)$totalGainedStats;
  			$this->characterVO->chaReborn = (int)$totalRebornPurchased;
  			$this->character->updatePurchaseReborn($this->characterVO);

 		}

  	}
  }

  /*Reborn to EPoints Conversion TODO*/
  function resetRebornToEpoints(){
  	global $_config;
  	$this->characterVO->chaNum = (int)$_GET['id'];
  	$this->get_CharacterInfo();
  	if(isset($_POST['HyperLink2'])){
  		if(!$this->isvalidCheckCode()){
  			$this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;
  		}elseif(!$this->character->isCharacterOnline($this->characterVO)) {
  			$this->errs['Result'] = $this->msg_Table(CHARACTER_ONLINE_ERR_MSG);
  		}elseif($this->characterVO->chaReborn < $_config['RBToEpoints']['RebornRequired']) {
  			$this->errs['Result'] = $this->msg_Table(REBORN_LESS_MSG);
  		}elseif($this->characterVO->chaLevel < $_config['RBToEpoints']['LevelRequired']){
  			$this->errs['Result'] = $this->msg_Table(REBORN_LEVEL_REQUIRED_MSG);
  		}elseif($this->userInfo->userPoint < $_config['RBToEpointsPay']){
  			$this->errs['Result'] = $this->msg_Table(R2PPAY_LESS_POINT_MSG);
  		}else{

  			$this->userInfo->userPoint = $_config['RBToEpointsPay'];
  			$this->user->charge_Point($this->userInfo);
  			$this->character->resetReborn($this->characterVO);
  			$this->userInfo->userPoint = $_config['RBToEpoints']['AddPoint'];
  			$this->add_Point($this->userInfo);


  			echo '<script type="text/javascript">alert("Congratulations! You have successfully converted your '.$this->characterVO->chaReborn.' Rebirth to '.$this->userInfo->userPoint.' Points.");window.self.location=\'index.php\';</script>'; 

  		}
  	}

  }
  //Gold to EPoits conversion
  function goldToEpoints(){
  	global $_config;
  	$this->characterVO->chaNum = (int)$_GET['id'];
  	$this->get_CharacterInfo();
  	if(isset($_POST["HyperLink2"])){
  		if(!$this->isvalidCheckCode()){
  			$this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;
  		}elseif(!$this->user->check_UserOnline($this->member)){
  			     $this->errs['Result'] = $this->msg_Table(USER_ONLINE_ERR_MSG);
  		}elseif($this->characterVO->chaMoney < $_config['GoldToEP']['RequestGold']){
  				$this->errs['Result'] = $this->msg_Table(GOLD2EP_CHAR_GOLD_ERR_MSG);
  		}elseif($this->userInfo->userPoint < $_config['GoldToEP']['RequestPoints']){
  				$this->errs['Result'] = $this->msg_Table(GOLD2EP_POINTS_LESS_ERR_MSG);
  		}else{
  			$RequestPoints = $_config['GoldToEP']['RequestPoints'];
  			$this->userInfo->userPoint = $RequestPoints;
  			$this->user->charge_Point($this->userInfo);

  			$this->characterVO->chaMoney = $_config['GoldToEP']['RequestGold'];
  			$this->character->charge_Money($this->characterVO);

  			$this->userInfo->userPoint = $_config['GoldToEP']['AddPoint'];
  			$this->user->add_Point($this->userInfo);

  			echo '<script type="text/javascript">alert("Congratulations! You have successfully converted your '.$RequestPoints.' EP and '.$this->characterVO->chaMoney.' Gold to '.$this->userInfo->userPoint.' EPoints!");window.self.location=\'index.php\';</script>'; 
  		}
  	}
  }

  //Epoints to GameGold conversion test TODO
  function pointToGameGold(){
  	global $_config;
  	$this->characterVO->chaNum = (int)$_GET['id'];
	$this->get_CharacterInfo();
  	if(isset($_POST["HyperLink2"])){
  		if (!$this->isvalidCheckCode()) {
  			$this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;
  		}elseif(!$this->user->check_UserOnline($this->member)){
  			$this->errs['Result'] = $this->msg_Table(USER_ONLINE_ERR_MSG);
  		}elseif($this->userInfo->userPoint < $_config['EpointsToGold']['RequestEpoints']){
  			$this->errs['Result'] = $this->msg_Table(EPOINTS_LESS_MSG);
  		}else{

  			/*POINT TO GAMEGOLD LOGS TODO*/
  			/*$pointToGameGoldLog = "| UserID:".$this->userInfo->userID." | Point = ".$this->userInfo->userPoint."+".$this->member->userPoint." | Total = ".((int)$this->userInfo->userPoint+$this->member->userPoint)."";*/

  			$this->userInfo->userPoint = $_config['EpointsToGold']['RequestEpoints'];
  			$this->user->charge_Point($this->userInfo);
  			$this->characterVO->chaMoney  = $_config['EpointsToGold']['AddGold'];
  			$this->character->add_Money($this->characterVO);
  			//$this->character->pointToGameGold($this->characterVO);	

			//write_log($pointToGameGoldLog, 'GameGold');
			echo '<script type="text/javascript">alert("Congratulations! You have successfully converted your EPoints to '.$this->characterVO->chaMoney.' Gold!");window.self.location=\'index.php\';</script>'; 

  		}
  	}
  }


  function changeSex(){
	global $_config;
	if(isset($_POST["HyperLink2"])){
			if($_POST["ChaList"]=="-1"){
			  $this->errs['Result'] = $this->msg_Table(CHARACTER_SELECT_ERR_MSG);
			}elseif(!$this->isvalidCheckCode()){
			  $this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;
			}else{
				$this->characterVO->chaNum = (int)$_POST["ChaList"];
				$this->get_CharacterInfo();
				if(!$this->character->isCharacterOnline($this->characterVO)){
			  	$this->errs['Result'] = $this->msg_Table(CHARACTER_ONLINE_ERR_MSG);
				}elseif($this->userInfo->userPoint < $_config['TranssexualPay']){
			  	$this->errs['Result'] = $this->msg_Table(USER_POINT_ERR_MSG);
				}else{
				$this->userInfo->userPoint = $_config['TranssexualPay'];
				$this->user->charge_Point($this->userInfo);
				$this->character->transsexual($this->characterVO);
				echo '<script type="text/javascript">alert("',TRANSSEXUAL_SUCCESS_MSG,'");window.self.location=\'index.php\';</script>'; 
				}
			}
		
	}
	  
  }
  function changeClass(){
	global $_config;
	if(isset($_POST["HyperLink2"])){
			if($_POST["ChaList"]=="-1"){
			  $this->errs['Result'] = CHARACTER_SELECT_ERR_MSG;
			}elseif($_POST["ChaClass"]=="-1"){
			  $this->errs['Result'] = CHANGE_CLASS_SELECT_MSG;
			}elseif(!$this->isvalidCheckCode()){
			  $this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;
			}else{
					$this->characterVO->chaNum = (int)$_POST["ChaList"];
					$this->get_CharacterInfo();
					if(!$this->character->isCharacterOnline($this->characterVO)){
					$this->errs['Result'] = CHARACTER_ONLINE_ERR_MSG;
					}elseif($this->userInfo->userPoint < $_config['ChangeClassPay']){
					$this->errs['Result'] = USER_POINT_ERR_MSG;
					}elseif($this->characterVO->chaClass==(int)$_POST["ChaClass"]){
					$this->errs['Result'] = CHANGE_CLASS_ALREADY_USE_MSG;
					}elseif(!$this->hasChangeClass($this->characterVO)){
					$this->errs['Result'] = CHANGE_CLASS_CHECK_MSG;
					}else{
						
				    $changeClass = "| UserID:".$this->userInfo->userID." | ChaName:".$this->characterVO->chaName." | Class = ".$_config['ChaClass'][$this->characterVO->chaClass]." | NewClass = ".$_config['ChaClass'][(int)$_POST["ChaClass"]]." | Point = ".$this->userInfo->userPoint."-".$_config['ChangeClassPay']." | Total = ".((int)$this->userInfo->userPoint-$_config['ChangeClassPay'])."";
						
					$this->userInfo->userPoint = $_config['ChangeClassPay'];
					$this->user->charge_Point($this->userInfo);
					$this->characterVO->chaClass = (int)$_POST["ChaClass"];
					$this->character->changeClass($this->characterVO);			
					
					
					write_log($changeClass, 'ChangeClass');
					echo '<script type="text/javascript">alert("Congratulations! Your character class is now ',$_config['ChaClass'][$this->characterVO->chaClass],'");window.self.location=\'index.php\';</script>'; 
					}
		  }
	}
  }
  function deleteItems(){
	global $_config;
	$this->characterVO->chaNum = (int)$_GET['cid'];
	$this->get_CharacterInfo();

	if($_POST["__EVENTTARGET"]=="ctl00ContentPlaceHoldermainCustomersItemView"){
	$targetArg = explode("$",$_POST["__EVENTARGUMENT"]);
		if($targetArg[0]=="Delete"){
		if(!$this->character->isCharacterOnline($this->characterVO)){
			echo '<script type="text/javascript">alert("',CHARACTER_ONLINE_ERR_MSG,'");window.self.location=\'extend.php?do=webdelitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
		}elseif($this->userInfo->userPoint < $_config['DeleteItemsPay']){
			echo '<script type="text/javascript">alert("',USER_POINT_ERR_MSG,'");window.self.location=\'extend.php?do=webdelitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
		}else{
				$newChaInvenData = $this->character->deleteItem($this->characterVO,$targetArg[1]);
				if((strlen($newChaInvenData['Old'])==24) || $newChaInvenData['Old']==NULL){
				echo '<script type="text/javascript">alert("',DELETE_ITEMS_FAILED_MSG,'");window.self.location=\'extend.php?do=webdelitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
				}else{
				$this->userInfo->userPoint = $_config['DeleteItemsPay'];
				$this->user->charge_Point($this->userInfo);
				$this->characterVO->chaInven = $newChaInvenData['Data'];
				$this->character->characterUpdateInventory($this->characterVO);				
				echo '<script type="text/javascript">alert("Success! The [',$newChaInvenData['Decode']['Name'],'] has been deleted.");window.self.location=\'extend.php?do=webdelitem_list&cid='.$this->characterVO->chaNum.'\';</script>'; 
				}
		}
	
	}
	}
	  
  }
  
  function recoverDeletedCharDo(){
  	global $_config;
  	$this->characterVO->chaNum = (int)$_GET['cid'];
  	$this->get_CharacterInfo();
  		if(isset($_POST['HyperLink2'])){
  			//do
  			if(!$this->isvalidCheckCode()){
  				$this->errs['Result'] = CHECK_CODE_ERR_MSG;
  				}elseif(!$this->user->check_UserOnline($this->member)){
  					$this->errs['Result'] = $this->msg_Table(USER_ONLINE_ERR_MSG);
  				}elseif($this->userInfo->userPoint < $_config['RecoverCharacterDeletedPay']){
  					$this->errs['Result'] = RECOVER_CHAR_POINT_LESS_MSG;
  				}else{
  					$this->userInfo->userPoint = $_config['RecoverCharacterDeletedPay'];
  					$this->user->charge_Point($this->userInfo);
  				    $this->character->updateChaDeleted($this->characterVO);
  				    echo '<script type="text/javascript">alert("Congratulations! You have successfully recover your character!");window.self.location=\'index.php\';</script>'; 
  				}
  			}
  }
  function recoverDeletedChar(){
  	//global $_config;
  	if(isset($_POST['HyperLink2'])){
  			//parse
		  	$this->parseRecoverCharDelForm();
		  	//declaration
		  	$this->fullUserInfoVO->userID = $this->userInfo->userID;
		  	//do
  		if(!$this->isvalidUserPWD($this->fullUserInfoVO->userPass2) || !$this->fullUserInfo->
  				checkUserPassword2($this->fullUserInfoVO)){
  			$this->errs['Result'] = RECOVER_CHAR_PIN_ERR_MSG;
  		}elseif(!$this->isvalidUserPWD($_POST['ReSafePWD']) || $this->fullUserInfoVO->userPass2 != clean_variable($_POST['ReSafePWD'])){
  			$this->errs['Result'] = RECOVER_CHAR_REPASS_ERR_MSG;
  		/*THIS LINE IS STILL ON PROGRESS*/
  		/*}elseif(!$this->isvalidUserPWD($this->fullUserInfoVO->userPass) || 
  	 			!$this->fullUserInfo->checkUserPassword($this->fullUserInfoVO)){
  			$this->errs['Result'] = RECOVER_CHAR_PASS_ERR_MSG;
  		}elseif(!$this->isvalidUserPWD($_POST['ReOldPass']) || 
  				$this->fullUserInfoVO->userPass2 != clean_variable($_POST['ReOldPass'])){
  			$this->errs['Result'] = RECOVER_CHAR_REPASS_ERR_MSG;*/
  		/*END OF LINE*/
  		}elseif(!$this->isvalidCheckCode()){
  			$this->errs['Result'] = CHECK_CODE_ERR_MSG;
  		}else{
  			header('Location: http://bozxsran.xyz/extend.php?do=recover_delchalist');
  			die();
  		}
  		
  	}	

  }

  function editSafePassword(){ 
	global $_config;
	if(isset($_POST["HyperLink2"])){
		$this->parseEditSafePasswordForm();
		$this->fullUserInfoVO->userID = $this->userInfo->userID;
		$this->member->userID = $this->userInfo->userID;
		if(!$this->isvalidUserPWD($this->fullUserInfoVO->userPass2) || !$this->fullUserInfo->checkUserPassword2($this->fullUserInfoVO)){
		$this->errs['Result'] = '<font color=Red>'.RESET_SAFE_PASSWORD_FAILED_MSG.'</font>';
		}elseif(!$this->isvalidUserPWD($_POST["NewSafePWD"]) || !$this->isvalidUserPWD($_POST["Re_NewSafePWD"]) || clean_variable($_POST["NewSafePWD"])!=clean_variable($_POST["Re_NewSafePWD"])){
		$this->errs['Result'] = '<font color=Red>'.RESET_SAFE_PASSWORD_VERIFY_MSG.'</font>';
		}elseif(!$this->isvalidCheckCode()){
		$this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;
		}elseif($this->userInfo->userPoint < $_config['EditSafePasswordPay']){
		$this->errs['Result'] = '<font color=Red>'.USER_POINT_ERR_MSG.'</font>';
		}else{
			//$this->fullUserInfoVO->userPass2 = $this->member->userPass2; 
			$this->fullUserInfoVO->userPass2 = $_POST["NewSafePWD"];
			$this->member->userPass2 = $this->fullUserInfoVO->userPass2;
			$this->userInfo->userPoint = $_config['EditSafePasswordPay'];
			$this->user->charge_Point($this->userInfo);
			//Update Full UserInfo User Password 2
			$this->fullUserInfo->updateUserPass2($this->fullUserInfoVO);
			$this->user->updateUserPass2($this->member);
			echo '<script type="text/javascript">alert("',RESET_SAFE_PASSWORD_SUCCESS_MSG,'");window.self.location=\'index.php\';</script>'; 
		}
	}
  }

  function gameTimeEarnPoint(){
	  global $_config;
	  if(isset($_POST["HyperLink2"])){
		 
		if(!$this->isvalidCheckCode()){
		$this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;
		}elseif(!$this->user->check_UserOnline($this->member)){
		$this->errs['Result'] = $this->msg_Table(USER_ONLINE_ERR_MSG);
		}elseif($this->member->gameTime2 < $_config['GameTimeEarnPoint']['RequestTime']){
		$this->errs['Result'] = $this->msg_Table(GAME_TIME_MIN_LESS_MSG);
		}else{
		$gameTime = (int)($this->member->gameTime2/$_config['GameTimeEarnPoint']['RequestTime']);
		$this->member->gameTime2 = $gameTime*$_config['GameTimeEarnPoint']['RequestTime'];
		$this->member->userPoint = $gameTime*$_config['GameTimeEarnPoint']['AddPoint'];
			
			$earnPointLog = "| UserID:".$this->userInfo->userID." | Point = ".$this->userInfo->userPoint."+".$this->member->userPoint." | Total = ".((int)$this->userInfo->userPoint+$this->member->userPoint)."";
			
			$this->character->updateGameTime($this->member);
			$this->userInfo->userPoint = $this->member->userPoint;
			$this->add_Point($this->userInfo);
			
			write_log($earnPointLog, 'EarnPoint');
			echo '<script type="text/javascript">alert("Congratulations! You have earn '.$this->member->userPoint.' Points!");window.self.location=\'index.php\';</script>'; 
		}
	  }
  }

  
  function resetStatsPoint(){
	 global $_config;
	if(isset($_POST["HyperLink2"])){
		if($_POST["ChaList"]=="-1"){
		  $this->errs['Result'] = $this->msg_Table(CHARACTER_SELECT_ERR_MSG);
		}elseif(!$this->isvalidCheckCode()){
		  $this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;
		}else{			
	        $this->characterVO->chaNum = (int)$_POST["ChaList"];
			$this->get_CharacterInfo();
			if(!$this->character->isCharacterOnline($this->characterVO)){
		    $this->errs['Result'] = $this->msg_Table(CHARACTER_ONLINE_ERR_MSG);
			}else{
				$totalStats = $this->characterVO->chaPower + $this->characterVO->chaStrong + $this->characterVO->chaStrength + $this->characterVO->chaSpirit + $this->characterVO->chaDex;
				
				$resetStatsPointLog = "| UserID:".$this->userInfo->userID." | ChaName:".$this->characterVO->chaName." | TotalStats = ".($totalStats+$this->characterVO->chaStRemain)." | Gold = ".$this->characterVO->chaMoney."-".$_config['ResetStatsPointPay']." | Total = ".($this->characterVO->chaMoney-$_config['ResetStatsPointPay'])."";
				
				
				if((int)($totalStats)==0){
				$this->errs['Result'] = $this->msg_Table(RESET_STATS_POINTS_NO_NEED_RESET_MSG);
				}elseif($this->characterVO->chaMoney < $_config['ResetStatsPointPay']){
				$this->errs['Result'] = $this->msg_Table(CHARACTER_MONEY_ERR_MSG);
				}else{
				$this->characterVO->chaMoney = $_config['ResetStatsPointPay'];
				$this->character->charge_Money($this->characterVO);
				$this->character->resetStatsPoint($this->characterVO);
				
				write_log($resetStatsPointLog, 'ResetStatsPoint');
				echo '<script type="text/javascript">alert("',RESET_STATS_POINTS_SUCCESS_MSG,'");window.self.location=\'index.php\';</script>'; 
				
				}
			}
			
		}
	}
  }
  function resetPK(){
	 global $_config;
	if(isset($_POST["HyperLink2"])){
		if($this->validate_Character()==true){
	        //$this->characterVO->chaNum = (int)$_POST["ChaList"];
			//$this->get_CharacterInfo();

			if($this->characterVO->chaBright >= 0){
				$this->errs['Result'] = RESET_PK_NO_NEED_MSG;
			}elseif($this->userInfo->userPoint < $_config['ResetPK']['Pay']){
				$this->errs['Result'] = USER_POINT_ERR_MSG;
			}else{
					$resetPKLog = "| UserID:".$this->userInfo->userID." | ChaName:".$this->characterVO->chaName." | PK Value = ".$this->characterVO->chaBright." | Points = ".$this->userInfo->userPoint."-".$_config['ResetPK']['Pay']." | Total = ".((int)$this->userInfo->userPoint-$_config['ResetPK']['Pay'])."";
					
					$this->userInfo->userPoint = $_config['ResetPK']['Pay'];
				    $this->user->charge_Point($this->userInfo);
					
					
					if($this->characterVO->chaBright <= -$_config['ResetPK']['AddValue']){
					$this->characterVO->chaBright = $_config['ResetPK']['AddValue'];
					$this->character->addPK($this->characterVO);
					}else{
					$this->character->resetPK($this->characterVO);
					}
					
					write_log($resetPKLog, 'ResetPK');
					
					echo '<script type="text/javascript">alert("',RESET_PK_SUCCESS_MSG,'");window.self.location=\'index.php\';</script>'; 
			}
			
		}
	}
  }
  #-- Public Function
  function get_CharacterInfo(){
	  	return $this->character->get_CharacterInfo($this->characterVO);
  }
  function get_CharacterList($userNum){
	  $this->characterVO->userNum = $userNum;
	  $this->character->characterList($this->characterVO);
  }
  function get_CharacterDeletedList($userNum){
  	//to do
  	  $this->characterVO->userNum = $userNum;
  	  $this->character->characterDeletedList($this->characterVO);
  }
  #--- Private Function
  function addStatsLimit(){
	  global $_config;
	  $total = count($_config['AddStatsLimit']);
	  $arrValues = array_values($_config['AddStatsLimit']);
	  $arrKeys = array_keys($_config['AddStatsLimit']);
	  $statsData = array((int)$_POST["AddChaPower"],
	  					 (int)$_POST["AddChaStrong"],
						 (int)$_POST["AddChaStrength"],
						 (int)$_POST["AddChaSpirit"],
					     (int)$_POST["AddChaDex"]
						 );
	  for($i=0;$i<$total;$i++){
	  	if($statsData[$i] > (int)$arrValues[$i]){
		  echo '<script type="text/javascript">alert("Points allocation error for ',str_replace("Cha","",$arrKeys[$i]),' please re-add points!");window.self.location=\'extend.php?do=webjd_todo&id=',$this->characterVO->chaNum,'\';</script>'; 
		  exit();
		  break;
	  	}
	  }
	  
	  
  }  
  function hasChangeClass($character){
	global $_config;
	if($_config['ChangeClassCheck']){
		if($character->changeClass > 0){
		return false;
		}else
		return true;
	}
		return true;
	  
  }
 
  function characterClassList(){
	  global $_config;
	  $classValues = array_values($_config['ChaClass']);
	  $classKeys = array_keys($_config['ChaClass']);
	  $totalChaClass = count($classKeys);
	  for($c=0;$c<$totalChaClass;$c++){
    	$content = '<option ';	
		if ((int)$_POST["ChaClass"] == $classKeys[$c]) { 
		$content.= 'selected="selected"'; 
		}
		$content.= 'value="'.$classKeys[$c].'">';
		$content.= $classValues[$c];
		$content.= '</option>';
		echo $content;
	  }

  }
  function characterItemsView(){
	  return $this->character->characterItemsList($this->characterVO);
  }
  function characterAllItemsView(){
	  return $this->character->characterAllItemsList($this->characterVO);
  }
  function recoverCharacterAllItemsView(){
  	  return $this->character->recoverCharacterAllItemsList($this->characterVO);
  }
  function msg_Table($msg){
	  $tableContents = '<table width="500" border="0" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC" align="center">  <tr>  	<td bgcolor="#FFFFFF" ><font color="#FF0000">&nbsp;&nbsp;'.$msg.'</font></td>  </tr></table>'; 
	  return $tableContents;
  }
  function parseAddStatsForm(){
	 $this->characterVO->chaPower = (int)$_POST["AddChaPower"];
	 $this->characterVO->chaStrong = (int)$_POST["AddChaStrong"];
	 $this->characterVO->chaStrength = (int)$_POST["AddChaStrength"];
	 $this->characterVO->chaSpirit = (int)$_POST["AddChaSpirit"];
	 $this->characterVO->chaDex  = (int)$_POST["AddChaDex"];
	 $this->characterVO->chaStRemain = $this->characterVO->chaPower + $this->characterVO->chaStrong + $this->characterVO->chaStrength + $this->characterVO->chaSpirit + $this->characterVO->chaDex;
  }

  function parseEditSafePasswordForm(){
	  $this->fullUserInfoVO->userPass2 = $_POST["OldSafePWD"]; 
	  //$this->member->userPass3 = $_POST["OldSafePWD"];
	  $this->member->userPass2 = $_POST["NewSafePWD"];
  }

  function parseRecoverCharDelForm(){
	  	$this->fullUserInfoVO->userPass2 = $_POST['SafePWD'];
  }
  
  function storageItemsView(){
	  return $this->character->storageItemsView($this->characterVO);
  }
  function validate_Character(){
	  if($_POST["ChaList"]=="-1"){
		$this->errs['Result'] = CHARACTER_SELECT_ERR_MSG;
	  }elseif(!$this->isvalidCheckCode()){
		$this->errs['CodeCheck'] = CHECK_CODE_ERR_MSG;
	  }else{
	        $this->characterVO->chaNum = (int)$_POST["ChaList"];
			$this->get_CharacterInfo();
		  	if(!$this->character->isCharacterOnline($this->characterVO)){
			$this->errs['Result'] = CHARACTER_ONLINE_ERR_MSG;
	  		}else{
			return true;
	  		}
	  }
	  
  }
  
	//added by otep
	
	function validate_pageSingle($page){
		
		if($this->character->isSinglePage($this->characterVO,$page)){
			return true;
	  	}else{
			
			$this->errs['Result'] = 'This Page is already Open in other Tab Browser in the Browser. You can use Reset Pages';
			return false;
	  	}
		
	}
	function checkCharExist($UserNum,$ChaNum){
		return $this->character->checkCharExist($UserNum,$ChaNum);
	}
	
	function resetPages($UserNum){
		return $this->character->resetPages($UserNum);
	}
	
	function getChaInformation($cha){
		return $this->character->getChaInformation($cha->characterVO);
	}
	
	function getItemName($_id,$_idsub){
		return $this->character->getItemName($_id,$_idsub);
	}
	
	function CharUpdateInventory($character){
		$result = $this->character->CharUpdateInventory($character);
		return $result;
	}
  
}
?>