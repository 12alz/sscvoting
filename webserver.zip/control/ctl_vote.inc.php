<?php
class VoteController extends UserController{
	
	
	function vote(){
	global $_config;//['VoteLinks']// $_config['VoteAddPoint']
	if($this->user->haslogin(true)){
	$siteNo = (int)$_GET['site'];
	$this->getUserInfo();
	$this->voteVO->userID = $this->member->userID;
	$result = $this->vote->getUserVote($this->voteVO);
		if($result){
		$voteLimit = 60*60*$_config['VoteTimeLimit'];
		$dateDiff = $this->vote->date_TimeDiff("1970-02-01 00:00:00.000",date('Y-m-d H:i:s'));
		$voteDiff = $this->vote->date_TimeDiff("1970-02-01 00:00:00.000",date('Y-m-d H:i:s',strtotime($this->voteVO->Date)));
		$voteTime = $dateDiff-$voteDiff;
			if(isset($_config['VoteLinks'][$siteNo])){
				
				if($voteTime  > $voteLimit){

				  if($siteNo==1 & $this->voteVO->last_Vote==1){
					      $this->voteVO->last_Vote = 2;
					  	  $this->vote->updateLastVote($this->voteVO);
						  $this->member->userPoint = $_config['VoteAddPoint'];
						  $this->add_Point($this->member);
					  
				  }else if($siteNo==2 & $this->voteVO->last_Vote==2){
					      $this->voteVO->last_Vote = 3;
					  	  $this->vote->updateLastVote($this->voteVO);
						  $this->member->userPoint = $_config['VoteAddPoint'];
						  $this->add_Point($this->member);
					  
				  }else if($siteNo==3 & $this->voteVO->last_Vote==3){
					      $this->voteVO->last_Vote = 4;
					  	  $this->vote->updateLastVote($this->voteVO);
						  $this->member->userPoint = $_config['VoteAddPoint'];
						  $this->add_Point($this->member);
					  
				  }else if($siteNo==4 & $this->voteVO->last_Vote==4){
					      $this->voteVO->last_Vote = 1;
					  	  $this->vote->updateLastVote($this->voteVO);
						  $this->vote->updateVoteInfo($this->voteVO);
						  $this->member->userPoint = $_config['VoteAddPoint'];
						  $this->add_Point($this->member);
				  }else{
					  echo '<script type="text/javascript">alert("',VOTE_SITE_ERR_MSG,'");window.close();</script>';	
					  
				  }
				}else{
					  echo '<script type="text/javascript">alert("Time-out, vote again after ',$_config['VoteTimeLimit'],' hours.");window.self.location=\'../index.php\';</script>'; 
					
				}
				$v_content = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">'."\n";
				$v_content.= '<html>'."\n";
				$v_content.= '<head>'."\n";
				$v_content.= '<title>'.PAGE_TITLE.'</title>'."\n";
				$v_content.= '<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />'."\n";
				$v_content.= '<meta name="description" content="'.PAGE_TITLE.'" />'."\n";
				$v_content.= '<meta name="keywords" content="'.PAGE_TITLE.'" />'."\n";
				$v_content.= '<link rel="shortcut icon" href="../common/ran.ico" type="image/x-icon" />'."\n";
				$v_content.= '</head>'."\n";
				if($_config['VoteAllowAds']){
				$v_content.= '<frameset rows="139,*" border="0" frameborder="0" >'."\n";
				$v_content.= '	<frame name="top" src="../event/ads/audit.php" marginwidth="10" marginheight="10" scrolling="no" frameborder="0">'."\n";
				$v_content.= '			<frameset cols="900,*" border="1" >'."\n";
				$v_content.= '			<frame name="mainFrame" src="'.$_config['VoteLinks'][$siteNo]['Link'].'" marginwidth="0" marginheight="10"  scrolling="auto" frameborder="0" >'."\n";
				$v_content.= '	<frame name="mainFrame" src="../event/ads/audit2.php" marginwidth="0" marginheight="10" scrolling="auto" frameborder="0" >'."\n";
				$v_content.= '	</frameset>'."\n";
				$v_content.= '</frameset>'."\n";
				}else{
				$v_content.= '<iframe src='.$_config['VoteLinks'][$siteNo]['Link'].' width="100%" height="768"></iframe>';	
				}
				$v_content.= '</html>'."\n";
				echo $v_content;
				
			}else{
				jump_location("../errorpage");
			}//Not set
		}else{
			$this->vote->insertVoteInfo($this->voteVO);
			echo '<script type="text/javascript">alert("',VOTE_ID_NOT_EXISTS_MSG,'");window.close();</script>';	 
			exit();
		}//User Vote Info not Exist
		
		}else{
		$_SESSION['goto_link'] = 'index.php';
		echo '<script type="text/javascript">alert("',MART_RE_LOGIN_MSG,'");window.self.location=\'../member.php?do=login\';</script>'; 
		}
	}
	
	function voteSiteList(){
	global $_config;
	if($this->user->haslogin(true)){
	/*echo '
	<FONT color=#ffa500>
	Please vote for us every ',$_config['VoteTimeLimit'],' hours <br>
	',$_config['VoteAddPoint'],' Points / vote site links.
	</font>
	';*/
	}else{
	echo '
	<FONT color=#ffa500>
	<br>
	
	</font>
	';
	}
	echo '<br>'."\n";
	$this->getUserInfo();
	$this->voteVO->userID = $this->member->userID;
	$result = $this->vote->getUserVote($this->voteVO);
	if($result){
	$voteLimit = 60*60*$_config['VoteTimeLimit'];
	$dateDiff = $this->vote->date_TimeDiff("1970-02-01 00:00:00.000",date('Y-m-d H:i:s'));
	$voteDiff = $this->vote->date_TimeDiff("1970-02-01 00:00:00.000",date('Y-m-d H:i:s',strtotime($this->voteVO->Date)));
	$voteTime = $dateDiff-$voteDiff;
	}
	$voteLinksCount = count($_config['VoteLinks']);
	for($c=1;$c<=$voteLinksCount;$c++){
			if($c!= 5){
				$voteContent = '<!-- Begin '.$_config['VoteLinks'][$c]['TitleName'].' voting code -->'."\n";
				$voteContent.= '<a href="http://'.$_SERVER['HTTP_HOST'].'/member/vote.php?site='.$c.'" title="'.$_config['VoteLinks'][$c]['TitleName'].'"';
			if($this->user->haslogin(true) & !$result || $voteTime > $voteLimit){
				$voteContent.= ' target="_blank">'."\n";
			}else{
				$voteContent.= '>'."\n";
			}
				$voteContent.= '<img src="'.$_config['VoteLinks'][$c]['BtnLink'].'" alt="Ran Online Top 100" width="88" height="53" border="0"';
			//if($this->user->haslogin(true) & !$result || $voteTime > $voteLimit){
			//	$voteContent.= ' onclick="setTimeout(\'location.reload();\',2000);"></a>'."\n";
			//}else{
				$voteContent.= '></a>'."\n";
			//}
				$voteContent.= '<!-- End '.$_config['VoteLinks'][$c]['TitleName'].' voting code -->'."\n";
				$voteContent.= "\n";
				echo $voteContent;
			}
	}

		
		
	}



}

?>