<?php
include_once('../root.inc.php');
$checkUser = new UserController;
$checkUser->checkBtnUserID();
?>