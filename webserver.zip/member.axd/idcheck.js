 var HttPRequest = false;
	   function doCallAjax() {
		  HttPRequest = false;
		  if (window.XMLHttpRequest) { // Mozilla, Safari,...
			 HttPRequest = new XMLHttpRequest();
			 if (HttPRequest.overrideMimeType) {
				HttPRequest.overrideMimeType('text/html');
			 }
		  } else if (window.ActiveXObject) { // IE
			 try {
				HttPRequest = new ActiveXObject("Msxml2.XMLHTTP");
			 } catch (e) {
				try {
				   HttPRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			 }
		  } 
		  
		  if (!HttPRequest) {
			 alert('Cannot create XMLHTTP instance');
			 return false;
		  }
	
		  var url = 'member.axd/checkid.php';
		  var pmeters = "ctl00_ContentPlaceHolder_main_HyperLink3=" + encodeURI( document.getElementById("ctl00_ContentPlaceHolder_main_UserID").value);

			HttPRequest.open('POST',url,true);

			HttPRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			HttPRequest.setRequestHeader("Content-length", pmeters.length);
			HttPRequest.setRequestHeader("Connection", "close");
			HttPRequest.send(pmeters);
			
			
			HttPRequest.onreadystatechange = function()
			{

				if(HttPRequest.readyState == 3) 
				{
					document.getElementById("ctl00_ContentPlaceHolder_main_UserIDMessage").innerHTML = "..";
				}

				if(HttPRequest.readyState == 4) 
				{
						document.getElementById("ctl00_ContentPlaceHolder_main_UserIDMessage").innerHTML = HttPRequest.responseText;
				}
				
			}

	   }
