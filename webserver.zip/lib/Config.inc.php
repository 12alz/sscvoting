<?php
					  ini_set("mssql.textlimit" , "2147483647");
					  ini_set("mssql.textsize" , "2147483647");
					  
					  define('PAGE_TITLE','EnBabyRanYongAsia,RAN,philippines,RANONLINE,RAN private server,EPX');
					  
					  define('ENTER','admin');
					  
					  define('EVENT_TITLE','<font color="ffa500">God of Wars Helmets drop in the Club Wars, Come on! Hot events in every night!');
					  
					  define('MAINTENANCE_MODE', false);
					  define('LINK_FORUM','http://127.0.0.1/');
					  define('NAME_FORUM','http://127.0.0.1/');
					
					  define('ADODB_ASSOC_CASE', 0); 
					  define('ADODB_FETCH_DEFAULT',0);
					  
					  #include('items.php');
					  
					  //Don't touch these.....
					  $ADODB_FETCH_MODE 						= ADODB_FETCH_ASSOC;
					  $ADODB_CACHE_DIR		 					= "tmp/";
					 
					 
					  $_config									= array();
					  $_config['SystemName'] 					= "BossYongRanOnline,philippines,RAN ONLINE";
					  $_config['Copyright'] 					= "Copyright(c) 2016~present @ EnBabyRanYong Online, 6 Class Gaming Online Ltd. All Rights Reserved.";
					  $_config['Author']						= "EnBabyRanYong";
						
					  $_config['ServerName'] 					= "192.168.233.140:52025";
					  $_config['Login'] 						= "sa"; 
					  $_config['Password']						= "Janzs420!";
					  $_config['DbRanUser'] 					= "RanUser"; 
					  $_config['DbDebug']						= false;
					  $_config['DbDebugConsole'] 				= false;
					  
					  
					  $_config['AdminLogs'] 					= "userLogs";
					  $_config['Language'] 						= "English";
					  $_config['Admins'] 						= array('admin');
					  
					  $_config['GuildRegion']					= array(1 => "SG", 
					  												    2 => "MP", 
																		3 => "Phoenix", 
																		4 => "Trading",
																		5 => "Seige"
																		);
					  
					  $_config['ChaClass']						= array(1	=>  "Brawler(Boy)",		
																		64	=>  "Brawler(Girl)",		
																		2	=>  "Swordsman(Boy)",
																		128	=>  "Swordsman(Girl)",
																		4	=>  "Archer(Girl)",	
																		256	=>  "Archer(Boy)",
																		512	=>  "Shaman(Boy)",
																		8	=>  "Shaman(Girl)",
																		16	=>  "Extreme(Boy)",
																		32	=>  "Extreme(Girl)",
																		1024 =>  "Gunner(Boy)",
																		2048 =>  "Gunner(Girl)",	
																		4096 => "Assassin(Boy)",
																		8192 => "Assassin(Girl)",
																		16384 => "Magician(Boy)",
																		32768 => "Magician(Girl)"																	
					  													);
					 
					  $_config['ChaSchool']						= array(0 => "SG", 
					  												    1 => "MP", 
																		2 => "Phoenix", 
																		);
					  #-- Rankings Setting
					  $_config['HideGM']						= true;
					  $_config['RankLimit']						= 100;
					  $_config['RankPerPage']					= 25;
					  
					  #-- News List Configuration
					  $_config['NewsListPerPage']				= 24;
					  
					  #-- Main Configuration , Registration Settings
					  $_config['FormatExpCheck']				= true;
					  $_config['Md5Encrypt']					= false;	
					  $_config['AjaxMode'] 						= true;
					  $_config['ShopPurKeyIdentity'] 			= false;
					  
			 		  #-- Register Configuration
					  $_config['RegisterOpen'] 					= true;
					  $_config['RegisterAddPoint'] 				= 10000;
					  $_config['RegisterMaxUser'] 				= 10000;
					  $_config['RegisterAutoFillForm'] 			= array("Gender" 			=> "1", //0 = Female , 1 = Male
																		"FirstName" 		=> "Null",
																		"LastName" 			=> "Null",
																		"BirthYear" 		=> "1990",
																		"BirthMonth" 		=> "1",
																		"BirthDay" 			=> "2",
																		"Telephone" 		=> "0",
																		"Mobile" 			=> "0",
																		"City" 				=> "Null",
																		"Province" 			=> "Null",
																		"Post" 				=> "0",
																		"Address" 			=> "Null"
					  												);

					  #-- User Control Panel
					  
					  #-- Add Stats Limit Config.
					  $_config['AddStatsLimit'] 				= array("ChaPower" 		=> 39000,
					 													"ChaStrong" 	=> 39000,
																		"ChaStrength" 	=> 39000,
																		"ChaSpirit" 	=> 39000,
																		"ChaDex" 		=> 39000
					  													);	
					  
					  #-- Delete Items
					  $_config['DeleteItemsPay'] 				= 40;	

					  #-- Bingo
					  $_config['BingoPay'] 						= 10000;
					  #-- Bingo Wheel 1 ItemList
					  $_config['BingoItemList'] 				= array('ProductNumList'=> array( 
																							  9581,
																							  9974,
																							  13596,
																							  9355,
																							  3,
																							  8953,
																							  5353,
																							  4390
																							  )
																  		);
					   #-- Bingo Wheel 2 ItemList
					  $_config['BingoItemList2'] 				= array('ProductNumList'=> array( 
																							  13601,
																							  14297,
																							  14302,
																							  2,
																							  5354,
																							  6393,
																							  9968,
																							  4385
																							  )
																  		);
					   #-- Bingo Wheel 3 ItemList
					  $_config['BingoItemList3'] 				= array('ProductNumList'=> array( 
																							  14307,
																							  14312,
																							  9693,
																							  9966,
																							  4,
																							  5352,
																							  4376,
																							  3
																							  )
																  		);
					  #-- Bingo Wheel 4 Points List
					  $_config['BingoPointsList'] 				= array('PointsList'=> array(
																							 2000,
																							 10000,
																							 4000,
																							 5000,
																							 3000,
																							 15000,
																							 9000,
																							 8000
																							)
																		);
					  
					  $_config['VoteAllowAds']				   = false;
					  $_config['VoteTimeLimit'] 			   = 12;
					  $_config['VoteAddPoint'] 				   = 5;
					  $_config['VoteLinks'] 				   = array( '1' => array(
																	  		'Link'		=>'',
																		  	'BtnLink'	=>'http://www.gtop100.com/images/votebutton.jpg',
																			'TitleName' =>'GTop100'
																  					),
																 		'2' => array(
																	  		'Link'		=>'',
																		  	'BtnLink'	=>'http://topsite.gamesama.com/votebutton.png',
																			'TitleName' =>'GameSama'
																  					),
																  		'3'=> array(
																	  		'Link'		=>'',
																		  	'BtnLink'	=>'http://www.arena-top100.com/images/arena-top100.png',
																			'TitleName' =>'Arena-Top100'
																  					),
																  		'4' => array(
																	  		'Link'		=>'',
																		  	'BtnLink'	=>'http://www.xtremeTop100.com/votenew.jpg',
																			'TitleName' =>'XTremeTop100'
																  					)
																  );
					  #-- Edit Safe Pwd
					  $_config['EditSafePasswordPay'] 			= 5000;
					 
					  #-- GameTime
					  $_config['GameTimeEarnPoint']				= array('RequestTime' => 120,
					  													'AddPoint'	  => 1
																		);
					  #-- EPoints to Game Gold Conversion
					  $_config['EpointsToGold']					= array('RequestEpoints' => 1000000,
																		'AddGold' => 1000000
																	);
					  #-- Gold to EPoints Conversion
					  $_config['GoldToEP'] 						= array('RequestGold'   => 1000000000,
					  													'RequestPoints' => 1,
																		'AddPoint'      => 2
																	);

					  #-- Reborn to EPoints Conversion 
					  $_config['RBToEpointsPay']				= 1000;
					  $_config['RBToEpoints']					= array('RebornRequired' => 600,
																		'LevelRequired'  => 349,
																		'AddPoint'       => 50,

																	);
																	
					  #-- Purchase Reborn
					  $_config['PurchaseRebornStandard']		= 1000;
					  $_config['PurchaseRebornVip']				= 150;

					  #-- Deleted Character Recovery	
					  $_config['RecoverCharacterDeletedPay'] 	= 20000;

					  #-- TransSexual
					  $_config['TranssexualPay'] 				= 50000;

					  #-- ItemUpgrade Configuration
					  $_config['InventoryFilter']				= "all";//all, default
					  $_config['WebWarehouseMaxStorage']		= 5;
					  #-- Attack Configuration
					  $_config['ItemUpgradeAtk']				= array('Range' => array( 1 => array(0, 50, 'Rate'  => '100%'),
					  																	  2 => array(51,76, 'Rate'  => '100%')), 
					  													'MaxGrade'  => 75, 
					  													'Addval' 	=> 1, 
					  													'Pay' 	 	=> 50,
																		'AddonName' => 'Attack'
					 													);
																		
					  $_config['ItemUpgradeAtkRate']			= array('Range' => array( 1 => array(0, 50, 'Rate'  => '100%'),
					  																	  2 => array(51,101, 'Rate'  => '100%')), 
					  													'MaxGrade' 	=> 100, 
					  													'Addval' 	=> 1, 
					  													'Pay' 	 	=> 10000,
																		'AddonName' => 'Attack Rate'
					 													);
					  #-- Defense Configuration												
					  $_config['ItemUpgradeDef']				= array('Range' => array( 1 => array(0, 36, 'Rate'  => '100%')), 
					  													'MaxGrade' 	=> 35, 
					  													'Addval' 	=> 1, 
					  													'Pay' 	 	=> 50,
																		'AddonName' => 'Defense'
					 													);
																		
					  $_config['ItemUpgradeDefRate']			= array('Range' => array( 1 => array(0, 20, 'Rate'  => '100%'),
					  																	  2 => array(21,51, 'Rate'  => '100%')), 
					  													'MaxGrade' 	=> 50, 
					  													'Addval' 	=> 1, 
					  													'Pay' 	 	=> 10000,
																		'AddonName' => 'Defense Rate'
					 													);
					  #-- HP
					  $_config['ItemUpgradeHP']					= array('Range' => array( 1 => array(0,100,    'Rate'  => '100%'),
					  																	  2 => array(200,600, 'Rate'  => '100%')), 
					  													'MaxGrade' 	=> 500, 
					  													'Addval' 	=> 100, 
					  													'Pay' 	 	=> 100,
																		'AddonName' => 'HP'
					 													);
																		
					  $_config['ItemUpgradeHMSRate']			= array('Range' => array( 1 => array(0,10,  'Rate'  => '100%'),
					  																	  2 => array(11,21, 'Rate'  => '100%')), 
					  													'MaxGrade' 	=> 20, 
					  													'Addval' 	=> 1, 
					  													'Pay' 	 	=> 100,
																		'AddonName' => '--'
					 													);
					  #-- Hit Rate
					  $_config['ItemUpgradeHitRate']			= array('Range' => array( 1 => array(0,50,  'Rate'  => '100%'),
					  																	  2 => array(51,101, 'Rate'  => '100%')), 
					  													'MaxGrade' 	=> 100, 
					  													'Addval' 	=> 1, 
					  													'Pay' 	 	=> 10000,
																		'AddonName' => 'Hit rate'
					 													);
					  
					  #-- Publicity Settings
					  $_config['PublicityRbRequest'] 			= 50;
					  $_config['PublicityAddPoint'] 			= 10;
					 
					  #-- Reborn Settings
					  $_config['RebornLimit'] 					= 50;
					  $_config['RebornSaveMap'] 				= "Market"; 
					  $_config['RebornRange'] 					= array("Junior"   => array(1, 10), 
														 				"Middle"   => array(11, 30),
														 				"Advanced" => array(31, 50)
						   								 				);
					  $_config['RebornStandard'] 				= array("Junior"   => array("Lvl" => "100", "Pay" => "1"), 
														 				"Middle"   => array("Lvl" => "180", "Pay" => "100000"),
														 				"Advanced" => array("Lvl" => "200", "Pay" => "500000"), 
														 				"AddStats" => "25"
						   								 				);
																		
					  $_config['RebornVip'] 					= array("Junior"   => array("Lvl" => "80",  "Pay"  => "1000000"), 
														 				"Middle"   => array("Lvl" => "160", "Pay"  => "1000000"),
														 				"Advanced" => array("Lvl" => "180", "Pay"  => "1000000"), 
														 				"AddStats" => "50"
						   								 				);
					  #-- Mart Configuration
					  $_config['ProductCategory']				= array('1' => "Super Jewelry",
																		'2' => "Wing",
																		'3' => "Consumables",
																		'4' => "Modeling",																					
																		'5' => "Vehicle Parts",
																		'6' => "Pet Item",																
																		);
					  #-- Reset Stats Point
					  $_config['ResetStatsPointPay'] 			= 25000000;	//Gold
					  
					  #-- Reset PK
					  $_config['ResetPK'] 						= array("AddValue" => 20,
					  													"Pay"      => 500
																		);
																		
																		
					  #-- ChangeClass
					  $_config['ChangeClassCheck']				= true;
					  $_config['ChangeClassPay']				= 5000;
					  $_config['ClassSkillsList'] 				= array('Brawler' => //Male ,Female Brawler
																		array(
																		array('Main'=>0,'Sub'=>array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24)), 
																		array('Main'=>1,'Sub'=>array(0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26)),
																		array('Main'=>2,'Sub'=>array(0,1,2,3,4,5,6,8,9,11,12,13,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29)), 
																		array('Main'=>3,'Sub'=>array(0,2,3,4,5,6,7,8,9,10))
																		
																		),
																		'Swordsman' => //Male ,Female Swordsman
																		array(
																		array('Main'=>4,'Sub'=>array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23)), 
																		array('Main'=>5,'Sub'=>array(0,1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26)), 
																		array('Main'=>6,'Sub'=>array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23)), 
																		array('Main'=>7,'Sub'=>array(0,3,4,5,6,7,8,9,10))
																		
																		),
																		'Archer' => //Male ,Female Archer
																		array(
																		array('Main'=>8,'Sub'=>array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24)), 
																		array('Main'=>9,'Sub'=>array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25)), 
																		array('Main'=>10,'Sub'=>array(0,1,2,3,5,6,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28)), 
																		array('Main'=>11,'Sub'=>array(0,1,3,4,6,7,8,9,10,11))
																		
																		),
																		'Shaman' => //Male ,Female Shaman
																		array(
																		array('Main'=>12,'Sub'=>array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25)), 
																		array('Main'=>13,'Sub'=>array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25)), 
																		array('Main'=>14,'Sub'=>array(0,1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30)),
																		array('Main'=>15,'Sub'=>array(2,3,4,5,6,7,8))
																		
																		)
																		,
																		'Extreme' => //Male ,Female Extreme
																		array(
																		array('Main'=>30,'Sub'=>array(0,1,2,3,4,5,6,7,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,29,30,31,32,34,36,37,39)), 
																		array('Main'=>31,'Sub'=>array(0,1,2,3,4,5,6,7,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,28,30,31,32,33,37,38,39)), 
																		array('Main'=>32,'Sub'=>array(0,1,2,3,4,5,6,7,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,28,31,32,36,37,38,39)), 
																		array('Main'=>33,'Sub'=>array(0,1,2,3,4,5,6,7,8,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,31,32,35,37)), 
																		
																		),
																		'SkillLevel' => 0
																		);

					$_config['included_item']				= array(
																'types' => array(8),
																'item_ids' => array('369_122')
															);
															
															
															
					//added  by janzs420											
					//$_config['ITEM_SUIT'] = $itemls;
					$_config['ITEM_SUIT'] = array('260_009','260_010','136_002','136_18','136_19','136_45','136_46','136_47','362_194','362_193','362_192','362_385','275_21','202_35','260_165','260_250','202_36','260_166','260_251','202_37','260_167','260_252','202_38','260_168','260_253','257_108','257_109','257_110','157_89','157_90','157_91','157_92','362_207','362_210','362_213','362_208','362_211','362_214','362_200','362_203','362_198','362_201','362_204','361_155','362_180','362_181','362_50','362_230','362_233','275_21','275_22','275_23','275_24','275_82','275_83','275_55','275_58','275_63','275_64','275_55','275_63','275_64','275_64','275_58','275_97','275_94','275_89','169_1','169_2','169_3','169_4','169_5','169_6','169_7','169_8','169_9','169_10','169_11','169_12','169_13','169_14','169_15','169_16','169_17','169_18','169_19','169_20','169_21','169_22','169_23','169_24','169_25','169_26','169_27','169_28','169_29','169_30','169_31','169_32','169_33','169_34','169_35','169_36','260_320','260_321','260_322','260_323','362_45','362_46','362_47','362_48','257_97','257_98','257_99','257_100','362_51','370_192','370_182','202_73','203_84','157_68','157_69','61_108','157_67','257_2','360_52','360_57','362_180','362_181','362_50','362_51','360_58','361_150','361_151','361_152','361_153','361_154','349_69','349_73','349_74','157_62','157_79','275_81','275_82','275_83','275_84','275_85','275_86','275_87','275_88','275_104','361_29','361_30','361_31','361_32','361_33','361_34','361_35','361_36','361_37','361_38','361_39','361_40','361_41','361_42','36_63','361_64','361_65','361_66','361_67','361_68','361_69','361_70','361_71','361_72','361_73','361_74','361_75','361_76','26_1','267_2','267_3','267_4','267_5','267_6','267_7','267_8','267_9','267_10','267_11','27_55','275_56','275_57','275_58','275_59','275_60','275_61','275_62','275_63','275_64','275_65','26_1','268_2','268_3','268_4','268_5','268_6','268_7','268_8','268_9','268_10','268_11','20_88','203_89','203_90','203_91','203_92','203_93','203_94','203_95','203_96','203_97','203_98','20_77','203_78','203_79','203_80','203_81','203_82','203_83','203_84','203_85','203_86','203_87','20_18','202_19','202_20','202_27','202_28','202_29','202_30','202_31','202_32','202_33','202_34','20_7','202_8','202_9','202_10','202_11','202_12','202_13','202_14','202_15','202_16','202_17','15_9','159_20','159_31','159_42','159_53','159_64','159_75','159_86','159_97','159_108','159_119','159_122','159_123','159_124','159_125','159_126','159_127','159_128','159_129','159_130','159_131','159_132','159_133','159_134','159_135','159_136','159_137','159_138','159_139','159_140','159_141','159_142','159_143','159_144','159_145','159_146','159_147','159_148','159_149','362_45','362_46','362_47','362_48','157_78','157_80','157_81','157_82','157_74','157_75','157_76','157_77','275_29','275_30','275_31','275_32','275_21','275_22','275_23','275_24','263_33','263_34','263_35','263_36','263_37','263_38','263_39','263_40','263_41','263_42','263_43','263_44','263_45','263_46','263_47','263_48','263_49','263_50','263_51','260_250','260_251','260_252','260_253','260_165','260_166','260_167','260_168','157_53','157_54','157_55','157_56','202_35','202_36','202_37','202_38','202_39','202_40','202_41','202_42','202_43','202_44','202_45','202_46','202_47','202_48','202_49','202_50','202_51','202_52','202_53','202_54','202_77','202_78','202_79','202_80','202_81','51_18','52_18','54_18','55_18','57_18','58_18','98_80','98_80','98_81','98_81','98_82','98_82','98_83','98_83','98_84','98_84','98_85','98_85','98_86','98_86','98_87','98_87','98_88','98_88','98_89','98_89','98_90','98_90','98_91','98_91','98_92','98_92','98_93','98_93','98_94','98_94','98_95','98_95','98_96','98_96','98_97','99_89','99_89','99_90','99_90','99_91','99_91','99_92','99_92','99_93','99_93','99_94','99_95','99_96','100_180','100_181','100_182','100_182','100_183','100_183','100_184','100_184','100_185','100_185','100_186','100_187','101_81','101_82','101_83','101_84','101_85','101_86','101_87','101_88','101_135','101_135','101_136','101_136','101_137','101_137','101_138','101_138','101_139','101_139','101_140','101_140','101_141','101_141','101_142','260_076','260_154','260_077','260_155','260_078','260_156','260_079','260_157','260_080','260_158','260_81','260_159','260_82','260_160','260_83','260_161','260_84','260_162','260_85','260_163','260_86','260_164','260_87','260_165','260_88','260_166','260_89','260_167','260_90','260_168','260_91','260_169','260_92','260_170','260_93','260_171','260_94','260_172','260_95','260_173','260_96','260_174','260_97','260_138','260_216','260_139','260_217','260_140','260_218','260_141','260_143','260_221','260_144','260_222','260_145','260_223','260_146','260_148','260_226','260_149','260_227','260_150','260_228','260_151','260_169','260_247','260_170','260_248','260_171','260_249','260_172','260_250','260_173','260_184','260_262','260_185','260_263','260_186','260_264','260_187','260_265','260_188','260_245','260_323','260_246','260_324','260_247','260_325','260_248','260_326','260_249','263_141','263_64','263_142','263_65','263_143','263_66','263_144','263_67','263_145','263_68','263_146','263_69','264_0','263_70','264_1','263_71','264_2','263_72','264_3','263_073','264_4','263_74','264_5','263_75','264_6','263_76','264_7','263_77','263_83','264_14','263_84','264_15','263_85','264_16','263_86','265_21','265_105','265_22','265_106','265_23','265_107','265_24','265_108','265_25');
					
					$_config['rewardsRB_LVL'] = array(
						1 => array(
							'rb'=>50,
							'lvl'=>1,
							'reward'=> array(
								array(
									'type' => 'box',
									'pcs' => 1,
									'id' => '001_207',
									'uiid' => '001_207',
									'pNum' => '81'
								),
							)
						),
							
					);				
					  
?>
