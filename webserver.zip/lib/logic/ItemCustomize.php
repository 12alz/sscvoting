<?php
class ItemLogic
{
    var $chaInfoDAO;
    var $itemCustomizeDAO;
	var $shopItemMapDAO;
	var $chaRebornListDAO;
	var $userInfoDAO;
	
	function ItemLogic() {
	$this->userInfoDAO = dao_getDAO("userinfo");
	$this->chaInfoDAO = dao_getDAO("chainfo");
	$this->itemCustomizeDAO = dao_getDAO("itemcustomize");
	$this->shopItemMapDAO = dao_getDAO("shopitemmap");
	$this->chaRebornListDAO = dao_getDAO("charebornlist");
	}
	#-- Private Function
	function dec2hex($dec,$digits=true) {
			$hex =  '';
			$sign = $dec < 0 ? false : true;
			while ($dec) {
				$hex .= dechex(abs(bcmod($dec, '16')));
				$dec = bcdiv($dec, '16', 0);
			}
			if ($digits) {
				while (strlen($hex) < $digits) { $hex .= '0'; }
			}
			if ($sign) {
				return strrev($hex);
			}
			for ($i = 0; isset($hex[$i]); $i++) { $hex[$i] = dechex(15 - hexdec($hex[$i])); }
			for ($i = 0; isset($hex[$i]) && $hex[$i] == 'f'; $i++) { $hex[$i] = '0'; }
			if (isset($hex[$i])) { $hex[$i] = dechex(hexdec($hex[$i]) + 1); }
			return strrev($hex);
	} 
	function hex2dec($hex){
		$hex = preg_replace('/[^0-9A-Fa-f]/', '', $hex);
		$dec = hexdec($hex);
		$max = pow(2, 4 * (strlen($hex) + (strlen($hex) % 2)));
		$_dec = $max - $dec;
		return $dec > $_dec ? -$_dec : $dec;
	}
	function itemFilter($type,$info){
		
		switch ($type){
					
			case "all":
				return true;
				break;	
					
			default:
				if (($this->check_ItemAddon($info,1,true) || $this->check_ItemAddon($info,2,true) || $this->check_ItemAddon($info,3,true) || $this->check_ItemAddon($info,5,true) || $this->check_ItemAddon($info,11,true) || ($info['Damage']!=0 & ($this->check_ItemAddonSlot($info,false,false,true,false) || $this->check_ItemAddonSlot($info,true,false,false,false) || $this->check_ItemAddonSlot($info,false,true,false,false) ))  || ($info['Defense']!=0 & ($this->check_ItemAddonSlot($info,false,false,true,false) || $this->check_ItemAddonSlot($info,true,false,false,false)|| $this->check_ItemAddonSlot($info,false,true,false,false)  ))  ) ){ 
				return true;
				}
				break;	
			
		}
		
		return false;
		
	}
	function itemAddonValue($item){
		for($d=0;$d<4;$d++){
			switch ($item['Rv'.($d+1).'Slot']){
				case 1:
					$info['Atkrate'] = $item['Rv'.($d+1)];
					$info['Atkrate_SlotNo'] = 1;
					break;
				case 2:
					$info['Defrate'] = $item['Rv'.($d+1)];
					$info['Defrate_SlotNo'] = 2;
					break;
				case 3:
					$info['Hitrate'] = $item['Rv'.($d+1)];
					$info['Hitrate_SlotNo'] = 3;
					break;	
				case 5:
					$info['HP'] = $item['Rv'.($d+1)];
					$info['HP_SlotNo'] = 5;
					break;
				/*case 6:
					$info['Makenum'] = $item['Rv'. ($d+1)];
					$info['Qty_SlotNo'] = 6;
					break;*/
				//case 8: #-- HP Rate Only - Disabled
					//$info['HPrate'] = $item['Rv'.($d+1)];
					//$info['HPrate_SlotNo'] = 8;
					//break;	
				case 11: #-- HP+MP+SP Recovery Rate
					$info['HMSrate'] = $item['Rv'.($d+1)];
					$info['HMSrate_SlotNo'] = 11;
					break;
				}
		}	
			return $info;
	}
	function inventorySlot($invenLine){
	 switch($invenLine){
		  case 0:
		  $slotNo = array('1'=>array(1,5,9,13,17,21),'2'=>array(4,8,12,16,20,24));
		  break;
			  
		  case 1:
		  $slotNo = array('1'=>array(1,6,11,16,21,26),'2'=>array(5,10,15,20,25,30));
		  break;
		  
		  case 2:
		  $slotNo = array('1'=>array(1,7,13,19,25,31),'2'=>array(6,12,18,24,30,36));
		  break;	
		  
		  case 3:
		  $slotNo = array('1'=>array(1,8,15,22,29,36),'2'=>array(7,14,21,28,35,42));
		  break;
		  
		  case 4:
		  $slotNo = array('1'=>array(1,9,17,25,33,41),'2'=>array(8,16,24,32,40,48));
		  break;	
		  
		  case 5:
		  $slotNo = array('1'=>array(1,10,19,28,37,46),'2'=>array(9,18,27,36,45,54));
		  break;	
		}
	 return $slotNo;
		
	}
	function getitemAddonValNames($infoArray,$addonValue=false){
			if($infoArray['Damage'] > 0){
				if($addonValue){
				  return $infoArray['Damage']; 
				}else
				return "Weapon";
			}elseif($infoArray['Defense'] > 0){
				if($addonValue){
				   return $infoArray['Defense']; 
				}else
				return "Armor";
				  
			}else{
				if($addonValue){
				  return 0;  
				}else
				return "Other";	
			}
	}
	function maxItemValue($info){
			
		$iatkMax = 	$this->item_MaxGrade(118,$info['Damage']);
		$iatkrateMax = $this->item_MaxGrade(1,$info['Atkrate']);
		$idefMax = $this->item_MaxGrade(119,$info['Defense']);
		$idefrateMax = $this->item_MaxGrade(2,$info['Defrate']);
		$ihpMax = $this->item_MaxGrade(5,$info['HP']);
		$ihmsrateMax = $this->item_MaxGrade(11,$info['HMSrate']);
		$ihitrateMax = $this->item_MaxGrade(3,$info['Hitrate']);
	
	 //Weapon
	 if (($info['Damage']!=0) || (($this->check_ItemAddon($info,1) & $info['Defrate']==0) & $this->check_ItemAddonSlot($info,false,true,false,false))){
		if($iatkMax || $iatkrateMax || $ihpMax || $ihmsrateMax || $ihitrateMax){
			return true;
		}
	 }else
	 //Armor
	 if (($info['Defense']!=0) || (($this->check_ItemAddon($info,2) & $info['Atkrate']==0) & $this->check_ItemAddonSlot($info,false,true,false,false))){ 
		if($idefMax || $idefrateMax || $ihpMax || $ihmsrateMax){
			return true;
		}
	 }else
	 if (($info['Atkrate']==0 & $info['Defrate']==0)){ 
		if($ihpMax || $ihitrateMax){
			return true;
		}
	 }
	 	return false;

	}
	function subOptionList($infoArray){
		$itemOptionList = $this->item_OptionList($infoArray);
		
		if($itemOptionList['Attack']) {
			echo '<option value="12">Attack</option>'; 
		} 
		
		if($itemOptionList['Atkrate']) {
		   echo '<option value="1">Attack Rate</option>'; 
		}
		
		if($itemOptionList['Defense']) {
			echo '<option value="13">Defense</option>'; 
		} 
		
		if($itemOptionList['Defrate']) {
			echo '<option value="2">Defense Rate</option>';
		}
		
		if($itemOptionList['HP']) {
			echo '<option value="5">HP</option>';
		} 
		
		if($itemOptionList['HMSrate']) {
			echo '<option value="11">HP/MP/SP Recovery</option>';
		} 
		
		if($itemOptionList['Hitrate']) {
			echo '<option value="3">Hit Rate</option>'; 
		} 
		
		
	}
	#----------- Item Upgrade --------------- #
	function addon_GradeRate($addonName,$resultval){
		
		if($resultval < 0){
			$result = (-$resultval)+(-$resultval);
		}else{
			$result = $resultval;
		}
		switch ($result){
			case $result < $addonName['Range']['1'][0]:
			case $result < $addonName['Range']['1'][1]:
			$grade['Rate'] = str_replace("%","",$addonName['Range']['1']['Rate']);
			break;
			
			case $result < $addonName['Range']['2'][0]:
			case $result < $addonName['Range']['2'][1]:
			$grade['Rate'] = str_replace("%","",$addonName['Range']['2']['Rate']);
			break;
		}
		
		return $grade;
	}
	function customizeItem($infoArray,$subOption){
	global $_config;	  
	$isAddonValue = $this->item_OptionList($infoArray);
	
	switch ($subOption){
		
		  case 12: //Attack Upgrade	
					if($isAddonValue['Attack']) {
						$addAtkResult = strtoupper(dechex($infoArray['Damage']+$_config['ItemUpgradeAtk']['Addval']));
					
						$itemStartData = substr($infoArray['Data'],0,90);
						$itemEndData = substr($infoArray['Data'],92);
						$item['CurrentValue'] = $infoArray['Damage'];
						$item['Result'] = hexdec($addAtkResult);
						  
						if(strlen($addAtkResult)!=2){
							$item['Data'] = strtoupper($itemStartData.'0'.$addAtkResult.$itemEndData);
						}else{
							$item['Data'] = strtoupper($itemStartData.$addAtkResult.$itemEndData);
						}
					
						$item['AddonType'] = $_config['ItemUpgradeAtk'];
						// echo '<pre>';
						// yyyvar_dump($item);exit();
					}else{
						jump_location('errorpage');
					}
				  break;
				  
		  case 1: //Attack Rate Upgrade	
				  if($isAddonValue['Atkrate']){ 
					$addAtkrateResult = $this->decode_ItemAddon($infoArray,1,$infoArray['Atkrate'],$_config['ItemUpgradeAtkRate']['Addval']);
					$resultSet = $addAtkrateResult['Result'];
					$item['CurrentValue'] = $resultSet['CurrentValue'];
					$item['Result'] = $resultSet['Total'];
					$item['Data'] = $addAtkrateResult['Data'];
					$item['AddonType'] = $_config['ItemUpgradeAtkRate'];
					}else{
					  jump_location('errorpage');
					}
				  break;
		  case 13: //Defense
				   if ($isAddonValue['Defense']){ 
					$addDefResult = strtoupper(dechex($infoArray['Defense']+$_config['ItemUpgradeDef']['Addval']));
					
					$itemStartData = substr($infoArray['Data'],0,92);
					$itemEndData = substr($infoArray['Data'],94);
					
					$item['CurrentValue'] = $infoArray['Defense'];
					$item['Result'] = hexdec($addDefResult);
					
					if(strlen($addDefResult)!=2){
					$item['Data'] = strtoupper($itemStartData.'0'.$addDefResult.$itemEndData);
					}else{
					$item['Data'] = strtoupper($itemStartData.$addDefResult.$itemEndData);
					}
					$item['AddonType'] = $_config['ItemUpgradeDef'];
					}else{
					  jump_location('errorpage');
					}
				break;
		  case 2: //Defense Rate
				  if($isAddonValue['Defrate']){ 
					$addDefrateResult = $this->decode_ItemAddon($infoArray,2,$infoArray['Defrate'],$_config['ItemUpgradeDefRate']['Addval']);
					$resultSet = $addDefrateResult['Result'];
					$item['CurrentValue'] = $resultSet['CurrentValue'];
					$item['Result'] = $resultSet['Total'];
					$item['Data'] = $addDefrateResult['Data'];
					$item['AddonType'] = $_config['ItemUpgradeDefRate'];
					}else{
					  jump_location('errorpage');
					}
				  break;
		  case 5: //HP
				  if($isAddonValue['HP']){ 
					$addHPResult = $this->decode_ItemAddon($infoArray,5,$infoArray['HP'],$_config['ItemUpgradeHP']['Addval']);
					$resultSet = $addHPResult['Result'];
					$item['CurrentValue'] = $resultSet['CurrentValue'];
					$item['Result'] = $resultSet['Total'];
					$item['Data'] = $addHPResult['Data'];
					$item['AddonType'] = $_config['ItemUpgradeHP'];
					}else{
					  jump_location('errorpage');
					}
				  break;
		  case 11: //HP+MP+SP Recovery Rate	
				  if($isAddonValue['HMSrate']){ 
					$addHMSrateResult = $this->decode_ItemAddon($infoArray,11,$infoArray['HMSrate'],$_config['ItemUpgradeHMSRate']['Addval']);
					$resultSet = $addHMSrateResult['Result'];
					$item['CurrentValue'] = $resultSet['CurrentValue'];
					$item['Result'] = $resultSet['Total'];
					$item['Data'] = $addHMSrateResult['Data'];
					$item['AddonType'] = $_config['ItemUpgradeHMSRate'];
					}else{
					  jump_location('errorpage');
					}
				  break;
		  case 3: //Hit Rate	
				  if($isAddonValue['Hitrate']){ 
					$addHitrateResult = $this->decode_ItemAddon($infoArray,3,$infoArray['Hitrate'],$_config['ItemUpgradeHitRate']['Addval']);
					$resultSet = $addHitrateResult['Result'];
					$item['CurrentValue'] = $resultSet['CurrentValue'];
					$item['Result'] = $resultSet['Total'];
					$item['Data'] = $addHitrateResult['Data'];
					$item['AddonType'] = $_config['ItemUpgradeHitRate'];
					}else{
					  jump_location('errorpage');
					}
				  break;
				  
		  case -1: 
				echo '<script type="text/javascript">alert("',ITEM_UPGRADE_SELECT_PROPERTIES_ERR_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.(int)$_GET['cid'].'\';</script>'; 
		  		break;
		  
		  default: 
		  		jump_location('errorpage'); 
		  		break;
	}
			return $item;
	}
	#-- Public Function
	function count_ItemFilter($data,$filterMode=true){
				$totalItems = count($data);
				for($i=0;$i<$totalItems;$i++){
					if(isset($data[$i]['Data'])){
					$lblNo++;	
					$count[] = $this->item_decode($data[$i]['Data'],$data[$i]['Num'],$lblNo,$filterMode);
					}
				}
			return $count;
	}
	function customize_ItemValue($addonType,$addonValue,$addValue){
	
	  $value = $this->item_Value($addonValue);
	  
	  switch ($addonType){
		//Attack Rate
		case 1:
			$addon['Add'] = $value+($addValue*100);
			$addon['Total'] = $addon['Add']/100;
			$addon['CurrentValue'] = $value/100;
			break;
	  
		//Defense Rate
		case 2:
			$addon['Add'] = $value+($addValue*100);
			$addon['Total'] = $addon['Add']/100;
			$addon['CurrentValue'] = $value/100;
			break;
			
		//Hit Rate
		case 3:
			$addon['Add'] = $value+($addValue*100);
			$addon['Total'] = $addon['Add']/100;
			$addon['CurrentValue'] = $value/100;
			break;
			
		//HP
		case 5:
			$addon['Add'] = $value+$addValue;
			$addon['Total'] = $addon['Add'];
			$addon['CurrentValue'] = $value;
			break;
			
		//HP+MP+SP
		case 11:
			$addon['Add'] = $value+($addValue*100);
			$addon['Total'] = $addon['Add']/100;
			$addon['CurrentValue'] = $value/100;
			break;
	  }
			if($addon['Add']<0){
			$addon['ResultValue'] = substr(dechex($addon['Add']),4,4);
			}else{
			$addon['ResultValue'] = dechex($addon['Add']);
			}
			
			return $addon;
	}
	/*POINT ABC DECODE ITEMVALUES*/
	function decode_ItemValues2($info){
		
		if($info['Name']){
			$decode['Name'] = $info['Name'];
		}else{
			$decode['Name'] = "";	
		}
		if(($info['Atkrate_SlotNo']==1) || ($info['Damage']!=0) ){
			$decode['Damage'] = $info['Damage'];
		}else{
			$decode['Damage'] = "--";	
		}
		
		if(($info['Defrate_SlotNo']==2) || ($info['Defense']!=0) ){
			$decode['Defense'] = $info['Defense'];
		}else{
			$decode['Defense'] = "--";	
		}
				
		if($info['Atkrate_SlotNo']==1){
			$decode['Atkrate'] = $this->item_Value($info['Atkrate'])/100;
		}else{
			$decode['Atkrate'] = "--";	
		}
		
		if($info['Defrate_SlotNo']==2){
			$decode['Defrate'] = $this->item_Value($info['Defrate'])/100;
		}else{
			$decode['Defrate'] = "--";	
		}
		
		if($info['HP_SlotNo']==5){
			$decode['HP'] = $info['HP'];
		}else{
			$decode['HP'] = "--";	
		}

		if(($info['Qty_SlotNo'] == 6) || ($info['Makenum']!=0)){
			$decode['Makenum'] = $info['Makenum'];
		}else{
			$decode['Makenum'] = "--";
		}

		if($info['HMSrate_SlotNo']==11){
			$decode['HMSrate'] = $this->item_Value($info['HMSrate'])/100;
		}else{
			$decode['HMSrate'] = "--";	
		}
	
		if($info['Hitrate_SlotNo']==3){
			$decode['Hitrate'] = $this->item_Value($info['Hitrate'])/100;
		}else{
			$decode['Hitrate'] = "--";	
		}
		return $decode;
	
	}
	function decode_ItemValues($info){
		if($info['Name']){
			$decode['Name'] = $info['Name'];
		}else{
			$decode['Name'] = "--";	
		}
		if(($info['Atkrate_SlotNo']==1) || ($info['Damage']!=0) ){
			$decode['Damage'] = $info['Damage'];
		}else{
			$decode['Damage'] = "--";	
		}
		
		if(($info['Defrate_SlotNo']==2) || ($info['Defense']!=0) ){
			$decode['Defense'] = $info['Defense'];
		}else{
			$decode['Defense'] = "--";	
		}
				
		if($info['Atkrate_SlotNo']==1){
			$decode['Atkrate'] = $this->item_Value($info['Atkrate'])/100;
		}else{
			$decode['Atkrate'] = "--";	
		}
		
		if($info['Defrate_SlotNo']==2){
			$decode['Defrate'] = $this->item_Value($info['Defrate'])/100;
		}else{
			$decode['Defrate'] = "--";	
		}
		
		if($info['HP_SlotNo']==5){
			$decode['HP'] = $info['HP'];
		}else{
			$decode['HP'] = "--";	
		}

		if(($info['Qty_SlotNo'] == 6) || ($info['Makenum']!=0)){
			$decode['Makenum'] = $info['Makenum'];
		}else{
			$decode['Makenum'] = "--";
		}

		if($info['HMSrate_SlotNo']==11){
			$decode['HMSrate'] = $this->item_Value($info['HMSrate'])/100;
		}else{
			$decode['HMSrate'] = "--";	
		}
	
		if($info['Hitrate_SlotNo']==3){
			$decode['Hitrate'] = $this->item_Value($info['Hitrate'])/100;
		}else{
			$decode['Hitrate'] = "--";	
		}
		return $decode;
	
	}
	function decode_ItemAddonValue($strval){
		
			switch ($strval){
				case strlen($strval)==0:
				  $newValue = '0'.$strval.'00';
				  break;
				
				case strlen($strval)==1:
				  $newValue = '0'.$strval.'00';
				  break;
				
				case strlen($strval)==2:
				  $newValue = $strval.'00';
				  break;
				
				case strlen($strval)==3:
				  $valuecut = substr($strval,1,2);
				  $valueEnd = '0'.substr($strval,0,1);
				  $newValue = $valuecut.$valueEnd;
				  break;
				
				case strlen($strval)==4:
				  $valuecut = substr($strval,0,2);
				  $valueEnd = substr($strval,2,3);
				  $newValue = $valueEnd.$valuecut;
				  break;
						
		}		
			return 	$newValue;
	}

	function decode_ItemAddon($infoArray,$addonType,$addonValue,$addValue){
		
				if((int)$infoArray['Rv1Slot']==$addonType || (int)$infoArray['Rv1Slot'] == 0){
					$rvtype = dechex($addonType);
					$rvstartData = substr($infoArray['Data'],0,105);
					$rvmidData = substr($infoArray['Data'],106,6);
					
					$valueResult = $this->customize_ItemValue($addonType,$addonValue,$addValue);
					
					$rvvalue = $this->decode_ItemAddonValue($valueResult['ResultValue']);
					$rvendData = substr($infoArray['Data'],116);
					
					#Data
					$randopt['Data'] = strtoupper($rvstartData.$rvtype.$rvmidData.$rvvalue.$rvendData);
					$randopt['Result'] = $valueResult;
	
				}else
				if((int)$infoArray['Rv2Slot']==$addonType || (int)$infoArray['Rv2Slot'] == 0){
					$rvtype = dechex($addonType);
					$rvstartData = substr($infoArray['Data'],0,107);
					$rvmidData = substr($infoArray['Data'],108,8);
					
					$valueResult = $this->customize_ItemValue($addonType,$addonValue,$addValue);
					
					$rvvalue = $this->decode_ItemAddonValue($valueResult['ResultValue']);
					$rvendData = substr($infoArray['Data'],120);
					
					#Data
					$randopt['Data'] = strtoupper($rvstartData.$rvtype.$rvmidData.$rvvalue.$rvendData);
					$randopt['Result'] = $valueResult;
	
				}else
				if((int)$infoArray['Rv3Slot']==$addonType || (int)$infoArray['Rv3Slot'] == 0){
					
					$rvtype = dechex($addonType);
					$rvstartData = substr($infoArray['Data'],0,109);
					$rvmidData = substr($infoArray['Data'],110,10);
					
					$valueResult = $this->customize_ItemValue($addonType,$addonValue,$addValue);
					
					$rvvalue = $this->decode_ItemAddonValue($valueResult['ResultValue']);
					$rvendData = substr($infoArray['Data'],124);
					
					#Data
					$randopt['Data'] = strtoupper($rvstartData.$rvtype.$rvmidData.$rvvalue.$rvendData);
					$randopt['Result'] = $valueResult;
	
				}else
				if((int)$infoArray['Rv4Slot']==$addonType || (int)$infoArray['Rv4Slot'] == 0){
					
					$rvtype = dechex($addonType);
					$rvstartData = substr($infoArray['Data'],0,111);
					$rvmidData = substr($infoArray['Data'],112,12);
					
					$valueResult = $this->customize_ItemValue($addonType,$addonValue,$addValue);
					
					$rvvalue = $this->decode_ItemAddonValue($valueResult['ResultValue']);
					$rvendData = substr($infoArray['Data'],128);
					
					#Data
					$randopt['Data'] = strtoupper($rvstartData.$rvtype.$rvmidData.$rvvalue.$rvendData);
					$randopt['Result'] = $valueResult;
	
				}else{
					$randopt = false;
				}
				return $randopt;
		
	}
	function decode_ItemData($data){
		
		$itemStorage = strtoupper(bin2hex($data));
		if (substr($itemStorage,0,2)=='0x') 
		$itemStorage = strtoupper(substr($itemStorage,2));
		return $itemStorage;
	}
	function get_ItemData($data){
		$items = $this->item_view($data,false,false);	
		$totalItems = count($items);
		for ($r=0;$r<$totalItems;$r++){
			$itemNo++;
			$itemResult[] = array('No' => $itemNo, 'Data' => $items[$r]['Data'],);
		}
		  return $itemResult;
		
	}
	function item_view($chaInven,$reverse=false,$filterMode=true) {
		
		$items = $this->item_cut(strtoupper(substr(bin2hex($chaInven),24)),0,160);
		
		$items = preg_split("/-/", $items, -1,PREG_SPLIT_OFFSET_CAPTURE);
		
		$totalItems = count($items);
		for ($i=0;$i<$totalItems;$i++){
			if(strlen($items[$i][0])==160){
			$num = $items[$i][0];
			$itemz[] = $this->item_decode($num,$i,NULL,$filterMode);
			}
		}	

		if($reverse){
			return $items; 
		}else{
			return $itemz; 
		}
		
	}
	
	function item_view2($chaInven,$reverse=false,$filterMode=true) {
		
		$items = $this->item_cut(strtoupper(substr(bin2hex($chaInven),24)),0,160);
		
		$items = preg_split("/-/", $items, -1,PREG_SPLIT_OFFSET_CAPTURE);
		
		$totalItems = count($items);
		for ($i=0;$i<$totalItems;$i++){
			if(strlen($items[$i][0])==160){
			$num = $items[$i][0];
			$itemz[] = $this->item_decode2($num,$i,NULL,$filterMode);
			}
		}	

		if($reverse){
			return $items; 
		}else{
			return $itemz; 
		}
		
	}
	
	function item_cut($string, $begin, $shortlength, $number=1) {   
		   $length = strlen($string);
		   if($length > ($shortlength * $number) )     
		   {
				   $end = $begin + $shortlength;
				   $flag = 0;
				   for($x=$begin; $x < $end; $x++){   
					   if(ord($string[$x]) <= 120) { 
					   $flag++;  
					   } 
				   }
					   if($flag%2==1){	 
					   $end++;    
					   }
		   $first_part = substr($string, 0, $end);
		   $last_part = substr($string, $end);
		   
		   $newstring = $first_part. "-" .$last_part;
		   $number++;		
		   return $this->item_cut($newstring, $end+1, $shortlength, $number);	
		   }else 
		   return $string;
	}
	
	function item_decode($_item,$itemNum=NULL,$lblNo=NULL,$filterMode=true) {
		// consoleLOGS($_item);
		global $_config;
		
		$ITEM_SUIT = $_config['ITEM_SUIT'];
		
		$types = array(8,12);
		$item_ids = array('369_122');
		if (substr($_item,0,2)=='0x') 
		$_item = substr($_item,2);
		
		$item16 = $_item[16];
		$item17 = $_item[17];
		$item19 = $_item[19];
		$MAINID 	=  hexdec($item19.$item16.$item17);	//itemMain
			
		$item20 = $_item[20];
		$item21 = $_item[21];
		$item23 = $_item[23];
		$SUBID =  hexdec($item23.$item20.$item21); // itemSub
		
		$ITEMID = $MAINID.'_'.$SUBID;
		
		if(in_array($ITEMID,$ITEM_SUIT)){
			
			// if(in_array(hexdec($_item[84].$_item[85]),$types) ){
		
		// if(in_array(hexdec($_item[84].$_item[85]),$types) 
		// || in_array(
			// hexdec($_item[19].$_item[16].$_item[17]).'_'.hexdec($_item[23].$_item[20].$_item[21]),
			// $item_ids)){
			
			// Get the hex contents
			$item1 = $_item[1];
			$item5 = $_item[5];
			$itemh = $item1;	
			$itemv = $item5;
			
			$item16 = $_item[16];
			$item17 = $_item[17];
			$item19 = $_item[19];
			$_id 	=  hexdec($item19.$item16.$item17);	//itemMain
			
			$item20 = $_item[20];
			$item21 = $_item[21];
			$item23 = $_item[23];
			$_idsub =  hexdec($item23.$item20.$item21); // itemSub
			
			$item64 = $_item[64];
			$item65 = $_item[65];
			$model =  hexdec($item64.$item65); //  model
			
			$item80 = $_item[80];
			$item81 = $_item[81];
			$makenum =  hexdec($item80.$item81); // makenum
			
			$item90 = $_item[90];
			$item91 = $_item[91];
			$damage =  hexdec($item90.$item91); // damage
			
			$item92 = $_item[92];
			$item93 = $_item[93];
			$defense =  hexdec($item92.$item93); // defense
			
			$item98 = $_item[98];
			$item99 = $_item[99];
			$elec =  hexdec($item98.$item99); // elec
			
			$item94 = $_item[94];
			$item95 = $_item[95];
			$fire =  hexdec($item94.$item95); // fire
			
			$item96 = $_item[96];
			$item97 = $_item[97];
			$ice =  hexdec($item96.$item97); // ice
			
			$item100 = $_item[100];
			$item101 = $_item[101];
			$poison =  hexdec($item100.$item101); // poison
			
			$item102 = $_item[102];
			$item103 = $_item[103];
			$spirit =  hexdec($item102.$item103); // spirit
			
			$item104 = $_item[104];
			$item105 = $_item[105];
			$rv1slot =  hexdec($item104.$item105); // rv1slot
			
			$item112 = $_item[112];
			$item113 = $_item[113];
			$item114 = $_item[114];
			$item115 = $_item[115];
			$rv1 =  hexdec($item114.$item115.$item112.$item113); // rv1
			
			$item106 = $_item[106];
			$item107 = $_item[107];
			$rv2slot =  hexdec($item106.$item107); // rv2slot
			
			$item116 = $_item[116];
			$item117 = $_item[117];
			$item118 = $_item[118];
			$item119 = $_item[119];
			$rv2 =  hexdec($item118.$item119.$item116.$item117); // rv2
			
			$item108 = $_item[108];
			$item109 = $_item[109];
			$rv3slot =  hexdec($item108.$item109); // rv3slot
			
			
			$item120 = $_item[120];
			$item121 = $_item[121];
			$item122 = $_item[122];
			$item123 = $_item[123];
			$rv3 =  hexdec($item122.$item123.$item120.$item121); // rv3
			
			$item110 = $_item[110];
			$item111 = $_item[111];
			$rv4slot =  hexdec($item110.$item111); // rv4slot
			
			$item124 = $_item[124];
			$item125 = $_item[125];
			$item126 = $_item[126];
			$item127 = $_item[127];
			$rv4 =  hexdec($item126.$item127.$item124.$item125); // rv4
			
			$item84 = $_item[84];
			$item85 = $_item[85];
			$type =  hexdec($item84.$item85); // type
			
			$item86 = $_item[86];
			$item87 = $_item[87];
			$chn =  hexdec($item86.$item87); // chn
			
			$item88 = $_item[88];
			$item89 = $_item[89];
			$field =  hexdec($item88.$item89); // field
			
			$item64 = $_item[64];
			$item65 = $_item[65];
			$unique =  hexdec($item64.$item65); // unique
			
			// $itemName = $this->shopItemMapDAO->getItemName($_id,$_idsub);
			$itemName = strval(trim($this->getItemString($_id,$_idsub)));
			
			//getname
			$info['lblNo'] = $lblNo;
			$info['Num'] = $itemNum;
			$info['Data'] = $_item;
			$info['Makenum'] = $makenum;
			$info['Model'] = $model;
			$info['Main'] = $_id;
			$info['Sub'] = $_idsub;
			$info['Name'] = $itemName;
			// $info['Name1'] = $itemName1;
			$info['Hor'] = $itemh;
			$info['Ver'] = $itemv;
			$info['Damage'] = $damage;
			$info['Defense'] = $defense;
			$info['Elec'] = $elec;
			$info['Fire'] = $fire;
			$info['Ice'] = $ice;
			$info['Poison'] = $poison;
			$info['Spirit'] = $spirit;
			$info['Rv1Slot'] = $rv1slot;
			$info['Rv1'] = $rv1;
			$info['Rv2Slot'] = $rv2slot;
			$info['Rv2'] = $rv2;
			$info['Rv3Slot'] = $rv3slot;
			$info['Rv3'] = $rv3;
			$info['Rv4Slot'] = $rv4slot;
			$info['Rv4'] = $rv4;
			$info['Type'] = $type;
			$info['Field'] = $field;
			$info['Unique'] = $unique;
			$info['Gen'] = "".$type."/".$chn."/".$field."/".$unique."";
			#-- Item Addon
			$item_addon = $this->itemAddonValue($info);
			$info['Atkrate'] = $item_addon['Atkrate'];
			$info['Defrate'] = $item_addon['Defrate'];
			$info['Hitrate'] = $item_addon['Hitrate'];
			$info['HP'] = $item_addon['HP'];
			//$info['HPrate'] = $item_addon['HPrate'];
			$info['HMSrate'] = $item_addon['HMSrate'];

			#-- Item Addon Slot
			$info['Atkrate_SlotNo'] = $item_addon['Atkrate_SlotNo'];
			$info['Defrate_SlotNo'] = $item_addon['Defrate_SlotNo'];
			$info['Hitrate_SlotNo'] = $item_addon['Hitrate_SlotNo'];
			$info['HP_SlotNo'] = $item_addon['HP_SlotNo'];
			//$info['HPrate_SlotNo'] = $item_addon['HPrate_SlotNo'];
			$info['HMSrate_SlotNo'] = $item_addon['HMSrate_SlotNo'];
			$info['Qty_SlotNo'] 	= $item_addon['Qty_SlotNo'];
			
			if($filterMode){
				if($this->itemFilter($_config['InventoryFilter'],$info)){
				return $info;
				}
			}else{
				return $info;
			}
				return false;
		// }
			
		}
		
	}
	
	function item_decode2($_item,$itemNum=NULL,$lblNo=NULL,$filterMode=true) {
		// consoleLOGS($_item);
		global $_config;
		
		$types = array(8,12);
		$item_ids = array('369_122');
		if (substr($_item,0,2)=='0x') 
		$_item = substr($_item,2);
		
		$item16 = $_item[16];
		$item17 = $_item[17];
		$item19 = $_item[19];
		$MAINID 	=  hexdec($item19.$item16.$item17);	//itemMain
			
		$item20 = $_item[20];
		$item21 = $_item[21];
		$item23 = $_item[23];
		$SUBID =  hexdec($item23.$item20.$item21); // itemSub
		
		$ITEMID = $MAINID.'_'.$SUBID;
		
		//if(in_array($ITEMID,$ITEM_SUIT)){
			
			// if(in_array(hexdec($_item[84].$_item[85]),$types) ){
		
		// if(in_array(hexdec($_item[84].$_item[85]),$types) 
		// || in_array(
			// hexdec($_item[19].$_item[16].$_item[17]).'_'.hexdec($_item[23].$_item[20].$_item[21]),
			// $item_ids)){
			
			// Get the hex contents
			$item1 = $_item[1];
			$item5 = $_item[5];
			$itemh = $item1;	
			$itemv = $item5;
			
			$item16 = $_item[16];
			$item17 = $_item[17];
			$item19 = $_item[19];
			$_id 	=  hexdec($item19.$item16.$item17);	//itemMain
			
			$item20 = $_item[20];
			$item21 = $_item[21];
			$item23 = $_item[23];
			$_idsub =  hexdec($item23.$item20.$item21); // itemSub
			
			$item64 = $_item[64];
			$item65 = $_item[65];
			$model =  hexdec($item64.$item65); //  model
			
			$item80 = $_item[80];
			$item81 = $_item[81];
			$makenum =  hexdec($item80.$item81); // makenum
			
			$item90 = $_item[90];
			$item91 = $_item[91];
			$damage =  hexdec($item90.$item91); // damage
			
			$item92 = $_item[92];
			$item93 = $_item[93];
			$defense =  hexdec($item92.$item93); // defense
			
			$item98 = $_item[98];
			$item99 = $_item[99];
			$elec =  hexdec($item98.$item99); // elec
			
			$item94 = $_item[94];
			$item95 = $_item[95];
			$fire =  hexdec($item94.$item95); // fire
			
			$item96 = $_item[96];
			$item97 = $_item[97];
			$ice =  hexdec($item96.$item97); // ice
			
			$item100 = $_item[100];
			$item101 = $_item[101];
			$poison =  hexdec($item100.$item101); // poison
			
			$item102 = $_item[102];
			$item103 = $_item[103];
			$spirit =  hexdec($item102.$item103); // spirit
			
			$item104 = $_item[104];
			$item105 = $_item[105];
			$rv1slot =  hexdec($item104.$item105); // rv1slot
			
			$item112 = $_item[112];
			$item113 = $_item[113];
			$item114 = $_item[114];
			$item115 = $_item[115];
			$rv1 =  hexdec($item114.$item115.$item112.$item113); // rv1
			
			$item106 = $_item[106];
			$item107 = $_item[107];
			$rv2slot =  hexdec($item106.$item107); // rv2slot
			
			$item116 = $_item[116];
			$item117 = $_item[117];
			$item118 = $_item[118];
			$item119 = $_item[119];
			$rv2 =  hexdec($item118.$item119.$item116.$item117); // rv2
			
			$item108 = $_item[108];
			$item109 = $_item[109];
			$rv3slot =  hexdec($item108.$item109); // rv3slot
			
			
			$item120 = $_item[120];
			$item121 = $_item[121];
			$item122 = $_item[122];
			$item123 = $_item[123];
			$rv3 =  hexdec($item122.$item123.$item120.$item121); // rv3
			
			$item110 = $_item[110];
			$item111 = $_item[111];
			$rv4slot =  hexdec($item110.$item111); // rv4slot
			
			$item124 = $_item[124];
			$item125 = $_item[125];
			$item126 = $_item[126];
			$item127 = $_item[127];
			$rv4 =  hexdec($item126.$item127.$item124.$item125); // rv4
			
			$item84 = $_item[84];
			$item85 = $_item[85];
			$type =  hexdec($item84.$item85); // type
			
			$item86 = $_item[86];
			$item87 = $_item[87];
			$chn =  hexdec($item86.$item87); // chn
			
			$item88 = $_item[88];
			$item89 = $_item[89];
			$field =  hexdec($item88.$item89); // field
			
			$item64 = $_item[64];
			$item65 = $_item[65];
			$unique =  hexdec($item64.$item65); // unique
			
			$itemName = $this->shopItemMapDAO->getItemName($_id,$_idsub);
			//itemName = strval(trim($this->getItemString($_id,$_idsub)));
			
			//getname
			$info['lblNo'] = $lblNo;
			$info['Num'] = $itemNum;
			$info['Data'] = $_item;
			$info['Makenum'] = $makenum;
			$info['Model'] = $model;
			$info['Main'] = $_id;
			$info['Sub'] = $_idsub;
			$info['Name'] = $itemName;
			// $info['Name1'] = $itemName1;
			$info['Hor'] = $itemh;
			$info['Ver'] = $itemv;
			$info['Damage'] = $damage;
			$info['Defense'] = $defense;
			$info['Elec'] = $elec;
			$info['Fire'] = $fire;
			$info['Ice'] = $ice;
			$info['Poison'] = $poison;
			$info['Spirit'] = $spirit;
			$info['Rv1Slot'] = $rv1slot;
			$info['Rv1'] = $rv1;
			$info['Rv2Slot'] = $rv2slot;
			$info['Rv2'] = $rv2;
			$info['Rv3Slot'] = $rv3slot;
			$info['Rv3'] = $rv3;
			$info['Rv4Slot'] = $rv4slot;
			$info['Rv4'] = $rv4;
			$info['Type'] = $type;
			$info['Field'] = $field;
			$info['Unique'] = $unique;
			$info['Gen'] = "".$type."/".$chn."/".$field."/".$unique."";
			#-- Item Addon
			$item_addon = $this->itemAddonValue($info);
			$info['Atkrate'] = $item_addon['Atkrate'];
			$info['Defrate'] = $item_addon['Defrate'];
			$info['Hitrate'] = $item_addon['Hitrate'];
			$info['HP'] = $item_addon['HP'];
			//$info['HPrate'] = $item_addon['HPrate'];
			$info['HMSrate'] = $item_addon['HMSrate'];

			#-- Item Addon Slot
			$info['Atkrate_SlotNo'] = $item_addon['Atkrate_SlotNo'];
			$info['Defrate_SlotNo'] = $item_addon['Defrate_SlotNo'];
			$info['Hitrate_SlotNo'] = $item_addon['Hitrate_SlotNo'];
			$info['HP_SlotNo'] = $item_addon['HP_SlotNo'];
			//$info['HPrate_SlotNo'] = $item_addon['HPrate_SlotNo'];
			$info['HMSrate_SlotNo'] = $item_addon['HMSrate_SlotNo'];
			$info['Qty_SlotNo'] 	= $item_addon['Qty_SlotNo'];
			
			if($filterMode){
				if($this->itemFilter($_config['InventoryFilter'],$info)){
				return $info;
				}
			}else{
				return $info;
			}
				return false;
		// }
			
		//}
		
	}
	
	function getItemString($mid,$sid){
		$myFile = "item_names_string.txt";
		$lines = file($myFile);
		$data = array();
		$strname = '';
		$s_id = '';
		if(strlen($sid) ==  3){
			$s_id = $sid;
		}elseif(strlen($sid) ==  2){
			$s_id = '0'.$sid;
		}else{
			$s_id = '00'.$sid;
		}
		
		$msid = $mid.'_'.$s_id;
		foreach($lines as $key => $value){
			$str = explode('	',$value);
			$str1 = $str[0];
			$str2 = $str[1];
			
			if (strpos($str1, 'IN') !== false) {
				$strMSID = str_replace('IN_','',$str1);
				
				if($msid == $strMSID){
					
					$strname = $str2;
					
					break;
				}
				
			}
		}
		return $strname;
	}
	
	function item_MaxGrade($addonNo,$addonValue){
		global $_config;
		
		switch ($addonNo){
			
			case 118:
				$addonMaxGrade = $_config['ItemUpgradeAtk']['MaxGrade'];
				$addonCurrentValue = $addonValue;
				break;
				
			case 119:
				$addonMaxGrade = $_config['ItemUpgradeDef']['MaxGrade'];
				$addonCurrentValue = $addonValue;
				break;
					
			case 1:
				$addonMaxGrade = $_config['ItemUpgradeAtkRate']['MaxGrade'];
				$addonCurrentValue = $addonValue/100;
				break;
				
			case 2:
				$addonMaxGrade =$_config['ItemUpgradeDefRate']['MaxGrade'];
				$addonCurrentValue = $addonValue/100;
				break;
				
			case 3:
				$addonMaxGrade = $_config['ItemUpgradeHitRate']['MaxGrade'];
				$addonCurrentValue = $addonValue/100;
				break;
				
			case 5:
				$addonMaxGrade = $_config['ItemUpgradeHP']['MaxGrade'];
				$addonCurrentValue = $addonValue;
				break;
				
			case 11:
				$addonMaxGrade = $_config['ItemUpgradeHMSRate']['MaxGrade'];
				$addonCurrentValue = $addonValue/100;
				break;
		}
		
		if($addonCurrentValue < $addonMaxGrade){
			return true;
		}
		return false;
		
	}
	

	
  //Item Slot Constructor
  function itemslot_build($data,$character){
	  $totalItems = count($data);
	  $invenSlot = $this->inventorySlot($character->chaInvenLine);
	  
	  for ($b=0;$b<$totalItems;$b++){
  
		  if($data[$b]['No'] >= $invenSlot['1'][0] & $data[$b]['No'] <= $invenSlot['2'][0]){
			  $yslot++;
			  $newslotNo = $this->rebuild_InventoryItemSlot($character,$data[$b]['Data'],0,$yslot-1);
			  $character->chaInven = $newslotNo['New'];
			  $this->chaInfoDAO->update_inven($character);
			  
		  }elseif($data[$b]['No'] >= $invenSlot['1'][1] & $data[$b]['No'] <= $invenSlot['2'][1]){
			  $yslot1++;
			  $newslotNo1 = $this->rebuild_InventoryItemSlot($character,$data[$b]['Data'],1,$yslot1-1);
			  $character->chaInven = $newslotNo1['New'];
			  $this->chaInfoDAO->update_inven($character);
			  
		  }elseif($data[$b]['No'] >= $invenSlot['1'][2] & $data[$b]['No'] <= $invenSlot['2'][2]){
			  $yslot2++;
			  $newslotNo2 = $this->rebuild_InventoryItemSlot($character,$data[$b]['Data'],2,$yslot2-1);
			  $character->chaInven = $newslotNo2['New'];
			  $this->chaInfoDAO->update_inven($character);
			  
		  }elseif($data[$b]['No'] >= $invenSlot['1'][3] & $data[$b]['No'] <= $invenSlot['2'][3]){
			  $yslot3++;
			  $newslotNo3 = $this->rebuild_InventoryItemSlot($character,$data[$b]['Data'],3,$yslot3-1);
			  $character->chaInven = $newslotNo3['New'];
			  $this->chaInfoDAO->update_inven($character);
			  
		  }elseif($data[$b]['No'] >= $invenSlot['1'][4] & $data[$b]['No'] <= $invenSlot['2'][4]){
			  $yslot4++;
			  $newslotNo4 = $this->rebuild_InventoryItemSlot($character,$data[$b]['Data'],4,$yslot4-1);
			   $character->chaInven = $newslotNo4['New'];
			  $this->chaInfoDAO->update_inven($character);
			  
		  }elseif($data[$b]['No'] >= $invenSlot['1'][5] & $data[$b]['No'] <= $invenSlot['2'][5]){
			  $yslot5++;
			  $newslotNo5 = $this->rebuild_InventoryItemSlot($character,$data[$b]['Data'],5,$yslot5-1);
			  $character->chaInven = $newslotNo5['New'];
			  $this->chaInfoDAO->update_inven($character);
			  
		  }elseif($data[$b]['No'] >= $invenSlot['1'][6] & $data[$b]['No'] <= $invenSlot['2'][6]){
			  $yslot6++;
			  $newslotNo6 = $this->rebuild_InventoryItemSlot($character,$data[$b]['Data'],6,$yslot6-1);
			  $character->chaInven = $newslotNo6['New'];
			  $this->chaInfoDAO->update_inven($character);
			  
		  }elseif($data[$b]['No'] >= $invenSlot['1'][7] & $data[$b]['No'] <= $invenSlot['2'][7]){
			  $yslot7++;
			  $newslotNo7 = $this->rebuild_InventoryItemSlot($character,$data[$b]['Data'],7,$yslot7-1);
			  $character->chaInven = $newslotNo7['New'];
			  $this->chaInfoDAO->update_inven($character);
			  
		  }elseif($data[$b]['No'] >= $invenSlot['1'][8] & $data[$b]['No'] <= $invenSlot['2'][8]){
			  $yslot8++;
			  $newslotNo8 = $this->rebuild_InventoryItemSlot($character,$data[$b]['Data'],8,$yslot5-1);
			  $character->chaInven = $newslotNo8['New'];
			  $this->chaInfoDAO->update_inven($character);
			  
		  }elseif($data[$b]['No'] >= $invenSlot['1'][9] & $data[$b]['No'] <= $invenSlot['2'][9]){
			  $yslot9++;
			  $newslotNo5 = $this->rebuild_InventoryItemSlot($character,$data[$b]['Data'],9,$yslot9-1);
			  $character->chaInven = $newslotNo9['New'];
			  $this->chaInfoDAO->update_inven($character);
			  
		  }elseif($data[$b]['No'] >= $invenSlot['1'][10] & $data[$b]['No'] <= $invenSlot['2'][10]){
			  $yslot10++;
			  $newslotNo10 = $this->rebuild_InventoryItemSlot($character,$data[$b]['Data'],10,$yslot10-1);
			  $character->chaInven = $newslotNo10['New'];
			  $this->chaInfoDAO->update_inven($character);
			  
		  }
		  
	  }//End Loop			
  }
  function rebuild_InventoryItemSlot($character,$data,$x,$y){

		  $characterInfo = $this->chaInfoDAO->characterInfo($character);		  
		  $t = preg_match("/".strtoupper($data)."/",strtoupper(bin2hex($characterInfo->chaInven)),$matches);			 
		  $xslot = dechex($x);
		  $yslot = dechex($y);
		  
		  $itemDataEnd = substr($matches[0],6);
		  
		  $item['OldSlot'] = strtoupper($matches[0]);
		  $item['NewSlot'] = strtoupper('0'.$xslot.'000'.$yslot.$itemDataEnd);
		  $item['New'] = str_replace(strtoupper($data),$item['NewSlot'],strtoupper(bin2hex($characterInfo->chaInven)));

	  return $item;
  }
  
  //Checks if Item Decimal Value is Negative
  function item_Value($value){
		  if($value < 9999){
		  $newValue = $value;
		  }else{
		  $hex = $this->dec2hex($value);
		  $newValue = $this->hex2dec($hex);
		  }
		  return $newValue;
  }
  //Item Header
  function item_HeaderNew($data,$action){
	  
		$ChaInven_Header = substr(bin2hex($data),0,24);
		$Header_Items = hexdec($ChaInven_Header[16].$ChaInven_Header[17]);
		
		$Header_start = substr($ChaInven_Header,0,16);
		switch($action){
			case 'sum':
			$Header_strval = dechex($Header_Items+1);
			break;
			case 'sub':
			$Header_strval = dechex($Header_Items-1);
			break;
		}
		
		if(strlen($Header_strval)!=2){
			$Header_val = '0'.$Header_strval;	
		}else{
			$Header_val = $Header_strval;
		}
		$Header_End = substr($ChaInven_Header,18);
		$new_header = strtoupper($Header_start.$Header_val.$Header_End);
	return $new_header;
	  
  }
  function item_OptionList($infoArray){
	 if(($infoArray['Damage']!=0) || (($this->check_ItemAddon($infoArray,1) & $infoArray['Defrate']==0) & $this->check_ItemAddonSlot($infoArray,false,true,false,false))) {
		 $info['Attack'] = true;
	 }else{
		 $info['Attack'] = false;
	 }
	 if($this->check_ItemAddon($infoArray,1) || ($infoArray['Damage']!=0 & $this->check_ItemAddonSlot($infoArray,false,false,false,true) )){ 
		 $info['Atkrate'] = true;
	 }else{
		 $info['Atkrate'] = false;
	 }
	 if (($infoArray['Defense']!=0) || (($this->check_ItemAddon($infoArray,2) & $infoArray['Atkrate']==0) & $this->check_ItemAddonSlot($infoArray,false,true,false,false))){ 
		 $info['Defense'] = true;
	 } else{
		 $info['Defense'] = false;
	 }
	 if($this->check_ItemAddon($infoArray,2) || ($infoArray['Defense']!=0 & $this->check_ItemAddonSlot($infoArray,false,false,false,true) )){ 
		 $info['Defrate'] = true;
	 }else{
		$info['Defrate'] = false;
	 }
	 if ($this->check_ItemAddon($infoArray,5) || $this->check_ItemAddonSlot($infoArray,false,false,false,true)){
		 $info['HP'] = true;
	 } else{
		 $info['HP'] = false;
	 }
	 if ($this->check_ItemAddon($infoArray,11) || $this->check_ItemAddonSlot($infoArray,false,false,false,true)){
		 $info['HMSrate'] = true;
	 } else{
		 $info['HMSrate'] = false;
	 }
	 if (($this->check_ItemAddon($infoArray,1) || ($infoArray['Damage']!=0) ) & ($this->check_ItemAddon($infoArray,3) || $this->check_ItemAddonSlot($infoArray,false,false,false,true))	){
		 $info['Hitrate'] = true;
	 } else{
		 $info['Hitrate'] = false;
	 }
	  return $info;
  }
  
	#-- Check if Errors
	function check_ItemAddonType($info,$addonNo,$slot1,$slot2,$slot3){
				switch ($addonNo){
					case 1: case 2: case 118:
					if($this->isItemAddonType($info,$addonNo,$slot1,$slot2,$slot3)){
						return true;
					}
					break;
									
				}	
		return false;
	}
	function check_ItemAddon($info,$addonNo,$checkAddonSlot=false){
		if ($info['Rv1Slot']==$addonNo){
			if($checkAddonSlot){
				if ($this->check_ItemAddonType($info,$addonNo,'Rv2Slot','Rv3Slot','Rv4Slot')){
						return true;
				}
			}else
			return true;
		}elseif ($info['Rv2Slot']==$addonNo){
			if($checkAddonSlot){
				if ($this->check_ItemAddonType($info,$addonNo,'Rv1Slot','Rv3Slot','Rv4Slot')){
						return true;
				}
			}else
			return true;
		}elseif ($info['Rv3Slot']==$addonNo){
			if($checkAddonSlot){
				if ($this->check_ItemAddonType($info,$addonNo,'Rv1Slot','Rv2Slot','Rv4Slot')){
						return true;
				}
			}else
			return true;
		}elseif ($info['Rv4Slot']==$addonNo){
			if($checkAddonSlot){
				if ($this->check_ItemAddonType($info,$addonNo,'Rv1Slot','Rv2Slot','Rv3Slot')){
						return true;
				}
			}else
			return true;
		}
		return false;
	}
	function check_ItemAddonSlotNo($rvslot){
		switch ($rvslot){
				case 1: case 2: case 3: case 5: case 11:
				return true;
				break;
		}
			return false;
	}
	function check_ItemAddonSlot($item,$addonCheck=false,$isallAddon=false,$isallSlotEmpty=false,$isSlotEmpty=false){
		$rv1check = $this->check_ItemAddonSlotNo($item['Rv1Slot']);
		$rv2check = $this->check_ItemAddonSlotNo($item['Rv2Slot']);
		$rv3check = $this->check_ItemAddonSlotNo($item['Rv3Slot']);
		$rv4check = $this->check_ItemAddonSlotNo($item['Rv4Slot']);
		
		//if one of the rv slot contains the addon No
		if($addonCheck){
			if (($rv1check==true || $rv2check==true || $rv3check==true || $rv4check==true) & ($item['Rv1Slot']==0 & $item['Rv2Slot']==0 & $item['Rv3Slot']==0 & $item['Rv4Slot']==0))		
			return true;
		}
		//check if all addon is present
		if($isallAddon){
			if ($rv1check==true || $rv2check==true || $rv3check==true || $rv4check==true)	
			return true;
		}
		//Check if all slot in the item in empty
		if($isallSlotEmpty){
			if ($item['Rv1Slot']==0 & $item['Rv2Slot']==0 & $item['Rv3Slot']==0 & $item['Rv4Slot']==0)		
			return true;
		}
		//check if one of the addon is empty
		if($isSlotEmpty){
			if ($item['Rv1Slot']==0 || $item['Rv2Slot']==0 || $item['Rv3Slot']==0 || $item['Rv4Slot']==0)		
			return true;
		}
		
		  
		return false;
	}
	function isItemAddonWeapon($info){
		switch ($info){
			case 3: case 5: case 11: case 0: case 1:
			return true;
			break;
		}
		return false;
	}
	function isItemAddonArmor($info){
		switch ($info){
			case 5: case 11: case 0: case 2:
			return true;
			break;
		}
		return false;
	}
	function isItemAddonType($info,$addonNo,$slot1,$slot2,$slot3){
				switch ($addonNo){
					case 1: case 3:	//Attack Rate ~ Weapon check each slot
					if($this->isItemAddonWeapon($info[$slot1]) & $this->isItemAddonWeapon($info[$slot2]) & $this->isItemAddonWeapon($info[$slot3])){
						return true;
					}else{
						return false;
					}
					break;
					
					case 2: //Defense Rate ~ Armor check each slot
					if($this->isItemAddonArmor($info[$slot1]) &  $this->isItemAddonArmor($info[$slot2]) &  $this->isItemAddonArmor($info[$slot3])){
						return true;
					}else{
						return false;
					}
					break;
									
				}
		return false;
		
	}
  
}
class ItemCustomizeLogic extends ItemLogic
{
	
	#-- Delete Item Storage
	function changeItem2NonDrop($itemcustomize){
		//Change Item to Non-Drop
		// consoleLOGS($itemcustomize->chaInven);
		$itemDataDecode = $this->item_decode($itemcustomize->chaInven,NULL,NULL,false);
		
		if($itemDataDecode['Type']!=6 || $itemDataDecode['Field']!=255){
			$newItemDataStart = substr($itemcustomize->chaInven,0,85); 
			$newItemDataType = dechex(6); //6 Type
			$newItemDataMidType = substr($itemcustomize->chaInven,86,2); 
			$newItemDataField = strtoupper(dechex(255)); //Field 255 /0
			if(strlen($newItemDataField)!=2){
			$itemDataField = '0'.$newItemDataField;
			}else{
			$itemDataField = $newItemDataField;
			}
			$newItemDataEnd = substr($itemcustomize->chaInven,90); //90

			$newData = strtoupper($newItemDataStart.$newItemDataType.$newItemDataMidType.$itemDataField.$newItemDataEnd);
		}else{
			$newData = $itemcustomize->chaInven;
		}
		
		return $newData;	
		
	}
	
	function changeItem2NonDrop2($itemcustomize){
		//Change Item to Non-Drop
		// consoleLOGS($itemcustomize->chaInven);
		
		if($itemcustomize['Type']!=6 || $itemcustomize['Field']!=255){
			$newItemDataStart = substr($itemcustomize['Data'],0,85); 
			$newItemDataType = dechex(6); //6 Type
			$newItemDataMidType = substr($itemcustomize['Data'],86,2); 
			$newItemDataField = strtoupper(dechex(255)); //Field 255 /0
			if(strlen($newItemDataField)!=2){
			$itemDataField = '0'.$newItemDataField;
			}else{
			$itemDataField = $newItemDataField;
			}
			$newItemDataEnd = substr($itemcustomize['Data'],90); //90

			$newData = strtoupper($newItemDataStart.$newItemDataType.$newItemDataMidType.$itemDataField.$newItemDataEnd);
		}else{
			$newData = $itemcustomize['Data'];
		}
		
		return $newData;	
		
	}
	
	function deleteItemStorage($itemcustomize){
		$this->itemCustomizeDAO->delete($itemcustomize);
	}
	function decodeItemStorageData($itemcustomize){
		
		$storageResult = $this->get_ItemStorageInfo($itemcustomize);
		
		$itemStorage = $this->decode_ItemData($storageResult->chaInven);
		
		$itemStorageInfo = $this->item_decode($itemStorage);
		
		return $itemStorageInfo;
	}
	
	function get_ItemStorageInfo($itemcustomize){
		$storageResult = $this->itemCustomizeDAO->getItemStorage($itemcustomize);
		if(!$storageResult){
			jump_location('errorpage');
		}
		return $storageResult;
		
	}
	function getItemStorageData($itemcustomize){
		$storageResult = $this->get_ItemStorageInfo($itemcustomize);
		$itemStorage = $this->decode_ItemData($storageResult->chaInven);		
		return $itemStorage;
	}
	function getImportItemDataBack($itemcustomize,$character){
		#check inven slot
		$xslot = mt_rand(0, 5);
		$yslot = 9;	
		#Already Decoded
		$xySlotEnd = substr($itemcustomize->chaInven,6);
		 
		$itemStorage = strtoupper('0'.$xslot.'000'.$yslot.$xySlotEnd);
		  
		#Move the item in the First Slot
		$cutItemHeader = strtoupper(substr($character->chaInven,0,24)); //updated item header
		$cutItem = strtoupper(substr($character->chaInven,24));	//Rest of the items....
			
		return $cutItemHeader.$itemStorage.$cutItem;
		  
	}
	
	function addItemPileNum($item,$pileNum){
		$remain = strval(dechex($pileNum));
		if(strlen($remain) == 2){
			$idx1 = $remain[0];
			$idx2 = $remain[1];
		}else{
			$idx1 = "0";
			$idx2 = $remain[0];
		}
		// $remainHex = dechex($idx1.$idx2);
		$item[80] = $idx1;
		$item[81] = $idx2;
		return $item;
	}

	function getCurrentInvenItemWOheader($character){
		return strtoupper(substr($character->chaInven,24));
	}
	
	function getHeaderItem($chaInven){
		return strtoupper(substr($chaInven,0,24)); //updated item header
	}
	
	function recodeItemz($data,$num){

		$str = strval($num);
			
		if($num >= 10){	
			$data[1] = $str[0];
			$data[5] = $str[1];
		}else{
			$data[1] = 0;
			$data[5] = $str[0];
				// console($cnt);
		}
		// echo $data.'<br />';
		return $data;

	}
	
	function headerItems($remain,$headeritem){
		$remain = strval(dechex($remain));
		// consoleLOGS($remain);
		if(strlen($remain) == 2){
			$idx1 = $remain[0];
			$idx2 = $remain[1];
		}else{
			$idx1 = "0";
			$idx2 = $remain[0];
		}
		// $remainHex = dechex($idx1.$idx2);
		$headeritem[16] = $idx1;
		$headeritem[17] = $idx2;
		
		return $headeritem;
	}
	
	function getImportItemDataBack2($itemcustomize,$character,$num){
		#check inven slot
		$xslot = mt_rand(0, 5);
		$yslot = 9;	
		
		$remain = strval(dechex($num));
		if(strlen($remain) == 2){
			$idx1 = $remain[0];
			$idx2 = $remain[1];
		}else{
			$idx1 = "0";
			$idx2 = $remain[0];
		}
		// $remainHex = dechex($idx1.$idx2);
		$itemcustomize->chaInven[16] = $idx1;
		$itemcustomize->chaInven[17] = $idx2;
		
		#Already Decoded
		$xySlotEnd = substr($itemcustomize->chaInven,6);
		 
		$itemStorage = strtoupper('0'.$xslot.'000'.$yslot.$xySlotEnd);
		  
		#Move the item in the First Slot
		$cutItemHeader = strtoupper(substr($character->chaInven,0,24)); //updated item header
		$cutItem = strtoupper(substr($character->chaInven,24));	//Rest of the items....
			
		return $cutItemHeader.$itemStorage.$cutItem;
		  
	}
	
	function getMergeImportItemData($itemcustomize,$character,$num){
		
	}
	
	function getTotalItemStorage($itemcustomize){
		return $this->itemCustomizeDAO->getTotalItemStorage($itemcustomize);
		
	}
	function insertItemStorage($itemcustomize){
		return $this->itemCustomizeDAO->insert($itemcustomize);
				
	}
	///////////////////
	function itemStorageList($itemcustomize){
		$storagePagination = new ItemPagination;
		$storagePagination->pageTitleName = "sPage";
		$storagePagination->tablecolSpan = 12;
		$storageItem = $this->itemCustomizeDAO->getItemStorageList($itemcustomize);
		
		if($storageItem){

		$storageItemPages = $storagePagination->generate($storageItem, 5);
		$totalStorageItem = count($storageItemPages);
		for($s=0;$s<$totalStorageItem;$s++){
			$decodeData = $this->decode_ItemData($storageItemPages[$s][5]);
			$itemDataDecode = $this->item_decode($decodeData,NULL,NULL,false);
			$itemValueDecode = $this->decode_ItemValues($itemDataDecode);
			
			if(!$this->maxItemValue($itemDataDecode)){
				$disabled = 'disabled="disabled"';
			}else{
				$disabled = '';
			}
			if($s%2){
			  $rowStyle =  "altrowstyle";
			}else{
			  $rowStyle =  "rowstyle";
			}
			echo '	
	<tr class="',$rowStyle,'" onmouseover="this.style.backgroundColor=\'#DAEAFD\';this.style.color=\'blue\'" onmouseout="this.style.backgroundColor=\'\'" style="height:20px;">
					<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">   
									<span id="ctl00_ContentPlaceHolder_main_GridView2_ctl02_lblNo2">',$storageItemPages[$s][0],'</span>   
								</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemValueDecode['Name'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemValueDecode['Damage'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemValueDecode['Defense'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemValueDecode['Atkrate'],'%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemValueDecode['Defrate'],'%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemValueDecode['HP'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemValueDecode['HMSrate'],'%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemValueDecode['Hitrate'],'%</td><td ',$disabled,' align="center">
								<select name="subOptList',$storageItemPages[$s][1],'" ',$disabled,' id="ctl00_ContentPlaceHolder_main_GridView2_ct',$storageItemPages[$s][1],'_subOptList">

						<option value="-1">Choose</option>
								',$this->subOptionList($itemDataDecode),'
					</select>
							  </td><td ',$disabled,' align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;font-weight:normal;width:70px;"><input type="submit" name="ctl00$ContentPlaceHolder_main$GridView2$ctl02$ctl00" value="Upgrade" ',$disabled,' onclick="if(confirm(\'Do you want to upgrade [',str_replace("'","\'",$itemValueDecode['Name']),'] ?\n\nPlease check the selected property type\nThis operation is not reversible\'))__doPostBack(\'ctl00ContentPlaceHoldermainCustomersGridBack\',\'Upgrade$',$storageItemPages[$s][2],'-',$storageItemPages[$s][3],'-',$storageItemPages[$s][1],'\');return false;" class="btn01" style="font-weight:normal;" /></td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;font-weight:normal;width:70px;"><input type="submit" name="ctl00$ContentPlaceHolder_main$GridView2$ctl02$ctl01" value="Take back" onclick="if(confirm(\'Do you want to import [',str_replace("'","\'",$itemValueDecode['Name']),'] to the Character Inventory?\'))__doPostBack(\'ctl00ContentPlaceHoldermainCustomersGridBack\',\'Select$',$storageItemPages[$s][2],'-',$storageItemPages[$s][3],'-',$storageItemPages[$s][1],'\');return false;" class="btn02" style="font-weight:normal;" /></td>
				</tr>
				';
							
			}
			echo $storagePagination->links();
		}else{
	
			echo '
<tr class="rowstyle" onmouseover="this.style.backgroundColor=\'#DAEAFD\';this.style.color=\'blue\'" onmouseout="this.style.backgroundColor=\'\'" style="height:20px;">
				<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">   
				                <span id="ctl00_ContentPlaceHolder_main_GridView2_ctl02_lblNo2">--</span>   
				            </td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--%</td><td disabled="disabled" align="center">
			                <select name="ctl00$ContentPlaceHolder_main$GridView2$ctl02$subOptList" disabled="disabled" id="ctl00_ContentPlaceHolder_main_GridView2_ctl02_subOptList">

					<option selected="selected" value="-1">Choose</option>

				</select>
			              </td><td disabled="disabled" align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;font-weight:normal;width:70px;"><input type="submit" name="ctl00$ContentPlaceHolder_main$GridView2$ctl02$ctl00" value="Upgrade" disabled="disabled" class="btn01" style="font-weight:normal;" /></td><td disabled="disabled" align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;font-weight:normal;width:70px;"><input type="submit" name="ctl00$ContentPlaceHolder_main$GridView2$ctl02$ctl01" value="Take back" disabled="disabled" class="btn02" style="font-weight:normal;" /></td>
			</tr>
			';
		}
		
	}//End Function
	
	function updateItemUpgradeInfo($itemcustomize){
		$result = $this->itemCustomizeDAO->update($itemcustomize);
		if(is_bool($result)){
			return true;
		}else{
			trigger_error($result->ErrorMsg()); 
			exit;
		}
		
	}
	
	//added by otep
	
	function getItemStorageListCha($itemcustomize){
		return $this->itemCustomizeDAO->getItemStorageList($itemcustomize);
	}
	
	function fusionAddOn($infoArray,$subOption,$added){
		global $_config;	 
			
		$isAddonValue = $this->item_OptionList($infoArray);
		
		switch ($subOption){
		
		  case 12: //Attack Upgrade	
			
					if($isAddonValue['Attack']) {
						// echo '<pre>';
		// var_dump($added);exit();
						$addAtkResult = strtoupper(dechex($added));
					
						$itemStartData = substr($infoArray['Data'],0,90);
						$itemEndData = substr($infoArray['Data'],92);
						$item['CurrentValue'] = $infoArray['Damage'];
						$item['Result'] = hexdec($addAtkResult);
						  
						if(strlen($addAtkResult)!=2){
							$item['Data'] = strtoupper($itemStartData.'0'.$addAtkResult.$itemEndData);
						}else{
							$item['Data'] = strtoupper($itemStartData.$addAtkResult.$itemEndData);
						}
					
						// $item['AddonType'] = $_config['ItemUpgradeAtk'];
						
					}else{
						
						jump_location('errorpage');
					}
				  break;
				  
		  case 1: //Attack Rate Upgrade	
				  if($isAddonValue['Atkrate']){ 
					$addAtkrateResult = $this->decode_ItemAddon_Fusion($infoArray,1,$infoArray['Atkrate'],$added);
					$resultSet = $addAtkrateResult['Result'];
					$item['CurrentValue'] = $resultSet['CurrentValue'];
					$item['Result'] = $resultSet['Total'];
					$item['Data'] = $addAtkrateResult['Data'];
					// $item['AddonType'] = $_config['ItemUpgradeAtkRate'];
					}else{
					  jump_location('errorpage');
					}
				  break;
		  case 13: //Defense
				   if ($isAddonValue['Defense']){ 
					$addDefResult = strtoupper(dechex($added));
					
					$itemStartData = substr($infoArray['Data'],0,92);
					$itemEndData = substr($infoArray['Data'],94);
					
					$item['CurrentValue'] = $infoArray['Defense'];
					$item['Result'] = hexdec($addDefResult);
					
					if(strlen($addDefResult)!=2){
					$item['Data'] = strtoupper($itemStartData.'0'.$addDefResult.$itemEndData);
					}else{
					$item['Data'] = strtoupper($itemStartData.$addDefResult.$itemEndData);
					}
					// $item['AddonType'] = $_config['ItemUpgradeDef'];
					}else{
						
					  jump_location('errorpage');
					}
				break;
		  case 2: //Defense Rate
				  if($isAddonValue['Defrate']){ 
					$addDefrateResult = $this->decode_ItemAddon_Fusion($infoArray,2,$infoArray['Defrate'],$added);
					$resultSet = $addDefrateResult['Result'];
					$item['CurrentValue'] = $resultSet['CurrentValue'];
					$item['Result'] = $resultSet['Total'];
					$item['Data'] = $addDefrateResult['Data'];
					// $item['AddonType'] = $_config['ItemUpgradeDefRate'];
					}else{
					  jump_location('errorpage');
					}
				  break;
		  case 5: //HP
				  if($isAddonValue['HP']){ 
					$addHPResult = $this->decode_ItemAddon_Fusion($infoArray,5,$infoArray['HP'],$added);
					$resultSet = $addHPResult['Result'];
					$item['CurrentValue'] = $resultSet['CurrentValue'];
					$item['Result'] = $resultSet['Total'];
					$item['Data'] = $addHPResult['Data'];
					// $item['AddonType'] = $_config['ItemUpgradeHP'];
					}else{
					  jump_location('errorpage');
					}
				  break;
		  case 11: //HP+MP+SP Recovery Rate	
				  if($isAddonValue['HMSrate']){ 
					$addHMSrateResult = $this->decode_ItemAddon_Fusion($infoArray,11,$infoArray['HMSrate'],$added);
					$resultSet = $addHMSrateResult['Result'];
					$item['CurrentValue'] = $resultSet['CurrentValue'];
					$item['Result'] = $resultSet['Total'];
					$item['Data'] = $addHMSrateResult['Data'];
					// $item['AddonType'] = $_config['ItemUpgradeHMSRate'];
					}else{
					  jump_location('errorpage');
					}
				  break;
		  case 3: //Hit Rate	
				  if($isAddonValue['Hitrate']){ 
					$addHitrateResult = $this->decode_ItemAddon_Fusion($infoArray,3,$infoArray['Hitrate'],$added);
					$resultSet = $addHitrateResult['Result'];
					$item['CurrentValue'] = $resultSet['CurrentValue'];
					$item['Result'] = $resultSet['Total'];
					$item['Data'] = $addHitrateResult['Data'];
					// $item['AddonType'] = $_config['ItemUpgradeHitRate'];
					}else{
					  jump_location('errorpage');
					}
				  break;
				  
		  case -1: 
				echo '<script type="text/javascript">alert("',ITEM_UPGRADE_SELECT_PROPERTIES_ERR_MSG,'");window.self.location=\'extend.php?do=webupitem_list&cid='.(int)$_GET['cid'].'\';</script>'; 
		  		break;
		  
		  default: 
		  		jump_location('errorpage'); 
		  		break;
	}
			return $item;
	}
	
	function decode_ItemAddon_Fusion($infoArray,$addonType,$addonValue,$addValue){
		
				if((int)$infoArray['Rv1Slot']==$addonType || (int)$infoArray['Rv1Slot'] == 0){
					$rvtype = dechex($addonType);
					$rvstartData = substr($infoArray['Data'],0,105);
					$rvmidData = substr($infoArray['Data'],106,6);
					
					$valueResult = $this->customize_ItemValue_Fusion($addonType,$addonValue,$addValue);
					
					$rvvalue = $this->decode_ItemAddonValue($valueResult['ResultValue']);
					$rvendData = substr($infoArray['Data'],116);
					
					#Data
					$randopt['Data'] = strtoupper($rvstartData.$rvtype.$rvmidData.$rvvalue.$rvendData);
					$randopt['Result'] = $valueResult;
	
				}else
				if((int)$infoArray['Rv2Slot']==$addonType || (int)$infoArray['Rv2Slot'] == 0){
					$rvtype = dechex($addonType);
					$rvstartData = substr($infoArray['Data'],0,107);
					$rvmidData = substr($infoArray['Data'],108,8);
					
					$valueResult = $this->customize_ItemValue_Fusion($addonType,$addonValue,$addValue);
					
					$rvvalue = $this->decode_ItemAddonValue($valueResult['ResultValue']);
					$rvendData = substr($infoArray['Data'],120);
					
					#Data
					$randopt['Data'] = strtoupper($rvstartData.$rvtype.$rvmidData.$rvvalue.$rvendData);
					$randopt['Result'] = $valueResult;
	
				}else
				if((int)$infoArray['Rv3Slot']==$addonType || (int)$infoArray['Rv3Slot'] == 0){
					
					$rvtype = dechex($addonType);
					$rvstartData = substr($infoArray['Data'],0,109);
					$rvmidData = substr($infoArray['Data'],110,10);
					
					$valueResult = $this->customize_ItemValue_Fusion($addonType,$addonValue,$addValue);
					
					$rvvalue = $this->decode_ItemAddonValue($valueResult['ResultValue']);
					$rvendData = substr($infoArray['Data'],124);
					
					#Data
					$randopt['Data'] = strtoupper($rvstartData.$rvtype.$rvmidData.$rvvalue.$rvendData);
					$randopt['Result'] = $valueResult;
	
				}else
				if((int)$infoArray['Rv4Slot']==$addonType || (int)$infoArray['Rv4Slot'] == 0){
					
					$rvtype = dechex($addonType);
					$rvstartData = substr($infoArray['Data'],0,111);
					$rvmidData = substr($infoArray['Data'],112,12);
					
					$valueResult = $this->customize_ItemValue_Fusion($addonType,$addonValue,$addValue);
					
					$rvvalue = $this->decode_ItemAddonValue($valueResult['ResultValue']);
					$rvendData = substr($infoArray['Data'],128);
					
					#Data
					$randopt['Data'] = strtoupper($rvstartData.$rvtype.$rvmidData.$rvvalue.$rvendData);
					$randopt['Result'] = $valueResult;
	
				}else{
					$randopt = false;
				}
				return $randopt;
		
	}
	
	function customize_ItemValue_Fusion($addonType,$addonValue,$addValue){
	
	  $value = $this->item_Value($addonValue);
	  
	  switch ($addonType){
		//Attack Rate
		case 1:
			$addon['Add'] = $addValue*100;
			$addon['Total'] = $addon['Add']/100;
			$addon['CurrentValue'] = $addon['Add']/100;
			break;
	  
		//Defense Rate
		case 2:
			$addon['Add'] = $addValue*100;
			$addon['Total'] = $addon['Add']/100;
			$addon['CurrentValue'] = $addon['Add']/100;
			break;
			
		//Hit Rate
		case 3:
			$addon['Add'] = $addValue*100;
			$addon['Total'] = $addon['Add']/100;
			$addon['CurrentValue'] = $addon['Add']/100;
			break;
			
		//HP
		case 5:
			$addon['Add'] = $addValue;
			$addon['Total'] = $addon['Add'];
			$addon['CurrentValue'] = $addon['Add'];
			break;
			
		//HP+MP+SP
		case 11:
			$addon['Add'] = $addValue*100;
			$addon['Total'] = $addon['Add']/100;
			$addon['CurrentValue'] = $addon['Add']/100;
			break;
	  }
			if($addon['Add']<0){
			$addon['ResultValue'] = substr(dechex($addon['Add']),4,4);
			}else{
			$addon['ResultValue'] = dechex($addon['Add']);
			}
			
			return $addon;
	}
	
	function checkCharacter($character){
		return $this->chaInfoDAO->characterInfo($character);
	}
}

?>