<?php
class UserLogic extends SecureLogin {

   var $userDAO;
   var $referrerDAO;
   var $shopItemMapDAO;
   var $shopPurchaseDAO;

   function UserLogic(){
	$this->userDAO = dao_getDAO("userinfo");
	$this->referrerDAO = dao_getDAO("referrer");
	$this->shopItemMapDAO = dao_getDAO("shopitemmap");
    $this->shopPurchaseDAO = dao_getDAO("shoppurchase");
	$this->handler['checklogin'] = 'user_checklogin';
	$this->handler['encode'] = 'md5_encrypt';
	$this->use_session = true;
   }

   function userLogin($user) {
	$this->post_index = array('user' => $user->userID,
							  'pass' => $user->userPass
							  );
	if ($this->haslogin(true)){
	   $this->savelogin();
	   return true;
	   }else{
	   return false;
	   }
	
	}
	function userAuth($user){
		return $this->userDAO->getUserNum($user);
	}
	
    function userLogout(){
		$this->clearlogin();
	}
	function getUserInfo($user){
	 	$result = $this->userDAO->getUserInfo($user);
	}
	
	function add_Point($user){
		$result = $this->userDAO->add_Point($user);
		if(is_bool($result)){
			return true;
		}else{
			trigger_error($result->ErrorMsg()); 
			exit;
		}
	}
	function check_UserOnline($user){
		$user->userLoginState = 1;
		$userOnline = $this->userDAO->userOnline($user);
		if($userOnline){
			return false;
		}else{
			return true;	
		}
		
	}
	function checkUserPassEmail($user) {
  	$result = $this->userDAO->checkUserPassEmail($user);
   	 	if($result){
		return true;
		}
		return false;
    }
    function checkUserPassword2($user) {
    	$result = $this->userDAO->checkUserPass2($user);
    	if($result){
    	return true;
    	}
    	return false;
    }
    function checkUserBlock($user) {
    	$user->userBlock = 1;
    	$result = $this->userDAO->checkUserBlock($user);
    	if($result){
    		return true;
    	}
    		return false;
    }
	function charge_Point($user){
		$result = $this->userDAO->charge_Point($user);
		if(is_bool($result)){
			return true;
		}else{
			trigger_error($result->ErrorMsg()); 
			exit;
		}
		
	}
	function goto_link($link=NULL,$LinkArg=true){
		if($LinkArg){
		$LinkArg = explode("/", $_SERVER['SCRIPT_NAME']);
		if($link!=NULL) $n_do = "?do=";
		$resumeLink = $LinkArg[1].$n_do.$link;
		}else{
		$resumeLink = $link;	
		}
		$_SESSION['goto_link'] = $resumeLink;
	}
	#-- Private Function
   function checkMaxAccount(){
	global $_config;
	$maxAccount = $this->userDAO->totalAccount();
	if($_config['RegisterMaxUser'] < $maxAccount){
		jump_location("errorpage");
	}
   }
   function getReferrerInfo($user){
	  	return $this->userDAO->getReferrerInfo($user);
   }
   function updateUserPass($user){
	global $_config;
	  if ($_config['Md5Encrypt']){
	  $user->userPass = strtoupper(substr(md5(clean_variable($user->userPass)),0,19));
	  }else{
	  $user->userPass = clean_variable($user->userPass);
	  }
	  $result = $this->userDAO->updateUserPass($user);
	  if(is_bool($result)){
		  return true;
	  }else{
		  trigger_error($result->ErrorMsg());
	  }
   }
   function updateUserPass2($user){
	global $_config;
	  if ($_config['Md5Encrypt']){
	  $user->userPass2 = strtoupper(substr(md5(clean_variable($user->userPass2)),0,19));
	  }else{
	  $user->userPass2 = clean_variable($user->userPass2);
	  }
	  $result = $this->userDAO->updateUserPass2($user);
	  if(is_bool($result)){
		  return true;
	  }else{
		  trigger_error($result->ErrorMsg());
	  }
   }
   function insertUserInfo($user){
	global $_config;
	  if ($_config['Md5Encrypt']){
	  $user->userPass = strtoupper(substr(md5(clean_variable($user->userPass)),0,19));
	  $user->userPass2 = strtoupper(substr(md5(clean_variable($user->userPass2)),0,19));
	  }else{
	  $user->userPass = clean_variable($user->userPass);
	  $user->userPass2 = clean_variable($user->userPass2);
	  }
	  $tjPrefix = "TJ";
	  $tjRandomID = $tjPrefix;
	  $tjRandomID .= chr(rand(65,90));
	  $tjRandomID .= microtime();
	  $tjRandomID .= uniqid($tjPrefix);
	  $user->tj = clean_variable(substr($tjRandomID,0,rand(10,15)));
	  $result = $this->userDAO->insertUserInfo($user);
	  if(is_bool($result)){
		  return true;
	  }else{
		  trigger_error($result->ErrorMsg());
	  }
		
		
	}
}
?>