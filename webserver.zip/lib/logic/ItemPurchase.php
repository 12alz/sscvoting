<?php
class ShopPurchaseLogic extends UserLogic {
	var $page = 1;
    var $perPage = 10;
	var $pageTitleName;
    
	function generate($array, $perPage = 10){
	  if (!empty($perPage))
      $this->perPage = $perPage;
	  $pageArg = explode("$", $_POST["__EVENTARGUMENT"]);
	  $page = (int)$pageArg[1];
      if (!empty($page) & $pageArg[0] == $this->pageTitleName) {
      $this->page = $page;
      }else{
      $this->page = $this->page;
      }
      $this->length = count($array);
      $this->pages = ceil($this->length / $this->perPage);
	  if($this->page > $this->pages){
	  $this->page = $this->pages;
	  }
      $this->start  = ceil(($this->page - 1) * $this->perPage);
      return array_slice($array, $this->start, $this->perPage);	  
	}
    function links(){	
	  $plinks = array();
      $links = array();
      $slinks = array();
      if ($this->pages > 1)
      {
		$range = 10;
		$range_min = ($range % 2 == 0) ? ($range / 2) - 1 : ($range - 1) / 2;
		$range_max = ($range % 2 == 0) ? $range_min + 1 : $range_min;
		$page_min = $this->page- $range_min;
		$page_max = $this->page+ $range_max;

		$page_min = ($page_min < 1) ? 1 : $page_min;
		$page_max = ($page_max < ($page_min + $range - 1)) ? $page_min + $range - 1 : $page_max;
		if ($page_max > $this->pages) {
			$page_min = ($page_min > 1) ? $this->pages - $range + 1 : 1;
			$page_max = $this->pages;
		}
		$page_min = ($page_min < 1) ? 1 : $page_min;
	  
	  		  $aLink = '<tr align="right" style="color:Black;background-color:#F7F7DE;">
			  <td colspan="4"><table border="0">
				  <tr>';
		  for ($j = $page_min; $j < ($page_max + 1); $j++) {
			if ($this->page == $j) {
			  $links[] = '<td><span>'.$j.'</span></td>';
			} else {
			  $links[] = '<td><a href="javascript:__doPostBack(\'ctl00ContentPlaceHolder_mainGridView1\',\''.$this->pageTitleName.'$'.$j.'\')" style="color:Black;">'.$j.'</a></td>'; 
			}
		  }
			  if($j > 10 & $j < $this->pages){
			  $links[] = '<td><span>...</span></td>';	
			  }
		  	  $bLink = '</tr>
			  </table></td>
		   </tr>';
		  
		  return $aLink.implode(' ', $plinks).implode($this->implodeBy, $links).implode(' ', $slinks).$bLink;
	  
	  
	  }
	  
	}
   function insert_ItemPurchase($purchase) {
        $result = $this->shopPurchaseDAO->insert_ItemPurchase($purchase);
		if(is_bool($result)){
			return true;
		}else{
			trigger_error($result->ErrorMsg());
		}
   
   }
   function insertBingoItemPurchase($purchase) {
        $result = $this->shopPurchaseDAO->insert_ItemPurchase($purchase);
		if(is_bool($result)){
			return true;
		}else{
			return $result->ErrorMsg();
		}
   
   }
   /*function random_ShopPurKey($min, $max) {    
			$generated = array();    
			for ($i = 0; $i < 100; $i++) {        
				$generated[] = mt_rand($min, $max);    
			}    
			shuffle($generated);    
			$position = mt_rand(0, 99);    
		
	return $generated[$position];
	}*/
	
	function get_PurchaseList($purchase,$perPage){
		$this->pageTitleName = "Page";
		$result = $this->shopPurchaseDAO->item_PurchaseList($purchase);
	    if($result){
		$itemPages = $this->generate($result,$perPage);
		return $itemPages;
		}
		return false;
	}
	function get_PurKeyMax(){
		return $this->shopPurchaseDAO->get_PurKeyMax($purchase);
	}
	
	
	
	function itemOrderList($purchase,$shopItemMap){
		$itemOrderPages = $this->get_PurchaseList($purchase,20);
	    if($itemOrderPages){
echo '
<tr class="aa" style="color:White;background-color:#CECFD6;font-weight:bold;">
			<th scope="col">Type</th><th scope="col">Name</th><th scope="col">Points</th><th scope="col">Date</th>

		</tr>
';
		$totalItemPurchase = count($itemOrderPages);
		for($p=0;$p<$totalItemPurchase;$p++){
		$shopItemMap->productNum = $itemOrderPages[$p][0];
		$productName = $this->shopItemMapDAO->getProductInfo($shopItemMap);
		if($p%2){
		 $alterRowStyle = "background-color:White;";	
		}else{
		 $alterRowStyle = "background-color:#F7F7DE;";	
		}
	echo '	
<tr style="',$alterRowStyle,'">
			<td align="center">Mall</td><td align="center">',$productName->itemName,'</td><td align="center">',$itemOrderPages[$p][1],'</td><td align="center">',date('Y-m-d H:i:s',strtotime($itemOrderPages[$p][2])),'</td>
		</tr>		
		';	
		}
	 
	  echo $this->links();
			
		}else{
	echo '		
<tr>
						<td colspan="4">No record</td>
				  </tr>		
				  ';	
		}
	}

    function payOrderList($purchase){
		$payOrderPages = $this->get_PurchaseList($purchase,25);
	    if($payOrderPages){
		$totalItemOrder = count($payOrderPages);
echo '		
<tr class="aa" style="color:White;background-color:#CECFD6;font-weight:bold;">
			<th scope="col">Account</th><th scope="col">Points</th><th scope="col">From</th><th scope="col">Date</th>

		</tr>		
		';
		for($i=0;$i<$totalItemOrder;$i++){
		  if($i%2){
		   $alterRowStyle = "background-color:White;";	
		  }else{
		   $alterRowStyle = "background-color:#C3D6DB;";	
		  }
		echo '	
<tr style="',$alterRowStyle,'">
			<td class="aa" align="center">',$payOrderPages[$i][3],'</td><td align="center">',$payOrderPages[$i][1],'</td><td align="center">Buy</td><td align="center" style="width:140px;">',date('Y-m-d H:i:s',strtotime($payOrderPages[$i][2])),'</td>
		</tr>	
		
		';	
		
		}	
	   echo $this->links();
		
		}else{
			echo '
<tr>
						<td colspan="4">No record</td>
				  </tr>
				  ';
		}
	}
}
?>