<?php
class RankPagination
{
    var $page = 1;
    var $perPage = 5;
	
    function generate($array, $perPage = 5){
	  if (!empty($perPage))
      $this->perPage = $perPage;
	  
	  $PageArg = explode("$", $_POST["__EVENTARGUMENT"]);
	  $Page = (int)$PageArg[1];
	  	  
      if (!empty($Page) & $PageArg[0] == "Page") {
      	$this->page = $Page;
      }else{
      	$this->page = 1;
      }
      $this->length = count($array);
      $this->pages = ceil($this->length / $this->perPage);
	  if($this->page > $this->pages){
	  $this->page = $this->pages;
	  }
      $this->start  = ceil(($this->page - 1) * $this->perPage);
      return array_slice($array, $this->start, $this->perPage);
	}

    function links(){	
	  $plinks = array();
      $links = array();
      $slinks = array();

      if (($this->pages) > 1){
		$range = 3;
		 /* $range_min = ($range % 2 == 0) ? ($range / 2) - 1 : ($range - 1) / 2;
		 $range_max = ($range % 2 == 0) ? $range_min + 1 : $range_min;
		 $page_min = $this->page- $range_min;
		 $page_max = $this->page+ $range_max; */

		$page_min = ($page_min < 1) ? 1 : $page_min;
		$page_max = ($page_max < ($page_min + $range - 1)) ? $page_min + $range - 1 : $page_max;
		if ($page_max > $this->pages) {
			$page_min = ($page_min > 1) ? $this->pages - $range + 1 : 1;
			$page_max = $this->pages;
		}
		$page_min = ($page_min < 1) ? 1 : $page_min;
        	$alink = '<td colspan="7"><table border="0">';
		for ($j = $page_min; $j < ($page_max + 1); $j++) {
          if ($this->page == $j) {
            $links[] = '<td><span>'.$j.'</span></td>';
          } else {
            $links[] = '<td><a href="javascript:__doPostBack(\'ctl00$ContentPlaceHolder_main$GridView1\',\'Page$'.$j.'\')" style="color:white;">'.$j.'</a></td>';
          }
        }
			if($j > 10 & $j < $this->pages){
			$links[] = '<td><span style="color:Black;">...</span></td>';	
			}
			$blink = '</table></td>';
        return $alink.implode(' ', $plinks).implode($this->implodeBy, $links).implode(' ', $slinks).$blink;
	  }
	  
	  
	}

}
class RankLogic  extends RankPagination{
	
   var $chaInfoDAO;
   var $guildInfoDAO;
   
   function RankLogic() {
   $this->chaInfoDAO = dao_getDAO("chainfo");
   $this->guildInfoDAO = dao_getDAO("guildinfo");
   }

   function getTop5Character($character,$hideGM) {

	 $top5Result = $this->chaInfoDAO->top5Character($character,$this->isHideGM($hideGM));
	 if(!is_array($top5Result) & count($top5Result)){
	 $this->showErrorMsg($top5Result);
	 }else{
	 $top5Count = count($top5Result);
	 if(count($top5Count)){
	 for($i=0;$i<$top5Count;$i++){
	 echo '	 
	  <li style="display:block; width:170px; height:20px;padding-left:15px;padding-right:15px;float:left;border-bottom:1px solid #AFE0FA;">
		  <span style="display:block; float:right; padding-top:0px; text-decoration:none;">',$top5Result[$i][0],'</span>
  
		  <span style="display:block; float:left; padding-top:0px;text-decoration:none;color:#4191BB;font-weight:bold">',$lblNo = $lblNo+1,'</span>
	  </li>
	  ';
	 }
	 }else{
	echo '
	  <span style="display:block; float:left; padding-top:0px; text-decoration:none;">
	  <br><br>
	  No record.
	  </span>
	 ';	   		 
	 }
	 }
   }

   function getClubWarWinner($guild,$guildRegionName) {
   	 $clubWarResult = $this->guildInfoDAO->clubWarWinner($guild);
	 if(!is_array($clubWarResult) & count($clubWarResult)){
	 $this->showErrorMsg($clubWarResult);
	 }else{
	 $clubWarCount = count($clubWarResult);
	 if(count($clubWarResult)){
	 if($clubWarCount > 4){
		 $altHeightLabel = 18;
	 }else{
		 $altHeightLabel = 20;
	 }
	 for($i=0;$i<$clubWarCount;$i++){
	 echo '
	  <li style="display:block; width:170px; height:',$altHeightLabel,'px;padding-left:15px;padding-right:15px;float:left;border-bottom:1px solid #AFE0FA;">
		  <span style="display:block; float:right; padding-top:0px; text-decoration:none;">',trim($clubWarResult[$i][0]),'</span>
  
		  <span style="display:block; float:left; padding-top:0px;text-decoration:none;color:#4191BB;font-weight:bold">',$guildRegionName[$clubWarResult[$i][1]],'(',$clubWarResult[$i][2],'%)</span>
	  </li>
	 ';
	 }
	}else{
	echo '
	  <span style="display:block; float:left; padding-top:0px; text-decoration:none;">
	  <br><br>
	  No record.
	  </span>
	 ';	   	 
	}
	 
   }
   }
   function rankList($character,$pageLimitView,$hideGM,$rankLimit,$chaSchoolAction,$chaClassName,$chaSchoolName){
	 $rankListResult = $this->chaInfoDAO->rankList($character,$this->isHideGM($hideGM),$rankLimit,$this->rankListSchool(clean_variable($chaSchoolAction)));
	 if(!is_array($rankListResult) & count($rankListResult)){
	 echo '<tr>
						<td colspan="7">',$rankListResult->ErrorMsg(),'</td>
				  </tr>';	 
	 }else{
	  if(count($rankListResult)){
	  $rankListPages = $this->generate($rankListResult, $pageLimitView);
	  $totalRankList = count($rankListPages);
		for ($i=0;$i<$totalRankList;$i++){	
		 if($i%2){
		 $alterRow = "bottom-border:1px solid #fff;";
		 }else{
		 $alterRow = "bottom-border:1px solid #fff;";	 
		 }
		 $date = $rankListPages[$i][7];
		 $formatted_date = date('Y-m-d', strtotime($date));

		 echo '
		  <tr class="aa" style="',$alterRow,'">
					  <td align="center">
			 
						  <span id="ctl00_ContentPlaceHolder_main_rank_GridView1_ctl02_lblNo">',$rankListPages[$i][0],'</span>   
					  
		  </td><td class="aa" align="left">
			<span id="ctl00_ContentPlaceHolder_main_rank_GridView1_ctl02_ChaName_">',$rankListPages[$i][1],'</span>   
		  
		  </td>
		  <td align="center">',$rankListPages[$i][2],'</td>
		  <td align="center">',$rankListPages[$i][3],'</td>
		  <td align="center">',$rankListPages[$i][6],'</td>
		  <td align="center">',$chaClassName[$rankListPages[$i][4]],'</td>
		  <td align="center">',$chaSchoolName[$rankListPages[$i][5]],'</td>
		  <td align="center">',$formatted_date,'</td>
				  </tr>	
		  '; 
		}
	  }else{
		 echo '<tr>
						<td colspan="8">No record.</td>
				  </tr>';	 
		  
	  }
	 }
   }
   function donorankList($character,$pageLimitView,$hideGM,$chaSchoolAction,$chaClassName,$chaSchoolName,$chaExp){
	 $rankListResult = $this->chaInfoDAO->donorankList($character,$this->isHideGM($hideGM),$rankLimit,$this->rankListSchool(clean_variable($chaSchoolAction)),$this->$chaClassName);
	 if(!is_array($rankListResult) & count($rankListResult)){
	 echo '<tr>
						<td colspan="5">',$rankListResult->ErrorMsg(),'</td>
				  </tr>';	 
	 }else{
	  if(count($rankListResult)){
	  $rankListPages = $this->generate($rankListResult, $pageLimitView);
	  $totalRankList = count($rankListPages);
		for ($i=0;$i<$totalRankList;$i++){	
		 if($i%2){
		 $alterRow = "background-color:White;";
		 }else{
		 $alterRow = "background-color:#C3D6DB;";	 
		 }
		 echo '
		  <tr class="aa" style="',$alterRow,'">
					  <td align="center">
			 
						  <span id="ctl00_ContentPlaceHolder_main_rank_GridView1_ctl02_lblNo">',$rankListPages[$i][0],'</span>   
					  
		  </td><td class="aa" align="center">
			<span id="ctl00_ContentPlaceHolder_main_rank_GridView1_ctl02_ChaName_">',$rankListPages[$i][1],'</span>   		  
		  </td>		  
		  <td align="center">',$rankListPages[$i][2],'</td>
		  <td align="center">',$rankListPages[$i][3],'</td>
				  </tr>	
		  '; 
		}
	  }else{
		 echo '<tr>
						<td colspan="5">No record.</td>
				  </tr>';	 
		  
	  }
	 }
   }
   #-- Private Function
   function showErrorMsg($result){
	echo '
	  <span style="display:block; float:left; padding-top:0px; text-decoration:none;">
	  <br><br>
	  ',$result->ErrorMsg(),'
	  </span>
	 ';	   
   }
	function rankListSchool($id){
		
		switch ($id)
		{
			case 'SG': return "AND ChaSchool = '0'"; break;	
			case 'MP': return "AND ChaSchool = '1'"; break;	
			case 'Phoenix': return "AND ChaSchool = '2'"; break;
			default: return "AND ChaSchool >= 0"; break;	
		}
			
		
	}
   function isHideGM($hideGM){
	 if($hideGM){
		return $option = "AND U.UserType != 30";
	 }else
	   return '';
   }
   
}
?>