<?php
class VoteLogic {
   
   var $voteDAO;
   
   function VoteLogic() {
   $this->voteDAO = dao_getDAO("vote");
   }
   
   function date_TimeDiff($strDateTime1,$strDateTime2){
			return (strtotime($strDateTime2) - strtotime($strDateTime1)); 
   }
   
   function getUserVote($vote){
	   return $this->voteDAO->getUserVote($vote) ;
   }
   function updateVoteInfo($vote){
	  $vote->Date = date('Y-m-d H:i:s');
	  $vote->hits = 1;
	  $result = $this->voteDAO->updateVoteInfo($vote);
	  if(is_bool($result)){
		  return true;
	  }else{
		  trigger_error($result->ErrorMsg()); 
	  }
   }
   function updateLastVote($vote){
	 $result = $this->voteDAO->updateLastVote($vote);
	  if(is_bool($result)){
		  return true;
	  }else{
		  trigger_error($result->ErrorMsg()); 
	  }
   }
   function insertVoteInfo($vote) {
	 $vote->last_Vote = 1;
	 $vote->hits = 0;  
	 $result = $this->voteDAO->insertVoteInfo($vote);
	  if(is_bool($result)){
		  return true;
	  }else{
		  trigger_error($result->ErrorMsg()); 
	  }
   }
}
?>