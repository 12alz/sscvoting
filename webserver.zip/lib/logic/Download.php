<?php
class DownloadLogic {
	
   var $downloadDAO;
   
   function DownloadLogic() {
   $this->downloadDAO = dao_getDAO("download");
   }

   function downloadList($download) {
	$clientResult = $this->downloadDAO->downloadList($download);
	if(!is_array($clientResult) & count($result)){
	echo '<tr>
						<td colspan="3">',$clientResult->ErrorMsg(),'</td>
				  </tr>
	 ';	   
	}else{
	$totalClientResult = count($clientResult);
	for ($i=0;$i<$totalClientResult;$i++){
	echo '
	  <TR vAlign=center align=middle>
	  <TD width=106><FONT color=#003366 size=2 face=Verdana>',$clientResult[$i][0],'</FONT></TD>
	  <TD width=214><FONT color=#003366 size=2 face=Verdana>',date('F j, Y',strtotime($clientResult[$i][1])),'</FONT></TD>
	  <TD width=162><STRONG><FONT size=2 face=Verdana><A href="',$clientResult[$i][2],'">Mirror',$clientResult[$i][3],'</A></FONT></STRONG></TD></TR>
	';
	}
	}
   }

}

?>