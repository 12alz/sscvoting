<?php
class ReferrerPagination extends UserLogic
{
	var $page = 1;
    var $perPage = 10;
	var $pageTitleName;
    function generate($array, $perPage = 10)
    {
	  if (!empty($perPage))
      $this->perPage = $perPage;
	  
	  $pageArg = explode("$", $_POST["__EVENTARGUMENT"]);
	  $page = (int)$pageArg[1];
	  	  
      if (!empty($page) & $pageArg[0] == $this->pageTitleName) {
      	$this->page = $page;
      }else{
      	$this->page = $this->page;
      }
      $this->length = count($array);
      $this->pages = ceil($this->length / $this->perPage);
	  if($this->page > $this->pages){
	  $this->page = $this->pages;
	  }
      $this->start  = ceil(($this->page - 1) * $this->perPage);
      return array_slice($array, $this->start, $this->perPage);	  
	}
    function links()
    {	
	  $plinks = array();
      $links = array();
      $slinks = array();
      if ($this->pages > 1)
      {
		$range = 10;
		$range_min = ($range % 2 == 0) ? ($range / 2) - 1 : ($range - 1) / 2;
		$range_max = ($range % 2 == 0) ? $range_min + 1 : $range_min;
		$page_min = $this->page- $range_min;
		$page_max = $this->page+ $range_max;

		$page_min = ($page_min < 1) ? 1 : $page_min;
		$page_max = ($page_max < ($page_min + $range - 1)) ? $page_min + $range - 1 : $page_max;
		if ($page_max > $this->pages) {
			$page_min = ($page_min > 1) ? $this->pages - $range + 1 : 1;
			$page_max = $this->pages;
		}
		$page_min = ($page_min < 1) ? 1 : $page_min;
	  
	  		  $aLink = '<tr align="right">
			  <td colspan="4"><table border="0">
				  <tr>';
		  for ($j = $page_min; $j < ($page_max + 1); $j++) {
			if ($this->page == $j) {
			  $links[] = '<td><span>'.$j.'</span></td>';
			} else {
			  $links[] = '<td><a href="javascript:__doPostBack(\'ctl00ContentPlaceHolder_mainGridView1\',\''.$this->pageTitleName.'$'.$j.'\')">'.$j.'</a></td>'; 
			}
		  }
			  if($j > 10 & $j < $this->pages){
			  $links[] = '<td><span>...</span></td>';	
			  }
		  	  $bLink = '</tr>
			  </table></td>
		   </tr>';
		  
		  return $aLink.implode(' ', $plinks).implode($this->implodeBy, $links).implode(' ', $slinks).$bLink;
	  
	  
	  }
	  
	}
}
class ReferrerLogic extends ReferrerPagination {
  
   function get_ReferrerList($referrer){
	   $this->pageTitleName = "Page";
	   $result = $this->referrerDAO->get_ReferrerList($referrer);
	   if($result){
	   return $this->generate($result , 15);
	   }
	   return false;
   }
   function getReferrerStatus($referrer) {
	  	return $this->referrerDAO->referrerStatus($referrer);
   }

   function updateReferrerInfo($referrer){
	   $result = $this->referrerDAO->updateReferrerStatus($referrer);
	   if(is_bool($result)){
			return true;
	   }else{
			trigger_error($result->ErrorMsg());
	   }
	   
   }
   function insertReferrerInfo($referrer){
	   $result = $this->referrerDAO->insertReferrerInfo($referrer);
	   if(is_bool($result)){
			return true;
	   }else{
			trigger_error($result->ErrorMsg());
	   }
   }
   function referrerUserList($referrer,$user){
	   $referrer->reFUserNum = $user->userNum;
	   $referrer->status = 0;
	   $userPages = $this->get_ReferrerList($referrer);
	   if($userPages){
echo '
<tr style="color:White;background-color:#8C8C8C;font-weight:bold;">

			<th scope="col">ID</th><th scope="col">Date</th><th scope="col">Rebirth</th><th scope="col">Get Points</th>
		</tr>
	   ';
	   $totalUserList = count($userPages);
	   for($r=0;$r<$totalUserList;$r++){
	   if($r%2){
		$alterRowStyle = "background-color:White;";   
	   }else{
		$alterRowStyle = "background-color:#D7F0EF;";   
	   }
echo	'	   
<tr style="',$alterRowStyle,'">
			<td align="center">
					<span id="ctl00_ContentPlaceHolder_main_CustomersGridView_ctl02_UserID">',substr($userPages[$r][0],0,strlen($userPages[$r][0])-3),'***','</span>
                </td><td align="center">',date('Y-m-d H:i:s',strtotime($userPages[$r][1])),'</td><td align="center">',$userPages[$r][2],'</td><td align="center">',$userPages[$r][3],'</td>

		</tr>	
		';	   
	   }
		echo  $this->links();
	   }else{
	echo '	   
<tr>

			<td colspan="4">No record</td>
		</tr>	
		';	   
	   }
	   
   }
   function referrerReportList($referrer,$user){
	   $referrer->reFUserNum = $user->userNum;
	   $referrer->status = 1;
	   $userPages = $this->get_ReferrerList($referrer);
	   if($userPages){
echo '
<tr style="color:White;background-color:#8C8C8C;font-weight:bold;">

			<th scope="col">ID</th><th scope="col">Date</th><th scope="col">Rebirth</th><th scope="col">Get Points</th>
		</tr>
	   ';
	   $totalUserList = count($userPages);
	   for($r=0;$r<$totalUserList;$r++){
	   if($r%2){
		$alterRowStyle = "background-color:White;";   
	   }else{
		$alterRowStyle = "background-color:#D7F0EF;";   
	   }
echo	'	   
<tr style="',$alterRowStyle,'">
			<td align="center">
					<span id="ctl00_ContentPlaceHolder_main_CustomersGridView_ctl02_UserID">',substr($userPages[$r][0],0,strlen($userPages[$r][0])-3),'***','</span>
                </td><td align="center">',date('Y-m-d H:i:s',strtotime($userPages[$r][1])),'</td><td align="center">',$userPages[$r][2],'</td><td align="center">',$userPages[$r][3],'</td>

		</tr>	
		';	   
	   }
		echo  $this->links();
	   }else{
	echo '	   
<tr>

			<td colspan="4">No record</td>
		</tr>	
		';	   
	   }
	   
   }
   
   
   
}
?>