<?php
class CharacterInventoryLogic extends ChaRebornLogic
{

	function characterAllItemsList($character){
		$allItemPagination = new ItemPagination;
		$allItemPagination->pageTitleName = "Page";
		$characterInfo = $this->get_CharacterInfo($character);
		$items = $this->item_view($characterInfo->chaInven,false,false);
		$excludeItem = $this->count_ItemFilter($items,false);
		if($excludeItem){
		  $itemPages = $allItemPagination->generate($excludeItem, 15);
		  $totalItems = count($itemPages);
		  for($i=0;$i<$totalItems;$i++){
			  $itemDecode = $this->decode_ItemValues2($itemPages[$i]);
			  if($i%2){
				$rowStyle =  "altrowstyle";
			  }else{
				$rowStyle =  "rowstyle";
			  }
  echo '	
  <tr class="',$rowStyle,'" onmouseover="this.style.backgroundColor=\'#DAEAFD\';this.style.color=\'blue\'" onmouseout="this.style.backgroundColor=\'\'" style="height:20px;">
				  <td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">
								  <span id="ctl00_ContentPlaceHolder_main_GridView1_ctl02_lblNo">',$itemPages[$i]['lblNo'],'</span>
  
							  </td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Name'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Damage'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Defense'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Makenum'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;font-weight:normal;width:140px;"><input type="submit" name="ctl00$ContentPlaceHolder_main$GridView1$ctl02$ctl00" value="Delete" onclick="if(confirm(\'Do you want to delete [',str_replace("'","\'",$itemDecode['Name']),'] in your Character Inventory?\nThis operation is not reversible\'))__doPostBack(\'ctl00ContentPlaceHoldermainCustomersItemView\',\'Delete$',$itemPages[$i]['Num'],'\');return false;" class="btn001" style="font-weight:normal;" /></td>
			  </tr>
			  ';
		  }
		  echo $allItemPagination->links();
		  }else{
  echo '	
<tr class="rowstyle" onmouseover="this.style.backgroundColor=\'#DAEAFD\';this.style.color=\'blue\'" onmouseout="this.style.backgroundColor=\'\'" style="height:20px;">
				<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">
				                <span id="ctl00_ContentPlaceHolder_main_GridView1_ctl02_lblNo">--</span>

				            </td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--</td><td disabled="disabled" align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;font-weight:normal;width:140px;"><input type="submit" name="ctl00$ContentPlaceHolder_main$GridView1$ctl02$ctl00" value="Delete" disabled="disabled" class="btn001" onclick="if(confirm(\'Do you want to delete [--] in your Character Inventory?\nThis operation is not reversible\'))__doPostBack(\'ctl00ContentPlaceHoldermainCustomersItemView\',\'Delete$\');return false;" style="font-weight:normal;" /></td>
			</tr>
			  ';
		 }
	}

	function recoverCharacterAllItemsList($character){
		$allItemPagination = new ItemPagination;
		$allItemPagination->pageTitleName = "Page";
		$characterInfo = $this->get_CharacterInfo($character);
		$items = $this->item_view($characterInfo->chaInven,false,false);
		$excludeItem = $this->count_ItemFilter($items,false);
		if($excludeItem){
		  $itemPages = $allItemPagination->generate($excludeItem, 15);
		  $totalItems = count($itemPages);
		  for($i=0;$i<$totalItems;$i++){
			  $itemDecode = $this->decode_ItemValues($itemPages[$i]);
			  if($i%2){
				$rowStyle =  "altrowstyle";
			  }else{
				$rowStyle =  "rowstyle";
			  }
  echo '	
  <tr class="',$rowStyle,'" onmouseover="this.style.backgroundColor=\'#DAEAFD\';this.style.color=\'blue\'" onmouseout="this.style.backgroundColor=\'\'" style="height:20px;">
				  <td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">
								  <span id="ctl00_ContentPlaceHolder_main_GridView1_ctl02_lblNo">',$itemPages[$i]['lblNo'],'</span>
  
							  </td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Name'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Damage'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Defense'],'</td>
			  </tr>
			  ';
		  }
		  echo $allItemPagination->links();
		  }

	}
	
	
	function characterItemsList($character){
		$chaInvenPagination = new ItemPagination;
		$chaInvenPagination->pageTitleName = "iPage";
		$characterInfo = $this->get_CharacterInfo($character);
		
		$items = $this->item_view($characterInfo->chaInven);
		$excludeItem = $this->count_ItemFilter($items);
		// echo '<pre>';
		// var_dump($items);exit();//OTEP STOP
		
		if($excludeItem){
			// $types = $included_item['types'];
			// $item_ids = $included_item['item_ids'];
		  $itemPages = $chaInvenPagination->generate($excludeItem, 5);
		  $totalItems = count($itemPages);
		  for($i=0;$i<$totalItems;$i++){
			  $itemDecode = $this->decode_ItemValues($itemPages[$i]);
			  if($i%2){
				$rowStyle =  "altrowstyle";
			  }else{
				$rowStyle =  "rowstyle";
			  }
			  
  echo '	
  <tr class="',$rowStyle,'" onmouseover="this.style.backgroundColor=\'#DAEAFD\';this.style.color=\'blue\'" onmouseout="this.style.backgroundColor=\'\'" style="height:20px;">
				  <td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">
								  <span id="ctl00_ContentPlaceHolder_main_GridView1_ctl02_lblNo">',$itemPages[$i]['lblNo'],'</span>
  
							  </td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Name'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Damage'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Defense'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Atkrate'],'%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Defrate'],'%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['HP'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['HMSrate'],'%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Hitrate'],'%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">',$itemDecode['Makenum'],'</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;font-weight:normal;width:140px;"><input type="submit" name="ctl00$ContentPlaceHolder_main$GridView1$ctl02$ctl00" value="Import Web Warehouse" onclick="if(confirm(\'Do you want to import [',str_replace("'","\'",$itemDecode['Name']),'] to the Web Warehouse?\'))__doPostBack(\'ctl00ContentPlaceHoldermainCustomersGridView\',\'ImportWB$',$itemPages[$i]['Num'],'\');return false;" class="btn002" style="font-weight:normal;" /></td>
			  </tr>
			  ';
		  }
		  echo $chaInvenPagination->links();
		  }else{
  echo '	
<tr class="rowstyle" onmouseover="this.style.backgroundColor=\'#DAEAFD\';this.style.color=\'blue\'" onmouseout="this.style.backgroundColor=\'\'" style="height:20px;">
				<td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">
				                <span id="ctl00_ContentPlaceHolder_main_GridView1_ctl02_lblNo">--</span>

				            </td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--%</td><td align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;">--%</td><td disabled="disabled" align="center" style="border-color:#D4D0C8;border-width:1px;border-style:solid;font-weight:normal;width:140px;"><input type="submit" name="ctl00$ContentPlaceHolder_main$GridView1$ctl02$ctl00" value="Import Web Warehouse" disabled="disabled" class="btn002" onclick="if(confirm(\'Do you want to import [--] to the Web Warehouse?\'))__doPostBack(\'ctl00ContentPlaceHoldermainCustomersGridView\',\'ImportWB$\');return false;" style="font-weight:normal;" /></td>
			</tr>
			  ';
		 }
	}
	function deleteItem($character,$itemNum){	
		if(ctype_digit($itemNum)){
		$itemList = $this->item_view($character->chaInven,true,false);
		#Cute ItemHeader
		$chaInvenItems = substr(bin2hex($character->chaInven),24);
		if (substr($chaInvenItems,0,2)=='0x') 
		$chaInvenItems = strtoupper(substr($chaInvenItems,2));
		$chaInvenNewHeader = $this->item_HeaderNew($character->chaInven,"sub");		
		$newData = str_replace(strtoupper($itemList[$itemNum][0]),'',strtoupper($chaInvenItems));
		$info['Old'] = $chaInvenItems;
		$info['Data'] = strtoupper($chaInvenNewHeader.$newData);
		$info['Decode'] = $this->item_decode($itemList[$itemNum][0],NULL,NULL,false);
		return $info;
		}else{
		jump_location("errorpage");
		}
	}
	function characterUpdateInventory($character){
		$result = $this->chaInfoDAO->update_inven($character);
		$this->is_Error($result);
	}
	
	function characterItemSlotRebuild($data,$character){
			$this->itemslot_build($data,$character);		
	}

	function checkInventorySlot($totalCharacterItems,$character){
		// echo '<pre>';
		// var_dump((4+$character->chaInvenLine)*6);
		// exit();
		if($totalCharacterItems < (4+$character->chaInvenLine)*6){
				return true;
		}
		return false;		
	}
	function getCharacterItemData($character){
		#Character Inventory
		$characterInfo = $this->get_CharacterInfo($character);

		$characterInvenDecode = strtoupper(bin2hex($characterInfo->chaInven));
		if($characterInvenDecode==NULL){
			$info['Data'] = "120100005000000001000000";
			$info['TotalItems'] = 0;

		}else{
			//Item Header Update
			$inventoryHeader = $this->item_HeaderNew($characterInfo->chaInven,"sum");//OTP
			
			//Character Items
			$characterInvenCut = substr(bin2hex($characterInfo->chaInven),24);
			// consoleLOGS($inventoryHeader);
			//Build New Item
			$info['Data'] = strtoupper($inventoryHeader.$characterInvenCut);
			// echo '<pre>';
			// var_dump($info['Data']);exit();//OTP
			
			#return how many items in character inventory
			
			$characterInvenitems = strtoupper(substr(bin2hex($characterInfo->chaInven),0,24));
			$info['TotalItems'] = hexdec($characterInvenitems[16].$characterInvenitems[17]);

		}
		// echo '<pre>';
		// var_dump($ss);exit();
		// echo '<pre>';
		// var_dump($info['TotalItems']);exit();
		return $info;
	}
	function importItemStorage($character,$itemNo){
		// echo '<pre>';
		// var_dump($itemNo);exit();
		$itemList = $this->item_view($character->chaInven,true,false);
		#Cute ItemHeader
		$chaInvenItems = substr(bin2hex($character->chaInven),24);
		if (substr($chaInvenItems,0,2)=='0x') 
		$chaInvenItems = strtoupper(substr($chaInvenItems,2));
		$chaInvenNewHeader = $this->item_HeaderNew($character->chaInven,"sub");
		$importItem = str_replace(strtoupper($itemList[$itemNo[1]][0]),"",strtoupper($chaInvenItems));
		$info['Decode'] = $this->item_decode($itemList[$itemNo[1]][0],NULL,NULL);
		$info['NewData'] = $chaInvenNewHeader.$importItem;
		return $info;
	}
	function prepareCharacterItemData($character){
		return $this->get_ItemData($character->chaInven);		
	}
	
}
class CharacterSkillsLogic extends CharacterInventoryLogic{

	function getClassName($character){
		switch($character->chaClass){
			case 1: case 64:
				    return "Brawler";
					break;
				
			case 2: case 128:
				    return "Swordsman";
					break;
			
			case 4: case 256:
				    return "Archer";
					break;
					
			case 8: case 512:
				    return "Shaman";
					break;
					
			case 16: case 32:
				    return "Extreme";
					break;
		}
	}
	function get_ClassGender($character){
		switch($character->chaClass){
				case 1: case 2: case 16: case 256: case 512:
					$character->chaSex = 1;
					break;
				
				case 4: case 8: case 32: case 64: case 128:
					$character->chaSex = 0;
					break;
		}
	}
	function revertClass($character){
		 switch ($character->chaClass){
					case 1: 
							$character->chaClass = 64;
							break; 
					
					case 2: 
							$character->chaClass = 128;
							break; 
					
					case 4: 
							$character->chaClass = 256;
							break; 
					
					case 8: 
							$character->chaClass = 512;
							break; 
					
					case 16: 
							$character->chaClass = 32;
							break; 
					
					case 32: 
							$character->chaClass = 16;
							break; 
					
					case 64: 
							$character->chaClass = 1;
							break; 
					
					case 128: 
							$character->chaClass = 2;
							break; 
					
					case 256: 
							$character->chaClass = 4;
							break; 
					
					case 512: 
							$character->chaClass = 8;
							break; 
		}
	}
	function constructSkillData($main,$sub,$lvl){
	
		  $skillLv = dechex($lvl);
	  
		  $skillMain = dechex($main);
		  if(strlen($skillMain)!=2)
		  $skillMain = '0'.dechex($main);
		  
		  $skillSub = dechex($sub);
		  if(strlen($skillSub)!=2)
		  $skillSub = '0'.dechex($sub);
		  
		  $skillData = strtoupper($skillMain.'00'.$skillSub.'000'.$skillLv.'00000C');
		  $skill0 = $skillData[0];
		  $skill1 = $skillData[1];
		  $skill3 = $skillData[3];
		  $_id 	=  hexdec($skill3.$skill0.$skill1);	//SkillMain
		  $skill4 = $skillData[4];
		  $skill5 = $skillData[5];
		  $skill7 = $skillData[7];
		  $_sidsub =  hexdec($skill7.$skill4.$skill5); // SkillSub
		  
		  $info['Main'] = $_id;
		  $info['Sub'] = $_sidsub;
		  $info['Data'] = $skillData;
		  
		  return $info;
	}
	function getSkillHeaderData($counterNo,$character){
		$characterInfo = $this->get_CharacterInfo($character);
		
		$skill['Data'] = substr(bin2hex($characterInfo->chaSkills),24);
		$skill['Header'] = substr(bin2hex($characterInfo->chaSkills),0,24);
		
		if($skill['Header']==NULL){
		$skill['Header'] = "000100000800000000000000";
		}else{
		$skill['Header'] = substr(bin2hex($characterInfo->chaSkills),0,24);
		}
		
		$totalSkill =  hexdec($skill['Header'][16].$skill['Header'][17]);
		
		$addSkill =  dechex($totalSkill+$counterNo);
		if(strlen($addSkill)!=2)
		$addSkill =  '0'.dechex($totalSkill+$counterNo);
		$startSkillHeader = substr($skill['Header'],0,16);	
		$endSkillHeader = substr($skill['Header'],18);	
		$skill['Header'] = $startSkillHeader.$addSkill.$endSkillHeader;
		
		return $skill;
	
	}
	function updateClassSkills($character){
	global $_config;
	$chaClass = $this->getClassName($character);
	$skillList = $_config['ClassSkillsList'];
	$skillMainCount = count($skillList[$chaClass]);

	for($k=0;$k<$skillMainCount;$k++){
	
	$skillArray =  array_values($skillList[$chaClass][$k]['Sub']);
	$skillValues = array_reverse($skillArray, true);
	$skillSubCount = count($skillValues);
		
		for($c=0;$c<$skillSubCount;$c++){
			
		  $skillData = $this->constructSkillData($skillList[$chaClass][$k]['Main'],$skillValues[$c],$skillList['SkillLevel']);
		  $skillHeaderData = $this->getSkillHeaderData(1,$character);
		  $character->chaSkills = strtoupper($skillHeaderData['Header'].$skillHeaderData['Data'].$skillData['Data']);
		  $this->characterUpdateSkills($character);
				
		}

	}
	
	
	}
	function characterUpdateSkills($character){
		$updateResult = $this->chaInfoDAO->updateChaSkills($character);
		$this->is_Error($updateResult);
	}
	function removeChaSkills($character){
		$skillsResult = $this->chaInfoDAO->removeChaSkills($character);
		$this->is_Error($skillsResult);
	}
	function removeChaSkillSlot($character){
		$result = $this->chaInfoDAO->removeChaSkillSlot($character);
		$this->is_Error($result);
	}
	function update_ChaClass($character){
		$classResult = $this->chaInfoDAO->update_ChaClass($character);		
		$this->is_Error($classResult);
	}
	function updateChangeClass($character){
		$changeClassResult = $this->chaInfoDAO->updateChangeClass($character);		
		$this->is_Error($changeClassResult);
	}
}
class CharacterLogic extends CharacterSkillsLogic
{
	function characterList($character){
	  $this->characterVO->userNum = $character;
	  $charList = $this->chaInfoDAO->characterList($character);
	  if(!is_array($charList) & $charList){
	  echo '<option value="-1">',$charList->ErrorMsg(),'</option>';
	  }else{
		  if(!$charList){
			  echo '<option value="-1">No char</option>';
		  }else{
		  	  $totalCharacter = count($charList);
			  for($c=0;$c<$totalCharacter;$c++){
				  $temp_c = '<option ';
				  if((int)$_POST["ChaList"]==$charList[$c][0]){
				  $temp_c.= 'selected="selected" ';
				  }
				  $temp_c.= 'value="'.$charList[$c][0].'">';
				  $temp_c.= $charList[$c][1];
				  $temp_c.= '</option>'."\n";
			  echo $temp_c;
		  	  }
		  }
		}
	}
	function characterDeletedList($character){
	  $this->characterVO->userNum = $character;
	  $charList = $this->chaInfoDAO->characterDeletedList($character);
	  if(!is_array($charList) & $charList){
	  echo '<option value="-1">',$charList->ErrorMsg(),'</option>';
	  }else{
		  if(!$charList){
			  echo '<option value="-1">No char</option>';
		  }else{
		  	  $totalCharacter = count($charList);
			  for($c=0;$c<$totalCharacter;$c++){
				  $temp_c = '<option ';
				  if((int)$_POST["ChaList"]==$charList[$c][0]){
				  $temp_c.= 'selected="selected" ';
				  }
				  $temp_c.= 'value="'.$charList[$c][0].'">';
				  $temp_c.= $charList[$c][1];
				  $temp_c.= '</option>'."\n";
			  echo $temp_c;
		  	  }
		  }
		}
	}
	function charge_Money($character){
		$result = $this->chaInfoDAO->update_ChaMoney($character);		
		$this->is_Error($result);
	}
	function add_Money($character){
		$result = $this->chaInfoDAO->add_ChaMoney($character);
		$this->is_Error($result);
	}
	function get_CharacterInfo($character){
		$characterInfo = $this->chaInfoDAO->characterInfo($character);
		if(!$characterInfo){
			jump_location('errorpage');
		}else{
			return $characterInfo;
		}
	}
	function isCharacterOnline($character) {
		$this->chaInfoDAO->characterInfo($character);
		if($character->chaOnline==1){
			return false;
		}else{
			return true;	
		}
	}
	
	function is_Error($result){
		if(is_bool($result)){
			return true;
		}else{
			trigger_error($result->ErrorMsg());
		}
	}
	#-- Private Function
	function addStats($character){
		$result = $this->chaInfoDAO->addStats($character);
		$this->is_Error($result);
	}
	function addPK($character){
		$result = $this->chaInfoDAO->addPK($character);
		$this->is_Error($result);
	}
	function changeClass($character){
		$this->updateChangeClass($character);
		$this->get_ClassGender($character);
		$this->update_ChaClass($character);	
		$this->removeChaSkills($character);
		$this->updateClassSkills($character);
		$this->removeChaSkillSlot($character);
	}
	function resetPK($character){
		$result = $this->chaInfoDAO->resetPK($character);
		$this->is_Error($result);
	}
	function resetStatsPoint($character){
		$result = $this->chaInfoDAO->resetStatsPoint($character);
		$this->is_Error($result);
	}
	function updateGameTime($user){
		$result = $this->userInfoDAO->updateGameTime($user);
		$this->is_Error($result);
	}
	function transsexual($character){
		$this->get_ClassGender($character);
		$this->revertClass($character);
		$this->update_ChaClass($character);		
	}
	function resetReborn($character){
		$result = $this->chaInfoDAO->resetReborn($character);
		$this->is_Error($result);
	}
	 function updatePurchaseReborn($character) {
   		$result = $this->chaInfoDAO->updatePurchaseReborn($character);
   		$this->is_Error($result);
   }
    function updateChaDeleted($character){
    	$result = $this->chaInfoDAO->updateChaDeleted($character);
    	$this->is_Error($result);
    }
	
	//added by otep
	
	function checkCharExist($UserNum,$ChaNum){
		return $result = $this->chaInfoDAO->checkCharExist($UserNum,$ChaNum);
    	// $this->is_Error($result);
	}
	
	function getChaInformation($cha){
		return $this->chaInfoDAO->characterInfo($cha);
	}
	
	function getItemName($_id,$_idsub){
		return $this->chaInfoDAO->getItemName($_id,$_idsub);
	}
	
	function resetPages($UserNum){
		return $this->chaInfoDAO->resetPages($UserNum);
	}
	
	function CharUpdateInventory($character){
		$result = $this->chaInfoDAO->update_inven($character);
		$this->is_Error($result);
	}
	function isSinglePage($character,$page){
		$this->chaInfoDAO->isSinglePage($character,$page);
		return $this->chaInfoDAO->isSinglePageCheck($character,$page);
	}
	
	function getSesData($character,$page,$ses){
		return $this->chaInfoDAO->getSesData($character,$page,$ses);
	}
	
	function getCurrentTabSession($character,$page){
		return $this->chaInfoDAO->getCurrentTabSession($character,$page);
	}
	
	function insertReward($character,$newItemArray){
		
		return $this->chaInfoDAO->insertReward($character,$newItemArray);
	}
	
	function rewardUpdateSuccess($character,$data){
		
		return $this->chaInfoDAO->rewardUpdateSuccess($character,$data);
	}
	
	function getCapReborn($character,$indexReward){
		return $this->chaInfoDAO->getCapReborn($character,$indexReward);
	}
	
	function getLogReward($character){
		return $this->chaInfoDAO->getLogReward($character);
	}
	
	function updateGoldEp($characterInfo,$userInfo,$arrayType){
		return $this->chaInfoDAO->updateGoldEp($characterInfo,$userInfo,$arrayType);
	}
}
?>