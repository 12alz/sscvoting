<?php
class ItemShopPagination extends UserLogic
{
	var $page = 1;
    var $perPage = 40;

    function generate($array, $perPage = 40)
    {
	  if (!empty($perPage))
      $this->perPage = $perPage;
	  
	  $Page = (int)$_GET['page'];
	  $gotoPage = (int)$_POST["goto_text"];
      if (!empty($Page)) {
        $this->page = $Page;
      } else {
        $this->page = $this->page;
		$this->pages = $this->page;
      }	  
      $this->length = count($array);
      $this->pages = ceil($this->length / $this->perPage);
	  if($this->page > $this->pages){
		$this->page = $this->pages;
	  }
	  if(isset($_POST["goto_link"])){
		if($gotoPage <= $this->pages){
		jump_location('mart.php?itemtype='.(int)$_GET['itemtype'].'&page='.$this->page = $gotoPage.'');
		}else{
		jump_location('mart.php?itemtype='.(int)$_GET['itemtype'].'&page='.$this->pages.'');
		}
	  }
      $this->start  = ceil(($this->page - 1) * $this->perPage);
      return array_slice($array, $this->start, $this->perPage);	  
	}
    function productPaginationLinks()
    {	
	  $plinks = array();
      $links = array();
      $slinks = array();
      if ($this->pages >= 0)
      {
	  
        if(($this->page - 1)) {
		  $plinks[] = '<a id="ctl00_ContentPlaceHolder_main_first" class="pagelink" href="mart.php">[Home]</a>'."\n";
          $plinks[] = '<a id="ctl00_ContentPlaceHolder_main_pre" class="pagelink" href="mart.php?itemtype='.(int)$_GET['itemtype'].'&page='.($this->page - 1).'">[Previous]</a>'."\n";
		}else{
		  $plinks[] = '<a id="ctl00_ContentPlaceHolder_main_first" class="pagelink">[Home]</a>'."\n";
          $plinks[] = '<a id="ctl00_ContentPlaceHolder_main_pre" class="pagelink">[Previous]</a>'."\n";
			
		}
          $links[] = '<a id="ctl00_ContentPlaceHolder_main_cur" class="pagelink" style="color:#FF6600;">'.$this->page.'</a>'."\n";

        if ($this->page < $this->pages) {
		  $slinks[] = '<a id="ctl00_ContentPlaceHolder_main_next" class="pagelink" href="mart.php?itemtype='.(int)$_GET['itemtype'].'&page='.($this->page + 1).'">[Next]</a>'."\n";	
          $slinks[] = '<a id="ctl00_ContentPlaceHolder_main_last" class="pagelink" href="mart.php?itemtype='.(int)$_GET['itemtype'].'&page='.$this->pages.'">[Last]</a>'."\n";
        }else{
		  $slinks[] = '<a id="ctl00_ContentPlaceHolder_main_next" class="pagelink">[Next]</a>'."\n";
          $slinks[] = '<a id="ctl00_ContentPlaceHolder_main_last" class="pagelink">[Last]</a>'."\n";		
		}
          $alinks = '&nbsp;&nbsp;&nbsp;&nbsp;';
          $alinks.= 'Go to page <input name="goto_text" type="text" value="'.$this->page.'" maxlength="5" id="ctl00_ContentPlaceHolder_main_goto_text" class="pagelink" style="width:20px;" />';
          $alinks.= '<span id="ctl00_ContentPlaceHolder_main_goto_text_Check_Null" style="color:Red;visibility:hidden;"></span>';
          $alinks.= '<span id="ctl00_ContentPlaceHolder_main_goto_text_Check" style="color:Red;visibility:hidden;"></span>';
          $alinks.= '/ All <span id="ctl00_ContentPlaceHolder_main_goto_total">'.$this->pages.'</span> Page&nbsp;';
		  $alinks.= "\n";
          $alinks.= '<input type="submit" name="goto_link" value="Submit" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;goto_link&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ContentPlaceHolder_main_goto_link" class="pagelink" />';
		
        return implode(' ', $plinks).implode($this->implodeBy, $links).implode(' ', $slinks).$alinks;
	  
	  
	  }
	  
	}
}
class ShopItemMapLogic extends ItemShopPagination {
	
	function getAllItemsFromProduct(){
		return $this->shopItemMapDAO->getProductInfo2();
	}
	
   function getProductSaleList($item,$operator) {
	   
	   $result = $this->productList($item,$operator);
	   if(!is_array($result) & count($result)){
		   echo $result->ErrorMsg();
	   }else{
	   if(count($result)){
	   $productPages = $this->generate($result);   
	   $totalProducts = count($productPages);
	   for($p=0;$p<$totalProducts;$p++){
	   $r++;   
		   if($r%2){
			echo '<tr>';   
		   }
echo '		   
			<td style="height:100%;">
            <table width="100%" >

              <tr>
                <td valign="top" width="90"><table>
                    <tr>
                      <td style="border-bottom:none !important;"><img id="ctl00_ContentPlaceHolder_main_MartList_ctl00_wupinpic" class="bbb" src="Mart/images/descpic/',$productPages[$p][1],'-',$productPages[$p][2],'.jpg" style="height:80px;width:80px;border-width:0px;" />
                      
                      </td>
                    </tr>
                    <tr>
                      <td style="border-bottom:none !important;"></td>
                    </tr>

                  </table></td>
                <td valign="top" ><table width=100%>
                    <tr>
                      <td><span id="ctl00_ContentPlaceHolder_main_MartList_ctl00_wupinname" style="font-weight:bold;">',$productPages[$p][3],'</span></td>
                    </tr>
                    <tr>
                      <td>Price: <font color=#ff0000><span id="ctl00_ContentPlaceHolder_main_MartList_ctl00_wupinpointold">',$productPages[$p][4],' Points</span></font></td>

                    </tr>
                    <tr>
                      <td valign="bottom" style="border-bottom:none !important;">
    <table width="100%" cellpadding="0" border="0">
      <tr>
      <td valign="bottom" width="65" style="border-bottom:none !important;"><a href="Mart/images/descpic/',$productPages[$p][1],'-',$productPages[$p][2],'.jpg"  title1="<b>',$productPages[$p][3],'</b><br>',$productPages[$p][5],'<br>"  class="thickbox"><img src = "/images/btn5.gif" border=0 style="margin-top:1px"></a></td>
        <td valign="bottom" style="border-bottom:none !important;"><input type="submit" name="ctl00$ContentPlaceHolder_main$MartList$ctl00$btnNext" value="Buy" onclick="if (confirm(\'After buy from website store, all items are in the item bank\'))__doPostBack(\'ctl00$ContentPlaceHolder_main$MartList$ct',$productPages[$p][0],'$btnNext\',\'Select$',$productPages[$p][0],'\');return false;" class="btn2" style="font-size:12px;" /><div style="height:6px"></td>
       </tr>
    </table>

                      </td>
                    </tr>

                  </table></td>
              </tr>
            </table>
          </td>	   
		  ';
	   				}
	   		}
	   }
   
   }
   function productCategoryList(){
	   global $_config;
	   $categoryList = $_config['ProductCategory'];
	   $categoryKeys = array_keys($categoryList);
	   $totalCategoryList = count($categoryList);
	   if($totalCategoryList){
		echo '<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#ffffff">
				<tbody align="center" valign="middle" bgcolor="#A7CFFC"  height=22>';
		   for($c=0;$c<$totalCategoryList;$c++){
			echo '<td onmouseover="this.style.backgroundColor=\'#FFCC66\'" onmouseout="this.style.backgroundColor=\'#A7CFFC\'" ><a href="?itemtype=',$categoryKeys[$c],'"><font color=#000> ',str_replace(".","<tr>",$categoryList[$categoryKeys[$c]]),'</font></a></td>';  

		   }
		echo '</tr>

			</table>';
		   }
   }
	function productLabelView(){
	 global $_config;
		if(isset($_config['ProductCategory'][$_GET['itemtype']])){ 
		echo str_replace(" (","<br>(",$_config['ProductCategory'][(int)$_GET['itemtype']]); 
	 	}else{ 
		echo 'All Items List';
		}
	}
   function getProductInfo($item){
	   $result = $this->shopItemMapDAO->getProductInfo($item);
	   if($result){
		   return $result;
	   }else{
		   jump_location("errorpage");
	   }
   }
   
   function getShopItems(){
	   $result = $this->shopItemMapDAO->getProductInfo();
	   if($result){
		   return $result;
	   }else{
		   jump_location("errorpage");
	   }
   }

   function checkProductAll(){
	   return $this->shopItemMapDAO->getProductAll();
	   
   } 
   function checkBingoProductExists($item){
	   $result = $this->shopItemMapDAO->getProductInfo($item);
	   if($result){
		  return true;
	   }
		  return false;
   }   
   function productList($item,$operator){
	   return $this->shopItemMapDAO->productSaleList($item,$operator);
   }
   function add_ItemStock($item){
	   return $this->shopItemMapDAO->add_ItemStock($item);
   }
   function update_ItemStock($item){
	   return $this->shopItemMapDAO->update_ItemStock($item);
   }
   
}
?>