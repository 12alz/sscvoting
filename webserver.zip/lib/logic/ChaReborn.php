<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/lib/logic/ItemCustomize.php';

class ChaRebornLogic extends ItemCustomizeLogic  {
	
	var $page = 1;
    var $perPage = 10;
	var $pageTitleName;
    function generate($array, $perPage = 10){
	  if (!empty($perPage))
      $this->perPage = $perPage;
	  $pageArg = explode("$", $_POST["__EVENTARGUMENT"]);
	  $page = (int)$pageArg[1];
      if (!empty($page) & $pageArg[0] == $this->pageTitleName) {
      $this->page = $page;
      }else{
      $this->page = $this->page;
      }
      $this->length = count($array);
      $this->pages = ceil($this->length / $this->perPage);
	  if($this->page > $this->pages){
	  $this->page = $this->pages;
	  }
      $this->start  = ceil(($this->page - 1) * $this->perPage);
      return array_slice($array, $this->start, $this->perPage);	  
	}
    function links(){	
	  $plinks = array();
      $links = array();
      $slinks = array();
      if ($this->pages > 1)
      {
		$range = 10;
		$range_min = ($range % 2 == 0) ? ($range / 2) - 1 : ($range - 1) / 2;
		$range_max = ($range % 2 == 0) ? $range_min + 1 : $range_min;
		$page_min = $this->page- $range_min;
		$page_max = $this->page+ $range_max;

		$page_min = ($page_min < 1) ? 1 : $page_min;
		$page_max = ($page_max < ($page_min + $range - 1)) ? $page_min + $range - 1 : $page_max;
		if ($page_max > $this->pages) {
			$page_min = ($page_min > 1) ? $this->pages - $range + 1 : 1;
			$page_max = $this->pages;
		}
		$page_min = ($page_min < 1) ? 1 : $page_min;
	  
	  		  $aLink = '<tr>
			  <td colspan="4"><table border="0">
				  <tr>';
		  for ($j = $page_min; $j < ($page_max + 1); $j++) {
			if ($this->page == $j) {
			  $links[] = '<td><span>'.$j.'</span></td>';
			} else {
			  $links[] = '<td><a href="javascript:__doPostBack(\'ctl00ContentPlaceHolder_mainGridView1\',\''.$this->pageTitleName.'$'.$j.'\')">'.$j.'</a></td>'; 
			}
		  }
			  if($j > 10 & $j < $this->pages){
			  $links[] = '<td><span>...</span></td>';	
			  }
		  	  $bLink = '</tr>
			  </table></td>
		   </tr>';
		  
		  return $aLink.implode(' ', $plinks).implode($this->implodeBy, $links).implode(' ', $slinks).$bLink;
	  }
	  
	}
   
   function getRebornRange($reborn,$rbTypeArray) {
	global $_config;
			if((int)$reborn <= (int)($_config['RebornRange']['Junior'][1])){
				$range['Lvl'] = $rbTypeArray['Junior']['Lvl'];
				$range['Pay'] =  $rbTypeArray['Junior']['Pay'];
				$range['LvlErrMsg'] = REBORN_JUNIOR_LVL_MSG;
    		}else if((int)$reborn <= (int)($_config['RebornRange']['Middle'][1])){
				$range['Lvl'] = $rbTypeArray['Middle']['Lvl'];
				$range['Pay'] =  $rbTypeArray['Middle']['Pay'];
				$range['LvlErrMsg'] = REBORN_MIDDLE_LVL_MSG;
			}else if((int)$reborn <= (int)($_config['RebornRange']['Advanced'][1])){
				$range['Lvl'] = $rbTypeArray['Advanced']['Lvl'];
				$range['Pay'] =  $rbTypeArray['Advanced']['Pay'];
				$range['LvlErrMsg'] = REBORN_ADVANCED_LVL_MSG;
			}		
		return $range;

   }
   function getRebornStandardDetail($rebirth){
		$result = $this->chaRebornListDAO->getRebornStandardDetail($rebirth);  
	    if(!$result){
			jump_location("errorpage");
		}else{
			return 	$result;
		}
   }
   function getRebornList($rebirth){
	$this->pageTitleName = "Page";
	$result = $this->chaRebornListDAO->rebornList($rebirth);
	if($result){
echo '		
<tr style="color:White;background-color:#C9EFBC;font-size:9pt;height:21px;">
			<th scope="col">Rebirth No.</th><th scope="col">Level</th><th scope="col">Time</th><th scope="col">Type</th><th scope="col">Action</th>

		</tr>		
	';	
	$rebornList = $this->generate($result, 30);
	$totalReborn = count($rebornList);
	for($r=0;$r<$totalReborn;$r++){
	  if($r%2){
		$bgStyle =  "background-color:black;height:24px;";
	  }else{
		$bgStyle =  "height:24px;";
	  }
	  if($rebornList[$r][4]==0){
	  //$actionBtn = '<input type="button" value="upgrade VIP" onclick="javascript:__doPostBack(\'ctl00ContentPlaceHoldermainCustomersGridView\',\'Select$'.$rebornList[$r][1].'\')" class="btn3" />';
	  }else{
	  $actionBtn =  '---';
	  }
	  echo '		
	  <tr style="',$bgStyle,'">
				  <td align="center" style="width:17%;">',$rebornList[$r][0],'</td><td align="center" style="width:20%;">',$rebornList[$r][2],'</td><td align="center" style="width:22%;">',date('m d Y  h:mA',strtotime($rebornList[$r][3])),'</td><td align="center" style="width:20%;">',$this->rebornType($rebornList[$r][4]),'</td><td align="center" style="width:21%;">',$actionBtn,'</td>
			  </tr>		
	  ';		
	  }
	  echo $this->links();	
	}else{
echo '			
<tr>
		<td colspan="5">No record.</td>
	</tr>
	';		
	}
		
   }
   #-- Private Function
   function addCharacterStats($character){
	    $result = $this->chaInfoDAO->updateStats($character);
		if(is_bool($result)){
			return true;
		}else{
			trigger_error($result->ErrorMsg());
		}
   }

   function rebornType($type){
	  switch($type){
		case 0:
			  return "standard";
			  break;  
			  
		case 1:
			  return "vip";
			  break;
	  }
   }
   function rebornSaveMap($character){
	   global $_config;
		  switch ($_config['RebornSaveMap']){
			  case "Market": default:
					$character->chaSaveMap = "22";
					$character->chaSavePosX = "241.993317";
					$character->chaSavePosY = "0.299";
					$character->chaSavePosZ = "-11.866971";
					break;
		  }
	   
   }
	function updateRebornType($rebornTypeArray,$rebirth,$character,$userInfo,$pay){
		switch ($rebornTypeArray[0]){
			case 0:
				  $totalRebornType = $this->chaRebornListDAO->countRebornType($rebirth);
				  $totlVipStats = $totalRebornType*25;
				  $totalStandardStats = ($character->chaReborn+1)*$rebornTypeArray[1]['AddStats'];
				  $character->chaStRemain = $totalStandardStats+$totlVipStats;
				  $character->chaMoney = $pay;
				  $this->chaInfoDAO->update_ChaMoney($character);
				  $this->chaInfoDAO->updateTotalRebornStats($character);
				  $rebirth->type = 0;
				  return $this->chaRebornListDAO->insertRebornDetails($rebirth);
				  break;
			
			case 1:	  
				  $totalReborn = $this->chaRebornListDAO->countTotalReborn($rebirth);
				  $totalRebornType = $this->chaRebornListDAO->countRebornType($rebirth);
				  $totalStandardReborn = $totalReborn-$totalRebornType;
				  $totalStandardStats = $totalStandardReborn*25;
				  $totalVipStats = ($character->chaReborn+1)*$rebornTypeArray[1]['AddStats'];
				  $character->chaStRemain = $totalVipStats-$totalStandardStats;
				  $userInfo->userPoint = $pay;
				  $this->userInfoDAO->charge_Point($userInfo);
				  $this->chaInfoDAO->updateTotalRebornStats($character);
				  $rebirth->type = 1;
				  return $this->chaRebornListDAO->insertRebornDetails($rebirth);
				  break;
		}
	}
   function updateRebornData($character){
	   $this->chaInfoDAO->resetStats($character);
	   $this->rebornSaveMap($character);
	   $this->chaInfoDAO->updateMapLocation($character);
	   $this->chaInfoDAO->updateRebornLvlExp($character);
	   
   }
   function updateUpgradeReborn($rebirth,$userInfo){
	   $this->userInfoDAO->charge_Point($userInfo);
	   $this->chaRebornListDAO->updateRebornStatus($rebirth);
	   
   }
   function updatePurchaseReborn($character) {
   		
   		$this->chaInfoDAO->updatePurchaseReborn($character);
   		//$this->userInfoDAO->charge_Point($userInfo);
   }
   //purchase reborn logs to do
   function insertRebornPurchaseDetails($rebirth) {

   		$rebirth->type = 0;
   		$this->chaRebornListDAO->insertRebornDetails($rebirth);
   }
}
?>