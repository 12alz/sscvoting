<?php
class NewsPagination {
    var $page = 1;
    var $perPage = 10;
	
    function generate($array, $perPage=10){
	  if (!empty($perPage))
      $this->perPage = $perPage;
	  $Page = (int)$_GET['page'];
      if (!empty($Page)) {
        $this->page = $Page;
      } else {
        $this->page = 1;
		$this->pages = 1;
      }
      $this->length = count($array);
      $this->pages = ceil($this->length / $this->perPage);
      if($this->page > $this->pages){
        $this->page = $this->pages;
	  }
      $this->start  = ceil(($this->page - 1) * $this->perPage);
      return array_slice($array, $this->start, $this->perPage);
	}
	
	function links($className)
    {	
	  $plinks = array();
      $links = array();
      $slinks = array();
      if(!isset($className)){
	  $plinkName = "?page="; 
	  }else{
	  $plinkName = "?classname=".clean_variable($className)."&page=";   
	  }
      if (($this->pages) >= 0)
      {
		  if (($this->page - 1)) {
			  
			$plinks[] = '<a href="list.php'.$plinkName.'1'.'"><img src="/img/Community/bt_pprev.jpg" name="Image20" width="20" height="16" border="0" align="absmiddle"></a>'."\n";
			$plinks[] = '<a href="list.php'.$plinkName.($this->page - 1).'"> <img src="/img/Community/bt_prev.jpg" name="Image19" width="16" height="16" hspace="2" border="0" align="absmiddle"></a>'."\n";
		  }else{
			$plinks[] = '<a><img src="/img/Community/bt_pprev.jpg" name="Image20" width="20" height="16" border="0" align="absmiddle"></a>'."\n";
			$plinks[] = '<a><img src="/img/Community/bt_prev.jpg" name="Image19" width="16" height="16" hspace="2" border="0" align="absmiddle"></a>'."\n";
			  
		  }
		  
			$links[] = '<a class="check">'.$this->page.'</a> '."\n";
	
		  if ($this->page != $this->pages & $this->pages > 0) {
			$slinks[] = '<a href="list.php'.$plinkName.($this->page + 1).'"><img src="/img/Community/bt_next.jpg"name="Image18" width="16" height="16" hspace="2" border="0" align="absmiddle"></a>'."\n";	
			$slinks[] = '<a href="list.php'.$plinkName.$this->pages.'"><img src="/img/Community/bt_nnext.jpg"name="Image17" width="20" height="16" border="0" align="absmiddle"></a>'."\n";
		  }else{
			$slinks[] = '<a><img src="/img/Community/bt_next.jpg"name="Image18" width="16" height="16" hspace="2" border="0" align="absmiddle"></a>'."\n";
			$slinks[] = '<a><img src="/img/Community/bt_nnext.jpg"name="Image17" width="20" height="16" border="0" align="absmiddle"></a>'."\n";		
		  }
		  
			   return implode(' ', $plinks).implode($this->implodeBy, $links).implode(' ', $slinks);
	  }

	}
}
class NewsLogic extends NewsPagination{
   
   var $newsDAO;	
   
   function NewsLogic() {
    $this->newsDAO = dao_getDAO("news");
   }

   function getTop12News($news) {
   	$top12News = $this->newsDAO->top12News($news);
	if(!is_array($top12News) & count($top12News)){
	echo '
	  <span style="display:block; float:left; padding-top:0px; text-decoration:none;">
	  <br><br>
	  ',$top12News->ErrorMsg(),'
	  </span>
	 ';	   
	}else{
	  $top12Count = count($top12News);
	  if(count($top12News)){
	  for($i=0;$i<$top12Count;$i++){
	  echo '	
	  <li style="height:12px;padding-bottom:8px">
		  <a href="/show.php?articleid=',$top12News[$i][0],'" title="" style="height:12px;padding:3px 0 0px 13px;">
			  ',$top12News[$i][1],'</a> 
		  <span class="date" style="padding-top:0px;height:12px;">',date('m-d', strtotime($top12News[$i][2])),'</span>
  
	  </li>
	  ';
	  }
	  }else{
	  echo '	
	  <span style="display:block; float:middle; padding-top:0px; text-decoration:none;">
	  <br><br>
	  No news.
	  </span>
	  ';
	  }
	}
   }
   function getNewsList(&$news,$newsPerPage) {
	$newsCataResult = $this->newsDAO->getNewsCata($news->title,"title");  
	if(!empty($newsCataResult)){
		$newsCataID = $newsCataResult->id;	
		$newsCataOperator = "=";
	}else{
		if(!isset($_GET['classname'])){
		$newsCataID = "0";	
		$newsCataOperator = ">";
		}else{
		$newsCataID = $newsCataResult->id;	
		$newsCataOperator = "=";
		}	
		
   }
	$newsListResult = $this->newsDAO->newsList($news,$newsCataOperator,$newsCataID);
	if(!is_array($newsListResult) & count($newsListResult)){
	echo '<tr>
						<td colspan="3">',$newsListResult->ErrorMsg(),'</td>
				  </tr>
	 ';	   
	}else{
		if(count($newsListResult)){
		$newsPages = $this->generate($newsListResult, $newsPerPage);
		$totalNewsPages = count($newsPages);
		  for ($i=0;$i<$totalNewsPages;$i++){
		  $newsCataName = $this->getNewsCategory($newsPages[$i][1]); 
		  echo '
		  <tr>
			  <td class="english"></td>
			  <td valign="middle">[<a href=/list.php?classname=',$newsCataName->title,'>',$newsCataName->title,'</a>] &nbsp;<a href="show.php?articleid=',$newsPages[$i][0],'">',$newsPages[$i][2],'</a>
				  
			  </td>
			  <td align="center">',$newsPages[$i][3],'</td>
	
			  <td class="english" width="100px" align=right>',date('Y-m-d',strtotime($newsPages[$i][4])),'&nbsp;&nbsp;&nbsp;&nbsp;</td>
			  <td class="english"></td>
		  </tr>
		  ';
		  }
		}else{
			if(!isset($_GET['classname'])){
			echo '<tr>
							<td colspan="3">No news.</td>
					  </tr>
			 ';	 
			}
		}
	}
   }
   
   function getShowNews($id){
	 $showNewsResult = $this->newsDAO->get($id);
	 if(!$showNewsResult){
	 return jump_location('errorpage');
	 }
	 return $showNewsResult;
   }
   function getNewsCategory($id,$option=NULL){
	 if($option!=NULL){
	 return $this->newsDAO->getNewsCata($id,$option);
	 }else
	 return $this->newsDAO->getNewsCata($id);
   }
   function launcherNews($news){
   	$top12News = $this->newsDAO->top12News($news);
	if(!is_array($top12News) & count($top12News)){
	echo '<tr><td>			
              <span class="STYLE3">',$top12News->ErrorMsg(),'</span>
       </td></tr>
	 ';	   
	}else{
	  $top12Count = count($top12News);
	  if(count($top12News)){
		
	  for($i=0;$i<$top12Count;$i++){
	 // echo' 
//			<li><a href="/show.php?articleid=',$top12News[$i][0],'" target="_blank"> ',date('m-d', strtotime($top12News[$i][2])),' ',$top12News[$i][1],'</a></li>
//	  ';
	  echo' 
			<a href="http://n-ranonline.dyndns.org/show.php?articleid=',$top12News[$i][0],'" target="_blank">',$top12News[$i][1],'</a><br>	  
			';
	  }
	}else{
		echo '<tr><td>			
              <span class="STYLE3">No news.</span>
       </td></tr>
	 	';	   
	}
	
	}
 
   }
   
   function updateNewsHits($id){
	 return $this->newsDAO->updateNewsHits($id);
   }
}


?>