<?php
class FullUserInfoLogic {
   
   var $fulluserInfoDAO;
   
   function FullUserInfoLogic() {
   $this->fulluserInfoDAO = dao_getDAO("fulluserinfo");
   }

   function checkEmail($fullUserInfo) {
  	$result = $this->fulluserInfoDAO->checkEmail($fullUserInfo);
   	 	if(!$result){
		return true;
		}
		return false;
   }
   function checkUserPassEmail($fullUserInfo) {
  	$result = $this->fulluserInfoDAO->checkUserPassEmail($fullUserInfo);
   	 	if($result){
		return true;
		}
		return false;
   }
   function checkUserPassword2($fullUserInfo){
  	$result = $this->fulluserInfoDAO->checkUserPass2($fullUserInfo);
    	if($result){
		return true;
		}
		return false;
   }
   function checkEmailAddress($fullUserInfo){
   	$result = $this->fulluserInfoDAO->checkemailAddress($fullUserInfo);
   		if($result){
   		return true;
   		}
   		return false;
   }
   function checkUserPassword($fullUserInfo){
  	$result = $this->fulluserInfoDAO->checkUserPass($fullUserInfo);
    	if($result){
		return true;
		}
		return false;
   }
   function check_UserID($fullUserInfo) {
  	$result = $this->fulluserInfoDAO->check_UserID($fullUserInfo);
    	if(!$result){
		return true;
		}
		return false;
   }
   function getFullUserInfo($fullUserInfo){
	  $result = $this->fulluserInfoDAO->getFullUserInfo($fullUserInfo);
   }
   function insertFullUserInfo($fullUserInfo){
	  $result = $this->fulluserInfoDAO->insertFullUserInfo($fullUserInfo);
	  if(is_bool($result)){
		  return true;
	  }else{
		  trigger_error($result->ErrorMsg());
	  }
   }
   function updateUserPass($fullUserInfo){
	  $result = $this->fulluserInfoDAO->updateUserPass($fullUserInfo);	   
	  if(is_bool($result)){
		  return true;
	  }else{
		  trigger_error($result->ErrorMsg());
	  }
   }
   function updateUserPass2($fullUserInfo){
	  $result = $this->fulluserInfoDAO->updateUserPass2($fullUserInfo);	   
	  if(is_bool($result)){
		  return true;
	  }else{
		  trigger_error($result->ErrorMsg());
	  }
   }
}
?>