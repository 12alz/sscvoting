<?php
class NewsDAO extends NewsCataDAO{

   function get($id) {
	 $newsResult = $this->conn->Execute("Select * From RanNews.dbo.news WHERE id =?",array($id));	   
	 if(!$newsResult){
	 return $this->conn;
	 }else{
	 $result = $this->getFromResult($news, $newsResult);
     return $result;
	 }
   }

   function top12News($news){
     $top12NewsResult = $this->conn->SelectLimit("Select * From RanNews.dbo.news Order By addtime DESC",12);	   
	 if(!$top12NewsResult){
	 return $this->conn;
	 }
	 for($i=0;$i<$top12NewsResult->RecordCount();$i++){
	 $result = $this->getFromResult($news, $top12NewsResult);
	 $top12Result[] = array($result->id,$result->title,$result->addtime,);
	 
	 $top12NewsResult->movenext();
	 }
	 return $top12Result;
	   
   }
   function newsList($news,$operator,$id){
	$newsListResult = $this->conn->Execute("SELECT * from RanNews.dbo.news Where cataid ".$operator." ? Order by addtime DESC",array($id));  
	if(!$newsListResult){
	return $this->conn;
	}
	for ($n=0;$n<$newsListResult->RecordCount();$n++){
	  $newsInfo = $this->getFromResult($news, $newsListResult);
	  $newsList[] = array($newsInfo->id,$newsInfo->cataid,$newsInfo->title,$newsInfo->nfrom,$newsInfo->addtime,);
	  $newsListResult->movenext();
	}
	return $newsList;
	   
   }
   #-- private functions
   function getFromResult($news, $result) {
	 if(!$result->EOF){
	 $news->id = $result->fields['id'];
	 $news->title = $result->fields['title'];
	 $news->addtime = $result->fields['addtime'];
	 $news->content = $result->fields['content'];
	 $news->nfrom = $result->fields['nfrom'];
	 $news->cataid = $result->fields['cataid'];
	 return $news;
	 }
	 return false;
   }

   function updateNewsHits($id) {
	  return $this->conn->Execute("Update RanNews.dbo.news set hits = hits+? where id = ?",array(1,$id));
   }

}
?>