<?php
class ReferrerDAO {
   var $conn;

   function ReferrerDAO(&$conn) {
     $this->conn =& $conn;
   }

   function get_ReferrerList($referrer) {
     $referrerListResult = $this->conn->Execute("SELECT * from RanUser.dbo.Referrer Where ReFUserNum = ? And Status = ?",array($referrer->reFUserNum,$referrer->status));
	 for($r=0;$r<$referrerListResult->RecordCount();$r++){
	 $result = $this->getFromResult($referrer, $referrerListResult);
	 $referrerList[] = array($result->userID,$result->Date,$result->chaRB,$result->getPoints,);
	 $referrerListResult->movenext();
	 }
     return $referrerList;
   }

   function referrerStatus($referrer) {
     $statusResult = $this->conn->Execute("SELECT * from RanUser.dbo.Referrer Where UserID = ? And Status = ?",array($referrer->userID,0));
	 $result = $this->getFromResult($referrer, $statusResult);
     return $result;
   }

   #-- private functions

   function getFromResult($referrer, $result) {
	 if(!$result->EOF){
	 $referrer->ID = $result->fields['ID'];
	 $referrer->reFUserNum = $result->fields['ReFUserNum'];
	 $referrer->userID = $result->fields['UserID'];
	 $referrer->chaNum = $result->fields['ChaNum'];
	 $referrer->chaRB = $result->fields['ChaRB'];
	 $referrer->getPoints = $result->fields['GetPoints'];
	 $referrer->Date = $result->fields['Date'];
	 $referrer->status = $result->fields['Status']; 
	 return $referrer;
	 }
	 return false;
   }

	function updateReferrerStatus($referrer){
	  $referrerStatusResult = $this->conn->Execute("Update RanUser.dbo.Referrer set ChaNum = ?, ChaRB = ?, GetPoints = ?, Status = ? Where UserID = ?",array($referrer->chaNum,$referrer->chaRB,$referrer->getPoints,1,$referrer->userID));
	  if(!$referrerStatusResult){
	  	 return $this->conn;
	  }else{
		 return true;
	  }
	}

   function insertReferrerInfo($referrer) {
	  $result = $this->conn->Execute("Insert Into Ranuser.dbo.Referrer ([ReFUserNum], [UserID], [ChaNum], [ChaRB],[GetPoints],[Status]) VALUES(?, ?, ?, ?, ?, ?)",array($referrer->reFUserNum,$referrer->userID,0,0,$referrer->getPoints,0));
	  if(!$result){
	  	 return $this->conn;
	  }else{
		 return true;
	  }
   }
 }
?>