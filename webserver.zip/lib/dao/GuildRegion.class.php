<?php
class GuildRegionDAO {
   var $conn;

   function GuildRegionDAO(&$conn) {
     $this->conn =& $conn;
   }

   function getGuildRegion($guildRegion) {
	 $guildResult = $this->conn->Execute("Select * From RanGame1.dbo.GuildRegion Where GuNum = ?",array($guildRegion->guNum));
	 $result = $this->getFromGuildRegionResult($guildRegion, $guildResult);
     return $result;
   }
   #-- private functions

   function getFromGuildRegionResult($guildRegion, $result) {
	 $guildRegion->regionID = $result->fields['RegionID'];
	 $guildRegion->guNum = $result->fields['GuNum'];
	 $guildRegion->regionTax = $result->fields['RegionTax'];
	 return $guildRegion;
   }

 }
?>