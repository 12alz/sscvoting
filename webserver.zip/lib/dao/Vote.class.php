<?php 
class VoteDAO {
   var $conn;

   function VoteDAO(&$conn) {
     $this->conn =& $conn;
   }


   function getUserVote($vote) {
	$voteResult = $this->conn->Execute("Select * from RanUser.dbo.vote where UserID = ?", array($vote->userID));
	$result = $this->getFromResult($vote,$voteResult);
	return $result;
   }

   #-- private functions
   function getFromResult($vote, $result) {
	 if(!$result->EOF){
		 $vote->id = $result->fields['id'];
		 $vote->userID = $result->fields['UserID'];
		 $vote->last_Vote = $result->fields['last_vote'];
		 $vote->Date = $result->fields['date'];
		 $vote->hits = $result->fields['hits'];
		 return $vote;
	 }
	     return false;
   }
   function updateVoteInfo($vote) {
      $result = $this->conn->Execute("Update RanUser.dbo.vote set date = ?, hits = hits+? where UserID = ?",array($vote->Date,$vote->hits,$vote->userID));
	  if(!$result){
		  return $this->conn;
	  }else{
		  return true;
	  }
   }
   function updateLastVote($vote) {
      $result = $this->conn->Execute("Update RanUser.dbo.vote set last_vote = ? where UserID = ?",array($vote->last_Vote,$vote->userID));
	  if(!$result){
		  return $this->conn;
	  }else{
		  return true;
	  }
   }

   function insertVoteInfo($vote) {
	  $result = $this->conn->Execute("Insert Into Ranuser.dbo.Vote ([UserID],[last_vote],[hits]) VALUES(?,?,?)",array($vote->userID,$vote->last_Vote,$vote->hits));	   
	  if(!$result){
		  return $this->conn;
	  }else{
		  return true;
	  }
   }
 }
?>