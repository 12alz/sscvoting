<?php
class GuildInfoDAO extends GuildRegionDAO {

   function getGuildInfo($guild) {
	 $guildResult = $this->conn->Execute("Select * From RanGame1.dbo.GuildInfo Where GuNum = ?",array($guild->guNum));
	 $result = $this->getFromResult($guild, $guildResult);
     return $result;
   }
   
   function clubWarWinner($guild){
   	 $clubWarWinner = $this->conn->Execute("Select R.GuNum, R.RegionID, R.RegionTax From RanGame1.dbo.GuildRegion R, RanGame1.dbo.GuildInfo I Where I.GuNum = R.GuNum");
	 if(!$clubWarWinner){
	 return $this->conn;
	 }
	 for($i=0;$i<$clubWarWinner->RecordCount();$i++){
	 $guildRegion = $this->getFromGuildRegionResult($guild, $clubWarWinner);
	 $guildInfo = $this->getGuildInfo($guildRegion);
	 $clubWarResult[] = array($guildInfo->guName,$guildRegion->regionID,$guildRegion->regionTax,);
	 $clubWarWinner->movenext();
	 }
	 return $clubWarResult;
   }

   #-- private functions
   function getFromResult($guild, $result) {
	 $guild->guName = $result->fields['GuName'];
	 $guild->guNum = $result->fields['GuNum'];
	 return $guild;
   }

 }
?>