<?php
class ChaInfoDAO {
   var $conn;

   function ChaInfoDAO(&$conn) {
     $this->conn =& $conn;
   }

   function characterInfo($character) {
	 $result = $this->conn->Execute('Select * from RanGame1.dbo.ChaInfo where UserNum = ? and ChaNum = ?', array($character->userNum,$character->chaNum));
	 $vo = $this->getFromResult($character, $result);
     return $vo;
   }
   
   function isSinglePage($character,$page){
	    $result = $this->conn->Execute('Select * from RanUser.dbo.SinglePage where user_id = ? and page = ?', array($character->userNum,$page));  
		
		
		
		if($result->_numOfRows == 0){
			
			$result2 = $this->conn->Execute("INSERT INTO RanUser.dbo.SinglePage (user_id,page,status) VALUES(". $character->userNum .",'".$page."',0)");
			
		}
   }
   
   function getSesData($character,$page,$ses){
		$sesCode = NULL;
	    $result = $this->conn->Execute('Select ses_code from RanUser.dbo.SinglePage where user_id = ? and page = ? ', array($character->userNum,$page));
		//var_dump("INSERT INTO RanUser.dbo.SinglePage (user_id,page,ses_code) VALUES(". $character->userNum .",'".$page."','".$ses."')");exit();
		if($result->_numOfRows == 0){
			$result2 = $this->conn->Execute("INSERT INTO RanUser.dbo.SinglePage (user_id,page,ses_code) VALUES(". $character->userNum .",'".$page."','".$ses."')");
			
			if($result2){
				return $ses;
			}
		}else{
			
			if($result->fields['ses_code'] == NULL){
				 $this->conn->Execute('Update RanUser.dbo.SinglePage set ses_code = ? where user_id = ? and page = ?',array($ses,$character->userNum,$page));
				 $sesCode = $ses;
			}else{
				 $sesCode = $result->fields['ses_code'];
			}
			
			return $sesCode;
		}
   }
   
	function getCurrentTabSession($character,$page){
		$result = $this->conn->Execute('Select ses_code from RanUser.dbo.SinglePage where user_id = ? and page = ? ', array($character->userNum,$page));
		
		if($result->_numOfRows > 0){
			return $result->fields['ses_code'];
		}else{
			return false;
		}
		
	}
   
   
   function isSinglePageCheck($character,$page){
	    $result = $this->conn->Execute('Select * from RanUser.dbo.SinglePage where user_id = ? and page = ? and status = 0', array($character->userNum,$page));
		
		if($result->_numOfRows > 0){
			
			$this->conn->Execute('Update RanUser.dbo.SinglePage set status = 1 where user_id = ? and page = ?',array($character->userNum,$page));
			
			// echo '<pre>';
			// var_dump($result);
			// exit();
			return true;
		}else{
			return false;
		}
   }
   
   function characterList($character){
	 $characterListResult = $this->conn->Execute("SELECT UserNum,ChaNum,ChaName FROM RanGame1.dbo.ChaInfo Where ChaDeleted!=1 And UserNum = ?",array($character->userNum));
	 if(!$characterListResult){
	 return $this->conn;
	 }
	 for($i=0;$i<$characterListResult->RecordCount();$i++){
	 $result = $this->getFromResult($character, $characterListResult);
	 $characterList[] = array($result->chaNum,$result->chaName,);
	 $characterListResult->movenext();
	 }
	 return $characterList;
   }
   function characterDeletedList($character){
	 $characterListResult = $this->conn->Execute("SELECT UserNum,ChaNum,ChaName FROM RanGame1.dbo.ChaInfo Where ChaDeleted!=0 And UserNum = ?",array($character->userNum));
	 if(!$characterListResult){
	 return $this->conn;
	 }
	 for($i=0;$i<$characterListResult->RecordCount();$i++){
	 $result = $this->getFromResult($character, $characterListResult);
	 $characterList[] = array($result->chaNum,$result->chaName,);
	 $characterListResult->movenext();
	 }
	 return $characterList;
   }
   function rankList($character,$hideGM,$rankLimit,$chaSchool){
	   
	 $rankListResult = $this->conn->SelectLimit("SELECT P.ChaExp,P.ChaName, P.ChaLevel, P.ChaClass, P.ChaSchool, P.ChaReborn, P.GuNum, P.ChaNum, U.LastLoginDate FROM RanGame1.dbo.ChaInfo P, RanUser.dbo.UserInfo U WHERE P.UserNum = U.UserNum ".$hideGM." AND P.ChaDeleted != 1 ".$chaSchool." ORDER BY P.ChaReborn DESC, P.ChaLevel DESC, P.ChaExp DESC,P.ChaRebornDate ASC",$rankLimit);
	 if(!$rankListResult){
	 return $this->conn;
	 }
	 for($r=0;$r<$rankListResult->RecordCount();$r++){
	 	$result = $this->getFromResult($character, $rankListResult);
		$lblNo++;
		$characterList[] = array($lblNo,$result->chaName,$result->chaLevel,$result->chaReborn,$result->chaClass,$result->chaSchool,$result->chaExp,$result->lastLoginDate);
		$rankListResult->movenext();
	 }
	  return $characterList;
   }
   function donorankList($character,$hideGM,$rankLimit){
	   
	 $rankListResult = $this->conn->SelectLimit("SELECT D.ChaName,D.ChaClass,D.ChaSchool FROM RanUser.dbo.DonorRanklist D ORDER BY Amount DESC");
	 if(!$rankListResult){
	 return $this->conn;
	 }
	 for($r=0;$r<$rankListResult->RecordCount();$r++){
	 	$result = $this->getFromResult($character, $rankListResult);
		$lblNo++;
		$characterList[] = array($lblNo,$result->chaName,$result->chaSchool,$result->chaClass);
		$rankListResult->movenext();
	 }
	  return $characterList;
   }
   function top5Character($character,$hideGM){
   	 $top5Character = $this->conn->SelectLimit("Select P.ChaName FROM RanGame1.dbo.ChaInfo P, RanUser.dbo.UserInfo U Where P.UserNum = U.UserNum ".$hideGM." And P.ChaDeleted != 1 Order by P.ChaReborn DESC, P.ChaLevel DESC, P.ChaExp DESC,P.ChaRebornDate ASC",5);
	 if(!$top5Character){
	 return $this->conn;
	 }
	 for($i=0;$i<$top5Character->RecordCount();$i++){
	 $result = $this->getFromResult($character, $top5Character);
	 $top5Result[] = array($result->chaName,);
	 $top5Character->movenext();
	 }
	 return $top5Result;
   }

   #-- private functions

   function getFromResult($chaInfo, $result) {
	 if(!$result->EOF){
	  $rs = $result->fields;
	  $chaInfo->chaNum = $rs['ChaNum'];
	  $chaInfo->UserID = $rs['UserID'];
	  $chaInfo->chaName = $rs['ChaName'];
	  $chaInfo->userNum = $rs['UserNum'];
	  $chaInfo->chaClass  = $rs['ChaClass'];
	  $chaInfo->chaSchool  = $rs['ChaSchool'];
	  $chaInfo->chaSex = $rs['ChaSex'];
	  $chaInfo->chaLevel  = $rs['ChaLevel'];
	  $chaInfo->chaMoney  = (float)$rs['ChaMoney'];
	  $chaInfo->chaPower = $rs['ChaPower'];
	  $chaInfo->chaStrong  = $rs['ChaStrong'];
	  $chaInfo->chaStrength  = $rs['ChaStrength'];
	  $chaInfo->chaSpirit  = $rs['ChaSpirit'];
	  $chaInfo->chaDex  = $rs['ChaDex'];
	  $chaInfo->chaStRemain  = $rs['ChaStRemain'];
	  $chaInfo->chaExp = $rs['ChaExp'];
	  $chaInfo->chaSaveMap  = $rs['ChaSaveMap'];
	  $chaInfo->chaSavePosX = $rs['ChaSavePosX'];
	  $chaInfo->chaSavePosY  = $rs['ChaSavePosY'];
	  $chaInfo->chaSavePosZ = $rs['ChaSavePosZ'];
	  $chaInfo->chaBright  = $rs['ChaBright'];
	  $chaInfo->chaPK = $rs['ChaPK'];
	  $chaInfo->chaSkillPoint  = $rs['ChaSkillPoint'];
	  $chaInfo->chaInvenLine = $rs['ChaInvenLine'];
	  $chaInfo->chaOnline  = $rs['ChaOnline'];
	  $chaInfo->chaInven  = $rs['ChaInven'];
	  $chaInfo->chaReborn  = $rs['ChaReborn'];
	  $chaInfo->changeClass = $rs['ChangeClass'];
	  $chaInfo->chaRebornDate = $rs['ChaRebornDate'];
	  $chaInfo->chaSkills = $rs['ChaSkills'];
	  $chaInfo->lastLoginDate = $rs['LastLoginDate'];
	 return $chaInfo;
	 }
	 return false;
   }
    function addStats($chaInfo){
	  $addStatsResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaPower=ChaPower+?,ChaStrong=ChaStrong+?,ChaStrength=ChaStrength+?,ChaSpirit=ChaSpirit+?,ChaDex=ChaDex+?,ChaStRemain=ChaStRemain-? Where ChaNum = ?',array($chaInfo->chaPower,$chaInfo->chaStrong,$chaInfo->chaStrength,$chaInfo->chaSpirit,$chaInfo->chaDex,$chaInfo->chaStRemain,$chaInfo->chaNum));
	  if(!$addStatsResult){
	  	 return $this->conn;
	  }else{
		  return true;
	  }
	}
	function addPK($chaInfo){
	  $addPKResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaBright = ChaBright+? where ChaNum = ?',array($chaInfo->chaBright,$chaInfo->chaNum));
	  if(!$addPKResult){
	  	 return $this->conn;
	  }else{
		  return true;
	  }
	}
	function resetStats($chaInfo){
	  $resetStatsResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaPower=?,ChaStrong=?,ChaStrength=?,ChaSpirit=?,ChaDex=?,ChaStRemain=?,ChaRebornDate=? where chanum = ?',array(0,0,0,0,0,0,date('Y-m-d H:i:s'),$chaInfo->chaNum));
	  if(!$resetStatsResult){
	  	 return $this->conn;
	  }else{
		  return true;
	  }
	}	
	function resetStatsPoint($chaInfo){
	  $resetStatsResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo Set ChaStRemain = ChaPower+ChaStrong+ChaStrength+ChaSpirit+ChaDex+ChaStRemain where ChaNum = ?',array($chaInfo->chaNum));
	  if(!$resetStatsResult){
	  	 return $this->conn;
	  }else{
		  $resetStats = $this->conn->Execute('Update RanGame1.dbo.ChaInfo Set ChaPower=?,ChaStrong=?,ChaStrength=?,ChaSpirit=?,ChaDex=? where ChaNum = ?',array(0,0,0,0,0,$chaInfo->chaNum));
 		  if(!$resetStats){
	  	  return $this->conn;
	  	  }else{
		  return true;
		  }
	  }
		
	}

	function resetPK($chaInfo){
	  $resetPKResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaBright = ChaBright-ChaBright where ChaNum = ?',array($chaInfo->chaNum));
	  if(!$resetPKResult){
	  	 return $this->conn;
	  }else{
		  return true;
	  }
		
	}
	function removeChaSkills($chaInfo){
	  $result = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaSkills = NULL where ChaNum = ?',array($chaInfo->chaNum));
	  if(!$result){
	  	 return $this->conn;
	  }else{
		  return true;
	  }
		
	}
	function removeChaSkillSlot($chaInfo){
	  $result = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaSkillSlot = NULL where ChaNum = ?',array($chaInfo->chaNum));
	  if(!$result){
	  	 return $this->conn;
	  }else{
		  return true;
	  }
		
	}
	function updateChangeClass($chaInfo){
		$changeClassResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChangeClass=ChangeClass+2 Where ChaNum = ?',array($chaInfo->chaNum));
		if(!$changeClassResult){
			return $this->conn;
		}else{
			return true;
		}
		
	}
	
	function resetPages($UserNum){
		$res = $this->conn->Execute('delete RanUser.dbo.SinglePage where user_id = ?',array( $UserNum ) );
		return $res ? true : false;
	}
	
	function updateGoldEp($characterInfo,$userInfo,$arrayType){
		//userPoint, chaMoney
		if(in_array('gold',$arrayType)){
			$this->conn->Execute('Update RanGame1.dbo.ChaInfo set chaMoney = ? where ChaNum = ?',array($characterInfo->chaMoney,$characterInfo->chaNum));
		}
		
		if(in_array('ep',$arrayType)){
			$this->conn->Execute('Update RanUser.dbo.UserInfo set userPoint = ? where userNum = ?',array($userInfo->userPoint,$userInfo->userNum));
		}
	}
	
	function update_ChaClass($chaInfo){
	  $result = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaClass=?,ChaSex=? Where ChaNum = ?',array($chaInfo->chaClass,$chaInfo->chaSex,$chaInfo->chaNum));
	  if(!$result){
	  	 return $this->conn;
	  }else{
		  return true;
	  }
		
	}
	function update_ChaMoney($chaInfo){
	  $chaMoneyResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaMoney = ChaMoney - ? Where ChaNum = ?',array($chaInfo->chaMoney,$chaInfo->chaNum));
	  if(!$chaMoneyResult){
	  	 return $this->conn;
	  }else{
		  return true;
	  }
	}
	function add_ChaMoney($chaInfo){
		$chaMoneyResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaMoney = ChaMoney + ? Where ChaNum = ?', array($chaInfo->chaMoney,$chaInfo->chaNum));
		if(!$chaMoneyResult){
			return $this->conn;
		}else{
			return true;
		}
	}
	function update_inven($chaInfo) {
	  $invenResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaInven = 0x'.$chaInfo->chaInven.' where ChaNum = ?',array($chaInfo->chaNum));
	  if(!$invenResult){
		  return $this->conn;
	  }else{
		  return true;
	  }
	}

	function updateChaSkills($chaInfo){
		$result = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaSkills = 0x'.$chaInfo->chaSkills.' where ChaNum = ?',array($chaInfo->chaNum));
		if(!$result){
			return $this->conn;
		}else{
			return true;
		}
	  
	}
	function updateMapLocation($chaInfo){
	  $mapResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaSaveMap=?,ChaSavePosX=?,ChaSavePosY=?,ChaSavePosZ=? Where ChaNum = ?',array($chaInfo->chaSaveMap,$chaInfo->chaSavePosX,$chaInfo->chaSavePosY,$chaInfo->chaSavePosZ,$chaInfo->chaNum));
	  if(!$mapResult){
		  return $this->conn;
	  }else{
		  return true;
	  }
	}
	function updateRebornLvlExp($chaInfo){
	  $rebornLvlExpResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaReborn=ChaReborn+?, ChaLevel = ?, ChaExp = ? Where ChaNum = ?',array('1','1','0',$chaInfo->chaNum));
	  if(!$rebornLvlExpResult){
		  return $this->conn;
	  }else{
		  return true;
	  }
	}
	function updateTotalRebornStats($chaInfo){
	  $rebornStats = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaStRemain = ? Where ChaNum = ?',array($chaInfo->chaStRemain,$chaInfo->chaNum));
	  if(!$rebornStats){
		  return $this->conn;
	  }else{
		  return true;
	  }
		
	}
	function updateStats($chaInfo){
	  $statsResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaStRemain = ChaStRemain + ? Where ChaNum = ?',array($chaInfo->chaStRemain,$chaInfo->chaNum));
	  if(!$statsResult){
		  return $this->conn;
	  }else{
		  return true;
	  }
	}

	function resetReborn($chaInfo){
		$resetRebornResult = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaReborn=? where chanum=?', array(0,$chaInfo->chaNum));

		if(!$resetRebornResult){
			return $this->conn;
		}else{

				//reset reborn logs
				$resetRebirthLogs = $this->conn->Execute('DELETE RanGame1.dbo.ChaRebirth_list WHERE ChaNum=?', array($chaInfo->chaNum));

					if(!$resetRebirthLogs){
						return $this->conn;
					}else{
							//Reset all stats!
							$resetStats = $this->conn->Execute('Update RanGame1.dbo.ChaInfo set ChaPower=?,ChaStrong=?, ChaStrength=?,ChaSpirit=?,ChaDex=?,ChaStRemain=?,ChaLevel=?,ChaExp=? where ChaNum = ?', array(0,0,0,0,0,0,1,0,$chaInfo->chaNum));

								if(!$resetStats){
									return $this->conn;
								}else{
									return true;
						}
					}
			}
		}


	function updatePurchaseReborn($chaInfo){
		$updateRebornResult = $this->conn->Execute('UPDATE RanGame1.dbo.ChaInfo SET ChaReborn = ChaReborn+?
			WHERE ChaNum=?', array($chaInfo->chaReborn, $chaInfo->chaNum));

		if(!$updateRebornResult){
			return $this->conn;
		}else{

			$updateStats = $this->conn->Execute('UPDATE RanGame1.dbo.ChaInfo set ChaStRemain = ChaStRemain+? WHERE ChaNum=?', array($chaInfo->chaStRemain, $chaInfo->chaNum));

			if(!$updateStats){
				return $this->conn;
			}else{
				return true;
			}
		}
	}

	function updateChaDeleted($chaInfo){
		$updateChaDeletedResult = $this->conn->Execute('UPDATE RanGame1.dbo.ChaInfo SET ChaDeleted=0 WHERE ChaNum=?', array($chaInfo->chaNum));

		if(!$updateChaDeletedResult){
			return $this->conn;
		}else{
			return true;
		}
	}
	
	//added by otep
	
	function getLogReward($character){
		$result = $this->conn->Execute('Select * from RanUser.dbo.cap_reward where user_id = ?', 
				array($character->userNum)
			);
			// consoleLOGS($result);
		if($result){
			$data = array();
			for($i=0;$i<$result->RecordCount();$i++){
				
				$rs = $result->fields;
				$data[$rs['reward']]['user_id'] = $rs['user_id'];
				$data[$rs['reward']]['reward'] = $rs['reward'];
				$result->movenext();
			}
			
			return $data;
		}else{
			return false;
		}
	}
	
	function getCapReborn($character,$indexReward){
		$result = $this->conn->Execute('Select * from RanUser.dbo.cap_reward where user_id = ? and reward = ?', 
				array($character->userNum,$indexReward)
			);
		if($result){
			return $result->_numOfRows;
		}else{
			return 0;
		}
	}
	
	function checkCharExist($UserNum,$ChaNum){
		return $result = $this->conn->Execute('Select UserNum from RanGame1.dbo.ChaInfo where UserNum = ? and ChaNum = ?', 
				array($UserNum,$ChaNum)
			)->RecordCount();
	}
	
	function getItemName($main,$sub) {
		$itemNameResult = $this->conn->Execute("SELECT * FROM RanShop.dbo.ShopItemMap where ItemMain = ? AND ItemSub = ?",array($main,$sub)); 
		$result = $this->getFromResult($item, $itemNameResult);
		return $result;
	}
	
	function rewardUpdateSuccess($character,$data){
		$result2 = $this->conn->Execute("INSERT INTO RanUser.dbo.cap_reward (user_id,chaNum,reward,_isClaim,dateClaim,lvl,rb) 
										VALUES(".$character->userNum.",".$character->chaNum.",".$data['indexReward'].",1,'".$data['date']."',".$data['lvl'].",".$data['rb'].")");
		if(!$result2){
			return false;
		}else{
			return true;
		}
	}
	
	function insertReward($character,$newItemArray){
		
		$userUID = '';
		$resultuser = $this->conn->Execute('Select UserID from RanUser.dbo.UserInfo where UserNum = ?', array($character->userNum) );
		if(!$resultuser->EOF){
			$rs1 = $resultuser->fields;
			$userUID = $rs1['UserID'];
			$resultuser->movenext();
		}
		// consoleLOGS($newItemArray);
		foreach($newItemArray as $key => $value){
			$pNum = $value;
			
			// $result = $this->conn->Execute('Select ProductNum from RanShop.dbo.ShopItemMap where ItemMain = ? and ItemSub = ?', 
				// array($MainSub[0],$MainSub[1])
			// );
			
			$purKeyMax = $this->conn->Execute("Select MAX(Purkey+1) as MaxPurkey From RanShop.dbo.ShopPurchase");
			$purKeyMax = $purKeyMax->fields["MaxPurkey"];
			
			if($purKeyMax){
				$result2 = $this->conn->Execute("INSERT INTO RanShop.dbo.ShopPurchase 
						(
							PurKey,
							UserUID,
							ProductNum,
							PurPrice,
							PurFlag,
							PurDate,
							PurChgDate
						)VALUES
						(
							'".$purKeyMax."',
							'".$userUID."',
							".$pNum.",
							0,
							0,
							'".date('Y-m-d')."',
							'".date('Y-m-d')."')
				");
				

			}
		}
		if(!$result2){
			return false;
		}else{
			return true;
		}
	}
}
?>