<?php   
class ChaRebornListDAO {
   var $conn;

  function ChaRebornListDAO(&$conn) {
   $this->conn =& $conn;
  }
  
  function getRebornStandardDetail($rebirth) {
   $standardRebornResult = $this->conn->Execute('Select * from RanGame1.dbo.ChaRebirth_list where RbNum = ? AND ChaNum = ? AND UserNum = ? AND Type = ?',array($rebirth->rbNum,$rebirth->chaNum,$rebirth->userNum,0));
   $result = $this->getFromResult($rebirth,$standardRebornResult);
   return $result;
  }
  function countTotalReborn($rebirth){
  	$totalReborn = $this->conn->Execute("SELECT * from RanGame1.dbo.ChaRebirth_list Where ChaNum = ?",array($rebirth->chaNum));   
  	return $totalReborn->RecordCount();
  }
  function countRebornType($rebirth){
  	$totalRebornType = $this->conn->Execute("SELECT * from RanGame1.dbo.ChaRebirth_list Where ChaNum = ? AND Type = ?",array($rebirth->chaNum,'1'));
  	return $totalRebornType->RecordCount();
  }
  function rebornList($rebirth){
	$rebornListResult = $this->conn->Execute("SELECT * from RanGame1.dbo.ChaRebirth_list WHERE UserNum = ? and ChaNum = ? ORDER by RBNum ASC",array($rebirth->userNum,$rebirth->chaNum));
	if(!$rebornListResult){
	return $this->conn;
	}
	for($i=0;$i<$rebornListResult->RecordCount();$i++){
	$lblNo++;
	$result = $this->getFromResult($rebirth, $rebornListResult);
	$rebornList[] = array($lblNo,$result->rbNum,$result->chaLevel,$result->createDate,$result->type,);
	$rebornListResult->movenext();
	}
	return $rebornList;   
  }
  
  #-- private functions
  
  function getFromResult($rebirth, $result) {
	if(!$result->EOF){
	$rebirth->id = $result->fields['Id'];
	$rebirth->rbNum = $result->fields['RbNum'];
	$rebirth->userNum = $result->fields['UserNum'];
	$rebirth->chaNum = $result->fields['ChaNum'];
	$rebirth->chaLevel = $result->fields['ChaLevel'];
	$rebirth->type = $result->fields['Type'];
	$rebirth->createDate = $result->fields['CreateDate'];
	return $rebirth;
	}
	return false;
  }
  
  function updateRebornStatus($rebirth){
	  $rebornStatusResult = $this->conn->Execute('Update RanGame1.dbo.ChaRebirth_list set type = ? where RBNum = ? and ChaNum = ?',array(1,$rebirth->rbNum,$rebirth->chaNum));
	  if(!$rebornStatusResult){
		  return $this->conn;
	  }
	  	  return true;
  }
  function insertRebornDetails($rebirth){
	  $result = $this->conn->Execute('INSERT INTO RanGame1.dbo.ChaRebirth_list (RbNum,UserNum,ChaNum,ChaLevel,Type) VALUES('.($rebirth->rbNum+1).','.$rebirth->userNum.','.$rebirth->chaNum.','.$rebirth->chaLevel.','.$rebirth->type.')');
	  if(!$result){
		  return $this->conn;
	  }else{
		  return true;
	  }
  }

}
?>