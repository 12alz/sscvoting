<?php
class ShopItemMapDAO {
   var $conn;

   function ShopItemMapDAO(&$conn) {
     $this->conn =& $conn;
   }

   function getItemName($main,$sub) {
	 $itemNameResult = $this->conn->Execute("SELECT * FROM RanShop.dbo.ShopItemMap where is_selling = 1 and ItemMain = ? AND ItemSub = ?",array($main,$sub)); 
	 $result = $this->getFromResult($item, $itemNameResult);
	 return $result;
   }
   function getProductInfo($item){
	 $productInfo = $this->conn->Execute("SELECT * from RanShop.dbo.ShopItemMap WHERE is_selling = 1 and ProductNum = ?",array($item->productNum));
	 $result = $this->getFromResult($item, $productInfo);
	 return $result;
   }
   function getProductInfo2(){
	 $productInfo = $this->conn->Execute("SELECT ItemMain,ItemSub,ItemName from RanShop.dbo.ShopItemMap WHERE is_selling = 1");
	 return $productInfo;
   }
   function getProductAll(){
	 $productAll = $this->conn->Execute("SELECT * from RanShop.dbo.ShopItemMap WHERE is_selling = 1");
	 return $productAll->RecordCount();
   }   
   function productSaleList($item,$operator) {
	 //  var_dump("SELECT * from RanShop.dbo.ShopItemMap WHERE Category ".$operator." ? ORDER BY ProductNum DESC",array($item->category));
	 $productSaleList = $this->conn->Execute("SELECT * from RanShop.dbo.ShopItemMap WHERE is_selling = 1 and Category ".$operator." ? ORDER BY ProductNum DESC",array($item->category));
	 for($p=0;$p<$productSaleList->RecordCount();$p++){
   		 $lblNo++;
		 $result = $this->getFromResult($item, $productSaleList);
		 $saleList[] = array(($lblNo-1),$result->itemMain,$result->itemSub,$result->itemName,$result->itemMoney,$result->itemComment,$result->itemStock,$result->productNum,);
	 	 $productSaleList->movenext();
	 }
   		return $saleList;
   }
   function add_ItemStock($item){
	  $result = $this->conn->Execute('Update RanShop.dbo.ShopItemMap set ItemStock = ? where ProductNum = ?',array($item->itemStock,$item->productNum));	   
	  if(!$result){
	  	 return $this->conn;
	  }else{
		  return true;
	  }
   }
   function update_ItemStock($item){
	  $result = $this->conn->Execute('Update RanShop.dbo.ShopItemMap set ItemStock = ItemStock-? where ProductNum = ?',array($item->itemStock,$item->productNum));	   
	  if(!$result){
	  	 return $this->conn;
	  }else{
		  return true;
	  }
   }
   #-- private functions
   function getFromResult($item, $result) {
	   if(!$result->EOF){
	   $item->productNum = $result->fields['ProductNum']; 
	   $item->itemMain = $result->fields['ItemMain'];
	   $item->itemSub = $result->fields['ItemSub'];
	   $item->itemName = $result->fields['ItemName'];
	   $item->itemList = $result->fields['ItemList'];
	   $item->duration = $result->fields['Duration'];
	   $item->category = $result->fields['Category'];
	   $item->itemStock = $result->fields['ItemStock'];
	   $item->itemImage = $result->fields['ItemImage']; 
	   $item->itemMoney = $result->fields['ItemMoney'];
	   $item->itemComment = $result->fields['ItemComment'];
	   return $item;
	   }
	   return false;
   }

}
?>