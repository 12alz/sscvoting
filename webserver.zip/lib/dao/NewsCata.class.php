<?php
class NewsCataDAO {
   var $conn;

   function NewsCataDAO(&$conn) {
     $this->conn =& $conn;
   }

   function getNewsCata($id,$colName=NULL) {
	 if($colName!=NULL){
	 $condition = $colName;	   
	 }else{
	 $condition = "id";	   
	 }
	 $newsCataResult = $this->conn->Execute("Select * FROM RanNews.dbo.newscata Where $condition =?",array($id));	 
	 $result = $this->getNewsCataFromResult($newsCataVO, $newsCataResult);
     return $result;
   }

   #-- private functions

   function getNewsCataFromResult($newsCata, $result) {
	 if(!$result->EOF){
	 $newsCata->id = $result->fields['id'];
	 $newsCata->title = $result->fields['title'];
	 $newsCata->addtime = $result->fields['addtime'];
	 $newsCata->rootid = $result->fields['rootid'];
	 return $newsCata;
	 }
	 return false;
   }

}
?>