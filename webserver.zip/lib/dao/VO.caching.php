<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/lib/dao/ShopPurChase.class.php';

function db_conn(){
  global $_config; 	
  $db = ADONewConnection('mssql');
  $db->locale = 'us_english';
  $db->debug = $_config['DbDebug'];
  $db->debug_console = $_config['DbDebugConsole'];
  $rs = $db->Connect($_config['ServerName'], $_config['Login'], $_config['Password'], $_config['DbRanUser']) or die("Unable to connect Microsoft SQL Server! " .$db->ErrorMsg());
  return $db;
	
}

function dao_getDAO($vo_class) {
   global $db;
   
   switch ($vo_class) {
		 case "fulluserinfo": 
		   return new FullUserInfoDAO($db);
		   break;

		 case "userinfo": 
		   return new UserInfoDAO($db);
		   break;
		 
		 case "referrer": 
		   return new ReferrerDAO($db);
		   break;

		 case "chainfo": 
		   return new ChaInfoDAO($db);
		   break;
		   
		 case "shoppurchase": 
		   return new ShopPurchaseDAO($db);
		   break;
		 
		 case "shopitemmap": 
		   return new ShopItemMapDAO($db);
		   break;
		 
		 case "itemcustomize": 
		   return new ItemCustomizeDAO($db);
		   break;
	
		 case "download": 
		   return new DownloadDAO($db);
		   break;
	
		 case "news": 
		   return new NewsDAO($db);
		   break;
	
		 case "newscata": 
		   return new NewsCataDAO($db);
		   break;
	
		 case "guildinfo": 
		   return new GuildInfoDAO($db);
		   break;
	
		 case "guildregion": 
		   return new GuildRegionDAO($db);
		   break;
		   
		 case "charebornlist": 
		   return new ChaRebornListDAO($db);
		   break;
		   
		 case "vote": 
		   return new VoteDAO($db);
		   break;
	
   }
}
?>