<?php
class DownloadDAO {
   var $conn;

   function DownloadDAO(&$conn) {
     $this->conn =& $conn;
   }

   function downloadList($download){   
	$downloadlistResult = $this->conn->Execute("SELECT * FROM RanUser.dbo.WEB_DOWNLOAD WHERE EXPLAIN = ?",array($download->explain));
	if(!$downloadlistResult){
	return $this->conn;
	}else{
	for ($i=0;$i<$downloadlistResult->RecordCount();$i++){
	$result = $this->getFromResult($download, $downloadlistResult);
	$lblNo++;
	$downloadList[] = array($result->name,$result->addTime,$result->downloadUrl,$lblNo,);	
	$downloadlistResult->movenext();
	}
	return $downloadList;
	}
   }
   #-- private functions
   function getFromResult($download, $result) {
	if(!$result->EOF){
	$download->id	= $result->fields['ID'];
	$download->name = $result->fields['NAME'];		
	$download->downloadUrl = $result->fields['DOWNLOADURL']; 		
	$download->explain = $result->fields['EXPLAIN']; 		
	$download->addTime = $result->fields['ADDTIME'];		
	return $download;   
	}
	return false;
   }

}
?>