<?php
class ItemCustomizeDAO {
   var $conn;

   function ItemCustomizeDAO(&$conn) {
     $this->conn =& $conn;
   }

   function getItemStorageList($item) {
	   // echo '<pre>';
	   // var_dump($item->chaNum);
	 $itemStorageResult = $this->conn->Execute("Select * from Rangame1.dbo.ItemCustomize WHERE ChaNum = ?",array($item->chaNum));
	 if(!$itemStorageResult){
	 return $this->conn;
	 }
	 for($r=0;$r<$itemStorageResult->RecordCount();$r++){
	 	$result = $this->getFromResult($item, $itemStorageResult);
		$lblNo++;
		$storageList[] = array($lblNo,$result->gmID,$result->mainID,$result->subID,$result->itemName,$result->chaInven,);
		$itemStorageResult->movenext();
	 }
	  return $storageList;
   }
   function getTotalItemStorage($item){
	   
	   $totalItem = $this->conn->Execute("SELECT * from RanGame1.dbo.ItemCustomize WHERE ChaNum = ?",array($item->chaNum));
	   return $totalItem->RecordCount();
   }
   function getItemStorage($item) {
	 $itemStorageResult = $this->conn->Execute("Select * from Rangame1.dbo.ItemCustomize WHERE MainID = ? and SubID = ? and GMID = ?",array($item->mainID,$item->subID,$item->gmID));
  	 $item = $this->getFromResult($item,$itemStorageResult);
     return $item;
   }

   function delete($item) {
	  $result = $this->conn->Execute('Delete from RanGame1.dbo.ItemCustomize where GMID = ? And ChaNum = ?',array($item->gmID,$item->chaNum));
	  if($result){
		  return true;
	  }
	  return false;		
   }

   #-- private functions
   function getFromResult($item, $result) {
	if(!$result->EOF){
	$item->gmID = $result->fields['GMID'];
	$item->mainID = $result->fields['MainID'];
	$item->subID = $result->fields['SubID'];
	$item->itemName = $result->fields['ItemName'];
	$item->changeQuantity = $result->fields['ChangeQuantity'];
	$item->attackUpgrade =  $result->fields['AttackUpgrade'];
	$item->defenceUpgrade = $result->fields['DefenceUpgrade'];
	$item->chaInven = $result->fields['ChaInven'];
	$item->point = $result->fields['Point'];
	$item->addDate = $result->fields['AddDate'];
	$item->gmType = $result->fields['GmType'];
	$item->editBol = $result->fields['EditBol'];
	$item->gfInfo = $result->fields['GfInfo'];
	$item->gmShuXing = $result->fields['GmShuXing']; 
	$item->gmPic = $result->fields['GmPic'];
    $item->addBol = $result->fields['AddBol'];
	$item->chaNum = $result->fields['ChaNum'];
	return $item;
	}
	return false;
   }

   function update($item) {
	  if($item->attackUpgrade > 0){
	  $upType = ",AttackUpgrade = 'true'";
	  }elseif($item->defenceUpgrade > 0){
	  $upType = ",DefenceUpgrade = 'true'";
	  }else{
	  $upType = ",AttackUpgrade = 'true', DefenceUpgrade = 'true'"; //false old
	  }
		
	  $result = $this->conn->Execute('Update RanGame1.dbo.ItemCustomize set GfInfo = ?, EditBol = ?, ChaInven = 0x'.$item->chaInven.', Point = ?, AddBol = ? '.$upType.' where GMid = ? And ChaNum = ?',array($item->gfInfo,$item->editBol,$item->point,$item->addBol,$item->gmID,$item->chaNum));
	  if(!$result){
		  return $this->conn;
	  }else{
	  	  return true;	
	  }
   }

   function insert($item) {
	$result = $this->conn->Execute('Insert into RanGame1.dbo.ItemCustomize ([MainID], [SubID], [ItemName], [GmType], [GfInfo], [ChaInven], [Point], [ChaNum]) VALUES(?,?,?,?,?,0x'.$item->chaInven.',?,?)',array($item->mainID,$item->subID,$item->itemName,$item->gmType,$item->gfInfo,$item->point,$item->chaNum));
	if($result){
		return true;
	}
	return false;		
   }
 }

?>