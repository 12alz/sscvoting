<?php
 class UserInfoDAO {
   var $conn;

   function UserInfoDAO(&$conn) {
     $this->conn =& $conn;
   }
   function getUserInfo($user) {
   	$userIDResult = $this->conn->Execute("Select * from RanUser.dbo.UserInfo where UserID
   		= ? ",array($user->userID));
   	$result = $this->getFromResult($user, $userIDResult);
   	return $result;
   }
   function getReferrerInfo($user) {
	 $referrerResult = $this->conn->Execute("Select * From RanUser.dbo.UserInfo Where tj = ?",array($user->tj));
     $result = $this->getFromResult($user, $referrerResult);
	 return $result;
   }
   function totalAccount(){
	  $result = $this->conn->Execute("SELECT * from RanUser.dbo.UserInfo");	   
	  $totalAccount = $result->RecordCount();
	  return $totalAccount;
   }
   function getUserNum($user) {
	 $getByUserNumResult = $this->conn->Execute("Select * From RanUser.dbo.UserInfo Where UserID = ? ",array($user->userID));
     $result = $this->getFromResult($user, $getByUserNumResult);
	 return $result;
   }
   
   function userOnline($user) {
	 $userOnlineResult = $this->conn->Execute("Select * From RanUser.dbo.UserInfo Where UserID = ? And UserLoginState = ? ",array($user->userID,$user->userLoginState));
     $result = $this->getFromResult($user, $userOnlineResult);
	 return $result;
   }
    function checkUserPassEmail($user) {
	  $userEmailResult = $this->conn->Execute('Select * From RanUser.dbo.UserInfo Where UserEmail = ? And UserPass2 = ? And UserID = ?',array($user->userEmail,$user->userPass2,$user->userID));
	  $result = $this->getFromResult($user, $userEmailResult);
	  return $result;
   }
   	function checkUserPass2($user) {
   		$safePwdResult = $this->conn->Execute("Select UserID,UserPass2 From RanUser.dbo.UserInfo where UserPass2 = ? And UserID = ?", array($user->userPass3, $user->userID));
   		$result = $this->getFromResult($user, $safePwdResult);
   		return $result;
   	}
   	function checkUserBlock($user) {
   		$userBlockResult = $this->conn->Execute("Select * from RanUser.dbo.UserInfo Where UserID = ? And UserBlock = ?", array($user->userID, $user->userBlock));
   		$result = $this->getFromResult($user, $safePwdResult);
   		return $result;
   	}

   #-- private functions

   function getFromResult($user, $result) {
	 if(!$result->EOF){
	 $user->userNum = $result->fields['UserNum'];
	 $user->userName = $result->fields['UserName']; 
	 $user->userID = $result->fields['UserID']; 
	 $user->userPass = $result->fields['UserPass']; 
	 $user->userPass2 = $result->fields['UserPass2']; 
	 $user->userBlock = $result->fields['UserBlock']; 
	 $user->userType = $result->fields['UserType']; 
	 $user->userLoginState = $result->fields['UserLoginState']; 
 	 $user->userEmail = $result->fields['UserEmail']; 
	 $user->userPoint = $result->fields['UserPoint']; 
	 $user->webLoginState = $result->fields['WebLoginState'];
	 $user->gameTime2 = $result->fields['Gametime3'];
	 $user->tj = $result->fields['tj'];
     return $user;
	 }
	 return false;
	 #fill vo from the database result set
   }
  function add_Point($user){
	$result = $this->conn->Execute('Update RanUser.dbo.UserInfo set UserPoint = UserPoint+? where UserNum = ?',array($user->userPoint,$user->userNum));
	if(!$result){
		return $this->conn;
	}else{
	  	return true;	
	}
				
  }
  function charge_Point($user){
	$result = $this->conn->Execute('Update RanUser.dbo.UserInfo set UserPoint = UserPoint-? where UserNum = ?',array($user->userPoint,$user->userNum));
	if(!$result){
		return $this->conn;
	}else{
	  	return true;	
	}
				
  }
   function updateGameTime($user) {
	$result = $this->conn->Execute('Update RanUser.dbo.UserInfo set Gametime3 = Gametime3-? where UserNum = ?',array($user->gameTime2,$user->userNum));
	if(!$result){
		return $this->conn;
	}else{
	  	return true;	
	}
   }

   function updateUserPass($user){
	$result = $this->conn->Execute('Update RanUser.dbo.UserInfo set UserPass = ? where UserID = ?',array($user->userPass,$user->userID));
	if(!$result){
		return $this->conn;
	}else{
	  	return true;	
	}
   }
   function updateUserPass2($user){
	$result = $this->conn->Execute('Update RanUser.dbo.UserInfo set UserPass2 = ? where UserID = ?',array($user->userPass2,$user->userID));
	if(!$result){
		return $this->conn;
	}else{
	  	return true;	
	}
   }
   function insertUserInfo($user) {
	$result = $this->conn->Execute("Insert Into Ranuser.dbo.UserInfo ([UserName], [UserID], [UserPass], [UserPass2], [UserType], [UserAvailable], [ChaRemain], [ChaTestRemain], [UserEmail], [UserPoint], [tj]) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)",array($user->userName,$user->userID,$user->userPass,$user->userPass2,'1','1','2','8',$user->userEmail,$user->userPoint,$user->tj));
	if(!$result){
		return $this->conn;
	}else{
		return true;	
	}
   }
}
?>