<?php
class FullUserInfoDAO {
   var $conn;

   function FullUserInfoDAO(&$conn) {
     $this->conn =& $conn;
   }

   function getFullUserInfo($fullUserInfo) {
	  $userIDResult = $this->conn->Execute('Select * From RanUser.dbo.FullUserInfo Where UserID = ? ',array($fullUserInfo->userID));
	  $result = $this->getFromResult($fullUserInfo , $userIDResult);
	  return $result;
   }

   function checkEmail($fullUserInfo) {
	  $emailResult = $this->conn->Execute('Select * From RanUser.dbo.FullUserInfo Where Email = ? ',array($fullUserInfo->email));
	  $result = $this->getFromResult($fullUserInfo , $emailResult);
	  return $result;
   }
   function checkUserPass($fullUserInfo) {
	  $userPwdResult = $this->conn->Execute('Select UserID,UserPass from RanUser.dbo.FullUserInfo Where UserPass = ? And UserID = ?',array($fullUserInfo->userPass,$fullUserInfo->userID));
	  $result = $this->getFromResult($fullUserInfo , $userPwdResult);
	  return $result;
   }
   function checkUserPassEmail($fullUserInfo) {
	  $userEmailResult = $this->conn->Execute('Select * From RanUser.dbo.FullUserInfo Where Email = ? And UserPass2 = ? And UserID = ?',array($fullUserInfo->email,$fullUserInfo->userPass2,$fullUserInfo->userID));
	  $result = $this->getFromResult($fullUserInfo , $userEmailResult);
	  return $result;
   }
   function check_UserID($fullUserInfo) {
	  $userIDResult = $this->conn->Execute('Select * From RanUser.dbo.FullUserInfo Where UserID = ? ',array($fullUserInfo->userID));
	  $result = $this->getFromResult($fullUserInfo , $userIDResult);
	  return $result;
   }
   function checkUserPass2($fullUserInfo) {
	  $safePwdResult = $this->conn->Execute('Select UserID,UserPass2 from RanUser.dbo.FullUserInfo Where UserPass2 = ? And UserID = ?',array($fullUserInfo->userPass2,$fullUserInfo->userID));
	  $result = $this->getFromResult($fullUserInfo , $safePwdResult);
	  return $result;
   }
    function checkemailAddress($fullUserInfo) {
	  $emailResult = $this->conn->Execute('Select * from RanUser.dbo.FullUserInfo Where Email = ? And UserID = ?',array($fullUserInfo->email,$fullUserInfo->userID));
	  $result = $this->getFromResult($fullUserInfo , $emailResult);
	  return $result;
   }

   #-- private functions
   function getFromResult($fullUserInfo, $result) {
	   if(!$result->EOF){
		$rs = $result->fields;
		$fullUserInfo->userNum = $rs['UserNum'];
		$fullUserInfo->userName = $rs['UserName']; 
		$fullUserInfo->userID = $rs['UserID'];
		$fullUserInfo->userPass = $rs['UserPass'];
		$fullUserInfo->userPass2 = $rs['UserPass2'];
		$fullUserInfo->bodyID = $rs['BodyID'];
		$fullUserInfo->sex = $rs['Sex'];
		$fullUserInfo->email = $rs['Email'];
		$fullUserInfo->birthY = $rs['BirthY'];
		$fullUserInfo->birthM = $rs['BirthM'];
		$fullUserInfo->birthD = $rs['BirthD'];
		$fullUserInfo->tel = $rs['TEL']; 
		$fullUserInfo->mobile = $rs['Mobile'];
		$fullUserInfo->qq = $rs['QQ'];
		$fullUserInfo->msn = $rs['MSN'];
		$fullUserInfo->city1 = $rs['City1'];
		$fullUserInfo->city2 = $rs['City2'];
		$fullUserInfo->post = $rs['Post'];
		$fullUserInfo->address = $rs['Address'];
		$fullUserInfo->safeId = $rs['SafeId'];
		$fullUserInfo->bodyID2 = $rs['BodyID2'];
	  	 return $fullUserInfo;
	   }
	     return false;
   }
   function updateUserPass($fullUserInfo) {
     $result = $this->conn->Execute('Update RanUser.dbo.FullUserInfo set UserPass = ? where UserID = ?',array($fullUserInfo->userPass,$fullUserInfo->userID));
	  if(!$result){
		  return $this->conn;
	  }else{
		  return true;
	  }
   }
   function updateUserPass2($fullUserInfo) {
     $result = $this->conn->Execute('Update RanUser.dbo.FullUserInfo set UserPass2 = ? where UserID = ?',array($fullUserInfo->userPass2,$fullUserInfo->userID));
	  if(!$result){
		  return $this->conn;
	  }else{
		  return true;
	  }
   }

   function insertFullUserInfo($fullUserInfo) {
     $result = $this->conn->Execute("Insert Into Ranuser.dbo.FullUserInfo ([UserName], [UserID], [UserPass], [UserPass2], [BodyID], [BodyID2], [Sex], [Email], [BirthY], [BirthM], [BirthD], [TEL], [Mobile], [QQ], [MSN], [City1], [City2], [Post], [Address], [SafeId]) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",array($fullUserInfo->userName,$fullUserInfo->userID,$fullUserInfo->userPass,$fullUserInfo->userPass2,$fullUserInfo->bodyID,$fullUserInfo->bodyID2,$fullUserInfo->sex,stripslashes($fullUserInfo->email),$fullUserInfo->birthY,$fullUserInfo->birthM,$fullUserInfo->birthD,$fullUserInfo->tel,$fullUserInfo->mobile,0,0,$fullUserInfo->city1,$fullUserInfo->city2,$fullUserInfo->post,$fullUserInfo->address,0));
	  if(!$result){
		  return $this->conn;
	  }else{
		  return true;
	  }
   }
}
?>