<?php
class ShopPurchaseDAO {
   var $conn;

   function ShopPurchaseDAO(&$conn) {
     $this->conn =& $conn;
   }
	
   function get_PurKeyMax(){
		$purKeyMax = $this->conn->Execute("Select MAX(Purkey+1) as MaxPurkey From RanShop.dbo.ShopPurchase");
		return $purKeyMax->fields["MaxPurkey"];
   }
   function item_PurchaseList($purchase){
	$purchaseResult = $this->conn->Execute("SELECT * from RanShop.dbo.ShopPurchase WHERE UserUID = ? ORDER BY PurDate ASC",array($purchase->userUID));	   
    for($i=0;$i<$purchaseResult->RecordCount();$i++){
		$result = $this->getFromResult($purchase, $purchaseResult);
		$purchaseList[] = array($result->productNum,$result->purPrice,$result->purDate,$result->userUID,$result->purChgDate,);	
		$purchaseResult->movenext();
	}
  		return $purchaseList;
   }
   function insert_ItemPurchase($purchase) {
	//No Indentity Specification
	if($purchase->purKey===false){
	$result = $this->conn->Execute('INSERT INTO RanShop.dbo.ShopPurchase ([UserUID],[ProductNum],[PurPrice],[PurFlag]) VALUES (?,?,?,?)', array($purchase->userUID,$purchase->productNum,$purchase->purPrice,$purchase->purFlag));
	}else{
	$result = $this->conn->Execute('INSERT INTO RanShop.dbo.ShopPurchase ([PurKey],[UserUID],[ProductNum],[PurPrice],[PurFlag]) VALUES (?,?,?,?,?)', array($purchase->purKey,$purchase->userUID,$purchase->productNum,$purchase->purPrice,$purchase->purFlag));
	//$result = $this->conn->Execute('INSERT INTO RanShop.dbo.ShopPurchase ([UserUID],[ProductNum],[PurPrice],[PurFlag]) VALUES (?,?,?,?)', array($purchase->userUID,$purchase->productNum,$purchase->purPrice,$purchase->purFlag));
	}
	if(!$result){
	   return $this->conn;
	}else{
		return true;
	}
   }
   #-- private functions
   function getFromResult($purchase, $result) {
	 if(!$result->EOF){
	  $purchase->purKey = $result->fields['PurKey'];
	  $purchase->userUID = $result->fields['UserUID'];
	  $purchase->productNum = $result->fields['ProductNum'];
	  $purchase->purPrice = $result->fields['PurPrice'];
	  $purchase->purFlag = $result->fields['PurFlag'];
	  $purchase->purDate = $result->fields['PurDate'];
	  $purchase->purChgDate = $result->fields['PurChgDate'];
     return $purchase;
	 }
	 return false;
   }

}
?>