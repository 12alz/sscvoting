<?php
class User
{
	 var $userNum, $userName, $userID, $userPass, $userPass2, $userType, $userLoginState, 
 	 $userEmail, $userPoint, $webLoginState, $gameTime2, $tj, $GameTime, $userBlock;
	
}

?>