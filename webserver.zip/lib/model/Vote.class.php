<?php
class Vote
{
	var  $id, $userID, $last_Vote, $Date, $hits;
}
?>