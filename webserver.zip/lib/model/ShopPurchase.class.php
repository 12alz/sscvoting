<?php
class ShopPurchase
{
	var $purKey, $userUID, $productNum, $purPrice, $purFlag, $purDate, $purChgDate;
}
?>