<?php
class ChaRebornList
{
	var $id, $rbNum, $userNum, $chaNum, $chaLevel, $type, $createDate;
	
}
?>