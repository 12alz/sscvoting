<?php

class Download
{
	
var $id, $name, $downloadUrl, $explain, $addTime;
	
	
	
	
}


?>