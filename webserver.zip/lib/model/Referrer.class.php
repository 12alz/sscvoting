<?php
class Referrer
{
	
	var  $ID, $reFUserNum, $userID, $chaNum, $chaRB, $getPoints, $Date, $status;
	
	
}
?>