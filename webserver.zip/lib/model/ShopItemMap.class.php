<?php
class ShopItemMap
{
	
	var $productNum, $itemMain, $itemSub, $itemName, $itemList, $duration, $category, $itemStock, $itemImage, $itemMoney, $itemComment;

}


?>