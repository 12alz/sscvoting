<?php
class Guild
{
	var $guNum,$guName;
}
?>