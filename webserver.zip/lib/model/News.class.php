<?php
class News
{
	var  $id, $cataid, $title, $content, $nfrom, $special, $permission, $addTime, $hits, $sortid, $imageNum, $firstImageName;
		
}


?>