<?php
class Character {
  var $chaNum, $chaName,$userNum, $chaClass,
  $chaSchool, $chaSex, $chaLevel, $chaMoney, $chaPower, 
  $chaStrong, $chaStrength, $chaSpirit, $chaDex, $chaStRemain, 
  $chaExp, $chaSaveMap, $chaSavePosX, $chaSavePosY, 
  $chaSavePosZ, $chaBright, $chaPK, $chaSkillPoint, $chaInvenLine, 
  $chaOnline, $chaInven, $chaReborn, $changeClass, $chaRebornDate,$chaSkills;
}
?>