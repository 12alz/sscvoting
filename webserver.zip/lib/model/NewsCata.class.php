<?php
class NewsCata
{
	var  $id, $title, $addTime, $rootid, $level;
	
}
?>