<?php
class FullUserInfo
{
	
	var $userNum, $userName, $userID, $userPass, $userPass2, $bodyID, $sex, $email, $birthY, 
	$birthM, $birthD, $tel, $mobile, $qq, $msn, $city1, $city2, $post, $address, $safeId, $bodyID2;
	
	
}

?>