<?php
class GuildRegion
{
		var $regionID,$guNum,$regionTax;
}
?>