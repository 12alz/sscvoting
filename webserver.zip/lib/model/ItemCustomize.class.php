<?php

class ItemCustomize
{
	
	var $gmID, $mainID, $subID, $itemName, $changeQuantity, $attackUpgrade, $defenceUpgrade, $chaInven, 
	$point, $addDate, $gmType, $editBol, $gfInfo, $gmShuXing, $gmPic,  $addBol, $chaNum;

	
	
	
}




?>