<?php
//Full Client
define('FULL_CLIENT_MSG','This is full client for new player');
define('PATCH_MSG','This patch is for split and full client');

//iLogin
define('ILOGIN_ID_ERR_FORMAT_MSG','The User ID is wrong format!');
define('ILOGIN_PWD_ERR_FORMAT_MSG','The Password is wrong format!');
define('ILOGIN_CODE_ERR_MSG','Identifying Code error, please enter the correct code!');
define('ILOGIN_ID_PWD_FAILED_MSG','Failure of the login,Please check your password or account number.');
define('ILOGIN_USER_BANNED_MSG', 'Account Banned');

define('LOGIN_ID_ERR_FORMAT_MSG','Incorrect User ID!');
define('LOGIN_PWD_ERR_FORMAT_MSG','Incorrect Password!');
define('LOGIN_CODE_ERR_MSG','Please try new code instead!');
define('LOGIN_ID_PWD_FAILED_MSG','Account or password error');

define('CHECK_CODE_ERR_MSG','Error code, please enter the correct verification code!');

define('CHARACTER_SELECT_ERR_MSG','Select the Character');
define('CHARACTER_ONLINE_ERR_MSG','Please logout in Game!');
define('CHARACTER_MONEY_ERR_MSG','You have not enough money!');

define('USER_ONLINE_ERR_MSG','Please logout in Game!');
define('USER_POINT_ERR_MSG','You have not enough points!');
define('USER_CHARACTER_POINT_MONEY_ERR_MSG','You have not enough money or points!');

//Register
define('REGISTER_ID_FORMAT_ERR_MSG','Account format is incorrect,Please re-enter');
define('REGISTER_PWD_FORMAT_ERR_MSG','Password format is incorrect,Please re-enter');
define('REGISTER_2ND_PWD_FORMAT_ERR_MSG','2ndPassword format is incorrect,Please re-enter');
define('REGISTER_RE_PWD_SAFE_ERR_MSG','Two different input, please re-enter');
define('REGISTER_EMAIL_FORMAT_ERR_MSG','Incorrect,please input again');
define('REGISTER_EMAIL_EXIST_MSG','Email is not available');
define('REGISTER_ID_EXIST_MSG','This ID is not available');
define('REGISTER_ID_OK_MSG','This ID is available');
define('REGISTER_ID_LESS_MSG','At least 4 characters needed');
define('REGISTER_SUCCESS_MSG','Success!');
define('REGISTER_CHECK_CODE_ERR_MSG','Please try new code instead!');

//ItemUpgrade
define('ITEM_IMPORT_BACK_SUCCESS_MSG','Import to Character Inventory success!');
define('ITEM_IMPORT_BACK_NO_SLOT_MSG','Import Failed! Insufficient inventory space');
define('ITEM_IMPORT_SUCCESS_MSG','Import to the Web Warehouse success!');
define('ITEM_IMPORT_FAILED_MSG','Import to the Web Warehouse failed!');
define('ITEM_IMPORT_FULL_MSG','The maximum space of web storage reached.');
define('ITEM_UPGRADE_USER_POINT_ERR_MSG','Operation Failed, You have not enough points!');
define('ITEM_MAX_GRADE_MSG','Operation Failed, You have not enough points!');
define('ITEM_ADDON_NO_SLOT_MSG','Failed, Item random value slot is full!');
define('ITEM_UPGRADE_SELECT_PROPERTIES_ERR_MSG','Please choose the type to upgrade');

//Add stats TODO
define('ADD_STATS_ERR_MSG','Error, plus at least one attribute');
define('ADD_STATS_POINTS_MSG','Points allocation error, please re-add points!');
define('ADD_STATS_SUCCESS_MSG','Success!');

//Game Time
define('GAME_TIME_MIN_LESS_MSG','Sorry, the current length of time is less than request.');

//Gold Conversion
define('EPOINTS_LESS_MSG','Sorry, the current length of epoints you have is less than request.');

//Reborn Conversion
define('REBORN_LESS_MSG', 'Rebirth/Reborn required is less than request.');
define('REBORN_LEVEL_REQUIRED_MSG', 'Your current character level is too low!');
define('R2PPAY_LESS_POINT_MSG', 'You dont have enough points to perform this transaction, please re-add points!');

//Purchase Reborn
define('PURCHASE_RB_LESS_POINT_MSG', 'You dont have enough points to perform this transaction, please re-add points!');
define('PURCHASE_RB_LIMIT_EXCEEDED', 'You have exceeded the maximum reborn value input, please re-enter again!');

//Reborn
define('REBORN_JUNIOR_LVL_MSG','You have not yet achieved the level of Primary reincarnation!');
define('REBORN_MIDDLE_LVL_MSG','You have not yet achieved the level of Secodary reincarnation!');
define('REBORN_ADVANCED_LVL_MSG','You have not yet achieved the level of Advanced reincarnation!');
define('REBORN_LIMIT_MSG','You have achieved the max reincarnation!');
define('REBORN_UPGRADE_SUCCESS_MSG','Success, added 25 stats!');

//Reset Stats
define('RESET_STATS_POINTS_SUCCESS_MSG','Success!');
define('RESET_STATS_POINTS_NO_NEED_RESET_MSG','Character does not need a reset stats point!');

//Reset PK
define('RESET_PK_SUCCESS_MSG','Success!');
define('RESET_PK_NO_NEED_MSG','Character does not need a reset pk!');

//Reset Password
define('RESET_PASSWORD_FAILED_MSG','Failed!');
define('RESET_PASSWORD_VERIFY_MSG','Please verify your password again');
define('RESET_PASSWORD_SUCCESS_MSG','Success!');

//Reset Safe PWD
define('RESET_SAFE_PASSWORD_FAILED_MSG','Failed!');
define('RESET_SAFE_PASSWORD_VERIFY_MSG','Please try it again');
define('RESET_SAFE_PASSWORD_SUCCESS_MSG','Success!');

//Mart
define('MART_RE_LOGIN_MSG','Time out,please re-login');
define('MART_ITEM_STOCK_ERR_MSG','Sorry, out of stock! Please try again');
define('MART_ITEM_BUY_SUCCESS_MSG','Success!');
define('MART_ITEM_NOT_EXISTS','Product not exists! Please check your Bingo ItemList Configuration.');
define('MART_NO_PRODUCT','No product available.');

//Find Password
define('FIND_PASSWORD_ID_FORMAT_ERR_MSG','The User ID is wrong format!');
define('FIND_PASSWORD_SAFE_FORMAT_ERR_MSG','The Second Password is wrong format!');
define('FIND_PASSWORD_EMAIL_CODE_SAFE_ERR_MSG','Wrong Information or Identifying Code!');

//Transsexual
define('TRANSSEXUAL_SUCCESS_MSG','Success!');

//Vote Msg
define('VOTE_SITE_ERR_MSG','Please vote each site in one after the other!');
define('VOTE_ID_NOT_EXISTS_MSG','Please try again.');

//ChangeClass
define('CHANGE_CLASS_SUCCESS_MSG','Success!');
define('CHANGE_CLASS_SELECT_MSG','Select the Character Class');
define('CHANGE_CLASS_CHECK_MSG','Character had already changed class!');
define('CHANGE_CLASS_ALREADY_USE_MSG','Class already in use');

//Delete Items
define('DELETE_ITEMS_FAILED_MSG','Failed!');

//Recover Char Del
define('RECOVER_CHAR_PASS_ERR_MSG', 'Invalid Password');
define('RECOVER_CHAR_REPASS_ERR_MSG', 'Re Enter Second Password Doesnt match!');
define('RECOVER_CHAR_PIN_ERR_MSG', 'Invalid Second Password');
define('RECOVER_CHAR_POINT_LESS_MSG', 'You dont have enough points to perform this transaction!');

//POINT BINGO
define('POINT_BINGO_NOT_EXIST', 'No Points have been configure..');

//Gold To EP
define('GOLD2EP_CHAR_GOLD_ERR_MSG','You dont have enough gold in your character inventory!');
define('GOLD2EP_POINTS_LESS_ERR_MSG','You dont have enough points to perform this transaction!');

?>