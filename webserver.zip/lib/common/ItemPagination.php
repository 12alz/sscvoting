<?php
class ItemPagination 
{
	var $page = 1;
    var $perPage = 10;
	var $pageTitleName;
	var $tablecolSpan = 10;
    function generate($array, $perPage = 10)
    {
	  if (!empty($perPage))
      $this->perPage = $perPage;
	  
	  $pageTarget = explode("$", $_POST["__EVENTARGUMENT"]);
	  $pageArg = explode("$", $_POST["__EVENTARGUMENT"]);
	  $page = (int)$pageArg[1];
	  	  
      if (!empty($page) & $pageArg[0] == $this->pageTitleName) {
      	$this->page = $page;
      }else{
      	$this->page = $this->page;
      }
      $this->length = count($array);
      $this->pages = ceil($this->length / $this->perPage);
	  if($this->page > $this->pages){
	  $this->page = $this->pages;
	  }
      $this->start  = ceil(($this->page - 1) * $this->perPage);
      return array_slice($array, $this->start, $this->perPage);	  
	}
    function links()
    {	
	  $plinks = array();
      $links = array();
      $slinks = array();
      if ($this->pages > 1)
      {
		$range = 10;
		$range_min = ($range % 2 == 0) ? ($range / 2) - 1 : ($range - 1) / 2;
		$range_max = ($range % 2 == 0) ? $range_min + 1 : $range_min;
		$page_min = $this->page- $range_min;
		$page_max = $this->page+ $range_max;

		$page_min = ($page_min < 1) ? 1 : $page_min;
		$page_max = ($page_max < ($page_min + $range - 1)) ? $page_min + $range - 1 : $page_max;
		if ($page_max > $this->pages) {
			$page_min = ($page_min > 1) ? $this->pages - $range + 1 : 1;
			$page_max = $this->pages;
		}
		$page_min = ($page_min < 1) ? 1 : $page_min;
	  
	  		  $aLink = '<tr class="pp" align="center" valign="middle" style="font-size:Large;text-decoration:underline overline;">
				<td colspan="'.$this->tablecolSpan.'"><table border="0">
					<tr>';
		  for ($j = $page_min; $j < ($page_max + 1); $j++) {
			if ($this->page == $j) {
			  $links[] = '<td><span>'.$j.'</span></td>';
			} else {
			  $links[] = '<td><a href="javascript:__doPostBack(\'ctl00ContentPlaceHolder_mainGridView1$'.$this->pageTitleName.'\',\''.$this->pageTitleName.'$'.$j.'\')">'.$j.'</a></td>'; 
			}
		  }
			  if($j > 10 & $j < $this->pages){
			  $links[] = '<td><span>...</span></td>';	
			  }
		  	  $bLink = '</tr>
				</table></td>
			</tr>';
		  
		  return $aLink.implode(' ', $plinks).implode($this->implodeBy, $links).implode(' ', $slinks).$bLink;
	  
	  
	  }
	  
	}
}
?>