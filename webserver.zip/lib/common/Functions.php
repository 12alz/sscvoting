<?php
function clean_variable($var=NULL,$r=NULL) {
$newvar = preg_replace('/[^a-zA-Z0-9\_]/', '', $var);
if (!preg_match('/^[a-zA-Z0-9\_\s]*$/i',stripslashes($var))) {
	if ($r != NULL) {  return true; } else { return $newvar; }
 } 
	if ($r == NULL) {  return $newvar; }
}

function jump_location($location){
	header("Location: $location");
	exit();
}
function user_checklogin($id,$hash) {
	global $_config,$db;
	if ($_config['Md5Encrypt']){
	$hash = strtoupper(substr(md5(clean_variable(md5_decrypt($hash))),0,19));
	}else{
	$hash = clean_variable(md5_decrypt($hash));
	}
	$res = $db->Execute("Select UserNum From RanUser.dbo.UserInfo Where UserID =? And UserPass = ?",array(clean_variable($id),$hash));
	$rs = $res->GetArray();
	return $rs[0]['UserNum'] > 0 ? true : false;
}
function get_rnd_iv($iv_len) {
   $iv = '';
   while ($iv_len-- > 0) {    $iv .= chr(mt_rand() & 0xff); }
   return $iv;
}
function md5_encrypt($plain_text, $password='hashhash', $iv_len = 16)
{
   $plain_text .= "\x13";
   $n = strlen($plain_text);
   if ($n % 16) $plain_text .= str_repeat("\0", 16 - ($n % 16));
   $i = 0;
   $enc_text = get_rnd_iv($iv_len);
   $iv = substr($password ^ $enc_text, 0, 512);
   while ($i < $n) {
       $block = substr($plain_text, $i, 16) ^ pack('H*', md5($iv));
       $enc_text .= $block;
       $iv = substr($block . $iv, 0, 512) ^ $password;
       $i += 16;
   }
   return base64_encode($enc_text);
}

function md5_decrypt($enc_text, $password='hashhash', $iv_len = 16)
{
   $enc_text = base64_decode($enc_text);
   $n = strlen($enc_text);
   $i = $iv_len;
   $plain_text = '';
   $iv = substr($password ^ substr($enc_text, 0, $iv_len), 0, 512);
   while ($i < $n) {
       $block = substr($enc_text, $i, 16);
       $plain_text .= $block ^ pack('H*', md5($iv));
       $iv = substr($block . $iv, 0, 512) ^ $password;
       $i += 16;
   }
   return preg_replace('/\\x13\\x00*$/', '', $plain_text);
}
function write_log($logentry, $lgname) {
global $_config;

$user = @isset($GLOBALS['user_auth']->username) ? @$GLOBALS['user_auth']->username : '' ;
$admin = @!isset($_SERVER['PHP_AUTH_USER']) ? @$GLOBALS['admin_auth']->username : @$_SERVER['PHP_AUTH_USER'];
$logentry = $_SERVER['REMOTE_ADDR']. " ". @$_SERVER['PHP_AUTH_USER']." $logentry";
$lgname = $_config['AdminLogs'].'/'.date("ymd").'_'.$lgname.'.txt';
      $logfile = @fopen ($lgname, "a+");
      if ($logfile)  {
          fwrite ($logfile, "[".date ("D M d Y h:iA")."] [$logentry]\r\n");
          fclose ($logfile);
        }
}

?>