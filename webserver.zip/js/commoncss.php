<style>
#loginBox,
#board,
#board table,
.showdetail td,
.ContentsFooter{/*background:none;*/}
.boxesWShadow{
		background: rgba(28, 54, 54, 0.8) !important;
		border: 2px solid #7bbfe4 !important;
		border-radius: 19px !important;
		/* box-shadow: -5px 5px 6px 0px #272727 !important; */
		overflow: hidden !important;
	}
	.inputOuter{
		background: rgba(0,0,0,0.5) !important;
		border-radius: 20px !important;
	}
	.inputInner{
		background: rgba(0,0,0,0) !important;
		outline: none !important;
	}
	.inputCusWidth{
		    width: 47% !important;
	}
	.boxCusMarginLeft{
		margin-left: 5px !important;
	}
    .boxCusMarginLeft2{
		margin-left: 6px !important;
	}
	.haveborderBot{
		    border-bottom: 2px dotted #fff;
	}
	.header3{
		color: #fff;
		background: #217892;
		border-radius: 50px;
	}
	.cus243{
		margin-bottom: 14px !important;
		line-height: 31px !important;
		font-weight: bold !important;
		color:#fff !important;
		background: #217892;
		border-radius: 50px;
	}
	#footer{
		    text-align: center;
		float: left;
		width: 73%;
		color: #fff;
	}
	ul.mainbtnfunc li {
    display: inline-block;
    color: #fff;
    background: #5093b9;
    padding: 3px 12px;
    border-radius: 2px;
}
ul.mainbtnfunc li a {
    color: #fff;
}
.subMenuBox tr td a,
#subMenu tr td a{
    color: #fff;
}
.contentsBodyCusWid{
	    width: 675px !important;
}
#board table td{border:0px;}
</style>