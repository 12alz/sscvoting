<script type="text/javascript">

	var ajaxReq = null,
		ajaxReq1 = 1,
		$globalElem;	
	var otp ={
		send_ajax: function(data, url, type){
			$.ajax(
				{
					type: type,
					url:url,
					data: data,
					dataType: 'json',
					success: function (data) {
						eval(data['func'])(data);
					}
				}
			);
		},
		send_ajax_with_attachment: function(data, url, type){
 			ajaxReq = $.ajax({				
				type: type,				
				url:url,				
				data: data,				
				processData: false,				
				contentType: false,				
				beforeSend : function() {					
					if(ajaxReq !== null) {                        
						ajaxReq.abort();                    
					}                
				},				
				success: function (data) {					
					if(data){						
						data = JSON.parse(data); 						
						eval(data['func'])(data);					
					}					
					ajaxReq = null;			
				}		
			});		
		}
	};

</script>