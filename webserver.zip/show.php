<?php
include_once('root.inc.php');
include_once('lib/logic/News.php');
include_once('control/ctl_news.inc.php');
$news = new NewsController;
$contents = $news->showNews();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title><?php echo PAGE_TITLE;?></title>
<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<meta name="description" content="<?php echo PAGE_TITLE;?>" />
<meta name="keywords" content="<?php echo PAGE_TITLE;?>" />
<meta http-equiv="imagetoolbar" content="no" />	
<link rel="shortcut icon" href="/common/ran.ico" type="image/x-icon" />
<link rel="stylesheet" href="/common/css/Layout.css" />
<link rel="stylesheet" href="/common/css/main.css" />
<link rel="stylesheet" href="/common/css/SubPage.css" />
<link rel="stylesheet" href="/common/css/table.css" />
<link rel="stylesheet" href="/common/css/common.css" />

<script type="text/javascript" src="/common/main.js"></script>

<script type="text/javascript" src="/common/menu.js"></script>	
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<?php include_once('js/commoncss.php'); ?>
<?php include_once('js/commonjs.php'); ?>
</head>
<body onload="MM_preloadImages('img/Common/menu_sub_31s.jpg','img/Common/menu_sub_33s.jpg','img/Common/menu_sub_34s.jpg','img/Common/menu_sub_35s.jpg','img/Common/menu_sub_36s.jpg','img/Common/menu_sub_37s.jpg','img/Common/menu_sub_38s.jpg','img/Common/menu_sub_22s.jpg','img/Common/menu_sub_391s.jpg','img/Common/menu_sub_24s.jpg','img/Common/menu_sub_25s.jpg')">

<div id="wrap">
   
    
<!--subbanner-->
   <div id="navigation"></div>

    
    <div id="contentsWrap">
        <div id="contentsNavi" class="">
            <div id="loginBox">

    <script type="text/javascript">
    
    function setBack(obj, showBg) {
        if (showBg == false) {
            obj.className = 'clearBg';
        }
        
        if (showBg == true && obj.value == '') {
            obj.className = '';
        }
    }
    </script>

<?php 
if($user_auth->haslogin){
$user = $user_auth->getUserInfo();
echo '	
	<div style="background:url(\'/img/loginbg2.jpg.png\') no-repeat bottom left;width:190px;height:85px;padding-top:3px">
	<div style="margin-left:20px;margin-top:-4px;color:#ffffff;text-align:left;line-height:16px;">
	<br>

	<strong>Hello, <span id="ctl00_UserID" style="color:#FFE32A;">',$user->userID,'</span></strong><br>
	<strong>Points: <span id="ctl00_GamePoint" style="color:#8FFAD0;">',$user->userPoint,'</span></strong> <a href=mart.php?do=itemorder><font color=#FFFFFF>[Use]</font></a> <a href=member.php?do=payorder><font color=#FFFFFF>[Get]</font></a>
		<br>
	<!-- <strong>You\'re<font color=#FF9E04><span id="ctl00_UserType"></span></font></strong>  -->
	</div>

	</div>
';
}else{
?>
<div id="loginIDNPW" style="margin:26px 2px 0px 0px;margin: 2px 0 0 1px!important; /* IE7+FF */">
	<iframe name="inner2" width="190" allowTransparency="true" height="85" src="member/ilogin.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no"></iframe>
</div>
<?php 
}
    if(!$user_auth->haslogin){
echo '';
}else{
echo '';	
}
?>	
    </map>
		


</div> 

		<div id="subMenuRing"></div>
            <div id="subMenu">
<!--leftmenn-->
	<div class="subMenuBox" style="margin-top:-38px;padding-left:0px;height:180px;">
	<img src="/img/common/menu_sub1_title.png" height="31" style="padding-bottom:8px">
		<table border="0" cellspacing="0" cellpadding="0">
		<tr>
<?php include_once('parts/SubMenuBox2.php'); ?>		
		
		</table>
	</div>
	
            </div>
            <!--div id="subBanner"><script>useSwf("/Common/Flash/sub_quick.swf","204","114",1)</script></div-->
        </div>
        <div id="contentsBody">
    <div id="subContents">

	
<!--title
	<div class="title"><img src="/img/Title/title_10.png" align="left" /></div>-->

	<div class="Contents">
	
<!--contents 
	<div class="contentsIMG"><img src="/img/Title/img_0101.png"></div>
<img src="/img/Intro/line_h_bdot.gif" alt="" style="margin-top:-12px"/>img-->

        <div id="board" >
		
<table width="100%" height="0" border="0" cellspacing="0" cellpadding="0">

  <tr>
    <td  style="border-bottom:1px solid #ffffff;">
<!--content-->

<!--
作者：<span id="ctl00_ContentPlaceHolder_main_AuthorLabel"></span>                                                                                                    
來源：<span id="ctl00_ContentPlaceHolder_main_SourceLabel"></span>                                                                                                                                                                                                                                                                                                                                                                                                                <br>
閱讀：<span id="ctl00_ContentPlaceHolder_main_HitsLabel"></span>1514
導航：<span id="ctl00_ContentPlaceHolder_main_BackLabel"></span><A href="default.php">新聞首頁</A>＞＞<A href="list.php?classname=News                                    ">News                                    </A>

<form name="aspnetForm" method="post" action="show.php?articleid=173" id="aspnetForm">
<div>
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwULLTEzNzg1MTU3MzgPZBYCZg9kFggCAQ8PFgIeBFRleHRkZGQCAg8PFgIfAGRkZAIDDw8WAh8AZGRkAgYPZBYCAgQPZBYCAgMPPCsACQEADxYEHghEYXRhS2V5cxYAHgtfIUl0ZW1Db3VudGZkZGR8AM6iEJic7c8GZ2XEKLYlpu1iWQ==" />
</div>

<div>

	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEWAgKV3djECwLp4bWbDE/8n33GtJ6FeuukhvXqnsc9cnNv" />
</div>
<span id="ctl00_ContentPlaceHolder_main_Label2" style="display:inline-block;width:114px;"></span>

<input type="submit" name="ctl00$ContentPlaceHolder_main$Button1" value="發　表" id="ctl00_ContentPlaceHolder_main_Button1" style="width:74px;" />
</form>

-->	


<!-- content /e -->
	<div class="read_top">
	    <div class="read_top_title" style="float:left;padding-left:10px;">[<?php echo $contents[4];?>] &nbsp;<?php echo $contents[0];?></div>
	    <div class="read_top_name" style="float:right;padding-right:10px;color:#fff;"><?php echo $contents[1];?></div>

	</div>

	<div class="read_top2">
	    <div class="read_link">
	        <a id="read_link_a">http://<?php echo $_SERVER['HTTP_HOST'],$_SERVER['SCRIPT_NAME'],"?articleid=",$contents[5];?></a> 
			<a href="javascript:clipboard_copy('http://<?php echo $_SERVER['HTTP_HOST'],$_SERVER['SCRIPT_NAME'],"?articleid=",$contents[5];?>');">
			<img src="/img/Community/bt_linkcopy.jpg" alt="" style="margin-left:3px;margin-bottom:-5px;"></a> 
	    </div>
	    <div class="read_date"><?php echo $contents[2];?></div>
	</div>

	<div class="line_dot"></div>

	<!-- 内容 /s -->
	<div class="read_contents" style="color:#fff;">
	<?php echo $contents[3];?>
	</div>
	<!-- 内容 /e -->
	<div class="lineEB4"></div>
	<!--<div class="list-btn"><a href="/list.php"><img src="/img/Community/bt_board_list.jpg" alt="" align="absmiddle"></a></div>-->
<!-- content /e -->
    </td>
  </tr>
</table>

        </div>

    </div>
    <div class="ContentsFooter"></div>
</div> 

        </div>
        <div class="clear">
        </div>
    </div>

</div>
<?php include_once('js/globaljs.php'); ?>
<?php include 'parts/global_script.php'; ?>
<?php
display_query_console($db);
$db->Close();  
?>
</body>
</html>