<?php
include("connect.php");
header('X-Frame-Options: GOFORIT'); 
?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <title>MOY Ran Online</title>
</head>
<body>
  <script>
	$(function(){
		$('input[type="text"]').change(function(){
			this.value = $.trim(this.value);
		});
	});
	</script>
  <form action="connect.php" method="GET">    
    <input type="text" name="chaName" placeholder="Enter character name"></input>
    <input type="submit" value="Claim Reward">
  </form>
</body>
</html>