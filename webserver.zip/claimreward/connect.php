<?php
error_reporting(1);
$host ="-\SQLEXPRESS"; 
$username ="sa";
$password ="-";
$database ="RanGame1";

mssql_connect($host, $username, $password);
mssql_select_db($database);


$charName = htmlspecialchars($_GET['chaName']);
if(isset($_GET["chaName"]))
{
//GET CHARACTER INFO
  $query = "SELECT UserNum,ChaName,ChaReborn FROM ChaInfo WHERE ChaName='$charName'";
  $result = mssql_query($query);
  while ( $record = mssql_fetch_array($result) )
  {
    //echo $record["UserNum"].",".$record["ChaName"] .", ". $record["ChaReborn"] ."<br />";           
    $chaNum = $record["UserNum"]; // UserNumber
    $chaRB = $record["ChaReborn"]; // Rebirth Count
    $chaNam = $record["ChaName"]; // UserCharacterName
  }  
//GET CLAIM INFO
    $newquery = "SELECT UserNum,isClaimed FROM RanUser.dbo.claimReward WHERE UserNum=$chaNum";
    $newresult = mssql_query($newquery);
    while( $row = mssql_fetch_array($newresult))
    {
      $isUser = $row["UserNum"];
    }
    if(empty($isUser)){
		if($chaRB>79){
         echo "<script>alert('Thankyou for claiming your reward!')</script>";
         $ins = "INSERT INTO RanUser.dbo.claimReward (UserNum,isClaimed) VALUES ($chaNum,1)";
         mssql_query($ins);
         $ins2 = "UPDATE RanUser.dbo.UserInfo SET UserPoint=UserPoint+16000 WHERE UserNum=$chaNum";
         mssql_query($ins2);
         echo "<script>window.location.href='http://enbabyranyong.online:8080/claimreward/index111.php'</script>";
		}else{
			echo "<script>alert('You must reach the required RB or Character does not exist!'); window.location.href='http://enbabyranyong.online:8080/claimreward/index111.php'</script>";
		}
    }else
    {	  
      echo "<script>alert('You already claim your reward!'); window.location.href='http://enbabyranyong.online:8080/claimreward/index111.php'</script>";
    }


}
  


 


  // if($_GET['chaName']>=100){
  //   echo"Reward Claim";
  //   $ins = "UPDATE RanUser.dbo.UserInfo SET UserPoint=UserPoint+6000 WHERE UserNum=$record[UserNum]";
  //   mssql_query($ins);
  //   $ins1 = "INSERT INTO RanUser.dbo.claimReward (UserNum,isClaimed) VALUES ($record[UserNum],1)";
  //   mssql_query($ins1);
  // }else{
  //   echo "You must reached the requirements or Reward Already Claimed, You can only claim once in each account";
  // }

  

?>