<?php
include_once('root.inc.php');
include_once('control/ctl_news.inc.php');
include_once('control/ctl_rank.inc.php');
$rank = new RankController;
$rank->hideGM = $_config['HideGM'];
$rank->rankLimit = $_config['RankLimit'];
$rank->perPage	= $_config['RankPerPage'];
$rank->chaClassName = $_config['ChaClass'];
$rank->chaSchoolName = $_config['ChaSchool'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title><?php echo PAGE_TITLE;?></title>
<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<meta name="description" content="<?php echo PAGE_TITLE;?>" />
<meta name="keywords" content="<?php echo PAGE_TITLE;?>" />
<meta http-equiv="imagetoolbar" content="no" />	
<link rel="icon"	  href="/common/boss.ico" 	  type="image/x-icon" />
<link rel="stylesheet" href="/common/css/Layout.css" />
<link rel="stylesheet" href="/common/css/main.css" />
<link rel="stylesheet" href="/common/css/SubPage.css" />
<link rel="stylesheet" href="/common/css/table.css" />
<link rel="stylesheet" href="/common/css/common.css" />

<script type="text/javascript" src="/common/main.js"></script>

<script type="text/javascript" src="/common/menu.js"></script>	
<script type="text/JavaScript">
<!--



//-->
</script>
<?php include_once('js/commoncss.php'); ?>
<?php include_once('js/commonjs.php'); ?>
</head>
<body onload="MM_preloadImages('img/Common/menu_sub_31s.jpg','img/Common/menu_sub_33s.jpg','img/Common/menu_sub_34s.jpg','img/Common/menu_sub_35s.jpg','img/Common/menu_sub_36s.jpg','img/Common/menu_sub_37s.jpg','img/Common/menu_sub_38s.jpg','img/Common/menu_sub_22s.jpg','img/Common/menu_sub_391s.jpg','img/Common/menu_sub_24s.jpg','img/Common/menu_sub_25s.jpg')">

<div id="wrap">
    <div id="navigation"></div>
    
<!--subbanner-->
	
    <div id="contentsWrap">
        <div id="contentsNavi">
            <div id="loginBox">

    <script type="text/javascript">
    
    function setBack(obj, showBg) {
        if (showBg == false) {
            obj.className = 'clearBg';
        }
        
        if (showBg == true && obj.value == '') {
            obj.className = '';
        }
    }
    </script>

<?php 
if($user_auth->haslogin){
$user = $user_auth->getUserInfo();
echo '	
	<div style="background:url(\'/img/loginbg2.jpg.png\') no-repeat bottom left;width:190px;height:85px;padding-top:3px">
	<div style="margin-left:20px;margin-top:-4px;color:#ffffff;text-align:left;line-height:16px;">
	<br>

	<strong>Hello, <span id="ctl00_UserID" style="color:#FFE32A;">',$user->userID,'</span></strong><br>
	<strong>Points: <span id="ctl00_GamePoint" style="color:#8FFAD0;">',$user->userPoint,'</span></strong> <a href=mart.php?do=itemorder><font color=#FFFFFF>[Use]</font></a> <a href=member.php?do=payorder><font color=#FFFFFF>[Get]</font></a>
		<br>
	<!-- <strong>You\'re<font color=#FF9E04><span id="ctl00_UserType"></span></font></strong>  -->
	</div>

	</div>
';
}else{
?>
<div id="loginIDNPW" style="margin:26px 2px 0px 0px;margin: 2px 0 0 1px!important; /* IE7+FF */">
	<iframe name="inner2" width="190" allowTransparency="true" height="85" src="member/ilogin.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no"></iframe>
</div>
<?php 
}
 if(!$user_auth->haslogin){
//  echo '<img src="/img/common/btn_idpw2.png" usemap="#loginSecuritySettingMap" />';
//  }else{
//  echo '<img src="/img/common/btn_idpw3.png" usemap="#loginSecuritySettingMap" style="margin-top:-6px"/>';	
 }
?>	
    <map name="loginSecuritySettingMap" id="loginSecuritySettingMap">
    <?php 
		if($user_auth->haslogin){
			echo'
				<area shape="rect" coords="3,5,100,25" href="/member.php?do=editpwd" alt="" />
				<area shape="rect" coords="115,5,170,25" href="/member/logout.php" alt="" />
				';
			}else{
			echo'
				<area shape="rect" coords="3,5,100,25" href="javascript:menu(1001);" alt="" />
				<area shape="rect" coords="115,5,170,25" href="javascript:menu(1002);" alt="" />
				';
			}
?>
    </map>
		


</div>
<div id="subMenuRing"></div>
            <div id="subMenu">
<!--leftmenn-->
	<div class="subMenuBox" style="margin-top:-38px;padding-left:0px;height:180px;">
	<img src="/img/common/menu_sub1_title.png" height="31" style="padding-bottom:8px"" >
		<table border="0" cellspacing="0" cellpadding="0">
		<tr>
<?php include_once('parts/SubMenuBox2.php'); ?>		
		
		</table>
	</div>
	
            </div>
            <!--div id="subBanner"><script>useSwf("/Common/Flash/sub_quick.swf","204","114",1)</script></div-->
        </div>
        <div id="contentsBody">
    <div id="subContents">

	
<!--title-->
<!-- <div class="title"><img src="/img/Title/title_21.jpg" align="left" /></div> -->

	<div class="Contents">
	
<!--contents img-->
<!-- <img src="/img/Intro/line_h_bdot.gif" alt="" style="margin-top:-12px"/> -->

        <div id="board" >
		
<table width="100%" height="350" border="0" cellspacing="0" cellpadding="0">
  <tr>

    <td  style="border-bottom:1px solid #ffffff;" valign=top>
<br>
                              <table width="100%" border="0" cellpadding="0" cellspacing="0" class="pk01" valign=top>
<font style="BACKGROUND-COLOR: #000000" color="#ffffff">                          

When two players has the same number of reborn and Level,<br>
the player who has higher EXP will temporarily be ranked ahead of the other player.<br>
This ranking system refresh every morning.<br>
We recommended that your account be offline once before midnight, <br>so that your character data will be saved and added to the ranking list. 


</font>




                                <tr>

                                  <td width="100%">
									
<style>
th{font-size: 9pt ; FONT-FAMILY:verdana,宋體;padding:2px 2px 2px 2px;}
.aa{font-size: 9pt ; FONT-FAMILY:verdana,宋體;padding:2px 2px 2px 12px;}
</style>
    <form name="phpnetForm" method="post" action="rank.php" id="phpnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['phpnetForm'];
if (!theForm) {
    theForm = document.phpnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>

<div>

	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="NcEm/94s3FvN03wgF/9pVvzqgRlqzQWnrZi9UKTLMT9qZZfzs2W3FyA+MT+fTcL5T/TLWlpzc6jJNtLVgSrC+81RRV6WMW90KwCSU8Xh96qCDOSv1rG9vJtZz8E1imt+jbSqWVT/MuVa0aEhGUY/td2Eryg=" />
</div>


 
<div align=right>

                <select name="rankTopx" id="ctl00_ContentPlaceHolder_main_rank_Topx" onChange="javascript:setTimeout('__doPostBack(\'rankTopx\',\'\')', 0)">
	<option <?php if (clean_variable($_POST["rankTopx"]) == '100') { echo 'selected="selected"'; } ?> value="100">Top 100</option>
    <option <?php if (clean_variable($_POST["rankTopx"]) == '200') { echo 'selected="selected"'; } ?> value="200">Top 200</option>
	<option <?php if (clean_variable($_POST["rankTopx"]) == '300') { echo 'selected="selected"'; } ?> value="300">Top 300</option>
</select> 
        <select name="rankChaSchool" onchange="javascript:setTimeout('__doPostBack(\'rankChaSchool\',\'\')', 0)" id="ctl00_ContentPlaceHolder_main_rank_ChaSchool">
	<option selected="selected" value="9">All School</option>
	<?php
	$schoolCount = count($_config['ChaSchool']);
	for($i=0;$i<$schoolCount;$i++){
	$selMenuContent = '<option ';
	if (clean_variable($_POST["rankChaSchool"]) == $_config['ChaSchool'][$i]){ 
	$selMenuContent.= 'selected="selected"'; 
	}
	$selMenuContent.= ' value="'.$_config['ChaSchool'][$i].'">'.$_config['ChaSchool'][$i].'</option>';
	echo $selMenuContent;
	}
	?>

</select>
</div><img height=4 ><br />
<div>
	<table cellspacing="0" cellpadding="4" align="Center" rules="cols" border="1" id="ctl00_ContentPlaceHolder_main_rank_GridView1" style="color:White;background-color:rgba(0,0,0,0.4);border-color:none;border-width:1px;border-style:None;width:100%;border-collapse:collapse;">
		<tr style="color:White;background-color:#8C8C8C;font-weight:bold;">

			<th scope="col" style="white-space:nowrap;">No.</th>
			<th scope="col" style="white-space:nowrap;">Character Name</th>
			<th scope="col">Level</th>
			<th scope="col">Rebirth</th>
			<th scope="col">EXP</th>
			<th scope="col">Class</th>
			<th scope="col">School</th>			
			<th scope="col">Date</th>	
		</tr>
		<?php $rank->rankList();?>
		<tr align=right">			
		<?php $rank->rankPagination();?>		
		</tr>
		
	</table>
</div> 

</form>
                                  </td>

                                </tr>
                              </table>
<br>
	</td>
</tr>
</table>

        </div>
    </div>

    <div class="ContentsFooter"></div>
</div> 

        </div>
        <div class="clear">
        </div>
    </div>


</div>
<?php include_once('js/globaljs.php'); ?>
<?php include 'parts/global_script.php'; ?>
<?php
display_query_console($db); 
$db->Close(); 
?>
</body>
</html>